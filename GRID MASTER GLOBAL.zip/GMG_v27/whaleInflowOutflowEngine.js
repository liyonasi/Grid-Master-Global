/**
 * GRID MASTER GLOBAL — WHALE INFLOW OUTFLOW ENGINE v1
 * =====================================================
 * Büyük cüzdan (balina) giriş ve çıkışlarını analiz eder.
 * Borsaya gelen büyük transfer = olası satış
 * Borsadan çıkan büyük transfer = birikim / HODLing
 *
 * KAYNAKLAR:
 *   - Whale Alert API (ücretsiz tier: büyük transferler)
 *   - CoinGecko (büyük holder istatistikleri)
 *   - Zincir explorer (Etherscan/Blockchain.info)
 *
 * MODÜLLER:
 *   1. WhaleTransferDetector — Anlık büyük transferler
 *   2. InflowOutflowBalance  — Net giriş/çıkış dengesi
 *   3. HolderConcentration   — Top 10/100 holder konsantrasyonu
 *   4. AccumulationPhase     — Biriktirme/dağıtım fazı
 *   5. WhaleAlertParser      — Whale Alert mesaj yorumlama
 */

import { clamp } from './engineCore.js';

// ─── SABİTLER ────────────────────────────────────────────────────────────────
const WHALE_THRESHOLD_USD = 1_000_000;   // $1M+ = balina işlemi
const LARGE_WHALE_USD     = 10_000_000;  // $10M+ = büyük balina
const WHALE_ALERT_URL     = 'https://api.whale-alert.io/v1/transactions';

// ─── ÖNBELLEK ─────────────────────────────────────────────────────────────────
const _cache = new Map();
function cacheGet(k, ttl = 60_000) { const e = _cache.get(k); return e && Date.now() - e.ts < ttl ? e.v : null; }
function cacheSet(k, v) { _cache.set(k, { v, ts: Date.now() }); }

// ─── WHALE ALERT API ─────────────────────────────────────────────────────────
/**
 * fetchWhaleTransactions — Son büyük transferleri çek
 *
 * @param {string} apiKey    — Whale Alert API key (ücretsiz: 10req/dk)
 * @param {number} minValue  — Minimum USD değeri
 * @param {string} currency  — 'btc' | 'eth' | 'usdt' vb.
 */
export async function fetchWhaleTransactions({ apiKey = '', minValue = WHALE_THRESHOLD_USD, currency = null } = {}) {
  const cacheKey = `whale_txs_${currency || 'all'}`;
  const cached   = cacheGet(cacheKey, 90_000); // 90sn cache
  if (cached) return cached;

  if (!apiKey) {
    // API key yoksa simüle et (demo mod)
    return _generateDemoTransactions();
  }

  try {
    let url = `${WHALE_ALERT_URL}?api_key=${apiKey}&min_value=${minValue}&limit=20`;
    if (currency) url += `&currency=${currency}`;

    const res  = await fetch(url, { signal: AbortSignal.timeout(6000) });
    const data = await res.json();

    if (data.result !== 'success') return [];

    const txs = (data.transactions || []).map(tx => ({
      id:          tx.id,
      blockchain:  tx.blockchain,
      symbol:      tx.symbol?.toUpperCase(),
      amount:      tx.amount,
      amountUSD:   tx.amount_usd,
      from:        tx.from?.owner_type || 'unknown',
      to:          tx.to?.owner_type   || 'unknown',
      fromLabel:   tx.from?.owner      || null,
      toLabel:     tx.to?.owner        || null,
      timestamp:   tx.timestamp * 1000,
      type:        classifyTransfer(tx.from?.owner_type, tx.to?.owner_type),
    }));

    cacheSet(cacheKey, txs);
    return txs;
  } catch (e) {
    console.error('[WHALE] Fetch hatası:', e.message);
    return [];
  }
}

// ─── TRANSFER TİPİ SINIFLANDIR ────────────────────────────────────────────────
function classifyTransfer(fromType, toType) {
  if (toType === 'exchange')   return 'EXCHANGE_DEPOSIT';  // Borsaya gönderdi → satış riski
  if (fromType === 'exchange') return 'EXCHANGE_WITHDRAW'; // Borsadan çekti → HODLing
  if (fromType === 'unknown' && toType === 'unknown') return 'WALLET_TO_WALLET';
  return 'OTHER';
}

// ─── DEMO VERİSİ ─────────────────────────────────────────────────────────────
function _generateDemoTransactions() {
  const types    = ['EXCHANGE_DEPOSIT', 'EXCHANGE_WITHDRAW', 'WALLET_TO_WALLET'];
  const symbols  = ['BTC', 'ETH', 'USDT'];
  return Array.from({ length: 8 }, (_, i) => ({
    id:         `demo_${i}`,
    symbol:     symbols[i % 3],
    amount:     Math.random() * 500 + 10,
    amountUSD:  Math.random() * 20_000_000 + 1_000_000,
    from:       i % 2 === 0 ? 'exchange' : 'unknown',
    to:         i % 3 === 0 ? 'exchange' : 'unknown',
    type:       types[i % 3],
    timestamp:  Date.now() - i * 600_000,
  }));
}

// ─── INFLOW/OUTFLOW BALANCE ───────────────────────────────────────────────────
/**
 * computeInflowOutflowBalance
 * Transfer listesinden net giriş/çıkış dengesi hesapla.
 *
 * @param {Array} transactions — fetchWhaleTransactions çıktısı
 * @param {string} symbol      — Filtrelenecek sembol (null = tümü)
 */
export function computeInflowOutflowBalance(transactions = [], symbol = null) {
  const filtered = symbol
    ? transactions.filter(tx => tx.symbol === symbol.replace('USDT', '').toUpperCase())
    : transactions;

  let   inflowUSD  = 0; // Borsaya gelen
  let   outflowUSD = 0; // Borsadan giden
  const inflowTxs  = [];
  const outflowTxs = [];

  for (const tx of filtered) {
    if (tx.type === 'EXCHANGE_DEPOSIT') {
      inflowUSD += tx.amountUSD;
      inflowTxs.push(tx);
    } else if (tx.type === 'EXCHANGE_WITHDRAW') {
      outflowUSD += tx.amountUSD;
      outflowTxs.push(tx);
    }
  }

  const netFlow    = outflowUSD - inflowUSD; // Pozitif = net çıkış = bullish
  const netFlowPct = (inflowUSD + outflowUSD) > 0
    ? netFlow / (inflowUSD + outflowUSD) * 100
    : 0;

  // Skor: net çıkış → bullish (yüksek skor), net giriş → bearish (düşük skor)
  let score = 50;
  if (netFlow > 5_000_000)       { score += 25; }
  else if (netFlow > 1_000_000)  { score += 12; }
  else if (netFlow < -5_000_000) { score -= 25; }
  else if (netFlow < -1_000_000) { score -= 12; }

  const direction = netFlow > 500_000 ? 'NET_ÇIKIŞ' :
                    netFlow < -500_000 ? 'NET_GİRİŞ' : 'DENGELİ';

  return {
    score:       clamp(score),
    inflowUSD:   parseFloat(inflowUSD.toFixed(0)),
    outflowUSD:  parseFloat(outflowUSD.toFixed(0)),
    netFlow:     parseFloat(netFlow.toFixed(0)),
    netFlowPct:  parseFloat(netFlowPct.toFixed(1)),
    direction,
    inflowCount:  inflowTxs.length,
    outflowCount: outflowTxs.length,
    bullish:     direction === 'NET_ÇIKIŞ',
    bearish:     direction === 'NET_GİRİŞ',
    summary:     `${direction}: $${Math.abs(netFlow / 1e6).toFixed(2)}M net ${netFlow >= 0 ? 'çıkış' : 'giriş'}`,
  };
}

// ─── HOLDER KONSANTRASYONU ────────────────────────────────────────────────────
/**
 * analyzeHolderConcentration
 * Top holder yoğunluğu:
 *   - Çok yoğunsa → Manipülasyon riski
 *   - Dağılıyorsa → Daha sağlıklı
 *
 * @param {object} holderData
 *   top10Pct    — Top 10 holder'ın toplam supply %
 *   top100Pct   — Top 100 holder'ın toplam supply %
 *   giniCoeff   — Gini katsayısı (0=eşit, 1=çok yoğun)
 */
export function analyzeHolderConcentration({ top10Pct = 30, top100Pct = 60, giniCoeff = 0.6 } = {}) {
  let   riskScore = 0;
  const flags     = [];

  if (top10Pct >= 60)      { riskScore += 30; flags.push(`Top 10 holder: %${top10Pct} — Çok yoğun ⚠️`); }
  else if (top10Pct >= 40) { riskScore += 15; flags.push(`Top 10 holder: %${top10Pct} — Yüksek yoğunluk`); }

  if (giniCoeff >= 0.85)   { riskScore += 20; flags.push(`Gini: ${giniCoeff.toFixed(2)} — Aşırı konsantrasyon`); }
  else if (giniCoeff < 0.5){ riskScore -= 10; flags.push('Dağılmış holder yapısı 🟢'); }

  return {
    riskScore:    clamp(riskScore),
    top10Pct,
    top100Pct,
    giniCoeff,
    concentrated: top10Pct >= 50,
    distributed:  top10Pct < 30,
    flags,
    summary:      flags[0] || `Holder dağılımı: Top10=%${top10Pct}`,
  };
}

// ─── BİRİKTİRME / DAĞITIM FAZI ───────────────────────────────────────────────
/**
 * detectAccumulationPhase
 * Büyük cüzdanların biriktirme mi dağıtım mı yaptığını belirler.
 *
 * @param {object} params
 *   netOutflow7d     — 7 günlük net çıkış (USD)
 *   avgTxSize        — Ortalama işlem büyüklüğü
 *   txCountTrend     — İşlem adedi trendi (pozitif = artıyor)
 *   priceChange7d    — 7g fiyat değişimi %
 */
export function detectAccumulationPhase({ netOutflow7d = 0, avgTxSize = 0, txCountTrend = 0, priceChange7d = 0 }) {
  let   accScore = 50;
  const signals  = [];

  // Yüksek çıkış + fiyat düşüşü → akıllı para satıyor
  if (netOutflow7d < 0 && priceChange7d < 0) {
    accScore -= 20; signals.push('Satış baskısı: Para çıkıyor + fiyat düşüyor');
  }
  // Yüksek çıkış + fiyat yükseliyor → Güçlü birikim
  else if (netOutflow7d > 0 && priceChange7d < 0) {
    accScore += 20; signals.push('Birikim: Para borsa dışına çıkıyor + fiyat düşük 🟢');
  }
  // Çıkış yok ama fiyat yükseliyor → Pahalı alım
  else if (netOutflow7d < 0 && priceChange7d > 0) {
    accScore += 5;
  }

  if (txCountTrend > 20)  { accScore += 10; signals.push('İşlem sayısı artıyor — Aktivite yükseliyor'); }
  if (avgTxSize > 5_000_000) { accScore += 8; signals.push('Büyük ortalama işlem boyutu — Kurumsal hareket'); }

  accScore = clamp(accScore);

  return {
    score:          accScore,
    phase:          accScore >= 65 ? 'BİRİKTİRME' : accScore <= 35 ? 'DAĞITIM' : 'NÖTR',
    accumulating:   accScore >= 60,
    distributing:   accScore <= 40,
    signals,
    summary:        signals[0] || 'Whale aktivitesi: Nötr',
    timestamp:      new Date().toISOString(),
  };
}

// ─── ANA MOTOR ───────────────────────────────────────────────────────────────
/**
 * runWhaleInflowOutflowEngine — Tüm balina modüllerini çalıştır
 *
 * @param {object} params
 *   apiKey       — Whale Alert API key (opsiyonel)
 *   symbol       — Coin sembolü
 *   holderData   — { top10Pct, top100Pct, giniCoeff }
 *   accData      — { netOutflow7d, avgTxSize, txCountTrend, priceChange7d }
 */
export async function runWhaleInflowOutflowEngine({
  apiKey     = '',
  symbol     = 'BTCUSDT',
  holderData = {},
  accData    = {},
} = {}) {

  const transactions = await fetchWhaleTransactions({ apiKey, currency: symbol.replace('USDT', '').toLowerCase() });
  const balance      = computeInflowOutflowBalance(transactions, symbol);
  const concentration = analyzeHolderConcentration(holderData);
  const accumulation  = detectAccumulationPhase(accData);

  // Ağırlıklı skor
  const score = clamp(
    balance.score     * 0.40 +
    accumulation.score * 0.40 +
    (100 - concentration.riskScore) * 0.20
  );

  const allSignals = [
    balance.summary,
    accumulation.signals[0],
    concentration.flags[0],
  ].filter(Boolean);

  const verdict = score >= 65 ? 'BALINA ALIM' : score <= 35 ? 'BALINA SATIM' : 'NÖTR';

  return {
    score:          parseFloat(score.toFixed(1)),
    verdict,
    transactions:   transactions.slice(0, 10),
    balance,
    concentration,
    accumulation,
    recentTxCount:  transactions.length,
    topSignals:     allSignals,
    summary:        `${verdict} (${score.toFixed(0)}/100) — ${allSignals[0] || 'Normal balina aktivitesi'}`,
    timestamp:      new Date().toISOString(),
  };
}
