/**
 * GMG — INTELLIGENCE + COUNCIL ENGINE
 * =====================================
 * intelligenceEngine: 16 tarama modülü → ham sinyal
 * councilEngine: 4 Konsey → tartışma → karar
 *
 * KULLANIM:
 *   import { runAllScanners } from './engineCore';
 *   import { runCouncils } from './engineCore';
 *   const scan = runAllScanners({ coins, btcChange, orderbookMap, klineMap });
 *   const decision = runCouncils(scan);
 */

// ─── MATH HELPERS ─────────────────────────────────────────────────────────────
const clamp = (v, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, v));

function ema(closes, period) {
  if (!closes || closes.length < period) return null;
  const k = 2 / (period + 1);
  let val = closes.slice(0, period).reduce((a, b) => a + b, 0) / period;
  for (let i = period; i < closes.length; i++) val = closes[i] * k + val * (1 - k);
  return val;
}

function rsi(closes, period = 14) {
  if (!closes || closes.length < period + 1) return 50;
  let gains = 0, losses = 0;
  for (let i = 1; i <= period; i++) { const d = closes[i] - closes[i-1]; d > 0 ? gains += d : losses -= d; }
  let ag = gains / period, al = losses / period;
  for (let i = period + 1; i < closes.length; i++) {
    const d = closes[i] - closes[i-1];
    ag = (ag*(period-1) + (d>0?d:0)) / period;
    al = (al*(period-1) + (d<0?-d:0)) / period;
  }
  return al === 0 ? 100 : parseFloat((100 - 100/(1+ag/al)).toFixed(1));
}

function macd(closes) {
  const f = emaArr(closes, 12), s = emaArr(closes, 26);
  const ml = closes.map((_, i) => f[i] != null && s[i] != null ? f[i]-s[i] : null);
  const vl = ml.filter(v => v != null), sg = emaArr(vl, 9);
  const sl = Array(closes.length).fill(null); let si = 0;
  for (let i = 0; i < closes.length; i++) if (ml[i] != null) { sl[i] = sg[si] ?? null; si++; }
  const last = ml[ml.length-1], lastSig = sl[sl.length-1];
  return { histogram: last != null && lastSig != null ? last-lastSig : 0, bullish: last > 0 && last > lastSig };
}

function emaArr(data, period) {
  if (!data || data.length < period) return Array(data?.length || 0).fill(null);
  const k = 2/(period+1), r = Array(data.length).fill(null);
  let s = 0, c = 0;
  for (let i = 0; i < period && i < data.length; i++) if (data[i] != null) { s += data[i]; c++; }
  if (!c) return r; r[period-1] = s/c;
  for (let i = period; i < data.length; i++) r[i] = data[i] != null ? data[i]*k + (r[i-1]??data[i])*(1-k) : null;
  return r;
}

function bollingerPosition(closes, period = 20) {
  if (!closes || closes.length < period) return 0.5;
  const recent = closes.slice(-period), mean = recent.reduce((a,b) => a+b, 0) / period;
  const std = Math.sqrt(recent.reduce((a,b) => a+(b-mean)**2, 0) / period);
  const last = closes[closes.length-1], upper = mean+2*std, lower = mean-2*std;
  return upper !== lower ? Math.max(0, Math.min(1, (last-lower)/(upper-lower))) : 0.5;
}

function volumeZScore(volumes) {
  if (!volumes || volumes.length < 5) return 0;
  const mean = volumes.reduce((a,b) => a+b, 0) / volumes.length;
  const std  = Math.sqrt(volumes.reduce((a,b) => a+(b-mean)**2, 0) / volumes.length);
  return std > 0 ? (volumes[volumes.length-1] - mean) / std : 0;
}

// ─── MODULE REGISTRY ──────────────────────────────────────────────────────────
export const MODULE_REGISTRY = {
  ALPHA_COUNCIL: [
    'RSI_STATE','EMA_TREND','KELTNER_CORE','BOLLINGER_BAND','TREND_CLOUD',
    'REVERSAL_TRIGGER','SUPERTRIGGER','BREAKOUT_FILTER','TREND_ACCELERATION',
    'MEAN_REVERSION','PATTERN_MATRIX','STEALTH_TREND','CHART_FORMATION',
    'HISTORICAL_MATCH','CANDLESTICK_ENGINE','SUPPORT_RESISTANCE',
    'STRUCTURE_DETECT','PULLBACK_ESTIM','MTF_PATTERN','MTF_CONFLUENCE',
    'FINAL_VISUAL_CORE','NEON_UI_RENDER','GRID_MASTER_GLOBAL','NEON_CORE_IFACE',
  ],
  FLOW_COUNCIL: [
    'GLOBAL_LIQ_FETCH','MULTI_EXCHANGE','WEBSOCKET_STREAM','ORDERBOOK_ENGINE',
    'MARKET_STRUCT_ENG','LIQUIDITY_MAP','DELTA_FLOW','CVD_PULSE','BOOK_PRESSURE',
    'BID_ASK_IMBALANCE','OB_WALL_TRACKER','LIQ_VOID_ENGINE','CROSS_EXCHANGE_ARB',
    'VOLUME_SPIKE','MOMENTUM_BIAS','REGIME_DETECTOR','GRID_DRIVERS',
    'WHALE_TRACE','FUNDING_BIAS','OPEN_INTEREST','VOLATILITY_LOCK',
    'CORRELATION_MAP','WHALE_INFLOW','SIGNAL_CONFIDENCE',
  ],
  RISK_COUNCIL: [
    'STOP_HUNT_RADAR','LIQUIDATION_WATCH','FAKE_MOVE_FILTER','LIQ_TRAP_SCANNER',
    'LIQ_SWEEP_DETECT','SPOOFING_DETECTOR','MM_BEHAVIOR','HFT_PULSE',
    'RISK_CLASSIFIER','RISK_HUB','VOL_REGIME','BTC_SHOCK_SENT',
    'PUMP_EARLY_SCAN','DUMP_EARLY_SCAN','MEXC_PUMP_HUNTER','NEW_LISTING_MON',
    'SOCIAL_HYPE_ENG','PROBABILITY_ENG','HIST_PATTERN_CMP','SCALP_ENGINE',
    'TOP200_SCANNER','ACCUMULATION_ENG','GLOBAL_ALERT_ENG','MACRO_FACTORS',
  ],
  MACRO_COUNCIL: [
    'ALT_ROTATION','BTC_REL_POWER','SECTOR_STRENGTH','BTC_DOMINANCE',
    'STABLE_DOM','ALT_SEASON_ENG','CRYPTO_SECTOR','ONCHAIN_ANALYSIS',
    'STABLE_FLOW_ENG','TOKEN_DIST_ANLYZ','SIGNAL_FUSION','AI_DECISION_LAYER',
    'TECHNICAL_COUNCIL','FLOW_COUNCIL_MOD','NEWS_COUNCIL','RISK_COUNCIL_MOD',
    'ASSET_SPEC_CNCL','FINAL_COUNCIL_OUT','MARKET_STATE','COUNCIL_OUTPUT',
    'NEWS_INTEL_ENG','FEAR_GREED','MULTI_ASSET_ENG',
  ],
};

// ─── 16 SCANNER MODULES ───────────────────────────────────────────────────────

export function scalpTrapScanner(coins) {
  return coins.filter(c => {
    const overExt = c.rsi ? (c.rsi > 72 || c.rsi < 28) : false;
    const rapidMove = Math.abs(c.change_24h || 0) > 3;
    return overExt || rapidMove;
  }).map(c => ({ symbol: c.symbol?.replace('/USDT','') || c.name, change: c.change_24h, rsi: c.rsi||50, reason: c.rsi>72?'Aşırı alım':c.rsi<28?'Aşırı satım':'Hızlı hareket' })).slice(0, 10);
}

export function scalpLongScanner(coins, btcChange = 0) {
  return coins.filter(c => { const rsiOk = !c.rsi||(c.rsi>45&&c.rsi<65); return rsiOk&&c.change_24h>0.5&&c.change_24h<8&&btcChange>-1; })
    .sort((a,b) => b.change_24h-a.change_24h).slice(0,8)
    .map(c => ({ symbol:c.symbol?.replace('/USDT','')||c.name, change:c.change_24h, rsi:c.rsi||50, entry:c.price, tp:c.price?(c.price*1.015).toFixed(6):null, sl:c.price?(c.price*0.99).toFixed(6):null }));
}

export function scalpShortScanner(coins, btcChange = 0) {
  return coins.filter(c => { const rsiOk = !c.rsi||(c.rsi>55&&c.rsi<75); return rsiOk&&c.change_24h<-0.5&&c.change_24h>-8&&btcChange<1; })
    .sort((a,b) => a.change_24h-b.change_24h).slice(0,8)
    .map(c => ({ symbol:c.symbol?.replace('/USDT','')||c.name, change:c.change_24h, rsi:c.rsi||50 }));
}

export function longReadyScanner(coins) {
  return coins.filter(c => { const rsiOk=c.rsi?(c.rsi>=35&&c.rsi<=55):true; const bbOk=c.bbPosition?(c.bbPosition<0.4):false; const volOk=c.volumeZScore?(c.volumeZScore>0.5):false; return rsiOk&&c.change_24h>=-3&&c.change_24h<=2&&(bbOk||volOk); })
    .sort((a,b) => (b.volumeZScore||0)-(a.volumeZScore||0)).slice(0,10)
    .map(c => ({ symbol:c.symbol?.replace('/USDT','')||c.name, change:c.change_24h, rsi:c.rsi||50, readyScore:clamp(Math.round(60+(c.rsi?50-Math.abs(c.rsi-42):0)+(c.bbPosition?(0.4-c.bbPosition)*50:0))) }));
}

export function shortReadyScanner(coins) {
  return coins.filter(c => (c.rsi&&c.rsi>=65&&c.rsi<=78)||(c.bbPosition&&c.bbPosition>0.75&&c.change_24h>=4))
    .sort((a,b) => (b.rsi||50)-(a.rsi||50)).slice(0,10)
    .map(c => ({ symbol:c.symbol?.replace('/USDT','')||c.name, change:c.change_24h, rsi:c.rsi||50 }));
}

export function explosionReadyScanner(coins) {
  return coins.filter(c => Math.abs(c.change_24h)<2&&(c.bbPosition?c.bbPosition>0.35&&c.bbPosition<0.65:false)&&(c.rsi?c.rsi>45&&c.rsi<60:true))
    .sort((a,b) => (b.volumeZScore||0)-(a.volumeZScore||0)).slice(0,8)
    .map(c => ({ symbol:c.symbol?.replace('/USDT','')||c.name, change:c.change_24h, explosionScore:clamp(Math.round(50+(c.volumeZScore||0)*15)) }));
}

export function suddenDumpScanner(coins) {
  return coins.filter(c => c.change_24h<=-4).sort((a,b) => a.change_24h-b.change_24h).slice(0,12)
    .map(c => ({ symbol:c.symbol?.replace('/USDT','')||c.name, change:c.change_24h, severity:c.change_24h<=-10?'KRİTİK':c.change_24h<=-7?'YÜKSEK':'ORTA' }));
}

export function suddenPumpScanner(coins) {
  return coins.filter(c => c.change_24h>=5).sort((a,b) => b.change_24h-a.change_24h).slice(0,12)
    .map(c => ({ symbol:c.symbol?.replace('/USDT','')||c.name, change:c.change_24h, severity:c.change_24h>=20?'FOMO':c.change_24h>=10?'GÜÇLÜ':'NORMAL' }));
}

export function stealthRisingScanner(coins) {
  return coins.filter(c => c.change_24h>0.3&&c.change_24h<4&&(!c.volumeZScore||c.volumeZScore<1.5)&&(!c.rsi||(c.rsi>45&&c.rsi<65)))
    .sort((a,b) => b.change_24h-a.change_24h).slice(0,10)
    .map(c => ({ symbol:c.symbol?.replace('/USDT','')||c.name, change:c.change_24h }));
}

export function stealthFallingScanner(coins) {
  return coins.filter(c => c.change_24h<-0.3&&c.change_24h>-4&&(!c.volumeZScore||c.volumeZScore<1.5))
    .sort((a,b) => a.change_24h-b.change_24h).slice(0,10)
    .map(c => ({ symbol:c.symbol?.replace('/USDT','')||c.name, change:c.change_24h }));
}

export function stopHuntScanner(coins, klineMap = {}) {
  return coins.map(c => {
    const klines = klineMap[c.symbol] || []; if (klines.length < 5) return null;
    const prices = klines.map(k => k.price||k.c), highs = klines.map(k => k.high||k.h||k.price||k.c), lows = klines.map(k => k.low||k.l||k.price||k.c);
    const recentHigh = Math.max(...highs.slice(-5)), recentLow = Math.min(...lows.slice(-5));
    const current = prices[prices.length-1], range = recentHigh-recentLow;
    const spikedAbove = recentHigh > Math.max(...prices.slice(-6,-1))*1.005;
    const spikedBelow = recentLow  < Math.min(...prices.slice(-6,-1))*0.995;
    const reversed = (spikedAbove&&current<recentHigh-range*0.3)||(spikedBelow&&current>recentLow+range*0.3);
    if (!reversed) return null;
    return { symbol:c.symbol?.replace('/USDT','')||c.name, change:c.change_24h, direction:spikedAbove?'YUKARI SWEEP':'AŞAĞI SWEEP', riskLevel:'YÜKSEK' };
  }).filter(Boolean).slice(0,8);
}

export function btcRelativeStrong(coins, btcChange = 0) {
  return coins.filter(c => (c.change_24h||0)-btcChange > 1.5 && c.change_24h > 0)
    .sort((a,b) => ((b.change_24h-btcChange)-(a.change_24h-btcChange))).slice(0,15)
    .map(c => ({ symbol:c.symbol?.replace('/USDT','')||c.name, change:c.change_24h, relStrength:parseFloat((c.change_24h-btcChange).toFixed(2)) }));
}

export function btcRelativeWeak(coins, btcChange = 0) {
  return coins.filter(c => (c.change_24h||0)-btcChange < -1.5)
    .sort((a,b) => ((a.change_24h-btcChange)-(b.change_24h-btcChange))).slice(0,15)
    .map(c => ({ symbol:c.symbol?.replace('/USDT','')||c.name, change:c.change_24h, relStrength:parseFloat((c.change_24h-btcChange).toFixed(2)) }));
}

export function liquiditySensitivityScanner(coins, orderbookMap = {}) {
  return coins.filter(c => orderbookMap[c.symbol]).map(c => {
    const ob = orderbookMap[c.symbol];
    const bidVol = ob.bids.slice(0,10).reduce((s,b) => s+b.amount*b.price, 0);
    const askVol = ob.asks.slice(0,10).reduce((s,a) => s+a.amount*a.price, 0);
    const imbalance = bidVol/(bidVol+askVol+0.001);
    return { symbol:c.symbol?.replace('/USDT','')||c.name, change:c.change_24h, imbalance:parseFloat(imbalance.toFixed(3)), bias:imbalance>0.6?'ALIŞ':imbalance<0.4?'SATIŞ':'NÖTR', riskLevel:Math.abs(imbalance-0.5)>0.4?'YÜKSEK':Math.abs(imbalance-0.5)>0.2?'ORTA':'DÜŞÜK' };
  }).sort((a,b) => Math.abs(b.imbalance-0.5)-Math.abs(a.imbalance-0.5)).slice(0,10);
}

export function multiExchangePumpDump(coins, mexcCoins = []) {
  const all = [...coins, ...mexcCoins.map(c => ({ ...c, exchange:'MEXC' }))];
  return {
    pumps: all.filter(c => (c.change_24h||0)>=8).sort((a,b) => b.change_24h-a.change_24h).slice(0,12).map(c => ({ symbol:c.symbol?.replace('/USDT','')||c.name, change:c.change_24h, exchange:c.exchange||'BNC' })),
    dumps: all.filter(c => (c.change_24h||0)<=-6).sort((a,b) => a.change_24h-b.change_24h).slice(0,12).map(c => ({ symbol:c.symbol?.replace('/USDT','')||c.name, change:c.change_24h, exchange:c.exchange||'BNC' })),
  };
}

// ─── MASTER SCANNER ───────────────────────────────────────────────────────────
export function runAllScanners({ coins = [], btcChange = 0, orderbookMap = {}, klineMap = {}, mexcCoins = [] }) {
  const enriched = coins.map(c => {
    const klines = klineMap[c.symbol] || [];
    const closes = klines.map(k => k.price||k.c||0);
    const volumes = klines.map(k => k.volume||k.v||0);
    return {
      ...c,
      rsi:          closes.length>15 ? rsi(closes) : null,
      bbPosition:   closes.length>=20 ? bollingerPosition(closes) : null,
      volumeZScore: volumes.length>5  ? volumeZScore(volumes) : null,
    };
  });

  return {
    scalpTraps:     scalpTrapScanner(enriched),
    scalpLongs:     scalpLongScanner(enriched, btcChange),
    scalpShorts:    scalpShortScanner(enriched, btcChange),
    longReady:      longReadyScanner(enriched),
    shortReady:     shortReadyScanner(enriched),
    explosionReady: explosionReadyScanner(enriched),
    suddenDumps:    suddenDumpScanner(enriched),
    suddenPumps:    suddenPumpScanner(enriched),
    stealthRising:  stealthRisingScanner(enriched),
    stealthFalling: stealthFallingScanner(enriched),
    stopHunts:      stopHuntScanner(enriched, klineMap),
    btcStrong:      btcRelativeStrong(enriched, btcChange),
    btcWeak:        btcRelativeWeak(enriched, btcChange),
    liquiditySens:  liquiditySensitivityScanner(enriched, orderbookMap),
    multiExchange:  multiExchangePumpDump(enriched, mexcCoins),
    enrichedCoins:  enriched,
    btcChange,
    timestamp: Date.now(),
  };
}

// ─── 4 COUNCILS ───────────────────────────────────────────────────────────────
function wAvg(sigs) {
  const tw = sigs.reduce((s,g) => s+g.w, 0);
  return tw > 0 ? clamp(Math.round(sigs.reduce((s,g) => s+g.score*g.w, 0)/tw)) : 50;
}

function toAction(score) {
  return score>=72?{act:'GÜÇLÜ AL',color:'#00e676',short:'AL'}: score>=58?{act:'AL',color:'#00cc66',short:'AL'}: score>=48?{act:'BEKLE',color:'#ffd600',short:'BEKLE'}: score>=35?{act:'SAT',color:'#ff6633',short:'SAT'}:{act:'GÜÇLÜ SAT',color:'#ff1744',short:'SAT'};
}

export function runAlphaCouncil(scan) {
  const { enrichedCoins, btcStrong, btcWeak } = scan;
  const posR = enrichedCoins.filter(c => (c.change_24h||0)>0).length / (enrichedCoins.length||1);
  const avgRSI = enrichedCoins.filter(c => c.rsi).reduce((s,c) => s+c.rsi, 0) / (enrichedCoins.filter(c=>c.rsi).length||1);
  const sigs = [
    { label:'Piyasa genişliği', score:clamp(posR*100), w:0.25 },
    { label:'RSI ortalaması',   score:avgRSI<30?80:avgRSI<45?65:avgRSI>70?25:50, w:0.20 },
    { label:'BTC relatif güç', score:clamp(50+(btcStrong.length-btcWeak.length)*4), w:0.25 },
    { label:'Trend sinyal',    score:clamp(50+scan.btcChange*4), w:0.30 },
  ];
  const score = wAvg(sigs);
  const { act, color, short } = toAction(score);
  return { id:'ALPHA', name:'Alpha Council', icon:'◈', score, act, color, short, signals:sigs, modules:MODULE_REGISTRY.ALPHA_COUNCIL };
}

export function runFlowCouncil(scan) {
  const { liquiditySens, suddenPumps, suddenDumps, multiExchange, btcChange } = scan;
  const buyBias = liquiditySens.filter(l => l.bias==='ALIŞ').length;
  const sellBias = liquiditySens.filter(l => l.bias==='SATIŞ').length;
  const total = liquiditySens.length || 1;
  const sigs = [
    { label:'Orderbook akışı',   score:clamp((buyBias/total)*100), w:0.30 },
    { label:'Pump/Dump dengesi', score:clamp(50+(suddenPumps.length-suddenDumps.length)*8), w:0.25 },
    { label:'Multi-borsa akışı', score:clamp(50+((multiExchange?.pumps?.length||0)-(multiExchange?.dumps?.length||0))*6), w:0.25 },
    { label:'BTC yönü',          score:clamp(50+btcChange*4), w:0.20 },
  ];
  const score = wAvg(sigs);
  const { act, color, short } = toAction(score);
  return { id:'FLOW', name:'Flow Council', icon:'⟁', score, act, color, short, signals:sigs, modules:MODULE_REGISTRY.FLOW_COUNCIL };
}

export function runRiskCouncil(scan) {
  const { scalpTraps, stopHunts, suddenDumps } = scan;
  const critDumps = suddenDumps.filter(d => d.change<=-10).length;
  const sigs = [
    { label:'Scalp tuzak',   score:clamp(100-scalpTraps.length*12), w:0.25 },
    { label:'Stop hunt',     score:clamp(100-stopHunts.length*18),  w:0.30 },
    { label:'Kritik dump',   score:clamp(100-critDumps*22),         w:0.25 },
    { label:'Genel volatil', score:clamp(100-suddenDumps.length*5), w:0.20 },
  ];
  const score = wAvg(sigs);
  const rl = score>=70?'DÜŞÜK':score>=50?'ORTA':score>=30?'YÜKSEK':'KRİTİK';
  const rcolor = score>=70?'#00e676':score>=50?'#ffd600':score>=30?'#ff6d00':'#ff1744';
  const { act, short } = toAction(score);
  return { id:'RISK', name:'Risk Council', icon:'⬡', score, act, color:rcolor, short, riskLevel:rl, signals:sigs, modules:MODULE_REGISTRY.RISK_COUNCIL };
}

export function runMacroCouncil(scan) {
  const { enrichedCoins, btcChange } = scan;
  const total = enrichedCoins.length || 1;
  const posR = enrichedCoins.filter(c => (c.change_24h||0)>0).length / total;
  const altAvg = enrichedCoins.slice(1, 51).reduce((s,c) => s+(c.change_24h||0), 0) / 50;
  const altRelBTC = altAvg - btcChange;
  const sigs = [
    { label:'Alt sezon',      score:clamp(50+altRelBTC*5), w:0.28 },
    { label:'Sektör gücü',    score:clamp(posR*100),        w:0.28 },
    { label:'BTC dominans',   score:btcChange>2?65:btcChange>0?55:btcChange>-2?45:30, w:0.22 },
    { label:'Para rotasyonu', score:clamp(50+btcChange*3+altRelBTC*2), w:0.22 },
  ];
  const score = wAvg(sigs);
  const { act, color, short } = toAction(score);
  return { id:'MACRO', name:'Macro Council', icon:'⎈', score, act, color, short, signals:sigs, altSeasonIndex:Math.round(50+altRelBTC*5), modules:MODULE_REGISTRY.MACRO_COUNCIL };
}

// ─── FINAL COUNCIL ────────────────────────────────────────────────────────────
export function runFinalCouncil(councils) {
  const { alpha, flow, risk, macro } = councils;
  const finalScore = Math.round(alpha.score*0.28 + flow.score*0.27 + risk.score*0.22 + macro.score*0.23);
  const { act, color } = toAction(finalScore);
  const bullish = [alpha,flow,macro].filter(c => c.score>=55).length;
  const bearish = [alpha,flow,macro].filter(c => c.score<=45).length;
  const confidence = clamp(Math.round(30+Math.max(bullish,bearish)*18+Math.abs(finalScore-50)*0.6));
  const marketBias = finalScore>=65?'GÜÇLÜ BULLISH':finalScore>=55?'BULLISH':finalScore<=35?'BEARISH':finalScore<=45?'ZAYIF BEARISH':'NÖTR';
  const biasColor = finalScore>=55?'#00e676':finalScore<=45?'#ff1744':'#ffd600';
  const consensusStrength = Math.max(bullish,bearish)===3?'TAM':Math.max(bullish,bearish)===2?'ÇOĞUNLUK':'BÖLÜNMÜŞ';
  return {
    finalScore, act, color, confidence, marketBias, biasColor,
    riskLevel: risk.riskLevel || 'ORTA',
    riskColor:  risk.color || '#ffd600',
    consensusStrength,
    votes: { bullish, bearish, neutral: 3-bullish-bearish },
    summary: [
      `${bullish}/3 konseyden AL oyu`,
      `Risk: ${risk.riskLevel} | Güven: ${confidence}%`,
      `Consensus: ${consensusStrength}`,
      `Piyasa: ${marketBias}`,
    ],
    timestamp: Date.now(),
  };
}

// ─── MASTER RUNNER ────────────────────────────────────────────────────────────
export function runCouncils(scan) {
  const alpha  = runAlphaCouncil(scan);
  const flow   = runFlowCouncil(scan);
  const risk   = runRiskCouncil(scan);
  const macro  = runMacroCouncil(scan);
  const final  = runFinalCouncil({ alpha, flow, risk, macro });
  return { alpha, flow, risk, macro, final };
}
