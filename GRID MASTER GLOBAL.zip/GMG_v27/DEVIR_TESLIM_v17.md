# GMG — DEVİR TESLİM v17
## Tarih: 2026-03-17 | ~185/235 modül (%79)

## YENİ OTURUMDA BAŞLARKEN
ZIP yükle → yaz: "DEVIR_TESLIM_v17.md oku, kaldığın yerden devam et"

---

## BU OTURUMDA YAPILAN DEĞİŞİKLİKLER

### masterCouncil.js — TAM YENİDEN YAZILDI
9 advanced motor eklendi:
- infraEngine (initInfra, LoggingEngine, DataSanityCheck)
- technicalAdvancedEngine (trendExhaustion, candleAnatomy, wickManip, fractalStruct, trendAccel)
- derivativesAdvancedEngine (leverageBuildup, fundingExtreme, cascadeRisk, derivTrap)
- newsAdvancedEngine (newsIntelligence, eventClassifier, panicNews)
- bondMacroAdvancedEngine (globalRiskAppetite, geopoliticalRisk, globalMoneyFlow)
- intelligenceAdvancedEngine (whaleTrace, smartMoney, strengthRank, cryptoContagion)
- councilAdvancedEngine (6. konsey: crypto/forex/commodity/index specialist)
- structureEngines (marketStruct)
- indexEngine

Yeni dönen alanlar: advanced{}, health{}, probability, specialist council

### executionLayer.js
trapScore + wickManipulation + panicNews → erken veto eklendi

### Dashboard_v4.jsx
- riskMode state (AGRESIF/NORMAL/MUHAFAZAKAR)
- RiskModeSelector import + toggle UI header'da
- scalpEngine + accumulationEngine çağrıları
- trapScore çağrısı

### LiveAICouncilPanel.jsx
- 6. konsey (Specialist Council) satırı eklendi
- Advanced uyarılar paneli (trendExhaustion, wickManip, derivTrap, panicNews...)

### YENİ DOSYALAR
- specialistEngines.js (8 modül: forexSpecial, commoditySpecial, listing, safeHaven, socialSentiment, onchain, etfFlow, panicDetector)
- jsonOutputEngine.js (JSONOutputEngine class, tüm JSON çıktıları üretiyor)
- docs/system_audit.md
- docs/acceptance_checklist.md

---

## SONRAKI OTURUMDA YAPILACAKLAR (ÖNCELİK SIRASI)

### 1. jsonOutputEngine → Dashboard (30 dakika)
```javascript
// Dashboard_v4.jsx runIntelligenceScan içine ekle:
import { jsonOutputEngine } from './jsonOutputEngine';

// master result sonrası:
const outputs = jsonOutputEngine.generateAll(master, results, {
  scalpResult: scalp,
  accuResult:  accu,
  alerts:      alerts,
});
// outputs kullanılabilir artık
```

### 2. specialistEngines → councilAdvancedEngine (20 dakika)
```javascript
// councilAdvancedEngine.js içinde:
import { runForexSpecialEngine, runCommoditySpecialEngine } from './specialistEngines';

// runForexSpecialistCouncil içinde:
const forexSpecial = runForexSpecialEngine({ utcHour: new Date().getUTCHours() });
score = (score + forexSpecial.score) / 2;
```

### 3. infraEngine null-safe (10 dakika)
```javascript
// masterCouncil.js içinde:
const infra = (() => { try { return initInfra(); } catch { return { status:'OK' }; } })();
const log   = { log: (...args) => { try { LoggingEngine.log(...args); } catch {} } };
```

### 4. TrapScore Widget (45 dakika)
- GMGChart_v3.jsx'e veya Dashboard header'a TrapScore göstergesi ekle
- 0-100 skor → renk: yeşil(0-40), sarı(41-70), kırmızı(71-100)
- Tıklanınca trapDetectionEngine detayları açılır

### 5. CouncilMemory Panel (30 dakika)
- CouncilMemoryEngine.getHistory() → son 20 karar
- Win/loss oranı göstergesi
- LiveAICouncilPanel'in altına ekle

### 6. onchainEngine + etfFlowEngine → MarketIntelPanel
- MarketIntelPanel'e yeni sekme: "ZİNCİR" veya "ETF"
- runOnchainEngine() + runETFFlowEngine() çağır

### 7. socialSentimentEngine → canlı bağlantı
- CryptoPanic API ücretsiz kullanılabilir
- fetchNewsIntelligence() içindeki veriyi socialSentiment'e de aktar

---

## DOSYA REFERANSI (45 JS/JSX)

masterCouncil.js — ANA ORKESTRATÖR (tüm motorlar bağlı)
  runMasterCouncil(candles, I, scanResults, orderbook, heatmapData, fundingRates, btcChange, vixLevel, ...)
  → { action, label, score, confidence, councils, advanced, multiAsset, health, probability, chartOverlay, summary }

pineEngine.js — Pine Script v6 tam port
  runPineEngine(candles, params) → { rf, sr, pb, signals, council, tpsl, filtLine, srZones, barColors }

executionLayer.js — Güvenlik filtresi (trapScore veto eklendi)
  runExecutionLayer({councilScores, finalScore, trapScore, wickManipulation, panicNews, ...})

specialistEngines.js — 8 yeni modül
  runForexSpecialEngine, runCommoditySpecialEngine, runListingMonitorEngine,
  runSafeHavenFlowEngine, runSocialSentimentEngine, runOnchainEngine,
  runETFFlowEngine, runPanicDetectorEngine

jsonOutputEngine.js — JSON çıktı jeneratörü
  jsonOutputEngine.generateAll(masterResult, scanResults, extraData)
  jsonOutputEngine.get('ai_decision_output')
  Üretilen JSON'lar: ai_decision, council, live_bridge, scalp, accumulation,
                     funding, top200, liquidity_trap, alert, health, multi_asset

---

## TEKNİK NOTLAR

### masterCouncil parametreleri (v17):
```javascript
await runMasterCouncil({
  candles,           // OHLCV array
  I,                 // { rsi, macd, bb, ema, adx, mfi }
  scanResults,       // intelligenceEngine çıktısı
  orderbook,         // { bids, asks }
  heatmapData,       // coin array
  fundingRates,      // [{ ex, rate }]
  btcChange,
  vixLevel,
  globalLiqData,
  dxyLevel,          // YENİ: varsayılan 104
  us10yYield,        // YENİ: varsayılan 4.5
  goldChange,        // YENİ: varsayılan 0
  oilChange,         // YENİ: varsayılan 0
  pineParams,
  macroOverrides,
})
```

### councilAdvancedEngine.CouncilMemoryEngine:
```javascript
CouncilMemoryEngine.record({ score, action, timestamp })
CouncilMemoryEngine.getHistory()  // son 50 karar
CouncilMemoryEngine.getWinRate()  // 0-1 arası win rate
```

### RiskModeSelector:
```javascript
RiskModeSelector.getParams('NORMAL')
// → { minScore:60, maxRisk:'ORTA', stopHuntFilter:true, ... }
RiskModeSelector.getParams('AGRESIF')
// → { minScore:50, maxRisk:'YÜKSEK', stopHuntFilter:false, ... }
RiskModeSelector.getParams('MUHAFAZAKAR')
// → { minScore:72, maxRisk:'DÜŞÜK', stopHuntFilter:true, doubleConfirm:true }
```

Son güncelleme: 2026-03-17 | v17
