/**
 * GRID MASTER GLOBAL — STOCK & BOND INTELLIGENCE ENGINE v1
 * ==========================================================
 * STOCK INTELLIGENCE MODULE — Hisse senedi piyasası analizi
 * BOND INTELLIGENCE MODULE  — Tahvil piyasası analizi
 *
 * Her iki modül kripto piyasasıyla korelasyon skoru üretir.
 *
 * VERİ KAYNAĞI:
 *   - Stooq.com (ücretsiz hisse + tahvil verileri)
 *   - FRED API (ABD Hazine tahvilleri)
 *   - Yahoo Finance fallback
 */

import { clamp } from './engineCore.js';

// ─── ÖNBELLEK ─────────────────────────────────────────────────────────────────
const _cache = new Map();
const CACHE_TTL = 10 * 60 * 1000;
function cacheGet(k) { const e = _cache.get(k); return e && Date.now() - e.ts < CACHE_TTL ? e.v : null; }
function cacheSet(k, v) { _cache.set(k, { v, ts: Date.now() }); }

// ─── STOOQ FETCH ──────────────────────────────────────────────────────────────
async function fetchStooq(stooqSymbol, id) {
  const cached = cacheGet(id);
  if (cached) return cached;

  try {
    const url  = `https://stooq.com/q/l/?s=${stooqSymbol}&f=sd2t2ohlcv&h&e=csv`;
    const res  = await fetch(url, { signal: AbortSignal.timeout(6000) });
    const csv  = await res.text();
    const lines = csv.split('\n');
    if (lines.length < 2) return null;

    const headers = lines[0].split(',');
    const values  = lines[1].split(',');
    const row     = {};
    headers.forEach((h, i) => { row[h.trim()] = values[i]?.trim(); });

    const close     = parseFloat(row['Close']);
    const open      = parseFloat(row['Open']);
    const high      = parseFloat(row['High']);
    const low       = parseFloat(row['Low']);
    const vol       = parseFloat(row['Volume']) || 0;

    if (isNaN(close)) return null;

    const change24h = open ? parseFloat(((close - open) / open * 100).toFixed(3)) : 0;
    const result    = { id, close, open, high, low, volume: vol, change24h };
    cacheSet(id, result);
    return result;
  } catch (e) {
    console.error(`[STOCK/BOND] Stooq hatası (${id}):`, e.message);
    return null;
  }
}

// ════════════════════════════════════════════════════════════════════════════════
// 1. STOCK INTELLIGENCE MODULE
// ════════════════════════════════════════════════════════════════════════════════

// Takip edilen hisseler
export const STOCK_LIST = [
  { id: 'AAPL',  name: 'Apple',      stooq: 'aapl.us',  cryptoCorr:  0.45, sector: 'tech'    },
  { id: 'MSFT',  name: 'Microsoft',  stooq: 'msft.us',  cryptoCorr:  0.50, sector: 'tech'    },
  { id: 'GOOGL', name: 'Alphabet',   stooq: 'googl.us', cryptoCorr:  0.45, sector: 'tech'    },
  { id: 'TSLA',  name: 'Tesla',      stooq: 'tsla.us',  cryptoCorr:  0.60, sector: 'tech'    },
  { id: 'NVDA',  name: 'Nvidia',     stooq: 'nvda.us',  cryptoCorr:  0.65, sector: 'tech'    },
  { id: 'COIN',  name: 'Coinbase',   stooq: 'coin.us',  cryptoCorr:  0.80, sector: 'crypto'  }, // En yüksek korelasyon
  { id: 'MSTR',  name: 'MicroStrategy', stooq: 'mstr.us', cryptoCorr: 0.85, sector: 'crypto' },
  { id: 'JPM',   name: 'JP Morgan',  stooq: 'jpm.us',   cryptoCorr:  0.30, sector: 'finance' },
];

/**
 * fetchStockData — Hisse verilerini çek
 */
export async function fetchStockData(stockIds = null) {
  const list = stockIds
    ? STOCK_LIST.filter(s => stockIds.includes(s.id))
    : STOCK_LIST;

  const results = await Promise.allSettled(
    list.map(stock => fetchStooq(stock.stooq, stock.id).then(d => ({ ...stock, data: d })))
  );

  return results
    .filter(r => r.status === 'fulfilled' && r.value?.data)
    .map(r => r.value);
}

/**
 * computeStockCryptoCorrelation — Hisse hareketlerinden kripto skoru üret
 */
export function computeStockCryptoCorrelation(stocks = []) {
  if (!stocks.length) return { score: 50, summary: 'Hisse verisi yok' };

  let weightedScore = 0;
  let totalWeight   = 0;
  const details     = [];

  for (const stock of stocks) {
    const { id, name, cryptoCorr, data } = stock;
    if (!data) continue;

    const impact = cryptoCorr * data.change24h;
    const weight = Math.abs(cryptoCorr);

    weightedScore += impact * weight;
    totalWeight   += weight;

    details.push({ id, name, price: data.close, change24h: data.change24h, cryptoCorr, impact: parseFloat(impact.toFixed(3)) });
  }

  const rawScore = totalWeight ? weightedScore / totalWeight : 0;
  const score    = clamp(50 + rawScore * 4);

  // MSTR ve COIN özel ağırlık — kripto hisseleri daha önemli
  const coinStock = stocks.find(s => s.id === 'COIN');
  const mstrStock = stocks.find(s => s.id === 'MSTR');
  let   cryptoStockSignal = null;

  if (coinStock?.data && mstrStock?.data) {
    const avgCryptoStock = (coinStock.data.change24h + mstrStock.data.change24h) / 2;
    cryptoStockSignal = avgCryptoStock >= 3  ? '🟢 Kripto hisseleri yükseliyor — Piyasa pozitif'  :
                        avgCryptoStock <= -3 ? '🔴 Kripto hisseleri düşüyor — Piyasa negatif'     : null;
  }

  // Nasdaq ile korelasyon
  const ndxLike = stocks.filter(s => s.sector === 'tech');
  const avgTech = ndxLike.length ? ndxLike.reduce((a, s) => a + (s.data?.change24h || 0), 0) / ndxLike.length : 0;

  return {
    score:            parseFloat(score.toFixed(1)),
    details,
    cryptoStockSignal,
    avgTechChange:    parseFloat(avgTech.toFixed(3)),
    verdict:          score >= 60 ? 'HİSSE DOSTU' : score <= 40 ? 'HİSSE RİSKLİ' : 'NÖTR',
    summary:          cryptoStockSignal || `Hisse piyasası ${score >= 55 ? 'destekleyici' : 'nötr'}`,
    timestamp:        new Date().toISOString(),
  };
}

/**
 * runStockIntelligenceEngine — Hisse zekası motoru
 */
export async function runStockIntelligenceEngine(stockIds = null) {
  try {
    const stocks = await fetchStockData(stockIds);
    const result = computeStockCryptoCorrelation(stocks);
    return { ...result, stockCount: stocks.length, stocks };
  } catch (e) {
    console.error('[STOCK] Hata:', e.message);
    return { score: 50, summary: 'Hisse verisi alınamadı', error: e.message, timestamp: new Date().toISOString() };
  }
}

// ════════════════════════════════════════════════════════════════════════════════
// 2. BOND INTELLIGENCE MODULE
// ════════════════════════════════════════════════════════════════════════════════

// Takip edilen tahviller
export const BOND_LIST = [
  { id: 'US2Y',   name: 'ABD 2Y Tahvil',  stooq: 'ust02y.b',  type: 'treasury', cryptoCorr: -0.55 },
  { id: 'US10Y',  name: 'ABD 10Y Tahvil', stooq: 'ust10y.b',  type: 'treasury', cryptoCorr: -0.60 }, // En kritik
  { id: 'US30Y',  name: 'ABD 30Y Tahvil', stooq: 'ust30y.b',  type: 'treasury', cryptoCorr: -0.50 },
  { id: 'DE10Y',  name: 'Almanya 10Y',    stooq: 'ger10y.b',  type: 'bund',     cryptoCorr: -0.35 },
  { id: 'JP10Y',  name: 'Japonya 10Y',    stooq: 'jgb10y.b',  type: 'jgb',      cryptoCorr: -0.25 },
];

/**
 * fetchBondData — Tahvil getiri verilerini çek
 */
export async function fetchBondData() {
  const results = await Promise.allSettled(
    BOND_LIST.map(bond => fetchStooq(bond.stooq, bond.id).then(d => ({ ...bond, data: d })))
  );

  return results
    .filter(r => r.status === 'fulfilled' && r.value?.data)
    .map(r => r.value);
}

/**
 * analyzeBondYields — Tahvil getirilerini analiz et
 * Yükselen getiri = parasal sıkışma = kripto baskı altında
 */
export function analyzeBondYields(bonds = []) {
  if (!bonds.length) return { score: 50, summary: 'Tahvil verisi yok' };

  const us10y = bonds.find(b => b.id === 'US10Y');
  const us2y  = bonds.find(b => b.id === 'US2Y');

  let   score   = 50;
  const signals = [];

  // 10Y getirisi artıyor → hisse + kripto riski
  if (us10y?.data) {
    const yieldChange = us10y.data.change24h;
    if (yieldChange >= 0.05)      { score -= 20; signals.push(`10Y +${yieldChange.toFixed(3)}% — Getiri yükseliyor, risk varlıkları baskı altında`); }
    else if (yieldChange >= 0.02) { score -= 10; signals.push(`10Y hafif yükseliyor`); }
    else if (yieldChange <= -0.05){ score += 20; signals.push(`10Y ${yieldChange.toFixed(3)}% — Getiri düşüyor, kripto desteklenebilir 🟢`); }
    else if (yieldChange <= -0.02){ score += 10; }

    // Mutlak seviye
    if (us10y.data.close >= 5.0)  { score -= 10; signals.push(`10Y %${us10y.data.close.toFixed(2)} — Yüksek seviye, para pahallı`); }
    else if (us10y.data.close <= 3.5) { score += 8; }
  }

  // Yield eğrisi (2Y-10Y spread)
  let   yieldCurve = null;
  if (us10y?.data && us2y?.data) {
    const spread = us10y.data.close - us2y.data.close;
    yieldCurve   = { spread: parseFloat(spread.toFixed(3)), inverted: spread < 0 };

    if (spread < -0.5) { score -= 15; signals.push(`Ters yield eğrisi (${spread.toFixed(2)}) — Resesyon riski`); }
    else if (spread < 0) { score -= 7; signals.push(`Hafif ters eğri — Dikkatli ol`); }
    else if (spread > 1) { score += 8; signals.push(`Normal yield eğrisi (${spread.toFixed(2)}) — Ekonomi sağlıklı`); }
  }

  score = clamp(score);

  return {
    score,
    us10yYield:   us10y?.data?.close || null,
    us2yYield:    us2y?.data?.close  || null,
    yieldCurve,
    signals,
    verdict:      score >= 60 ? 'TAHVİL DOSTU' : score <= 40 ? 'TAHVİL RİSKLİ' : 'NÖTR',
    summary:      signals[0] || `Tahvil piyasası nötr (10Y: %${us10y?.data?.close?.toFixed(2) || '?'})`,
    timestamp:    new Date().toISOString(),
  };
}

/**
 * runBondIntelligenceEngine — Tahvil zekası motoru
 */
export async function runBondIntelligenceEngine() {
  try {
    const bonds  = await fetchBondData();
    const result = analyzeBondYields(bonds);
    return { ...result, bondCount: bonds.length, bonds };
  } catch (e) {
    console.error('[BOND] Hata:', e.message);
    return { score: 50, summary: 'Tahvil verisi alınamadı', error: e.message, timestamp: new Date().toISOString() };
  }
}

// ─── BİRLEŞİK STOCK + BOND RAPORU ────────────────────────────────────────────
/**
 * runStockBondIntelligence — İkisini birden çalıştır
 */
export async function runStockBondIntelligence() {
  const [stockResult, bondResult] = await Promise.all([
    runStockIntelligenceEngine(),
    runBondIntelligenceEngine(),
  ]);

  // Ağırlıklı ortalama: Bond biraz daha ağır (makro göstergesi)
  const combined = clamp(stockResult.score * 0.45 + bondResult.score * 0.55);

  return {
    score:       parseFloat(combined.toFixed(1)),
    stock:       stockResult,
    bond:        bondResult,
    verdict:     combined >= 60 ? 'GELENEKSEL PİYASA DESTEKLEYICI' :
                 combined <= 40 ? 'GELENEKSEL PİYASA BASKILAYICI'  : 'NÖTR',
    topSignal:   bondResult.signals[0] || stockResult.cryptoStockSignal || 'Geleneksel piyasalar nötr',
    summary:     `Hisse:${stockResult.score} | Tahvil:${bondResult.score} | Bileşik:${combined.toFixed(0)}`,
    timestamp:   new Date().toISOString(),
  };
}
