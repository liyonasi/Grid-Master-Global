/**
 * GRID MASTER GLOBAL — LIVE AI QUERY ENGINE v1
 * ==============================================
 * Kullanıcı coin sorunca Claude API üzerinden canlı AI analizi yapar.
 *
 * ÖZELLİKLER:
 *   - "Neden AL / SAT / BEKLE?" doğal dil açıklaması
 *   - Council bazlı gerekçe (Alpha / Flow / Risk / Macro)
 *   - Türkçe yanıt
 *   - Streaming desteği (isteğe bağlı)
 *   - Rate limit koruması (kullanıcı başına 10/dk)
 *
 * KULLANIM:
 *   const answer = await askAI({ symbol: 'ETHUSDT', councilData, question: 'Neden AL?' });
 */

import { clamp } from './engineCore.js';

// ─── SABİTLER ────────────────────────────────────────────────────────────────
const CLAUDE_API_URL  = 'https://api.anthropic.com/v1/messages';
const CLAUDE_MODEL    = 'claude-sonnet-4-20250514';
const MAX_TOKENS      = 1000;
const RATE_LIMIT_MS   = 6000;  // Kullanıcı başına istekler arası min süre

// ─── RATE LİMİT ──────────────────────────────────────────────────────────────
const _lastCall = new Map();

function checkRateLimit(userId = 'default') {
  const last = _lastCall.get(userId) || 0;
  const now  = Date.now();
  if (now - last < RATE_LIMIT_MS) {
    const wait = Math.ceil((RATE_LIMIT_MS - (now - last)) / 1000);
    return { allowed: false, waitSec: wait };
  }
  _lastCall.set(userId, now);
  return { allowed: true };
}

// ─── SİSTEM PROMPT'U ─────────────────────────────────────────────────────────
function buildSystemPrompt() {
  return `Sen Grid Master Global'in yapay zeka trading analistisisin.
Kullanıcılara kripto para piyasası hakkında net, özlü ve Türkçe yanıtlar verirsin.

KURALLAR:
- Her zaman Türkçe yaz
- Finansal tavsiye değil, analiz sunarsın
- Council skorlarını yorumlarken somut gerekçe ver
- Max 3 paragraf, madde madde açıklama
- Spekülatif tahminleri "olası" diye işaretle
- Risk her zaman vurgulanmalı`;
}

// ─── KULLANICI PROMPT OLUŞTUR ─────────────────────────────────────────────────
function buildUserPrompt({ symbol, councilData, currentPrice, question, marketState }) {
  const alpha = councilData?.alpha  || {};
  const flow  = councilData?.flow   || {};
  const risk  = councilData?.risk   || {};
  const macro = councilData?.macro  || {};
  const final = councilData?.final  || {};

  return `## ${symbol} ANALİZİ

**Mevcut Fiyat:** $${currentPrice || 'N/A'}
**Piyasa Durumu:** ${marketState || 'Bilinmiyor'}

**Council Skorları:**
- Alpha Council (Teknik): ${alpha.score ?? '?'}/100 → ${alpha.verdict || '?'}
- Flow Council (Likidite): ${flow.score ?? '?'}/100 → ${flow.verdict || '?'}
- Risk Council (Manipülasyon): ${risk.score ?? '?'}/100 → ${risk.verdict || '?'}
- Macro Council (BTC/Makro): ${macro.score ?? '?'}/100 → ${macro.verdict || '?'}
- **Nihai Karar: ${final.action || '?'} (${final.score ?? '?'}/100)**

**Öne Çıkan Sinyaller:**
${alpha.topSignals?.map(s => `- [Alpha] ${s}`).join('\n') || '- Veri yok'}
${flow.topSignals?.map(s => `- [Flow] ${s}`).join('\n') || ''}
${risk.warnings?.map(s => `- ⚠️ [Risk] ${s}`).join('\n') || ''}

**Kullanıcı Sorusu:** ${question || 'Bu coin için ne düşünüyorsun?'}

Lütfen council verilerini kullanarak soruyu yanıtla. Risk uyarısı ekle.`;
}

// ─── CLAUDE API ÇAĞRISI ───────────────────────────────────────────────────────
async function callClaudeAPI(systemPrompt, userPrompt) {
  const body = {
    model:      CLAUDE_MODEL,
    max_tokens: MAX_TOKENS,
    system:     systemPrompt,
    messages:   [{ role: 'user', content: userPrompt }],
  };

  const res = await fetch(CLAUDE_API_URL, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify(body),
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Claude API hatası: ${res.status} — ${err}`);
  }

  const data = await res.json();
  const text = data.content
    ?.filter(b => b.type === 'text')
    ?.map(b => b.text)
    ?.join('') || '';

  return {
    text,
    inputTokens:  data.usage?.input_tokens  || 0,
    outputTokens: data.usage?.output_tokens || 0,
  };
}

// ─── ANA FONKSİYON ───────────────────────────────────────────────────────────
/**
 * askAI — Coin hakkında AI sorgusu
 *
 * @param {object} params
 *   symbol       — 'BTCUSDT'
 *   councilData  — { alpha, flow, risk, macro, final }
 *   currentPrice — float
 *   question     — Kullanıcının sorusu
 *   marketState  — 'BULL' | 'BEAR' | 'SIDEWAYS'
 *   userId       — Rate limit için kullanıcı ID
 */
export async function askAI({
  symbol       = 'BTCUSDT',
  councilData  = {},
  currentPrice = null,
  question     = 'Bu coin için ne düşünüyorsun?',
  marketState  = null,
  userId       = 'default',
} = {}) {
  // Rate limit kontrolü
  const rl = checkRateLimit(userId);
  if (!rl.allowed) {
    return {
      success: false,
      error:   `Rate limit: ${rl.waitSec} saniye bekleyin`,
      text:    null,
      timestamp: new Date().toISOString(),
    };
  }

  try {
    const systemPrompt = buildSystemPrompt();
    const userPrompt   = buildUserPrompt({ symbol, councilData, currentPrice, question, marketState });

    const result = await callClaudeAPI(systemPrompt, userPrompt);

    return {
      success:      true,
      symbol,
      question,
      text:         result.text,
      tokens:       { in: result.inputTokens, out: result.outputTokens },
      timestamp:    new Date().toISOString(),
      score:        null, // AI metin yanıtı, skor yok
      summary:      result.text.slice(0, 120) + '...',
    };

  } catch (e) {
    console.error('[LIVE AI QUERY] Hata:', e.message);
    return {
      success: false,
      error:   e.message,
      text:    null,
      timestamp: new Date().toISOString(),
    };
  }
}

// ─── COUNCIL BAZLI SORU ŞABLONLARI ───────────────────────────────────────────
export const AI_QUESTION_PRESETS = [
  { label: 'Neden AL?',       value: 'Neden AL sinyali veriyor, gerekçeleri neler?' },
  { label: 'Neden SAT?',      value: 'Neden SAT sinyali veriyor, riskler neler?' },
  { label: 'Risk var mı?',    value: 'Bu coinle ilgili öne çıkan riskler neler?' },
  { label: 'Giriş noktası?',  value: 'İdeal giriş noktası ve seviyeleri nerede?' },
  { label: 'Hedef fiyat?',    value: 'Kısa vadeli fiyat hedefleri neler olabilir?' },
  { label: 'BTC etkisi?',     value: 'BTC hareketi bu coini nasıl etkiler?' },
  { label: 'Genel yorum',     value: 'Bu coin için genel bir değerlendirme yap.' },
];

// ─── HIZLI ANALİZ (Tam council olmadan) ──────────────────────────────────────
/**
 * quickAnalysis — Sadece fiyat + temel sinyal ile hızlı AI yorumu
 */
export async function quickAnalysis({ symbol, price, action, score, userId = 'default' }) {
  const question = `${symbol} fiyatı $${price} ve sistem "${action}" (skor: ${score}/100) diyor. Kısa yorum yap.`;
  return askAI({ symbol, question, currentPrice: price, councilData: {}, userId });
}

// ─── SOHBET GEÇMİŞİ (çok turlu) ─────────────────────────────────────────────
const _chatHistory = new Map();

/**
 * chatWithAI — Çok turlu sohbet
 */
export async function chatWithAI({ userId = 'default', symbol, message, councilData, currentPrice }) {
  const rl = checkRateLimit(userId);
  if (!rl.allowed) {
    return { success: false, error: `Rate limit: ${rl.waitSec}s bekle` };
  }

  // Geçmişi al veya oluştur
  if (!_chatHistory.has(userId)) _chatHistory.set(userId, []);
  const history = _chatHistory.get(userId);

  // Sistem context
  const ctxMsg = buildUserPrompt({ symbol, councilData, currentPrice, question: message });

  // Mesajları birleştir
  const messages = [
    ...history,
    { role: 'user', content: ctxMsg },
  ];

  try {
    const body = {
      model:      CLAUDE_MODEL,
      max_tokens: MAX_TOKENS,
      system:     buildSystemPrompt(),
      messages,
    };

    const res  = await fetch(CLAUDE_API_URL, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(body),
    });
    const data = await res.json();
    const text = data.content?.map(b => b.text || '').join('') || '';

    // Geçmişe ekle (max 10 tur tut)
    history.push({ role: 'user',      content: message });
    history.push({ role: 'assistant', content: text });
    if (history.length > 20) history.splice(0, 2);

    return { success: true, text, timestamp: new Date().toISOString() };

  } catch (e) {
    return { success: false, error: e.message };
  }
}

/**
 * clearChatHistory — Sohbet geçmişini temizle
 */
export function clearChatHistory(userId = 'default') {
  _chatHistory.delete(userId);
}
