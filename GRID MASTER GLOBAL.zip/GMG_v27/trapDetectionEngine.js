/**
 * trapDetectionEngine.js — GMG v16
 * Tuzak Tespit Motorları:
 *   52. Stop Hunt Radar (gelişmiş)
 *   53. Double Stop Hunt Engine
 *   54. Liquidity Sweep Detector
 *   55. Double Sweep Detector
 *   58. HFT Pulse Engine
 *   59. Bait Timer Engine
 *   63. Fake Breakout Engine (gelişmiş)
 *   64. Trap Score Engine
 */

const clamp = (v, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, v));

// ─── STOP HUNT RADAR (gelişmiş) ───────────────────────────────────────────────
export function runStopHuntRadar(klines, orderbook = {}) {
  if (!klines || klines.length < 20) return { score: 0, detected: false, zones: [] };

  const last = klines[klines.length - 1];
  const prev5 = klines.slice(-6, -1);
  const recent20 = klines.slice(-20);

  // Stop hunt belirtileri:
  // 1. Uzun fitil + küçük gövde
  const body = Math.abs(last.c - last.o);
  const totalRange = last.h - last.l;
  const wickRatio = totalRange > 0 ? (totalRange - body) / totalRange : 0;

  // 2. Önceki swing low/high'ın kısa süreli kırılması
  const swingLow = Math.min(...recent20.map(k => k.l));
  const swingHigh = Math.max(...recent20.map(k => k.h));
  const brokeBelow = last.l < swingLow * 1.001 && last.c > swingLow;
  const brokeAbove = last.h > swingHigh * 0.999 && last.c < swingHigh;

  // 3. Hacim spike ile birlikte
  const avgVol = prev5.reduce((s, k) => s + (k.v || 0), 0) / Math.max(prev5.length, 1);
  const volSpike = avgVol > 0 ? (last.v || 0) / avgVol : 1;

  // 4. Hızlı geri dönüş (kapanış ters yönde)
  const quickReverse = brokeBelow ? last.c > (swingLow + (last.h - swingLow) * 0.5) : brokeAbove ? last.c < (swingHigh - (swingHigh - last.l) * 0.5) : false;

  let score = 0;
  if (wickRatio > 0.6) score += 25;
  if (wickRatio > 0.75) score += 15;
  if (brokeBelow || brokeAbove) score += 30;
  if (volSpike > 1.8) score += 15;
  if (quickReverse) score += 15;

  const zones = [];
  if (brokeBelow) zones.push({ type: 'LONG_STOP_HUNT', price: swingLow, direction: 'DOWN_THEN_UP' });
  if (brokeAbove) zones.push({ type: 'SHORT_STOP_HUNT', price: swingHigh, direction: 'UP_THEN_DOWN' });

  return {
    score: clamp(score),
    detected: score >= 50,
    wickRatio: parseFloat(wickRatio.toFixed(3)),
    brokeBelow,
    brokeAbove,
    volSpike: parseFloat(volSpike.toFixed(2)),
    quickReverse,
    zones,
    verdict: score >= 70 ? 'GÜÇLÜ STOP HUNTi' : score >= 50 ? 'MUHTEMEL STOP HUNT' : 'YOK',
    timestamp: Date.now(),
  };
}

// ─── DOUBLE STOP HUNT ENGINE ──────────────────────────────────────────────────
export function runDoubleStopHunt(klines) {
  if (!klines || klines.length < 40) return { detected: false, score: 0 };

  const recent = klines.slice(-40);
  let hunts = [];

  for (let i = 5; i < recent.length - 1; i++) {
    const k = recent[i];
    const prev = recent.slice(Math.max(0, i - 5), i);
    const swL = Math.min(...prev.map(x => x.l));
    const swH = Math.max(...prev.map(x => x.h));
    const body = Math.abs(k.c - k.o);
    const range = k.h - k.l;
    const wRatio = range > 0 ? (range - body) / range : 0;

    if ((k.l < swL * 1.001 && k.c > swL && wRatio > 0.55) ||
        (k.h > swH * 0.999 && k.c < swH && wRatio > 0.55)) {
      hunts.push({ idx: i, price: k.c, low: k.l, high: k.h, wRatio });
    }
  }

  const doubleHunt = hunts.length >= 2;
  const bothDirections = hunts.some(h => h.low < klines[klines.length - 20].l) &&
                         hunts.some(h => h.high > klines[klines.length - 20].h);

  return {
    detected: doubleHunt,
    bothDirections,
    huntCount: hunts.length,
    score: clamp(hunts.length * 25 + (bothDirections ? 20 : 0)),
    hunts: hunts.slice(-3),
    verdict: bothDirections ? 'ÇİFT YÖN STOP HUNT — TUZAK YÜKSEK' : doubleHunt ? 'ÇİFT STOP HUNT' : 'YOK',
    timestamp: Date.now(),
  };
}

// ─── LIQUIDITY SWEEP DETECTOR ─────────────────────────────────────────────────
export function runLiquiditySweepDetector(klines, recentTrades = []) {
  if (!klines || klines.length < 10) return { detected: false, type: 'NONE', score: 0 };

  const last3 = klines.slice(-3);
  const prev10 = klines.slice(-13, -3);
  const recentHigh = Math.max(...prev10.map(k => k.h));
  const recentLow  = Math.min(...prev10.map(k => k.l));
  const last = last3[last3.length - 1];

  // Sweep Up: fiyat kısa süre recentHigh'ı geçti, sonra geri döndü
  const sweepUp = last3.some(k => k.h > recentHigh) && last.c < recentHigh * 0.999;
  // Sweep Down: fiyat kısa süre recentLow'u geçti, sonra geri döndü
  const sweepDown = last3.some(k => k.l < recentLow) && last.c > recentLow * 1.001;

  const sweepUpPct = sweepUp ? ((Math.max(...last3.map(k => k.h)) - recentHigh) / recentHigh * 100) : 0;
  const sweepDownPct = sweepDown ? ((recentLow - Math.min(...last3.map(k => k.l))) / recentLow * 100) : 0;

  let score = 0;
  let type = 'NONE';
  if (sweepUp && sweepDown) { score = 85; type = 'DOUBLE_SWEEP'; }
  else if (sweepUp)   { score = clamp(40 + sweepUpPct * 200); type = 'SWEEP_UP'; }
  else if (sweepDown) { score = clamp(40 + sweepDownPct * 200); type = 'SWEEP_DOWN'; }

  return {
    detected: score >= 45,
    type,
    sweepUp,
    sweepDown,
    sweepUpPct:   parseFloat(sweepUpPct.toFixed(3)),
    sweepDownPct: parseFloat(sweepDownPct.toFixed(3)),
    recentHigh,
    recentLow,
    score: clamp(score),
    verdict: score >= 70 ? 'GÜÇLÜ SWEEP — GİRİŞ OLUŞUYOR' : score >= 45 ? 'SWEEP TESPİT EDİLDİ' : 'YOK',
    timestamp: Date.now(),
  };
}

// ─── DOUBLE SWEEP DETECTOR ────────────────────────────────────────────────────
export function runDoubleSweepDetector(klines) {
  if (!klines || klines.length < 30) return { detected: false, score: 0 };

  const sweeps = [];
  for (let i = 5; i < klines.length - 2; i++) {
    const result = runLiquiditySweepDetector(klines.slice(0, i + 3));
    if (result.detected) sweeps.push({ idx: i, type: result.type, score: result.score });
  }

  const recent = sweeps.slice(-5);
  const hasUp   = recent.some(s => s.type.includes('UP'));
  const hasDown = recent.some(s => s.type.includes('DOWN'));

  return {
    detected: hasUp && hasDown,
    sweepCount: recent.length,
    hasUpSweep: hasUp,
    hasDownSweep: hasDown,
    score: clamp((hasUp && hasDown) ? 80 : recent.length * 15),
    verdict: hasUp && hasDown ? 'DOUBLE SWEEP — AKIM DEĞİŞİMİ YAKLAŞIYOR' : 'YOK',
    timestamp: Date.now(),
  };
}

// ─── HFT PULSE ENGINE ─────────────────────────────────────────────────────────
export function runHFTPulseEngine(recentTrades = [], intervalMs = 1000) {
  // recentTrades: [{price, amount, side, time}]
  if (!recentTrades || recentTrades.length < 10) {
    return { detected: false, score: 0, tradeRate: 0, patternType: 'NONE' };
  }

  const now = Date.now();
  const window1s = recentTrades.filter(t => now - t.time < intervalMs);
  const tradeRate = window1s.length; // işlem/saniye

  // HFT belirtileri:
  // 1. Çok yüksek işlem frekansı
  const isHighFreq = tradeRate > 50;

  // 2. Küçük miktarların tekrarlanması (layering)
  const amounts = window1s.map(t => t.amount);
  const avgAmt  = amounts.reduce((a, b) => a + b, 0) / Math.max(amounts.length, 1);
  const smallTrades = amounts.filter(a => a < avgAmt * 0.2).length;
  const isLayering = smallTrades > window1s.length * 0.6;

  // 3. Fiyat ping-pong (aynı fiyat seviyesinde ileri geri)
  const prices = window1s.map(t => t.price);
  const uniquePrices = new Set(prices.map(p => p.toFixed(2))).size;
  const isPingPong = uniquePrices < prices.length * 0.3;

  let score = 0;
  let patternType = 'NONE';
  if (isHighFreq) { score += 35; patternType = 'HIGH_FREQ'; }
  if (isLayering) { score += 30; patternType = 'LAYERING'; }
  if (isPingPong) { score += 25; patternType = 'PING_PONG'; }
  if (isHighFreq && isLayering) patternType = 'HFT_SPOOFING';

  return {
    detected: score >= 50,
    score: clamp(score),
    tradeRate,
    isHighFreq,
    isLayering,
    isPingPong,
    patternType,
    verdict: score >= 70 ? 'HFT AKTİF — MANIPÜLASYON RİSKİ' : score >= 50 ? 'HFT PALSİ TESPİT EDİLDİ' : 'NORMAL',
    timestamp: Date.now(),
  };
}

// ─── BAIT TIMER ENGINE ────────────────────────────────────────────────────────
const _baitTimerState = {};

export const BaitTimerEngine = {
  // Bir hareketin tuzak olup olmadığını zamanlama ile ölçer
  startTimer(symbol, direction) {
    _baitTimerState[symbol] = {
      direction,
      startTime: Date.now(),
      startPrice: null,
      samples: [],
    };
  },
  addSample(symbol, price) {
    if (!_baitTimerState[symbol]) return;
    _baitTimerState[symbol].samples.push({ price, time: Date.now() });
    if (!_baitTimerState[symbol].startPrice) _baitTimerState[symbol].startPrice = price;
  },
  evaluate(symbol) {
    const state = _baitTimerState[symbol];
    if (!state || state.samples.length < 3) return { isBait: false, score: 0 };

    const elapsed = (Date.now() - state.startTime) / 1000; // saniye
    const prices   = state.samples.map(s => s.price);
    const maxMove  = Math.max(...prices);
    const minMove  = Math.min(...prices);
    const lastPrice = prices[prices.length - 1];
    const startPrice = state.startPrice;
    const totalMove = Math.abs(maxMove - minMove) / startPrice * 100;

    // Tuzak kriterleri: Hareket başladı ama 30s içinde geri döndü
    const quickReturn = elapsed < 30 && Math.abs(lastPrice - startPrice) / startPrice < 0.001;
    const bigWick = totalMove > 0.3 && quickReturn;

    let score = 0;
    if (quickReturn) score += 40;
    if (bigWick) score += 35;
    if (elapsed < 10 && totalMove > 0.5) score += 25;

    return {
      isBait: score >= 60,
      score: clamp(score),
      elapsed: Math.round(elapsed),
      totalMove: parseFloat(totalMove.toFixed(3)),
      quickReturn,
      verdict: score >= 70 ? 'TUZAK HAREKET — GİRME' : score >= 50 ? 'MUHTEMEL TUZAK' : 'TEMİZ',
    };
  },
  clear: (symbol) => delete _baitTimerState[symbol],
};

// ─── FAKE BREAKOUT ENGINE (gelişmiş) ──────────────────────────────────────────
export function runFakeBreakoutEngine(klines, srLevels = []) {
  if (!klines || klines.length < 20) return { score: 0, detected: false };

  const last  = klines[klines.length - 1];
  const prev5 = klines.slice(-6, -1);
  const prev20 = klines.slice(-20);

  const recentHigh = Math.max(...prev20.map(k => k.h));
  const recentLow  = Math.min(...prev20.map(k => k.l));

  // Kırılım var mı?
  const brokeUp   = last.h > recentHigh && last.c < recentHigh;
  const brokeDown = last.l < recentLow  && last.c > recentLow;

  // Hacim desteği var mı?
  const avgVol = prev5.reduce((s, k) => s + (k.v || 0), 0) / Math.max(prev5.length, 1);
  const volSupport = (last.v || 0) > avgVol * 1.5;

  // Kapanış kırılımı desteklemiyor
  const fakeUp   = brokeUp   && !volSupport;
  const fakeDown = brokeDown && !volSupport;

  // S/R seviyelerine yakınlık kontrolü
  const nearSR = srLevels.some(level => Math.abs(last.c - level) / last.c < 0.003);

  let score = 0;
  if (fakeUp || fakeDown) score += 45;
  if (!volSupport && (brokeUp || brokeDown)) score += 25;
  if (nearSR) score += 15;
  const body = Math.abs(last.c - last.o);
  const range = last.h - last.l;
  if (range > 0 && body / range < 0.3) score += 15; // Küçük gövde = belirsizlik

  return {
    detected: score >= 55,
    score: clamp(score),
    brokeUp,
    brokeDown,
    fakeUp,
    fakeDown,
    volSupport,
    nearSR,
    recentHigh,
    recentLow,
    verdict: score >= 70 ? 'SAHTE KIRILIM — GİRME' : score >= 55 ? 'MUHTEMEL SAHTE KIRILIM' : 'GERÇEK KIRILIM OLABİLİR',
    timestamp: Date.now(),
  };
}

// ─── TRAP SCORE ENGINE ────────────────────────────────────────────────────────
export function runTrapScoreEngine({
  stopHunt = {},
  doubleStopHunt = {},
  sweep = {},
  hftPulse = {},
  baitEval = {},
  fakeBreakout = {},
  spoofingScore = 0,
} = {}) {
  // Tüm manipülasyon sinyallerini tek skora birleştir
  const weights = {
    stopHunt:      0.22,
    doubleStop:    0.18,
    sweep:         0.15,
    hft:           0.13,
    bait:          0.12,
    fakeBreakout:  0.12,
    spoofing:      0.08,
  };

  const scores = {
    stopHunt:     stopHunt.score      || 0,
    doubleStop:   doubleStopHunt.score || 0,
    sweep:        sweep.score         || 0,
    hft:          hftPulse.score      || 0,
    bait:         baitEval.score      || 0,
    fakeBreakout: fakeBreakout.score  || 0,
    spoofing:     spoofingScore,
  };

  const totalScore = Object.entries(scores).reduce((sum, [k, v]) => sum + v * (weights[k] || 0), 0);

  const activeTraps = [];
  if ((stopHunt.score || 0) >= 50) activeTraps.push('STOP HUNT');
  if ((doubleStopHunt.score || 0) >= 50) activeTraps.push('ÇİFT STOP HUNT');
  if ((sweep.score || 0) >= 45) activeTraps.push('SWEEP ' + (sweep.type || ''));
  if ((hftPulse.score || 0) >= 50) activeTraps.push('HFT ' + (hftPulse.patternType || ''));
  if ((fakeBreakout.score || 0) >= 55) activeTraps.push('SAHTE KIRILIM');

  const riskLevel = totalScore >= 70 ? 'KRİTİK' : totalScore >= 50 ? 'YÜKSEK' : totalScore >= 30 ? 'ORTA' : 'DÜŞÜK';
  const action    = totalScore >= 60 ? 'WAIT' : 'PASS';

  return {
    totalScore: parseFloat(totalScore.toFixed(1)),
    riskLevel,
    action,
    activeTraps,
    scores,
    verdict: totalScore >= 70 ? '⛔ KRİTİK TUZAK — BEKLE' : totalScore >= 50 ? '⚠ YÜKSEK RİSK' : totalScore >= 30 ? 'DİKKAT' : '✓ TEMİZ',
    recommendation: action === 'WAIT' ? 'Sinyal iptal — tuzak riski çok yüksek' : 'Devam edilebilir',
    timestamp: Date.now(),
  };
}
