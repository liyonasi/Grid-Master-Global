/**
 * GMG — MASTER COUNCIL ORCHESTRATOR
 * =====================================
 * Tüm konseyleri + Pine Engine + Execution Layer bağlar.
 * 
 * Akış:
 * Veri → 5 Konsey → Final Council → Execution Layer → BUY/SELL/WAIT
 * 
 * KULLANIM:
 *   import { runMasterCouncil } from './masterCouncil';
 *   const result = await runMasterCouncil({ candles, scanResults, orderbook, fundingRates });
 */

import { runPineEngine }       from './pineEngine.js';
import { runNewsMacroCouncil } from './newsMacroCouncil.js';
import { runExecutionLayer }   from './executionLayer.js';
import {
  runForexEngine, runBondEngine, runTechnicalExtEngine,
  runBuyWallDetector, runSellWallDetector, runSqueezeDetector,
} from './multiAssetEngines.js';

// ── Advanced Motorlar ──────────────────────────────────────────────────────────
import { initInfra, HealthMonitor, LoggingEngine, DataSanityCheck } from './infraEngine.js';
import {
  runTrendExhaustionEngine, runCandleAnatomyEngine,
  runWickManipulationEngine, runBreakoutFilterEngine,
  runFractalStructureEngine, runTrendAccelerationEngine,
} from './technicalAdvancedEngine.js';
import {
  runLeverageBuildupEngine, runFundingExtremeEngine,
  runOIDivergenceEngine, runCascadeRiskEngine, runDerivativeTrapEngine,
} from './derivativesAdvancedEngine.js';
import { runNewsIntelligenceEngine, runEventClassifier, runPanicNewsEngine } from './newsAdvancedEngine.js';
import {
  runGlobalRiskAppetiteEngine, runGeopoliticalRiskEngine,
  runGlobalMoneyFlowEngine, runYieldCurveEngine as runBondYieldCurve,
} from './bondMacroAdvancedEngine.js';
import {
  runWhaleTraceEngine, runSmartMoneyTracker,
  runCryptoContagionEngine, runStrengthRankEngine,
} from './intelligenceAdvancedEngine.js';
import {
  CouncilMemoryEngine, runCryptoSpecialistCouncil,
  runForexSpecialistCouncil, runCommoditySpecialistCouncil,
  runIndexSpecialistCouncil, runProbabilityEngine,
  runForexSpecialistFull, runCommoditySpecialistFull,
} from './councilAdvancedEngine.js';
import { detectMarketStructure, estimatePullback } from './structureEngines.js';
import { runIndexEngine } from './indexEngine.js';
import { runSocialSentimentEngine } from './socialSentimentEngine.js';
import { runSocialSentimentWithAPI } from './specialistEngines.js';
import { runMissingModulesBundle, LatencyMonitor, CrossFeedValidator } from './missingModules.js';
import { runLiquiditySpecialEngines, runDarkPoolEngineWithGlassnode, runOTCFlowEngineWithAPI } from './liquiditySpecialEngines.js';

// ─── TECHNICAL COUNCIL (Pine entegreli) ──────────────────────────────────────

function runTechnicalCouncil({ candles, I, pineData, mags }) {
  if (!candles?.length || !I?.rsi) return { id:'TECHNICAL', score:50, action:'NEUTRAL', color:'#ffd600', signals:[], debate:[] };

  const n   = candles.length - 1;
  const cur = candles[n].c;
  const rv  = I.rsi[n]  ?? 50;
  const mh  = I.macd?.h?.[n] ?? 0;
  const e9  = I.e9?.[n]  ?? cur, e21 = I.e21?.[n] ?? cur, e50 = I.e50?.[n] ?? cur;
  const bbu = I.bb?.u?.[n], bbl = I.bb?.l?.[n];
  const bp  = bbu && bbl ? (cur-bbl)/(bbu-bbl)*100 : 50;
  const adv = I.adx?.[n] ?? 20;
  const mfi = I.mfi?.[n] ?? 50;

  // Pine katkıları
  const pineScore = pineData?.score || 50;
  const rfTrendUp   = pineData?.rf?.trendUp   || false;
  const rfTrendDown = pineData?.rf?.trendDown  || false;
  const rfBuy       = pineData?.rf?.buySignal  || false;
  const rfSell      = pineData?.rf?.sellSignal || false;
  const pbBuy       = pineData?.pb?.pbBuy      || false;
  const pbSell      = pineData?.pb?.pbSell     || false;
  const nearSup     = pineData?.pb?.nearSupport || false;
  const nearRes     = pineData?.pb?.nearRes     || false;
  const inChannel   = pineData?.pb?.inAnyChannel || false;

  const signals = [
    // Klasik teknik
    { label:'RSI',            score: rv<30?85:rv<45?68:rv>75?20:rv>60?36:52, weight:0.12, key:'RSI_STATE' },
    { label:'MACD',           score: mh>0?70:mh<0?30:50,                     weight:0.12, key:'MACD' },
    { label:'EMA Trend',      score: e9>e21&&e21>e50?78:e9>e21?62:e9<e21&&e21<e50?22:38, weight:0.12, key:'EMA_TREND' },
    { label:'Bollinger',      score: bp<20?78:bp<40?62:bp>80?22:bp>65?36:52,  weight:0.10, key:'BOLLINGER_BAND' },
    { label:'ADX Güç',        score: adv>30?65:adv>20?55:45,                  weight:0.08, key:'TREND_ACCELERATION' },
    { label:'MFI',            score: mfi<35?75:mfi>70?28:50,                  weight:0.08, key:'MOMENTUM_BIAS' },

    // Pine Range Filter
    { label:'RF Trend Yönü',  score: rfTrendUp?75:rfTrendDown?25:50,           weight:0.15, key:'RANGE_FILTER_TREND' },
    { label:'RF Flip Sinyali',score: rfBuy?82:rfSell?18:50,                    weight:0.12, key:'RANGE_FILTER_SIGNAL' },

    // Pine S/R
    { label:'S/R Yakınlık',   score: nearSup&&rfTrendUp?72:nearRes&&rfTrendDown?28:inChannel?52:50, weight:0.08, key:'SR_PROXIMITY' },

    // Pine PB
    { label:'PB-AL/SAT',      score: pbBuy?78:pbSell?22:50,                   weight:0.13, key:'PULLBACK' },
  ];

  const totalW = signals.reduce((s,g) => s+g.weight, 0);
  const score  = Math.round(Math.max(0, Math.min(100,
    signals.reduce((s,g) => s+g.score*g.weight, 0) / totalW
  )));

  const action = score>=65?'BULLISH':score>=55?'ZAYIF BULLISH':score<=35?'BEARISH':score<=45?'ZAYIF BEARISH':'NEUTRAL';
  const color  = score>=55?'#00e676':score<=45?'#ff1744':'#ffd600';

  return {
    id: 'TECHNICAL',
    name: 'Technical Council',
    icon: '◈',
    score, action, color,
    signals,
    debate: [
      `RSI: ${rv.toFixed(1)} | MACD: ${mh>=0?'+':''}${mh.toFixed(4)} | EMA: ${e9>e21?'YUKARI':'AŞAĞI'}`,
      `Range Filter: ${rfTrendUp?'YUKARI':rfTrendDown?'AŞAĞI':'NÖTR'} | Flip: ${rfBuy?'BUY SİNYALİ':rfSell?'SELL SİNYALİ':'YOK'}`,
      `S/R: ${inChannel?'KANAL İÇİ':nearSup?'DESTEK YAKINI':nearRes?'DİRENÇ YAKINI':'KANAL DIŞI'}`,
      `PB: ${pbBuy?'PB-AL AKTİF':pbSell?'PB-SAT AKTİF':'Yok'} | BB: ${bp.toFixed(0)}%`,
    ],
  };
}

// ─── FLOW COUNCIL ─────────────────────────────────────────────────────────────

function runFlowCouncil({ scanResults, orderbook, fundingRates, btcChange }) {
  const { liquiditySens=[], suddenPumps=[], suddenDumps=[], multiExchange={}, enrichedCoins=[] } = scanResults || {};

  const buyBias  = liquiditySens.filter(l => l.bias==='ALIŞ').length;
  const sellBias = liquiditySens.filter(l => l.bias==='SATIŞ').length;
  const total    = liquiditySens.length || 1;
  const posR     = enrichedCoins.filter(c => (c.change_24h||0)>0).length / (enrichedCoins.length||1);

  // Orderbook
  let obBuyPct = 50;
  if (orderbook?.bids?.length && orderbook?.asks?.length) {
    const bidVol = orderbook.bids.slice(0,15).reduce((s,b) => s+b.amount*b.price, 0);
    const askVol = orderbook.asks.slice(0,15).reduce((s,a) => s+a.amount*a.price, 0);
    obBuyPct = Math.round((bidVol/(bidVol+askVol+0.001))*100);
  }

  // Funding
  const avgFunding = fundingRates?.length
    ? fundingRates.reduce((s,f) => s+(f.rate||0), 0) / fundingRates.length : 0;
  const fundingScore = Math.max(0, Math.min(100, Math.round(50 - avgFunding * 300)));

  const signals = [
    { label:'OB Akışı',         score: obBuyPct,                               weight:0.28 },
    { label:'Liq Sens. Dengesi',score: Math.round((buyBias/total)*100),        weight:0.22 },
    { label:'Piyasa Genişliği', score: Math.round(posR*100),                   weight:0.20 },
    { label:'Pump/Dump Dengesi',score: Math.max(0,Math.min(100,50+(suddenPumps.length-suddenDumps.length)*7)), weight:0.18 },
    { label:'Funding Bias',     score: fundingScore,                           weight:0.12 },
  ];

  const totalW = signals.reduce((s,g) => s+g.weight, 0);
  const score  = Math.round(Math.max(0, Math.min(100, signals.reduce((s,g) => s+g.score*g.weight, 0)/totalW)));
  const action = score>=60?'BUY PRESSURE':score<=40?'SELL PRESSURE':'NEUTRAL';
  const color  = score>=55?'#00e676':score<=45?'#ff1744':'#ffd600';

  return {
    id: 'FLOW',
    name: 'Flow Council',
    icon: '⟁',
    score, action, color,
    signals,
    debate: [
      `Orderbook: %${obBuyPct} alış baskısı`,
      `Piyasa genişliği: %${Math.round(posR*100)} coin pozitif`,
      `Funding ort: ${avgFunding>=0?'+':''}${avgFunding.toFixed(4)}%`,
      `Pump/Dump: ${suddenPumps.length}/${suddenDumps.length}`,
    ],
  };
}

// ─── RISK COUNCIL ─────────────────────────────────────────────────────────────

function runRiskCouncil({ scanResults, vixLevel=50, fundingRates=[], pineData=null }) {
  const { scalpTraps=[], stopHunts=[], suddenDumps=[], liquiditySens=[] } = scanResults || {};
  const critDumps    = suddenDumps.filter(d => d.change<=-10).length;
  const highRiskLiq  = liquiditySens.filter(l => l.riskLevel==='YÜKSEK').length;
  const avgFunding   = fundingRates.length ? fundingRates.reduce((s,f) => s+Math.abs(f.rate||0), 0)/fundingRates.length : 0;

  const signals = [
    { label:'Scalp Tuzak',      score: Math.max(0,100-scalpTraps.length*12), weight:0.20 },
    { label:'Stop Hunt',        score: Math.max(0,100-stopHunts.length*20),  weight:0.25 },
    { label:'Kritik Dump',      score: Math.max(0,100-critDumps*22),         weight:0.20 },
    { label:'Liq Risk',         score: Math.max(0,100-highRiskLiq*12),       weight:0.15 },
    { label:'VIX',              score: vixLevel>80?20:vixLevel>60?40:vixLevel>40?58:72, weight:0.12 },
    { label:'Funding Aşırılık', score: avgFunding>0.1?30:avgFunding>0.05?50:70, weight:0.08 },
  ];

  // Pine: PB-SAT aktif ise risk yüksek
  if (pineData?.pb?.pbSell) {
    signals.push({ label:'PB-SAT Uyarısı', score:35, weight:0.10 });
  }

  const totalW = signals.reduce((s,g) => s+g.weight, 0);
  const score  = Math.round(Math.max(0, Math.min(100, signals.reduce((s,g) => s+g.score*g.weight, 0)/totalW)));
  const rl     = score>=70?'DÜŞÜK':score>=50?'ORTA':score>=30?'YÜKSEK':'KRİTİK';
  const color  = score>=70?'#00e676':score>=50?'#ffd600':score>=30?'#ff6d00':'#ff1744';

  return {
    id: 'RISK',
    name: 'Risk Council',
    icon: '⬡',
    score, action: `Risk: ${rl}`, color,
    riskLevel: rl,
    signals,
    debate: [
      `${stopHunts.length} stop hunt | ${scalpTraps.length} scalp tuzak`,
      `${critDumps} kritik dump (>-10%)`,
      `VIX seviyesi: ${vixLevel?.toFixed(1)}`,
      `Funding aşırılığı: ${avgFunding.toFixed(4)}%`,
    ],
  };
}

// ─── ASSET SPECIALIST COUNCIL ────────────────────────────────────────────────

function runAssetSpecialistCouncil({ heatmapData=[], btcChange=0, globalLiqData=null }) {
  const total  = heatmapData.length || 1;
  const posR   = heatmapData.filter(c => (c.change_24h||0)>0).length / total;
  const altAvg = heatmapData.slice(1,51).reduce((s,c) => s+(c.change_24h||0), 0) / 50;
  const altRelBTC = altAvg - btcChange;
  const btcDom = globalLiqData?.btcDominance || 50;

  const signals = [
    { label:'Alt Sezon',       score: Math.max(0,Math.min(100,50+altRelBTC*5)),  weight:0.28 },
    { label:'Sektör Gücü',     score: Math.round(posR*100),                      weight:0.25 },
    { label:'BTC Dominans',    score: btcChange>2?65:btcChange>0?55:btcChange>-2?45:30, weight:0.22 },
    { label:'Para Rotasyonu',  score: Math.max(0,Math.min(100,50+btcChange*3+altRelBTC*2)), weight:0.15 },
    { label:'Stablecoin Akış', score: globalLiqData?.marketCapChange24h>0?62:38,  weight:0.10 },
  ];

  const totalW = signals.reduce((s,g) => s+g.weight, 0);
  const score  = Math.round(Math.max(0, Math.min(100, signals.reduce((s,g) => s+g.score*g.weight, 0)/totalW)));
  const action = score>=60?'ASSET BULLISH':score<=40?'ASSET BEARISH':'ASSET NEUTRAL';
  const color  = score>=55?'#00e676':score<=45?'#ff1744':'#ffd600';

  return {
    id: 'ASSET',
    name: 'Asset Specialist Council',
    icon: '⎈',
    score, action, color,
    signals,
    altSeasonIndex: Math.round(Math.max(0,Math.min(100,50+altRelBTC*5))),
    debate: [
      `BTC: ${btcChange>=0?'+':''}${btcChange.toFixed(2)}% | Alt ort: ${altAvg>=0?'+':''}${altAvg.toFixed(2)}%`,
      `Alt-BTC fark: ${altRelBTC>=0?'+':''}${altRelBTC.toFixed(2)}%`,
      `BTC Dominans: ${btcDom.toFixed(1)}%`,
    ],
  };
}

// ─── FINAL COUNCIL ────────────────────────────────────────────────────────────

function runFinalCouncil(councils) {
  const { technical, flow, risk, asset, newsMacro } = councils;
  const all = [technical, flow, asset, newsMacro].filter(Boolean);

  // Ağırlıklar
  const weights = {
    TECHNICAL: 0.30,
    FLOW:      0.25,
    ASSET:     0.20,
    NEWS_MACRO:0.15,
    RISK:      0.10,  // Risk Council ayrıca veto etkisi var
  };

  const weightedScore = Math.round(Math.max(0, Math.min(100,
    (technical?.score  || 50) * weights.TECHNICAL +
    (flow?.score       || 50) * weights.FLOW +
    (asset?.score      || 50) * weights.ASSET +
    (newsMacro?.score  || 50) * weights.NEWS_MACRO +
    (risk?.score       || 50) * weights.RISK
  )));

  const proposedAction =
    weightedScore >= 60 ? 'BUY'  :
    weightedScore <= 40 ? 'SELL' : 'WAIT';

  const color = weightedScore>=55?'#00e676':weightedScore<=45?'#ff1744':'#ffd600';

  // Konsensüs gücü
  const bullCount = all.filter(c => c.score>=55).length;
  const bearCount = all.filter(c => c.score<=45).length;
  const total     = all.length;

  const consensusStr =
    Math.max(bullCount,bearCount) === total ? 'TAM' :
    Math.max(bullCount,bearCount) >= total*0.7 ? 'GÜÇLÜ' :
    Math.max(bullCount,bearCount) >= total*0.5 ? 'ÇOĞUNLUK' : 'BÖLÜNMÜŞ';

  const confidence = Math.round(Math.min(95, Math.max(20,
    25 + Math.max(bullCount,bearCount)*12 + Math.abs(weightedScore-50)*0.6
  )));

  return {
    id: 'FINAL',
    name: 'Final Council',
    score:           weightedScore,
    proposedAction,
    color,
    confidence,
    consensusStr,
    votes: { bull: bullCount, bear: bearCount, neutral: total-bullCount-bearCount },
    marketBias:
      weightedScore>=65?'GÜÇLÜ BULLISH':
      weightedScore>=55?'BULLISH':
      weightedScore<=35?'GÜÇLÜ BEARISH':
      weightedScore<=45?'BEARISH':'NÖTR',
  };
}

// ─── MASTER RUNNER ────────────────────────────────────────────────────────────

export async function runMasterCouncil({
  candles,        // OHLCV candles
  I,              // indicators (rsi, macd, bb, ema, adx, mfi, obv, atr)
  scanResults,    // intelligenceEngine çıktısı
  orderbook,      // { bids, asks }
  heatmapData,    // coin listesi
  fundingRates,   // [{ ex, rate }]
  btcChange,      // BTC 24s değişim
  vixLevel,       // VIX seviyesi
  globalLiqData,  // fetchGlobalLiquidity() çıktısı
  lastSignalBarsAgo,
  prevFinalScore,
  signalBarCount,

  // Pine Engine parametreleri
  pineParams = {},

  // News/Macro overrides
  macroOverrides = {},

  // CrossFeed fiyat doğrulama (opsiyonel — { binance:45000, bybit:45010, ... })
  aggregatedPrices = null,

  // MultiAsset makro verileri (opsiyonel — sağlanmazsa varsayılan değerler)
  dxyLevel   = 104,
  us10yYield = 4.5,
  goldChange   = 0,
  oilChange    = 0,
  silverChange = 0,
  sp500Change  = 0,
  nasdaqChange = 0,
  marketBreadth = 0.6,
  fearGreed    = 50,
  externalTrapScore = 0,  // Dashboard'dan gelen trapScore

  // API anahtarları — UI'dan gelir (localStorage → Dashboard → buraya)
  glassnodeKey = '',
  cqKey        = '',

  // Seçili sembol (sosyal sentiment için)
  symbol = 'BTC',
} = {}) {

  // 0. Infra — sağlık + log başlat (null-safe)
  const infra = (() => { try { return initInfra(); } catch(e) { return { status:'OK', healthy:true }; } })();
  const log   = { log: (...args) => { try { LoggingEngine.log(...args); } catch(e) {} } };
  log.log('masterCouncil', 'START', { symbol: candles?.[candles?.length-1]?.s || 'unknown' });
  LatencyMonitor.start('masterCouncil');

  // 1. Pine Engine
  const pineData = candles?.length >= 30 ? runPineEngine(candles, pineParams) : null;

  // 1b. MultiAsset motorları
  const forexData = runForexEngine({ dxyData:{ dxyLevel, dxyChange:0 }, carryData:{}, sessionHour: new Date().getUTCHours() });
  const bondData  = runBondEngine({ yieldCurve:{ us10y:us10yYield, us2y:us10yYield-0.3 }, globalLiq: globalLiqData||{} });
  const techExtData = candles?.length>=20 ? runTechnicalExtEngine({ candles, orderbook, currentPrice:candles[candles.length-1]?.c||0 }) : null;
  const buyWall   = orderbook ? runBuyWallDetector({ orderbook, currentPrice: candles?.[candles.length-1]?.c||0 }) : null;
  const sellWall  = orderbook ? runSellWallDetector({ orderbook, currentPrice: candles?.[candles.length-1]?.c||0 }) : null;
  const squeeze   = candles?.length>=20 ? runSqueezeDetector({ candles }) : null;

  // 2. Advanced Teknik Motorlar
  const trendExhaustion = candles?.length>=20 ? runTrendExhaustionEngine(candles) : null;
  const candleAnatomy   = candles?.length>=5  ? runCandleAnatomyEngine(candles)   : null;
  const wickManip       = candles?.length>=10 ? runWickManipulationEngine(candles) : null;
  const fractalStruct   = candles?.length>=20 ? runFractalStructureEngine(candles) : null;
  const trendAccel      = candles?.length>=15 ? runTrendAccelerationEngine(candles): null;
  const marketStruct    = candles?.length>=20 ? detectMarketStructure(candles)     : null;

  // 3. Advanced Türev Motorlar
  const leverageBuildup = scanResults?.fundingRates?.length
    ? runLeverageBuildupEngine({ fundingHistory: scanResults.fundingRates.map(f=>f.rate||0), oiChange: 0 })
    : null;
  const fundingExtreme  = scanResults?.funding
    ? runFundingExtremeEngine([], scanResults.funding)
    : null;
  const cascadeRisk     = runCascadeRiskEngine({ liquidationZones:[], currentPrice: candles?.[candles.length-1]?.c||0, oiTotal:0 });
  const derivTrap       = runDerivativeTrapEngine({ stopHuntScore: scanResults?.stopHunts?.length>0?70:20, cascadeRisk: cascadeRisk?.risk||'LOW', fundingExtreme: fundingExtreme?.extreme||false, oiDivergence: false });

  // 4. Advanced Haber Motorları
  const newsIntel  = scanResults?.news?.length ? runNewsIntelligenceEngine(scanResults.news) : null;

  // Sosyal Sentiment — CryptoPanic API (ücretsiz) önce dene
  let socialSentiment = null;
  try {
    const sym = symbol.replace('USDT','').replace('/','').toUpperCase();
    // CryptoPanic canlı veri
    socialSentiment = await runSocialSentimentWithAPI({
      symbol:      sym,
      volumeSpike: (scanResults?.volumeSpike || false),
      priceChange: btcChange || 0,
    });
  } catch(e) {
    // Fallback: eski engine
    try {
      socialSentiment = await runSocialSentimentEngine({
        symbol:        symbol.replace('USDT','').replace('/','').toUpperCase(),
        priceChange24h: btcChange || 0,
      });
    } catch(e2) { /* sessizce geç */ }
  }
  const panicNews  = newsIntel ? runPanicNewsEngine(newsIntel.cleaned||[]) : null;

  // 5. Advanced Makro Motorlar
  const globalRisk  = runGlobalRiskAppetiteEngine({ vixLevel:vixLevel||20, dxyChange:0, bondYieldChange:0, goldChange, oilChange });
  const geoRisk     = runGeopoliticalRiskEngine([]);
  const moneyFlow   = runGlobalMoneyFlowEngine({});
  const indexData   = runIndexEngine({ vixLevel: vixLevel||20 });

  // 6. Advanced Intelligence Motorları
  const whaleTrace  = scanResults?.largeTrades?.length ? runWhaleTraceEngine(scanResults.largeTrades, candles?.[candles.length-1]?.c||0) : null;
  const smartMoney  = runSmartMoneyTracker({ oiChangePercent:0, fundingRate:0, priceChange: candles?.length>=2 ? (candles[candles.length-1].c-candles[candles.length-2].c)/candles[candles.length-2].c*100 : 0 });
  const strengthRank= heatmapData?.length ? runStrengthRankEngine(heatmapData) : null;

  // 7. News & Macro Council (async)
  const newsMacroCouncil = await runNewsMacroCouncil({ btcChange7d: btcChange||0, ...macroOverrides });

  // 8. 5 Ana Konsey
  const technicalCouncil = runTechnicalCouncil({ candles, I, pineData, mags: scanResults?.mags });
  const flowCouncil      = runFlowCouncil({ scanResults, orderbook, fundingRates, btcChange });
  const riskCouncil      = runRiskCouncil({ scanResults, vixLevel, fundingRates, pineData });
  const assetCouncil     = runAssetSpecialistCouncil({ heatmapData, btcChange, globalLiqData });

  // 9. Advanced Specialist Councils (6. konsey grubu)
  const cryptoSpecialist     = runCryptoSpecialistCouncil({ btcDominance: scanResults?.btcDom||50, altSeasonScore: scanResults?.altSeason||50, btcChange, heatmapData: heatmapData||[] });
  // Full versiyonlar: internal (%60) + specialistEngines (%40) blend
  const forexSpecialist      = runForexSpecialistFull({ dxyLevel, dxyChange:0, sessionHour: new Date().getUTCHours() });
  const commoditySpecialist  = runCommoditySpecialistFull({ goldChange, oilChange, vixLevel: vixLevel||20 });
  const indexSpecialist      = runIndexSpecialistCouncil({ vixLevel: vixLevel||20, spxChange:0, nasdaqChange:0 });

  // Specialist council birleşik skoru
  const specialistScore = Math.round(
    cryptoSpecialist.score * 0.35 +
    forexSpecialist.score  * 0.25 +
    commoditySpecialist.score * 0.20 +
    indexSpecialist.score  * 0.20
  );
  const specialistCouncil = {
    id: 'SPECIALIST', score: specialistScore,
    action: specialistScore>=65?'BULLISH':specialistScore<=35?'BEARISH':'NEUTRAL',
    color: specialistScore>=65?'#00ff88':specialistScore<=35?'#ff3366':'#ffcc00',
    signals: [
      { label:'Crypto Specialist', score: cryptoSpecialist.score },
      { label:'Forex Specialist',  score: forexSpecialist.score  },
      { label:'Commodity',         score: commoditySpecialist.score },
      { label:'Index',             score: indexSpecialist.score  },
    ],
    debate: [cryptoSpecialist.summary||'', forexSpecialist.summary||''].filter(Boolean),
  };

  // Advanced skor düzeltmeleri
  const trendExhAdj  = trendExhaustion?.exhausted ? -8 : 0;
  const wickManipAdj = wickManip?.manipulationDetected ? -6 : 0;
  const derivTrapAdj = derivTrap?.isTrap ? -10 : 0;
  const panicAdj     = panicNews?.panicDetected ? -8 : 0;
  const globalRiskAdj= globalRisk ? (globalRisk.score - 50) * 0.08 : 0;
  const smartMoneyAdj= smartMoney?.smartMoneyLong ? 5 : smartMoney?.smartMoneyShort ? -5 : 0;
  const structureAdj = marketStruct?.bias==='bullish' ? 4 : marketStruct?.bias==='bearish' ? -4 : 0;

  const councils = {
    technical:  technicalCouncil,
    flow:       flowCouncil,
    risk:       riskCouncil,
    asset:      assetCouncil,
    newsMacro:  newsMacroCouncil,
    specialist: specialistCouncil,
  };

  // 10. Final Council
  const finalCouncil = runFinalCouncil(councils);

  // 11. Probability Engine
  const probability = runProbabilityEngine({
    councilScores: [technicalCouncil.score, flowCouncil.score, riskCouncil.score, assetCouncil.score, specialistCouncil.score],
    pineScore: pineData?.score || 50,
    historicalWinRate: CouncilMemoryEngine.getWinRate(),
  });

  // 12. Tüm düzeltmeler toplamı
  const forexAdj   = forexData   ? (forexData.score - 50) * 0.10 : 0;
  const bondAdj    = bondData    ? (bondData.score  - 50) * 0.08 : 0;
  const techAdj    = techExtData ? (techExtData.score-50) * 0.06 : 0;
  const squeezeAdj = squeeze?.squeezeFiring ? 5 : 0;
  const wallAdj    = (buyWall?.wallScore||0)>70 ? 3 : (sellWall?.wallScore||0)>70 ? -3 : 0;
  const specialAdj = (specialistScore - 50) * 0.08;
  // Sosyal sentiment düzeltmesi — F&G + CryptoPanic + Trending (±5 puan max)
  const socialAdj  = socialSentiment ? Math.max(-5, Math.min(5, (socialSentiment.score - 50) * 0.10)) : 0;

  // missingModulesBundle çalıştır
  let missingBundle = null;
  try {
    missingBundle = runMissingModulesBundle({
      klines:         candles,
      sessionUTCHour: new Date().getUTCHours(),
      goldChange:     goldChange   || 0,
      silverChange:   silverChange || 0,
      oilChange:      oilChange    || 0,
      wtiPrice:       85,
      sp500Change:    sp500Change  || 0,
      nasdaqChange:   nasdaqChange || 0,
      vixLevel:       vixLevel     || 20,
      marketBreadth:  marketBreadth || 0.6,
      btcChange:      btcChange    || 0,
      coinChanges:    (heatmapData||[]).slice(0,20).map(c=>({symbol:c.symbol||c.id, change:c.change24h||0})),
      priceChange15m: candles.length >= 3
        ? (candles[candles.length-1].c - candles[candles.length-3].c) / candles[candles.length-3].c * 100
        : 0,
      fearGreed:      fearGreed    || 50,
      inflationTrend: vixLevel > 25 ? 'rising' : 'stable',
      laborMarket:    'strong',
    });
  } catch(e) { /* sessizce geç */ }

  // Likidite Özel Motorlar (Dark Pool, Flash Crash, OTC)
  let liquiditySpecial = null;
  try {
    // Glassnode/CryptoQuant: Dashboard'dan gelen parametre öncelikli, sonra env fallback
    const resolvedGlassnodeKey = glassnodeKey || (typeof process !== 'undefined' && process.env?.GLASSNODE_API_KEY) || '';
    const resolvedCqKey        = cqKey        || (typeof process !== 'undefined' && process.env?.CRYPTOQUANT_API_KEY) || '';
    liquiditySpecial = runLiquiditySpecialEngines({
      candles,
      orderbook,
      currentPrice:  candles?.[candles.length-1]?.c || 0,
      glassnodeKey:  resolvedGlassnodeKey,
      cqApiKey:      resolvedCqKey,
    });
  } catch(e) { /* sessizce geç */ }

  const missingBonusAdj   = Math.max(-5, Math.min(5, missingBundle?.bonusScore || 0));
  const liquiditySpecAdj  = liquiditySpecial
    ? Math.max(-6, Math.min(4,
        (liquiditySpecial.darkPool?.score   - 50) * 0.06 +
        (liquiditySpecial.otcFlow?.score    - 50) * 0.05 +
        (liquiditySpecial.flashCrash?.detected ? -8 : 0)
      ))
    : 0;

  const multiAssetAdjustment = Math.round(Math.max(-20, Math.min(20,
    forexAdj + bondAdj + techAdj + squeezeAdj + wallAdj + specialAdj + socialAdj +
    trendExhAdj + wickManipAdj + derivTrapAdj + panicAdj + globalRiskAdj + smartMoneyAdj + structureAdj +
    missingBonusAdj + liquiditySpecAdj
  )));

  const adjustedFinalScore = Math.min(100, Math.max(0, finalCouncil.score + multiAssetAdjustment));

  // Council Memory kaydet
  CouncilMemoryEngine.record({ score: adjustedFinalScore, action: finalCouncil.proposedAction, timestamp: Date.now() });


  // 13. Execution Layer — tüm filtreler + veto
  const execution = runExecutionLayer({
    councilScores: {
      alpha: technicalCouncil.score,
      flow:  flowCouncil.score,
      risk:  riskCouncil.score,
      macro: assetCouncil.score,
      news:  newsMacroCouncil.score,
      specialist: specialistScore,
    },
    finalScore:       adjustedFinalScore,
    proposedAction:   finalCouncil.proposedAction,
    pineSignal:       pineData,
    riskCouncilScore: riskCouncil.score,
    vixLevel:         vixLevel || 50,
    fundingRates:     fundingRates || [],
    volatilityZScore: scanResults?.enrichedCoins?.[0]?.volumeZScore || 0,
    nearLiquidation:  cascadeRisk?.risk === 'CRITICAL',
    stopHunts:        scanResults?.stopHunts || [],
    scalpTraps:       scanResults?.scalpTraps || [],
    liqTraps:         [],
    trapScore:        Math.max(derivTrap?.trapScore || 0, externalTrapScore || 0),
    wickManipulation: wickManip?.manipulationDetected || false,
    panicNews:        panicNews?.panicDetected || false,
    orderbookImbalance: orderbook ? (() => {
      const b = orderbook.bids?.slice(0,10).reduce((s,x) => s+x.amount*x.price, 0) || 0;
      const a = orderbook.asks?.slice(0,10).reduce((s,x) => s+x.amount*x.price, 0) || 0;
      return b/(b+a+0.001);
    })() : 0.5,
    volumeZScore:     scanResults?.enrichedCoins?.[0]?.volumeZScore || 0,
    lastSignalBarsAgo,
    prevFinalScore,
    signalBarCount,
  });

  const masterLatency = LatencyMonitor.end('masterCouncil');
  log.log('masterCouncil', 'DONE', { action: execution.action, score: execution.score, latencyMs: masterLatency });

  // CrossFeedValidator — fiyat tutarlılık kontrolü (aggregatedPrices varsa)
  let crossFeedResult = null;
  if (aggregatedPrices && Object.keys(aggregatedPrices).length >= 2) {
    try { crossFeedResult = CrossFeedValidator.validateMultiple(aggregatedPrices); } catch {}
  }

  // ─── CouncilMemoryEngine.record() — her council kararı kaydedilir ──────────
  try {
    const councilMap = {
      TECHNICAL:  councils?.technical,
      FLOW:       councils?.flow,
      RISK:       councils?.risk,
      ASSET:      councils?.asset,
      NEWS_MACRO: councils?.newsMacro,
      SPECIALIST: councils?.specialist,
    };
    Object.entries(councilMap).forEach(([id, c]) => {
      if (c?.action && c?.score != null) {
        CouncilMemoryEngine.record({
          councilId: id + '_COUNCIL',
          action:    c.action,
          score:     c.score,
        });
      }
    });
  } catch(e) { /* CouncilMemory hata — sessizce geç */ }

  // ─── NIHAI PAKET ──────────────────────────────────────────────────────────
  return {
    action:     execution.action,
    label:      execution.label,
    score:      execution.score,
    color:      execution.color,
    confidence: execution.confidence,
    riskLevel:  execution.riskLevel,
    riskColor:  execution.riskColor,

    councils,
    missingBundle,
    liquiditySpecial,
    finalCouncil,
    execution,
    pineData,
    probability,

    // Advanced motor çıktıları
    advanced: {
      trendExhaustion, candleAnatomy, wickManip, fractalStruct, trendAccel,
      marketStruct, leverageBuildup, fundingExtreme, cascadeRisk, derivTrap,
      newsIntel, panicNews, globalRisk, geoRisk, moneyFlow, indexData,
      whaleTrace, smartMoney, strengthRank,
      cryptoSpecialist, forexSpecialist, commoditySpecialist, indexSpecialist,
      socialSentiment,
    },

    multiAsset: {
      forex: forexData, bond: bondData, techExt: techExtData,
      buyWall, sellWall, squeeze, adjustment: multiAssetAdjustment,
      adjustedScore: adjustedFinalScore,
    },

    chartOverlay: pineData ? {
      filtLine:  pineData.filtLine,
      hbandLine: pineData.hbandLine,
      lbandLine: pineData.lbandLine,
      srZones:   pineData.srZones,
      buySignal: pineData.rf?.buySignal,
      sellSignal:pineData.rf?.sellSignal,
      pbBuy:     pineData.pb?.pbBuy,
      pbSell:    pineData.pb?.pbSell,
      trendDir:  pineData.rf?.trendDir,
    } : null,

    health: {
      modulesOnline: [
        'pineEngine', 'masterCouncil', 'executionLayer',
        trendExhaustion && 'technicalAdvanced',
        derivTrap && 'derivativesAdvanced',
        newsIntel && 'newsAdvanced',
        globalRisk && 'bondMacroAdvanced',
        smartMoney && 'intelligenceAdvanced',
        specialistCouncil && 'councilAdvanced',
        missingBundle && 'missingModules',
      ].filter(Boolean),
      infraStatus:   infra?.status || 'OK',
      latencyMs:     masterLatency || 0,
      crossFeed:     crossFeedResult,
    },

    summary: [
      `${execution.label} (${execution.score}/100) — Güven: %${execution.confidence}`,
      `Technical: ${technicalCouncil.action} (${technicalCouncil.score})`,
      `Flow: ${flowCouncil.action} (${flowCouncil.score})`,
      `Risk: ${riskCouncil.riskLevel} (${riskCouncil.score})`,
      `Asset: ${assetCouncil.action} (${assetCouncil.score})`,
      `Specialist: ${specialistCouncil.action} (${specialistScore})`,
      `News/Macro: ${newsMacroCouncil.verdict} (${newsMacroCouncil.score})`,
      pineData ? `RF: ${pineData.rf?.trendDir} | PB: ${pineData.pb?.pbBuy?'AL':pineData.pb?.pbSell?'SAT':'-'}` : '',
      `Forex: ${forexData?.verdict||'—'} | Bond: ${bondData?.verdict||'—'}`,
      trendExhaustion?.exhausted ? '⚠ Trend tükenmesi' : '',
      wickManip?.manipulationDetected ? '🚨 Wick manipülasyonu' : '',
      derivTrap?.isTrap ? '🚨 Türev tuzağı' : '',
      panicNews?.panicDetected ? '📰 Panik haberi' : '',
      socialSentiment ? `😊 Sosyal: ${socialSentiment.summary || '—'}` : '',
      squeeze?.squeezeFiring ? `🔥 SQUEEZE: ${squeeze.direction}` : '',
      liquiditySpecial?.flashCrash?.detected ? `⚡ ${liquiditySpecial.flashCrash.signal}` : '',
      liquiditySpecial?.darkPool?.detected   ? `🕵 ${liquiditySpecial.darkPool.signal}`  : '',
      `Düzeltme: ${multiAssetAdjustment>0?'+':''}${multiAssetAdjustment}`,
      `Execution: ${execution.filters.veto.wasVetoed ? 'VETO' : 'TEMİZ'}`,
      `Olasılık: %${probability?.probability||50}`,
    ].filter(Boolean),

    timestamp: Date.now(),
  };
}
