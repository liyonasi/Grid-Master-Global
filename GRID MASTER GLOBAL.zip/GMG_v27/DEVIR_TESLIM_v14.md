# GMG — DEVİR TESLİM v14
## Tarih: 2026-03-16 | Versiyon: v14

---

## YENİ OTURUMA BAŞLARKEN

ZIP'i yükle ve şunu yaz:
> "DEVIR_TESLIM_v14.md'yi oku, kaldığın yerden devam et."

---

## BU OTURUMDA TAMAMLANANLAR (v13 → v14)

### MADDE 1 ✅ — TradesTable tarih kolonu
**Dosya:** `BacktestPanel.jsx`

- `fmtTradeDate(ts)` fonksiyonu eklendi — timestamp → "15 Mar 14:22" format
- `hasDate` kontrolü: `t.entryTime` alanı var mı dinamik kontrol
- `hasDate === true` ise 7 kolon: **Tarih | Yön | Çıkış | Giriş | Çıkış F. | P&L% | Süre**
- `hasDate === false` ise eski 6 kolon korunur (geri uyumluluk)
- `gridTemplateColumns` dinamik olarak hesaplanıyor
- Footer'da "• tarih" badge'i gösteriyor
- `backtestEngine.js`'in trade objelerine `entryTime` (timestamp) eklenirse otomatik açılır
- "Tümünü Gör" butonu düzeltildi (string concat hatası giderildi)

### MADDE 2 ✅ — backtestWorker Vite/CRA uyumu
**Dosya:** `backtestWorker.js`

- **3 kademeli fallback:**
  1. `new Worker(..., { type: 'module' })` — Vite + CRA webpack5
  2. `new Worker(...)` (classic) — CRA webpack4
  3. Main thread fallback — Worker hiç başlatılamazsa
- `IS_MODULE_WORKER` tespiti — `typeof importScripts === 'undefined'`
- ES module worker → `import('./backtestEngine.js')`
- Classic worker → `importScripts('./backtestEngine.js')` + `self.runBacktest` check
- `runBacktest` ile `runMultiPeriodBacktest` ikisini de destekler
- `_daysLabel()` helper eklendi

**Dosya:** `BacktestPanel.jsx`
- Worker başlatma: `type: 'module'` → catch → classic → catch → null fallback
- `console.info` ile hangi modun aktif olduğu loglanıyor
- `worker.terminate()` try/catch ile güvenli

### MADDE 3 ✅ — macroAPIEngine proxy güvenilirliği
**Dosya:** `macroAPIEngine.js`

- **3 proxy zinciri** (sırayla dener):
  1. `corsproxy.io` — daha hızlı ve güvenilir
  2. `allorigins.win` — eski fallback
  3. `api.codetabs.com` — üçüncü seçenek
- `_fetchWithProxies(url, timeoutMs)` — tüm proxy'leri iterate eden merkezi fetch
- `testProxies()` export edildi — Dashboard ayarlar panelinde kullanılabilir
- Promise.allSettled ile paralel DXY + US10Y çekme

### MADDE 4 ✅ — dipOnaylayici Dashboard entegrasyonu (YENİ ÖZELLİK)
**Dosya:** `Dashboard_v4.jsx` + **YENİ:** `DipOnayPanel.jsx`

**Dashboard değişiklikleri:**
- `import { runBottomConfirmation }` eklendi
- `import DipOnayPanel` eklendi
- `const [dipData, setDipData] = useState(null)` eklendi
- `runBottomConfirmation(results, { klineMap, obImbalance })` master council sonrası çalışıyor
- Sol panel LEFT_TABS'a `{ id: 'dip', label: '🎯 Dip Onay' }` eklendi
- `leftTab === 'dip'` sekmesi → `<DipOnayPanel dipData={dipData} loading={scanLoading} />`

**DipOnayPanel.jsx (yeni bileşen):**
- 3 sekme: **Onaylı** | **Şüpheli** | **Tümü**
- Her coin satırı: Sembol | Skor bar | Puan | Karar badge | RSI | 24s değişim
- Tıklanınca expand: 8 katman skoru grid + kritik uyarı + Fiyat/BB/VolZ detay
- En güçlü dip adayı header banner olarak gösterilir
- Loading skeleton + boş durum mesajları
- Footer'da katman listesi + timestamp

---

## DOSYA LİSTESİ (42 dosya — 1 yeni eklendi)

### YENİ
```
DipOnayPanel.jsx     — Dip onay sonuçlarını gösteren panel bileşeni
```

### GÜNCELLENENLER
```
BacktestPanel.jsx    — fmtTradeDate + tarih kolonu + Worker 3 kademeli fallback
backtestWorker.js    — Vite/CRA module+classic worker uyumu, _daysLabel helper
macroAPIEngine.js    — 3 proxy zinciri (corsproxy.io + allorigins + codetabs), testProxies()
Dashboard_v4.jsx     — dipOnaylayici entegrasyonu, DipOnayPanel sekmesi
```

### DEĞİŞMEYENLER
```
masterCouncil.js, pineEngine.js, GMGChart_v3.jsx
executionLayer.js, newsMacroCouncil.js, councilEngine.js
aiCouncilEngine.js, engineCore.js, intelligenceEngine.js
dipOnaylayici.js (motor değişmedi, sadece Dashboard bağlandı)
realDerivativesEngine.js, structureEngines.js
macroNewsEngines.js, alertMonitorEngines.js, indexEngine.js
exchangeAPI_multi.js, chartModule.js, moduleRegistry.js
ve diğer tüm v13 dosyaları
```

---

## SONRAKI OTURUMDA YAPILABİLECEKLER

### Teknik borç
1. **backtestEngine.js'e entryTime ekle** — Her trade objesine `entryTime: klines[entryBarIdx].ts` eklenirse TradesTable tarih kolonu otomatik açılır
2. **testProxies() UI** — Ayarlar veya debug paneline "Proxy Test" butonu ekle
3. **dipOnaylayici btcRsi** — `runBottomConfirmation` çağrısına gerçek BTC RSI geçilmeli (şu an 50 hardcode)

### Yeni özellikler
4. Kullanıcının yeni ekleme listesi bekleniyor

---

## KOD YAZIM KURALLARI

1. Tüm fonksiyonlar export edilmeli
2. Türkçe yorum satırları
3. clamp() ile 0-100 arası skor
4. Her modül { score, summary, timestamp } döndürür
5. Null-safe yazım (?. operatör)
6. Async/await ile API çağrıları
7. Her oturum sonunda ZIP yedek

Son güncelleme: 2026-03-16 | v14
Toplam dosya: 42 | Toplam satır: ~15.000+
