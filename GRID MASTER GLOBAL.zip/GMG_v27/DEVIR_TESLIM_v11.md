# GMG — DEVİR TESLİM v11
## Tarih: 2026-03-15 | Versiyon: v11 COMPLETE

---

## YENİ OTURUMA BAŞLARKEN

ZIP'i yükle ve şunu yaz:
> "DEVIR_TESLIM_v11.md'yi oku, kaldığın yerden devam et."

---

## DOSYA LİSTESİ (30 dosya)

### ANA ÇALIŞTIRICI
```
masterCouncil.js     — TÜM SİSTEMİ BAĞLAR
                       runMasterCouncil() → { action, label, score, councils, chartOverlay }
```

### GRAFİK
```
GMGChart_v3.jsx      — Ana grafik (1357 satır)
                       Pine RF + S/R + PB-AL/SAT + TP/SL + Mum renklendirme
                       pineData useMemo → filtLine, srZones, barColors
                       Props: symbol, onCouncilUpdate, chartOverlay, councilResult
```

### DASHBOARD
```
Dashboard_v4.jsx     — Ana dashboard (505 satır)
                       masterCouncil bağlı ✓ (runIntelligenceScan içinde)
                       LiveAICouncilPanel bağlı ✓
                       GMGChart bağlı ✓ (chartOverlay + councilResult prop geçiyor)
                       Sekmeler: ⚡ Master AI | Konseyler | Orderbook | Liq Radar
```

### KARAR MOTORları
```
pineEngine.js        — Pine Script v6 tam port (493 satır)
                       KLASİK/FİLTRELİ mod, trendUp düzeltmesi, GMG Council
                       TP1/TP2/SL, barColors, alarm mesajları
                       Export: runPineEngine(candles, params)

masterCouncil.js     — 5 Konsey + Execution Layer
executionLayer.js    — Tüm filtreler + veto mekanizması
newsMacroCouncil.js  — News & Macro async council
councilEngine.js     — Basit konsey motoru
aiCouncilEngine.js   — Detaylı AI konsey motoru
engineCore.js        — 16 tarayıcı + eski konsey
intelligenceEngine.js — 16 scan fonksiyonu
```

### YENİ MOTORLAR (bu oturumda eklendi)
```
multiAssetEngines.js — Forex + Emtia + Tahvil + TechnicalExt (490 satır)
                       runForexEngine(), runCommodityEngine(), runBondEngine()
                       runBOSDetector(), runCHoCHDetector()
                       runBuyWallDetector(), runSellWallDetector()
                       runSqueezeDetector(), runStealthTrendEngine()
                       runLongShortRatioEngine(), runTechnicalExtEngine()

backtestEngine.js    — Geçmiş test motoru
                       runBacktest(klines, params, config)
                       runMultiPeriodBacktest() → 1ay/3ay/6ay/1yıl

liveAIEngine.js      — Claude API canlı soru-cevap
                       askLiveAI({ question, symbol, masterResult })
                       autoMarketSummary({ masterResult, scanResults, symbol })
```

### PANELLER
```
LiveAICouncilPanel.jsx         — 5 konsey canlı panel ✓ (Dashboard'a bağlı)
WallAndAccumulationPanels.jsx  — LiquidityWallPanel + AccumulationPlanPanel
ForexAndMultiMarketPanels.jsx  — ForexPanel + MultiMarketPanel
CouncilPanel.jsx               — Eski konsey paneli
MarketIntelPanel.jsx           — 7 sekme (DİP ONAY sekmesi dahil)
LiquidityRadar.jsx             — Likidite radar
FundingPanel.jsx               — Funding + OI
MultiTimeframePanel.jsx        — MTF panel
```

### DİĞER MOTORLAR
```
dipOnaylayici.js        — 8 katmanlı dip onay motoru
realDerivativesEngine.js — Real OI + Funding + Likidasyon API
structureEngines.js     — BOS/CHoCH + S/R + Pullback Estimator
macroNewsEngines.js     — Macro Calendar + Central Bank + News Intel
alertMonitorEngines.js  — Alert + Telegram + Health + Logging
indexEngine.js          — VIX + Sector Rotation + Index Breadth
exchangeAPI_multi.js    — 7 borsa API + WebSocket
chartModule.js          — Pattern recognition
moduleRegistry.js       — 95 modül dağılımı
```

---

## KARAR AKIŞI

```
Borsa (7 adet) → exchangeAPI_multi.js
    ↓
intelligenceEngine.js → 16 tarayıcı → scanResults
    ↓
masterCouncil.js →
  ├── pineEngine.js        (Technical + Pine RF)
  ├── newsMacroCouncil.js  (News & Macro async)
  ├── runTechnicalCouncil  (RSI/MACD/EMA/BB/Pine)
  ├── runFlowCouncil       (OB/CVD/Liq)
  ├── runRiskCouncil       (Stop hunt/Vol/Veto)
  └── runAssetCouncil      (BTC Dom/Alt)
    ↓
executionLayer.js → BUY / SELL / WAIT
    ↓
Dashboard → LiveAICouncilPanel + GMGChart
```

---

## SONRAKI OTURUMDA YAPILACAKLAR

### ÖNCELİK 1 — Panelleri Dashboard'a bağla
```javascript
// Dashboard_v4.jsx içine ekle:
import { LiquidityWallPanel, AccumulationPlanPanel } from './WallAndAccumulationPanels';
import { ForexPanel, MultiMarketPanel } from './ForexAndMultiMarketPanels';

// LEFT_TABS'e ekle:
{ id: 'forex', label: 'Forex/Makro' }
{ id: 'accu',  label: 'Birikim' }

// RIGHT_TABS'e ekle:
{ id: 'multimarket', label: 'Piyasalar' }
```

### ÖNCELİK 2 — liveAIEngine Dashboard'a bağla
```javascript
import { askLiveAI, autoMarketSummary } from './liveAIEngine';

// State:
const [aiAnswer, setAiAnswer] = useState(null);
const [aiQuery, setAiQuery]   = useState('');

// Kullanım:
const ans = await askLiveAI({ question: aiQuery, symbol: selectedSymbol, masterResult });
setAiAnswer(ans);
```

### ÖNCELİK 3 — multiAssetEngines.js → masterCouncil entegrasyonu
```javascript
// masterCouncil.js içinde:
import { runForexEngine, runBondEngine, runTechnicalExtEngine } from './multiAssetEngines';

// runMasterCouncil içinde:
const forexData   = runForexEngine({ dxyData: { dxyLevel: 104 } });
const bondData    = runBondEngine({ yieldCurve: { us10y: 4.5 } });
const techExtData = runTechnicalExtEngine({ candles, orderbook, currentPrice: candles.slice(-1)[0]?.c });

// finalCouncil score'a ekle:
score += (forexData.score - 50) * 0.10;
score += (bondData.score - 50)  * 0.08;
```

### ÖNCELİK 4 — Telegram Alert bağlantısı
```javascript
// alertMonitorEngines.js içinde TelegramAlertEngine var
// Dashboard'da:
import { TelegramAlertEngine } from './alertMonitorEngines';
const telegram = new TelegramAlertEngine(BOT_TOKEN, CHAT_ID);
// masterResult.pineData.alerts.buy varsa:
if (masterResult?.pineData?.alerts?.buy) telegram.send(formatSignalMessage(...));
```

### ÖNCELİK 5 — Backtest UI
- `BacktestPanel.jsx` oluştur
- Kullanıcı zaman dilimi seçsin (1ay/3ay/6ay/1yıl)
- `runMultiPeriodBacktest()` çalıştır
- Sonuçları tablo + chart ile göster

---

## KOD YAZIM KURALLARI

1. Tüm fonksiyonlar export edilmeli
2. Türkçe yorum satırları
3. clamp() ile 0-100 arası skor
4. Her modül { score, summary, timestamp } döndürür
5. Null-safe yazım (?. operatör)
6. Async/await ile API çağrıları
7. Her oturum sonunda ZIP yedek

---

Son güncelleme: 2026-03-15 | v11
Toplam dosya: 30 | Toplam satır: ~12.500+
