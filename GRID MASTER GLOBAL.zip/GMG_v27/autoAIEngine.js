/**
 * GRID MASTER GLOBAL — AUTO AI ENGINE v1
 * ========================================
 * Her 5 dakikada otomatik piyasa özeti + seçili coin AI yorumu üretir.
 *
 * ÖZELLİKLER:
 *   - Otomatik zamanlayıcı (5dk/10dk/15dk aralık)
 *   - Genel piyasa risk özeti
 *   - Seçili coin otomatik yorumu
 *   - Son özeti önbellekle (tekrar istek önle)
 *   - Olay tetikli özet (büyük hareket algılandığında)
 */

import { clamp } from './engineCore.js';

// ─── SABİTLER ────────────────────────────────────────────────────────────────
const CLAUDE_API_URL = 'https://api.anthropic.com/v1/messages';
const CLAUDE_MODEL   = 'claude-sonnet-4-20250514';
const MAX_TOKENS     = 800;

const DEFAULT_INTERVAL_MS = 5 * 60 * 1000; // 5 dakika

// ─── DURUM ────────────────────────────────────────────────────────────────────
let _timerHandle    = null;
let _lastSummary    = null;
let _lastSummaryTs  = 0;
let _summaryCache   = new Map(); // symbol → son özet
let _subscribers    = [];        // Callback listesi

// ─── ABONE SİSTEMİ ───────────────────────────────────────────────────────────
/**
 * onSummary — Yeni özet gelince çağrılacak callback kaydet
 */
export function onSummary(callback) {
  _subscribers.push(callback);
  return () => { _subscribers = _subscribers.filter(cb => cb !== callback); }; // unsubscribe
}

function _notify(event) {
  _subscribers.forEach(cb => { try { cb(event); } catch(e) {} });
}

// ─── CLAUDE API ÇAĞRISI ───────────────────────────────────────────────────────
async function callClaude(prompt, systemMsg) {
  const res = await fetch(CLAUDE_API_URL, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model:      CLAUDE_MODEL,
      max_tokens: MAX_TOKENS,
      system:     systemMsg,
      messages:   [{ role: 'user', content: prompt }],
    }),
  });
  if (!res.ok) throw new Error(`API ${res.status}`);
  const data = await res.json();
  return data.content?.map(b => b.text || '').join('') || '';
}

// ─── PİYASA GENEL DURUMU PROMPT ──────────────────────────────────────────────
function buildMarketPrompt(marketSnapshot) {
  const {
    btcPrice, btcChange24h, ethChange24h,
    totalMarketCap, fearGreed,
    topMovers = [], councilAlerts = [],
  } = marketSnapshot || {};

  return `## PİYASA ANLIK DURUM (${new Date().toLocaleTimeString('tr-TR')})

**BTC:** $${btcPrice || '?'} (${btcChange24h >= 0 ? '+' : ''}${btcChange24h?.toFixed(2) || '?'}%)
**ETH:** ${ethChange24h >= 0 ? '+' : ''}${ethChange24h?.toFixed(2) || '?'}%
**Toplam Piyasa Değeri:** $${totalMarketCap || '?'}
**Fear & Greed:** ${fearGreed || '?'}

**En Çok Hareket Edenler:**
${topMovers.slice(0, 5).map(m => `- ${m.symbol}: ${m.change >= 0 ? '+' : ''}${m.change?.toFixed(2)}%`).join('\n') || '- Veri yok'}

**Aktif Council Uyarıları:**
${councilAlerts.slice(0, 3).map(a => `- ⚠️ ${a}`).join('\n') || '- Yok'}

Piyasa genel durumunu 3 cümlede özetle. Risk seviyesini belirt. Türkçe yaz.`;
}

// ─── TEK COIN ÖZET PROMPT ────────────────────────────────────────────────────
function buildCoinPrompt(symbol, coinData) {
  const { price, change24h, councilScore, action, rsi, volume24h } = coinData || {};

  return `## ${symbol} OTOMATİK ANALİZ

Fiyat: $${price || '?'} | 24s: ${change24h >= 0 ? '+' : ''}${change24h?.toFixed(2) || '?'}%
Council Skoru: ${councilScore || '?'}/100 | Sinyal: ${action || '?'}
RSI: ${rsi?.toFixed(1) || '?'} | Hacim: ${volume24h || '?'}

Bu coin için 2-3 cümle otomatik yorum yap. Spekülatif değil, veri bazlı. Türkçe.`;
}

// ─── PİYASA ÖZETİ ÜRET ───────────────────────────────────────────────────────
/**
 * generateMarketSummary — Genel piyasa özeti üret
 */
export async function generateMarketSummary(marketSnapshot = {}) {
  try {
    const prompt = buildMarketPrompt(marketSnapshot);
    const system = 'Sen GMG platformunun otomatik piyasa analiz motorusun. Kısa, net, Türkçe cevaplar ver.';
    const text   = await callClaude(prompt, system);

    const summary = {
      type:      'MARKET_SUMMARY',
      text,
      snapshot:  marketSnapshot,
      timestamp: new Date().toISOString(),
      score:     clamp(50 + (marketSnapshot.fearGreed > 50 ? 20 : -20)),
    };

    _lastSummary   = summary;
    _lastSummaryTs = Date.now();
    _notify(summary);
    return summary;

  } catch (e) {
    console.error('[AUTO AI] Market summary hatası:', e.message);
    return { type: 'MARKET_SUMMARY', error: e.message, timestamp: new Date().toISOString() };
  }
}

// ─── COIN ÖZETİ ÜRET ─────────────────────────────────────────────────────────
/**
 * generateCoinSummary — Belirli coin için otomatik AI yorumu
 */
export async function generateCoinSummary(symbol, coinData = {}) {
  // Önbellekte yeni özet var mı?
  const cached = _summaryCache.get(symbol);
  if (cached && Date.now() - cached.ts < 4 * 60 * 1000) {
    return { ...cached.data, fromCache: true };
  }

  try {
    const prompt = buildCoinPrompt(symbol, coinData);
    const system = 'Sen GMG kripto analiz asistanısın. Kısa, somut, Türkçe yorum yap.';
    const text   = await callClaude(prompt, system);

    const summary = {
      type:      'COIN_SUMMARY',
      symbol,
      text,
      data:      coinData,
      timestamp: new Date().toISOString(),
    };

    _summaryCache.set(symbol, { data: summary, ts: Date.now() });
    _notify(summary);
    return summary;

  } catch (e) {
    console.error('[AUTO AI] Coin summary hatası:', e.message);
    return { type: 'COIN_SUMMARY', symbol, error: e.message, timestamp: new Date().toISOString() };
  }
}

// ─── OLAY TETİKLİ ÖZET ───────────────────────────────────────────────────────
/**
 * triggerEventSummary — Büyük hareket / alarm durumunda anlık özet
 *
 * @param {string} eventType — 'PRICE_SPIKE' | 'COUNCIL_ALERT' | 'LIQUIDATION'
 * @param {object} eventData — { symbol, change, description }
 */
export async function triggerEventSummary(eventType, eventData = {}) {
  const { symbol = '', change = 0, description = '' } = eventData;

  const prompt = `OLAY: ${eventType}
Sembol: ${symbol} | Değişim: ${change >= 0 ? '+' : ''}${change?.toFixed(2)}%
Açıklama: ${description}

Bu olayı 2 cümlede yorumla ve trader'a ne yapması gerektiğini söyle. Türkçe.`;

  try {
    const system = 'GMG acil uyarı analistisisin. Kısa, net, önemli bilgi ver.';
    const text   = await callClaude(prompt, system);

    const event = {
      type:      'EVENT_SUMMARY',
      eventType,
      symbol,
      text,
      data:      eventData,
      timestamp: new Date().toISOString(),
      urgent:    true,
    };

    _notify(event);
    return event;

  } catch (e) {
    return { type: 'EVENT_SUMMARY', eventType, error: e.message, timestamp: new Date().toISOString() };
  }
}

// ─── OTOMATİK ZAMANLAYICI ────────────────────────────────────────────────────
/**
 * startAutoSummary — Otomatik piyasa özeti zamanlayıcısını başlat
 *
 * @param {function} getMarketSnapshot — Her çalıştığında piyasa verisi çeken fonksiyon
 * @param {number}   intervalMs        — Kaç ms'de bir (default: 5dk)
 */
export function startAutoSummary(getMarketSnapshot, intervalMs = DEFAULT_INTERVAL_MS) {
  if (_timerHandle) {
    console.warn('[AUTO AI] Zamanlayıcı zaten çalışıyor, durdurulup yeniden başlatılıyor...');
    stopAutoSummary();
  }

  console.log(`[AUTO AI] Otomatik özet başlatıldı — ${intervalMs / 60000}dk aralık`);

  // İlk özeti hemen üret
  getMarketSnapshot().then(snap => generateMarketSummary(snap)).catch(e => console.error(e));

  _timerHandle = setInterval(async () => {
    try {
      const snap = await getMarketSnapshot();
      await generateMarketSummary(snap);
    } catch (e) {
      console.error('[AUTO AI] Zamanlayıcı hatası:', e.message);
    }
  }, intervalMs);

  return _timerHandle;
}

/**
 * stopAutoSummary — Zamanlayıcıyı durdur
 */
export function stopAutoSummary() {
  if (_timerHandle) {
    clearInterval(_timerHandle);
    _timerHandle = null;
    console.log('[AUTO AI] Zamanlayıcı durduruldu');
  }
}

// ─── SON ÖZET AL ─────────────────────────────────────────────────────────────
/**
 * getLastSummary — En son üretilen piyasa özetini döndür
 */
export function getLastSummary() {
  return _lastSummary;
}

/**
 * getLastCoinSummary — Symbol için önbellekteki son özeti döndür
 */
export function getLastCoinSummary(symbol) {
  const cached = _summaryCache.get(symbol);
  return cached ? cached.data : null;
}

/**
 * clearSummaryCache — Önbelleği temizle
 */
export function clearSummaryCache(symbol = null) {
  if (symbol) _summaryCache.delete(symbol);
  else _summaryCache.clear();
}

// ─── DURUM RAPORU ────────────────────────────────────────────────────────────
export function getAutoAIStatus() {
  return {
    running:          !!_timerHandle,
    lastSummaryAge:   _lastSummaryTs ? Math.round((Date.now() - _lastSummaryTs) / 1000) : null,
    cachedCoins:      [..._summaryCache.keys()],
    subscriberCount:  _subscribers.length,
    timestamp:        new Date().toISOString(),
  };
}
