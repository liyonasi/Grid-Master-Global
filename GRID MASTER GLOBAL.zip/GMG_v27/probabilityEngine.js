/**
 * GRID MASTER GLOBAL — PROBABILITY & SIGNAL CONFIDENCE ENGINE v1
 * ================================================================
 * PROBABILITY ENGINE      — Sinyalin gerçekleşme olasılığını hesaplar
 * SIGNAL CONFIDENCE ENGINE — Sinyalin güven yüzdesini hesaplar
 *
 * Her iki motor da Council çıktılarını, geçmiş başarı oranlarını ve
 * piyasa koşullarını birleştirerek nihai güven/olasılık değeri üretir.
 */

import { clamp } from './engineCore.js';

// ═══════════════════════════════════════════════════════════════════════════════
// 1. PROBABILITY ENGINE
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * PROBABILITY ENGINE
 * ------------------
 * Verilen sinyalin TP'ye ulaşma olasılığını hesaplar.
 *
 * Faktörler:
 *   - Council konsensüs gücü
 *   - Piyasa rejimi (trend/yatay/dönüş)
 *   - Volatilite seviyesi
 *   - Geçmiş benzer koşullarda başarı oranı
 *   - Risk/Ödül oranı
 *
 * @param {object} params
 *   councilScores    — { alpha, flow, risk, macro } (0-100)
 *   marketRegime     — 'TREND' | 'SIDEWAYS' | 'REVERSAL' | 'VOLATILE'
 *   riskReward       — TP/SL oranı (örn: 2.0 = 1:2)
 *   volRegime        — 'LOW' | 'NORMAL' | 'HIGH' | 'EXTREME'
 *   historicalWinRate — Geçmiş benzer koşullarda WR (0-1, opsiyonel)
 *   action           — 'AL' | 'SAT' | 'BEKLE'
 */
export function runProbabilityEngine({
  councilScores    = {},
  marketRegime     = 'SIDEWAYS',
  riskReward       = 1.5,
  volRegime        = 'NORMAL',
  historicalWinRate = null,
  action           = 'BEKLE',
} = {}) {

  const { alpha = 50, flow = 50, risk = 50, macro = 50 } = councilScores;

  // ── Temel olasılık: Konsensüs gücü ──
  const avgScore    = (alpha + flow + risk + macro) / 4;
  let   baseProbPct = avgScore; // 0-100 → direkt başlangıç

  // ── Piyasa rejimi çarpanı ──
  const regimeMult = {
    TREND:    action === 'AL' ? 1.15 : 0.90,
    SIDEWAYS: 0.95,
    REVERSAL: action === 'AL' ? 1.05 : 0.85,
    VOLATILE: 0.80,
  }[marketRegime] ?? 1.0;

  baseProbPct *= regimeMult;

  // ── Volatilite ayarı ──
  const volAdj = { LOW: +5, NORMAL: 0, HIGH: -8, EXTREME: -18 }[volRegime] ?? 0;
  baseProbPct += volAdj;

  // ── Risk/Ödül düzeltmesi (RR > 2 → güvenilir sinyal = daha yüksek seçicilik) ──
  if (riskReward >= 3)     baseProbPct += 4;
  else if (riskReward < 1) baseProbPct -= 10; // Düşük RR = kötü set-up

  // ── Geçmiş WR etkisi ──
  if (historicalWinRate !== null) {
    const histAdj = (historicalWinRate * 100 - 50) * 0.3;
    baseProbPct  += histAdj;
  }

  // ── Risk konseyi veto cezası ──
  if (risk < 40) baseProbPct -= 15;

  const probability = clamp(Math.round(baseProbPct));

  // ── Beklenen değer (EV) hesabı ──
  // EV = P(win)*RR - P(loss)*1
  const pWin  = probability / 100;
  const pLoss = 1 - pWin;
  const ev    = parseFloat((pWin * riskReward - pLoss * 1).toFixed(3));

  // ── Olasılık etiketi ──
  const label = probability >= 70 ? 'YÜKSEK OLASILIK' :
                probability >= 55 ? 'ORTA OLASILIK'   :
                probability >= 40 ? 'DÜŞÜK OLASILIK'  : 'ÇOK DÜŞÜK';

  const bands = [
    { min: 70, label: '🟢 İdeal set-up'        },
    { min: 55, label: '🟡 Kabul edilebilir'    },
    { min: 40, label: '🟠 Riskli — küçük pozisyon' },
    { min: 0,  label: '🔴 Geç — sinyal zayıf'  },
  ];
  const band = bands.find(b => probability >= b.min)?.label || '🔴 Geç';

  return {
    score:       probability,
    probability, // Alias
    ev,
    evPositive:  ev > 0,
    label,
    band,
    breakdown: {
      avgScore:  parseFloat(avgScore.toFixed(1)),
      regimeMult,
      volAdj,
      historicalWinRate,
    },
    summary:     `${label} (%${probability}) | EV: ${ev > 0 ? '+' : ''}${ev}`,
    timestamp:   new Date().toISOString(),
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// 2. SIGNAL CONFIDENCE ENGINE
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * SIGNAL CONFIDENCE ENGINE
 * -------------------------
 * Sinyalin ne kadar "emin" verildiğini ölçer.
 * Olasılıktan farkı: Güven = konsensüs kalitesi, hizalama, çelişki yokluğu.
 *
 * Faktörler:
 *   - Konsey oybirliği (4/4 mu, 3/4 mü?)
 *   - Sinyal-skor uzaklığı (50'den ne kadar uzak?)
 *   - Zaman dilimi uyumu (MTF)
 *   - Manipülasyon riski yokluğu
 *   - Exchange anomalisi yokluğu
 *
 * @param {object} params
 *   councilScores      — { alpha, flow, risk, macro }
 *   finalScore         — Nihai ağırlıklı skor
 *   timeframeAlignment — 'FULL' | 'PARTIAL' | 'CONFLICT'
 *   exchangeAnomaly    — boolean
 *   stopHuntRisk       — 0-100
 *   approvedProtocol   — boolean (5 koşul geçildi mi?)
 */
export function runSignalConfidenceEngine({
  councilScores      = {},
  finalScore         = 50,
  timeframeAlignment = 'PARTIAL',
  exchangeAnomaly    = false,
  stopHuntRisk       = 20,
  approvedProtocol   = false,
} = {}) {

  const { alpha = 50, flow = 50, risk = 50, macro = 50 } = councilScores;
  const scores = [alpha, flow, risk, macro];

  let confidence = 30; // Başlangıç tabanı
  const factors  = [];

  // ── 1. Konsey hizalaması ──
  const aligned   = scores.filter(s => s >= 55).length;
  const misaligned = scores.filter(s => s < 40).length;
  if (aligned === 4)      { confidence += 30; factors.push('Tam oybirliği (4/4) +30'); }
  else if (aligned === 3) { confidence += 18; factors.push('Güçlü çoğunluk (3/4) +18'); }
  else if (aligned === 2) { confidence += 8;  factors.push('Bölünmüş konsey (2/4) +8'); }
  else                    { confidence -= 10; factors.push('Konsensüs yok -10'); }

  if (misaligned >= 2)    { confidence -= 12; factors.push('2+ konsey karşı -12'); }

  // ── 2. Sinyal gücü (50'den uzaklık) ──
  const dist = Math.abs(finalScore - 50);
  if (dist >= 25)         { confidence += 20; factors.push(`Güçlü sinyal (${finalScore}/100) +20`); }
  else if (dist >= 15)    { confidence += 12; factors.push(`Belirgin sinyal +12`); }
  else if (dist >= 8)     { confidence += 5; }
  else                    { confidence -= 5;  factors.push('Skor 50\'ye çok yakın -5'); }

  // ── 3. Zaman dilimi uyumu ──
  if (timeframeAlignment === 'FULL')     { confidence += 15; factors.push('Tam MTF uyumu +15'); }
  else if (timeframeAlignment === 'PARTIAL') { confidence += 5; }
  else                                   { confidence -= 10; factors.push('MTF çelişkili -10'); }

  // ── 4. Exchange anomalisi ──
  if (exchangeAnomaly)    { confidence -= 25; factors.push('Exchange anomali aktif -25'); }

  // ── 5. Stop hunt riski ──
  if (stopHuntRisk >= 70) { confidence -= 20; factors.push(`Stop hunt riski yüksek (%${stopHuntRisk}) -20`); }
  else if (stopHuntRisk >= 45) { confidence -= 10; }

  // ── 6. Protokol onayı ──
  if (approvedProtocol)   { confidence += 10; factors.push('5 koşul onaylandı +10'); }

  confidence = clamp(confidence);

  // ── Etiket ve renk ──
  const label = confidence >= 75 ? 'ÇOK GÜVENİLİR' :
                confidence >= 60 ? 'GÜVENİLİR'     :
                confidence >= 45 ? 'ORTA GÜVENİLİR':
                confidence >= 30 ? 'ZAYIF'          : 'GÜVENSİZ';

  const color = confidence >= 75 ? '#00ff88' :
                confidence >= 60 ? '#88ff44' :
                confidence >= 45 ? '#ffcc00' :
                confidence >= 30 ? '#ff8844' : '#ff3366';

  return {
    score:      confidence,
    confidence, // Alias
    label,
    color,
    factors,
    approved:   confidence >= 60,
    breakdown: {
      aligned,
      misaligned,
      signalDist: dist,
      timeframeAlignment,
      exchangeAnomaly,
      stopHuntRisk,
    },
    summary:    `${label} (%${confidence}) — ${factors.length} faktör değerlendirildi`,
    timestamp:  new Date().toISOString(),
  };
}

// ─── BİRLEŞİK SKOR ───────────────────────────────────────────────────────────
/**
 * getCombinedProbConf — Hem olasılık hem güveni tek çağrıda hesapla
 */
export function getCombinedProbConf(params) {
  const prob = runProbabilityEngine(params);
  const conf = runSignalConfidenceEngine(params);

  // Bileşik karar puanı: %60 güven + %40 olasılık
  const composite = clamp(Math.round(conf.confidence * 0.6 + prob.probability * 0.4));

  return {
    probability: prob,
    confidence:  conf,
    composite,
    compositeLabel: composite >= 70 ? '✅ AL — Güçlü set-up' :
                    composite >= 55 ? '🟡 AL — Dikkatli'    :
                    composite >= 40 ? '⏳ BEKLE'             : '❌ GEÇME',
    score:    composite,
    summary:  `Olasılık:%${prob.probability} | Güven:%${conf.confidence} | Bileşik:%${composite}`,
    timestamp: new Date().toISOString(),
  };
}
