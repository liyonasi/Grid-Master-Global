/**
 * GMG — BACKTEST PANEL
 * ====================
 * Geçmiş test sonuçlarını gösterir.
 * runMultiPeriodBacktest() çıktısını tablo + mini equity curve ile sunar.
 *
 * Props:
 *   symbol        — seçili coin
 *   klines        — OHLCV dizisi (backtestEngine'e gönderilir)
 *   masterResult  — masterCouncil çıktısı (pineParams için)
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
// runMultiPeriodBacktest artık Web Worker üzerinden çalışır (UI bloklanmaz)
// import { runMultiPeriodBacktest } from './backtestEngine'; // Worker fallback olarak korundu

// ─── YARDIMCI ─────────────────────────────────────────────────────────────────

function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }

function ColorBadge({ value, suffix = '%', goodAbove = 0 }) {
  const good = value > goodAbove;
  const color = value === 0 ? '#888' : good ? '#00ff88' : '#ff4466';
  return (
    <span className="font-mono font-bold text-[11px]" style={{ color }}>
      {value > 0 && good ? '+' : ''}{value}{suffix}
    </span>
  );
}

// Mini equity eğrisi SVG
function EquityCurve({ trades, w = 160, h = 40 }) {
  if (!trades?.length) return null;

  let cap = 10000;
  const points = [cap];
  for (const t of trades) {
    cap += t.pnl;
    points.push(cap);
  }

  const mn = Math.min(...points);
  const mx = Math.max(...points);
  const range = mx - mn || 1;

  const pts = points.map((v, i) => {
    const x = (i / (points.length - 1)) * w;
    const y = h - ((v - mn) / range) * (h - 4) - 2;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(' ');

  const isProfit = points[points.length - 1] >= points[0];
  const lineColor = isProfit ? '#00ff88' : '#ff4466';

  return (
    <svg width={w} height={h} style={{ overflow: 'visible' }}>
      <polyline
        points={pts}
        fill="none"
        stroke={lineColor}
        strokeWidth="1.5"
        opacity="0.8"
      />
      {/* Başlangıç çizgisi */}
      <line
        x1="0" y1={h - ((points[0] - mn) / range) * (h - 4) - 2}
        x2={w} y2={h - ((points[0] - mn) / range) * (h - 4) - 2}
        stroke="#ffffff15" strokeWidth="0.5" strokeDasharray="3,3"
      />
    </svg>
  );
}

// ─── BÜYÜK EQUİTY CURVE (genişletilmiş) ──────────────────────────────────────
function EquityCurveLarge({ trades, initialCapital = 10000 }) {
  const [hovered, setHovered] = React.useState(null);
  if (!trades?.length) return null;

  const W = 440, H = 120, PAD = 8;

  let cap = initialCapital;
  const points = [{ cap, idx: 0, trade: null }];
  trades.forEach((t, i) => {
    cap += t.pnl || 0;
    points.push({ cap, idx: i + 1, trade: t });
  });

  const mn  = Math.min(...points.map(p => p.cap));
  const mx  = Math.max(...points.map(p => p.cap));
  const rng = mx - mn || 1;

  const toX = (i) => PAD + (i / (points.length - 1)) * (W - PAD * 2);
  const toY = (v) => H - PAD - ((v - mn) / rng) * (H - PAD * 2);

  const polyline = points.map(p => `${toX(p.idx).toFixed(1)},${toY(p.cap).toFixed(1)}`).join(' ');
  const fillPoly = `${toX(0)},${H} ` + polyline + ` ${toX(points.length-1)},${H}`;

  const finalCap    = points[points.length - 1].cap;
  const totalReturn = ((finalCap - initialCapital) / initialCapital * 100).toFixed(1);
  const isProfit    = finalCap >= initialCapital;
  const lineColor   = isProfit ? '#00ff88' : '#ff4466';
  const fillColor   = isProfit ? '#00ff8808' : '#ff446608';

  // Drawdown hesapla
  let peak = initialCapital, maxDD = 0;
  points.forEach(p => {
    if (p.cap > peak) peak = p.cap;
    const dd = (peak - p.cap) / peak * 100;
    if (dd > maxDD) maxDD = dd;
  });

  return (
    <div style={{ background:'#06060e', border:'1px solid #1a1a2e', borderRadius:6, padding:'8px 10px', marginTop:8 }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:6 }}>
        <span style={{ fontSize:9, color:'#404070', letterSpacing:1 }}>EQUİTY CURVE</span>
        <div style={{ display:'flex', gap:10 }}>
          <span style={{ fontSize:9, color: isProfit ? '#00ff88' : '#ff4466', fontFamily:'monospace', fontWeight:700 }}>
            {isProfit ? '+' : ''}{totalReturn}%
          </span>
          <span style={{ fontSize:8, color:'#404060', fontFamily:'monospace' }}>
            DD: {maxDD.toFixed(1)}%
          </span>
          <span style={{ fontSize:8, color:'#404060', fontFamily:'monospace' }}>
            ${finalCap.toFixed(0)}
          </span>
        </div>
      </div>
      <svg width={W} height={H} style={{ display:'block', cursor:'crosshair' }}
        onMouseLeave={() => setHovered(null)}
        onMouseMove={(e) => {
          const rect = e.currentTarget.getBoundingClientRect();
          const x = e.clientX - rect.left - PAD;
          const idx = Math.round(x / (W - PAD*2) * (points.length - 1));
          const p = points[Math.max(0, Math.min(idx, points.length-1))];
          setHovered(p);
        }}>
        {/* Arka plan grid */}
        {[0.25, 0.5, 0.75].map(f => (
          <line key={f} x1={PAD} y1={PAD + f*(H-PAD*2)} x2={W-PAD} y2={PAD + f*(H-PAD*2)}
            stroke="#0a0a1e" strokeWidth="1" />
        ))}
        {/* Sıfır çizgisi */}
        <line x1={PAD} y1={toY(initialCapital)} x2={W-PAD} y2={toY(initialCapital)}
          stroke="#ffffff15" strokeWidth="0.8" strokeDasharray="4,4" />
        {/* Fill */}
        <polygon points={fillPoly} fill={fillColor} />
        {/* Curve */}
        <polyline points={polyline} fill="none" stroke={lineColor} strokeWidth="1.5" />
        {/* Win/Loss noktaları */}
        {points.filter(p => p.trade).map((p, i) => (
          <circle key={i} cx={toX(p.idx)} cy={toY(p.cap)} r="2"
            fill={p.trade.pnlPct > 0 ? '#00ff8880' : '#ff446680'}
            stroke="none" />
        ))}
        {/* Hover crosshair */}
        {hovered && (
          <>
            <line x1={toX(hovered.idx)} y1={PAD} x2={toX(hovered.idx)} y2={H-PAD}
              stroke="#ffffff20" strokeWidth="1" strokeDasharray="2,2" />
            <circle cx={toX(hovered.idx)} cy={toY(hovered.cap)} r="4"
              fill={lineColor} stroke="#050505" strokeWidth="1.5" />
            <rect x={Math.min(toX(hovered.idx)+6, W-90)} y={toY(hovered.cap)-18}
              width={82} height={28} rx={3} fill="#0a0a1e" stroke="#1a1a2e" strokeWidth="1" />
            <text x={Math.min(toX(hovered.idx)+10, W-86)} y={toY(hovered.cap)-6}
              fill="#9090c0" fontSize="7" fontFamily="monospace">
              ${hovered.cap.toFixed(0)} ({hovered.idx}/{points.length-1})
            </text>
            <text x={Math.min(toX(hovered.idx)+10, W-86)} y={toY(hovered.cap)+6}
              fill={hovered.trade?.pnlPct > 0 ? '#00ff88' : hovered.trade ? '#ff4466' : '#404070'}
              fontSize="7" fontFamily="monospace">
              {hovered.trade ? `${hovered.trade.pnlPct > 0 ? '+' : ''}${hovered.trade.pnlPct?.toFixed(2)}%` : 'Başlangıç'}
            </text>
          </>
        )}
      </svg>
    </div>
  );
}

// ─── TAM İŞLEM TABLOSU ───────────────────────────────────────────────────────
// ─── TARİH FORMATLAYICI ───────────────────────────────────────────────────────
function fmtTradeDate(ts) {
  if (!ts) return null;
  const d = new Date(typeof ts === 'number' ? ts : Date.parse(ts));
  if (isNaN(d.getTime())) return null;
  // "15 Mar 14:22" formatı
  const day   = d.getDate().toString().padStart(2, '0');
  const month = ['Oca','Şub','Mar','Nis','May','Haz','Tem','Ağu','Eyl','Eki','Kas','Ara'][d.getMonth()];
  const hh    = d.getHours().toString().padStart(2, '0');
  const mm    = d.getMinutes().toString().padStart(2, '0');
  return `${day} ${month} ${hh}:${mm}`;
}

function TradesTable({ trades }) {
  const [showAll, setShowAll]   = useState(false);
  const [filter, setFilter]     = useState('all'); // 'all' | 'win' | 'loss' | 'long' | 'short'

  const filtered = [...trades].reverse().filter(t => {
    if (filter === 'win')   return t.pnlPct > 0;
    if (filter === 'loss')  return t.pnlPct <= 0;
    if (filter === 'long')  return t.direction === 'LONG';
    if (filter === 'short') return t.direction === 'SHORT';
    return true;
  });
  const sorted  = filtered;
  const visible = showAll ? sorted : sorted.slice(0, 10);
  const hasMore = sorted.length > 10;

  // İstatistik özeti
  const wins   = trades.filter(t => t.pnlPct > 0);
  const losses = trades.filter(t => t.pnlPct <= 0);
  const avgWin  = wins.length   ? (wins.reduce((s,t)   => s + t.pnlPct, 0) / wins.length).toFixed(2)   : 0;
  const avgLoss = losses.length ? (losses.reduce((s,t) => s + t.pnlPct, 0) / losses.length).toFixed(2) : 0;

  // entryTime alanı var mı kontrol et (tarih kolonunu sadece varsa göster)
  const hasDate  = sorted.some(t => t.entryTime != null);

  // gridTemplateColumns: tarih varsa 7 kolon, yoksa 6 kolon
  const cols = hasDate
    ? '56px 40px 40px 58px 52px 46px 38px'   // Tarih | Yön | Çıkış | Giriş | Çıkış F. | P&L% | Süre
    : '40px 40px 60px 55px 50px 40px';         // mevcut 6 kolon
  const headers = hasDate
    ? ['Tarih', 'Yön', 'Çıkış', 'Giriş', 'Çıkış F.', 'P&L%', 'Süre']
    : ['Yön', 'Çıkış', 'Giriş', 'Çıkış F.', 'P&L%', 'Süre'];

  return (
    <div>
      {/* İstatistik özeti */}
      <div style={{ display:'flex', gap:6, marginBottom:5, flexWrap:'wrap' }}>
        {[
          { label:'Tümü', val:'all', count: trades.length, color:'#6060a0' },
          { label:'Kazanç', val:'win', count: wins.length, color:'#00ff88' },
          { label:'Kayıp', val:'loss', count: losses.length, color:'#ff4466' },
          { label:'Long', val:'long', count: trades.filter(t=>t.direction==='LONG').length, color:'#00aaff' },
          { label:'Short', val:'short', count: trades.filter(t=>t.direction==='SHORT').length, color:'#ff8800' },
        ].map(f => (
          <button key={f.val} onClick={() => { setFilter(f.val); setShowAll(false); }}
            style={{ fontSize:7, padding:'1px 6px', borderRadius:3, cursor:'pointer', fontFamily:'monospace',
              background: filter===f.val ? `${f.color}20` : 'transparent',
              border: `1px solid ${filter===f.val ? f.color+'60' : '#1a1a2e'}`,
              color: filter===f.val ? f.color : '#404060' }}>
            {f.label} ({f.count})
          </button>
        ))}
        <span style={{ marginLeft:'auto', fontSize:7, color:'#2a2a4a', fontFamily:'monospace', alignSelf:'center' }}>
          Ort.Kazanç: <span style={{color:'#00ff88'}}>+{avgWin}%</span>
          {' · '}Ort.Kayıp: <span style={{color:'#ff4466'}}>{avgLoss}%</span>
        </span>
      </div>
      <div className="flex items-center justify-between mb-1">
        <span className="text-[8px] font-mono text-gray-600">
          {sorted.length}/{trades.length} işlem
          {hasDate && <span className="ml-1 text-[#333355]">• tarih</span>}
        </span>
        {hasMore && (
          <button
            onClick={() => setShowAll(v => !v)}
            className="text-[8px] font-mono text-[#00aaff] hover:text-[#44ccff] transition-colors"
          >
            {showAll ? '▲ Küçült' : `Tümünü Gör (${sorted.length})`}
          </button>
        )}
      </div>

      {/* Başlık */}
      <div className="grid gap-0 mb-0.5" style={{ gridTemplateColumns: cols }}>
        {headers.map(h => (
          <span key={h} className="text-[7px] font-mono text-gray-700 text-center">{h}</span>
        ))}
      </div>

      {/* Satırlar */}
      <div style={{ maxHeight: showAll ? '320px' : 'auto', overflowY: showAll ? 'auto' : 'visible' }}>
        {visible.map((t, i) => {
          const isLong   = t.direction === 'LONG';
          const isWin    = t.pnlPct > 0;
          const dirCol   = isLong ? '#00aaff' : '#ff6688';
          const pnlCol   = isWin  ? '#00ff88' : '#ff4466';
          const bars     = t.barsHeld ?? '—';
          const dateStr  = hasDate ? fmtTradeDate(t.entryTime) : null;

          return (
            <div
              key={i}
              className="grid py-0.5 border-b border-[#0d0d1a] hover:bg-[#0a0a1c] transition-colors"
              style={{ gridTemplateColumns: cols }}
            >
              {/* Tarih kolonu — sadece entryTime varsa */}
              {hasDate && (
                <span className="text-[7px] font-mono text-center text-gray-600 leading-tight">
                  {dateStr ?? '—'}
                </span>
              )}
              <span className="text-[8px] font-mono text-center" style={{ color: dirCol }}>
                {isLong ? '▲ L' : '▼ S'}
              </span>
              <span className="text-[8px] font-mono text-center text-gray-500">
                {t.exitReason || '—'}
              </span>
              <span className="text-[8px] font-mono text-center text-gray-500">
                {t.entry ? t.entry.toFixed(2) : '—'}
              </span>
              <span className="text-[8px] font-mono text-center text-gray-500">
                {t.exitPrice ? t.exitPrice.toFixed(2) : '—'}
              </span>
              <span className="text-[8px] font-mono text-center font-bold" style={{ color: pnlCol }}>
                {isWin ? '+' : ''}{t.pnlPct ?? 0}%
              </span>
              <span className="text-[8px] font-mono text-center text-gray-700">
                {bars}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── MULTI-PERIOD KARŞILAŞTIRMA GRAFİĞİ ─────────────────────────────────────
// 4 dönemin equity curve'lerini aynı SVG'de normalize edilmiş olarak gösterir.
// Her dönem farklı renk — hover ile dönem adı + ROI gösterilir.

function MultiPeriodComparisonChart({ periods = {}, initialCapital = 10000 }) {
  const [hovered, setHovered] = React.useState(null); // { periodKey, pointIdx, x, y, cap, roi }

  const W = 440, H = 140, PAD = { top: 20, right: 80, bottom: 22, left: 36 };
  const CW = W - PAD.left - PAD.right;
  const CH = H - PAD.top - PAD.bottom;

  const COLORS = {
    '1 Ay':  '#00e87a',
    '3 Ay':  '#00aaff',
    '6 Ay':  '#ffc800',
    '1 Yıl': '#ff335c',
  };
  const DEFAULT_COLORS = ['#00e87a','#00aaff','#ffc800','#ff335c','#aa66ff'];

  // Her dönem için normalize equity serisi üret (% bazlı, 0 = başlangıç)
  const series = Object.entries(periods)
    .filter(([, r]) => r?.trades?.length > 0)
    .map(([label, r], ci) => {
      let cap = initialCapital;
      const pts = [0]; // % değişim
      r.trades.forEach(t => {
        cap += t.pnl || 0;
        pts.push(((cap - initialCapital) / initialCapital) * 100);
      });
      return {
        label,
        pts,
        color: COLORS[label] || DEFAULT_COLORS[ci % DEFAULT_COLORS.length],
        finalRoi: r.stats?.roi || 0,
        winRate: r.stats?.winRate || 0,
      };
    });

  if (series.length === 0) return null;

  // Tüm serilerin min/max ROI'sunu bul
  const allVals = series.flatMap(s => s.pts);
  const minV = Math.min(0, ...allVals);
  const maxV = Math.max(0, ...allVals);
  const range = maxV - minV || 1;

  const toX = (i, total) => PAD.left + (i / Math.max(total - 1, 1)) * CW;
  const toY = (v) => PAD.top + CH - ((v - minV) / range) * CH;
  const zeroY = toY(0);

  return (
    <div style={{ background: '#07070f', border: '1px solid #0f0f22', borderRadius: 8, padding: '10px 12px', marginBottom: 8 }}>
      {/* Başlık + legend */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
        <span style={{ fontSize: 8, fontFamily: 'monospace', fontWeight: 700, letterSpacing: 2, color: '#2a2a50', textTransform: 'uppercase' }}>
          Dönem Karşılaştırması
        </span>
        <div style={{ display: 'flex', gap: 8 }}>
          {series.map(s => (
            <div key={s.label} style={{ display: 'flex', alignItems: 'center', gap: 3 }}>
              <div style={{ width: 16, height: 2, borderRadius: 1, background: s.color }} />
              <span style={{ fontSize: 8, fontFamily: 'monospace', color: s.color }}>
                {s.label} {s.finalRoi >= 0 ? '+' : ''}{s.finalRoi.toFixed(1)}%
              </span>
            </div>
          ))}
        </div>
      </div>

      <svg width={W} height={H} style={{ display: 'block', cursor: 'crosshair', overflow: 'visible' }}
        onMouseLeave={() => setHovered(null)}
        onMouseMove={(e) => {
          const rect = e.currentTarget.getBoundingClientRect();
          const mx = e.clientX - rect.left;
          // En yakın seri noktasını bul
          let best = null, bestDist = Infinity;
          series.forEach(s => {
            const xi = Math.round((mx - PAD.left) / CW * (s.pts.length - 1));
            const idx = Math.max(0, Math.min(xi, s.pts.length - 1));
            const px = toX(idx, s.pts.length);
            const dist = Math.abs(mx - px);
            if (dist < bestDist) {
              bestDist = dist;
              best = { ...s, pointIdx: idx, x: px, y: toY(s.pts[idx]), roi: s.pts[idx] };
            }
          });
          if (best) setHovered(best);
        }}>

        {/* Grid yatay çizgiler */}
        {[-15, -10, -5, 0, 5, 10, 15, 20, 25].filter(v => v >= minV - 2 && v <= maxV + 2).map(v => (
          <g key={v}>
            <line x1={PAD.left} y1={toY(v)} x2={W - PAD.right} y2={toY(v)}
              stroke={v === 0 ? '#ffffff18' : '#0a0a1c'} strokeWidth={v === 0 ? 1 : 0.5}
              strokeDasharray={v === 0 ? '4,4' : '2,4'} />
            <text x={PAD.left - 3} y={toY(v) + 3} textAnchor="end"
              fill="#1e1e38" fontSize="7" fontFamily="monospace">
              {v > 0 ? '+' : ''}{v}%
            </text>
          </g>
        ))}

        {/* Her dönem için equity curve */}
        {series.map(s => {
          const poly = s.pts.map((v, i) => `${toX(i, s.pts.length).toFixed(1)},${toY(v).toFixed(1)}`).join(' ');
          const fillPts = `${toX(0, s.pts.length)},${zeroY} ${poly} ${toX(s.pts.length - 1, s.pts.length)},${zeroY}`;
          const isHov = hovered?.label === s.label;
          return (
            <g key={s.label}>
              <polygon points={fillPts} fill={s.color + '08'} />
              <polyline points={poly} fill="none" stroke={s.color}
                strokeWidth={isHov ? 2.5 : 1.5} opacity={hovered && !isHov ? 0.35 : 1}
                style={{ transition: 'opacity 0.15s, stroke-width 0.15s' }} />
              {/* Son nokta etiketi */}
              <circle cx={toX(s.pts.length - 1, s.pts.length)} cy={toY(s.pts[s.pts.length - 1])} r="3"
                fill={s.color} opacity={hovered && !isHov ? 0.35 : 1} />
            </g>
          );
        })}

        {/* Hover crosshair */}
        {hovered && (
          <>
            <line x1={hovered.x} y1={PAD.top} x2={hovered.x} y2={H - PAD.bottom}
              stroke="#ffffff15" strokeWidth="1" strokeDasharray="2,3" />
            <circle cx={hovered.x} cy={hovered.y} r="5"
              fill={hovered.color} stroke="#07070f" strokeWidth="1.5" />
            {/* Tooltip */}
            <rect
              x={Math.min(hovered.x + 8, W - PAD.right - 78)} y={Math.max(hovered.y - 22, PAD.top)}
              width={74} height={26} rx={3}
              fill="#0a0a1e" stroke={hovered.color + '44'} strokeWidth="1" />
            <text
              x={Math.min(hovered.x + 12, W - PAD.right - 74)} y={Math.max(hovered.y - 11, PAD.top + 10)}
              fill={hovered.color} fontSize="8" fontFamily="monospace" fontWeight="700">
              {hovered.label}
            </text>
            <text
              x={Math.min(hovered.x + 12, W - PAD.right - 74)} y={Math.max(hovered.y + 1, PAD.top + 22)}
              fill={hovered.color + 'cc'} fontSize="7" fontFamily="monospace">
              {hovered.roi >= 0 ? '+' : ''}{hovered.roi.toFixed(2)}%
            </text>
          </>
        )}

        {/* X ekseni dönem etiketleri */}
        {series.map(s => {
          const lastX = toX(s.pts.length - 1, s.pts.length);
          return (
            <text key={s.label + '_x'} x={lastX} y={H - PAD.bottom + 12}
              textAnchor="middle" fill={s.color + '88'} fontSize="7" fontFamily="monospace">
              {s.label}
            </text>
          );
        })}
      </svg>

      {/* Özet istatistik satırı */}
      <div style={{ display: 'grid', gridTemplateColumns: `repeat(${series.length}, 1fr)`, gap: 4, marginTop: 6 }}>
        {series.map(s => (
          <div key={s.label} style={{
            background: `${s.color}08`, border: `1px solid ${s.color}20`,
            borderRadius: 4, padding: '4px 6px', textAlign: 'center',
          }}>
            <div style={{ fontSize: 7, fontFamily: 'monospace', color: s.color + '80', marginBottom: 1 }}>{s.label}</div>
            <div style={{ fontSize: 11, fontFamily: 'monospace', fontWeight: 700, color: s.finalRoi >= 0 ? s.color : '#ff335c' }}>
              {s.finalRoi >= 0 ? '+' : ''}{s.finalRoi.toFixed(1)}%
            </div>
            <div style={{ fontSize: 7, fontFamily: 'monospace', color: '#2a2a50' }}>
              W:{s.winRate}%
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── TEK DÖNEM KART ───────────────────────────────────────────────────────────

function PeriodCard({ label, result }) {
  const [expanded, setExpanded] = useState(false);

  if (result?.error) {
    return (
      <div className="border border-[#1a1a2e] rounded p-3 bg-[#0a0a0f]">
        <div className="flex items-center justify-between mb-1">
          <span className="text-[10px] font-mono font-bold text-gray-400">{label}</span>
          <span className="text-[9px] font-mono text-[#ff4466]">{result.error}</span>
        </div>
      </div>
    );
  }

  const s = result?.stats;
  if (!s) return null;

  const pfColor = s.profitFactor >= 1.5 ? '#00ff88' : s.profitFactor >= 1.0 ? '#ffd600' : '#ff4466';
  const wrColor = s.winRate >= 55 ? '#00ff88' : s.winRate >= 45 ? '#ffd600' : '#ff4466';

  return (
    <div
      className="border rounded bg-[#0a0a0f] cursor-pointer transition-all hover:border-[#ffffff20]"
      style={{ borderColor: s.roi >= 0 ? '#00ff8830' : '#ff446630' }}
      onClick={() => setExpanded(e => !e)}
    >
      {/* Başlık satırı */}
      <div className="flex items-center justify-between p-3">
        <div className="flex items-center gap-2">
          <span className="text-[10px] font-mono font-bold text-gray-300">{label}</span>
          <span className="text-[8px] font-mono text-gray-600">{s.totalTrades} işlem</span>
        </div>
        <div className="flex items-center gap-3">
          <ColorBadge value={s.roi} suffix="%" goodAbove={0} />
          <span className="text-[8px] font-mono text-gray-600">{expanded ? '▲' : '▼'}</span>
        </div>
      </div>

      {/* Mini equity curve */}
      <div className="px-3 pb-2">
        <EquityCurve trades={result.trades} w={200} h={36} />
        <EquityCurveLarge trades={result.trades} initialCapital={10000} />
      </div>

      {/* Özet satır */}
      <div className="grid grid-cols-4 gap-0 border-t border-[#1a1a2e] px-3 py-2">
        <div className="text-center">
          <div className="text-[8px] font-mono text-gray-600 mb-0.5">Kazanma</div>
          <span className="text-[10px] font-mono font-bold" style={{ color: wrColor }}>%{s.winRate}</span>
        </div>
        <div className="text-center">
          <div className="text-[8px] font-mono text-gray-600 mb-0.5">PF</div>
          <span className="text-[10px] font-mono font-bold" style={{ color: pfColor }}>{s.profitFactor}</span>
        </div>
        <div className="text-center">
          <div className="text-[8px] font-mono text-gray-600 mb-0.5">MaxDD</div>
          <ColorBadge value={-s.maxDrawdown} suffix="%" goodAbove={-10} />
        </div>
        <div className="text-center">
          <div className="text-[8px] font-mono text-gray-600 mb-0.5">ROI</div>
          <ColorBadge value={s.roi} suffix="%" goodAbove={0} />
        </div>
      </div>

      {/* Genişletilmiş tablo */}
      {expanded && (
        <div className="border-t border-[#1a1a2e] px-3 py-2 space-y-1">
          {[
            ['Toplam İşlem',  s.totalTrades, ''],
            ['Kazanan',       s.wins,        ''],
            ['Kaybeden',      s.losses,      ''],
            ['Ort. Kazanç',   s.avgWin,      '%'],
            ['Ort. Kayıp',    s.avgLoss,     '%'],
            ['Ort. Süre',     s.avgBars,     ' mum'],
            ['Final Sermaye', s.finalCapital.toLocaleString('tr-TR'), ' ₺'],
          ].map(([lbl, val, sfx]) => (
            <div key={lbl} className="flex justify-between items-center">
              <span className="text-[9px] font-mono text-gray-600">{lbl}</span>
              <span className="text-[9px] font-mono text-gray-300">{val}{sfx}</span>
            </div>
          ))}
          {/* Tam işlem tablosu — scroll edilebilir */}
          {result.trades?.length > 0 && (
            <div className="mt-2 border-t border-[#1a1a2e] pt-2">
              <TradesTable trades={result.trades} />
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── ANA PANEL ────────────────────────────────────────────────────────────────

export default function BacktestPanel({ symbol, klines = [], masterResult }) {
  const [results,    setResults]    = useState(null);
  const [loading,    setLoading]    = useState(false);
  const [progress,   setProgress]   = useState(0);
  const [error,      setError]      = useState(null);
  const [tp1Mult,    setTp1Mult]    = useState(1.0);
  const [slMult,     setSlMult]     = useState(1.0);
  const [posSizePct, setPosSizePct] = useState(10);
  // Optimizör state
  const [optRunning, setOptRunning] = useState(false);
  const [optProgress, setOptProgress] = useState(0);
  const [optResult,  setOptResult]  = useState(null);
  const workerRef  = useRef(null);
  const reqIdRef   = useRef(0);

  // Worker başlat (bir kez)
  // Vite / CRA webpack5: { type: 'module' } ile ES import desteklenir
  // CRA webpack4 (react-scripts < 5): catch → classic worker → main thread fallback
  useEffect(() => {
    let worker = null;
    // Önce module worker dene (Vite + CRA webpack5)
    try {
      worker = new Worker(
        new URL('./backtestWorker.js', import.meta.url),
        { type: 'module' }
      );
      workerRef.current = worker;
      console.info('[BacktestPanel] Module Worker başlatıldı ✓');
    } catch (e1) {
      // Module worker başarısız → classic worker dene (CRA webpack4)
      try {
        worker = new Worker(new URL('./backtestWorker.js', import.meta.url));
        workerRef.current = worker;
        console.info('[BacktestPanel] Classic Worker başlatıldı ✓');
      } catch (e2) {
        // Her ikisi de başarısız → main thread fallback
        console.warn('[BacktestPanel] Worker başlatılamadı, main thread fallback:', e2.message);
        workerRef.current = null;
      }
    }
    return () => {
      if (worker) { try { worker.terminate(); } catch {} }
    };
  }, []);

  const runTest = useCallback(async () => {
    if (!klines?.length) {
      setError('Kline verisi yok — önce grafik yüklensin.');
      return;
    }
    setLoading(true);
    setProgress(0);
    setError(null);

    const pineParams = masterResult?.pineData
      ? { rfPer: 100, rfMult: 3.0, signalMode: 'FİLTRELİ' }
      : {};
    const config = {
      tp1Mult,
      tp2Mult:         tp1Mult * 2,
      slMult,
      positionSizePct: posSizePct,
      initialCapital:  10000,
    };

    // ─── Web Worker varsa kullan ──────────────────────────────────────────
    if (workerRef.current) {
      const id = ++reqIdRef.current;
      workerRef.current.onmessage = (e) => {
        if (e.data.id !== id) return; // eski istek cevabı — yoksay
        if (e.data.type === 'PROGRESS') {
          setProgress(e.data.progress);
        } else if (e.data.type === 'RESULT') {
          setResults(e.data.result);
          setLoading(false);
          setProgress(100);
        } else if (e.data.type === 'ERROR') {
          setError(e.data.error);
          setLoading(false);
        }
      };
      workerRef.current.onerror = (e) => {
        setError('Worker hatası: ' + e.message);
        setLoading(false);
      };
      workerRef.current.postMessage({
        type: 'RUN', id, klines, params: pineParams, config, periods: [30, 90, 180, 365],
      });
      return;
    }

    // ─── Fallback: main thread (Worker yoksa) ────────────────────────────
    try {
      await new Promise(r => setTimeout(r, 20));
      const { runMultiPeriodBacktest } = await import('./backtestEngine');
      const res = runMultiPeriodBacktest(klines, pineParams, config);
      setResults(res);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [klines, masterResult, tp1Mult, slMult, posSizePct]);

  // klines değişince otomatik çalıştır
  useEffect(() => {
    if (klines?.length >= 80) runTest();
  }, [klines?.length]); // eslint-disable-line

  // ─── OPTİMİZÖR HANDLER ───────────────────────────────────────────────────
  const runOptimizer = useCallback(async () => {
    if (!klines?.length) { setError('Kline verisi yok.'); return; }
    setOptRunning(true);
    setOptProgress(0);
    setOptResult(null);
    try {
      const { runPineOptimizer } = await import('./pineEngine');
      const res = await runPineOptimizer(klines, {
        onProgress: (pct) => setOptProgress(pct),
      });
      setOptResult(res);
      // Bulunan en iyi parametreleri backtest'e uygula
      if (res?.bestParams) {
        // pineParams masterResult'a yazılmaz ama sonucu gösteriyoruz
      }
    } catch (e) {
      setError('Optimizör hatası: ' + e.message);
    } finally {
      setOptRunning(false);
      setOptProgress(100);
    }
  }, [klines]);

  const periods = results?.periods ? Object.entries(results.periods) : [];

  return (
    <div className="space-y-3">
      {/* Başlık */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-1.5 h-1.5 rounded-full bg-[#ffd600]" style={{ boxShadow: '0 0 6px #ffd600' }} />
          <span className="text-[10px] font-mono font-bold text-[#ffd600] tracking-widest uppercase">
            Backtest — {symbol}
          </span>
        </div>
        {results && (
          <span className="text-[8px] font-mono text-gray-600">
            {new Date(results.timestamp).toLocaleTimeString('tr-TR')}
          </span>
        )}
      </div>

      {/* Parametreler */}
      <div className="border border-[#1a1a2e] rounded p-2 bg-[#0a0a0f] grid grid-cols-3 gap-2">
        {[
          { lbl: 'TP Çarpanı', val: tp1Mult, set: setTp1Mult, step: 0.5, min: 0.5, max: 5 },
          { lbl: 'SL Çarpanı', val: slMult,  set: setSlMult,  step: 0.5, min: 0.5, max: 5 },
          { lbl: 'Poz. %',     val: posSizePct, set: setPosSizePct, step: 5, min: 5, max: 100 },
        ].map(({ lbl, val, set, step, min, max }) => (
          <div key={lbl} className="text-center">
            <div className="text-[8px] font-mono text-gray-600 mb-1">{lbl}</div>
            <div className="flex items-center gap-1 justify-center">
              <button
                onClick={() => set(v => Math.max(min, parseFloat((v - step).toFixed(1))))}
                className="w-4 h-4 text-[9px] font-mono text-gray-500 hover:text-gray-300 border border-[#1a1a2e] rounded"
              >−</button>
              <span className="text-[10px] font-mono text-gray-300 w-8 text-center">{val}</span>
              <button
                onClick={() => set(v => Math.min(max, parseFloat((v + step).toFixed(1))))}
                className="w-4 h-4 text-[9px] font-mono text-gray-500 hover:text-gray-300 border border-[#1a1a2e] rounded"
              >+</button>
            </div>
          </div>
        ))}
      </div>

      {/* Çalıştır butonu */}
      <div style={{ display: 'flex', gap: 6 }}>
        <button
          onClick={runTest}
          disabled={loading}
          className="w-full py-2 rounded text-[10px] font-mono font-bold uppercase tracking-widest transition-all disabled:opacity-40"
          style={{ background: '#ffd60015', border: '1px solid #ffd60040', color: '#ffd600', flex: 2 }}
        >
          {loading ? '⏳ Hesaplanıyor…' : '🔬 Backtest Çalıştır'}
        </button>
        <button
          onClick={runOptimizer}
          disabled={optRunning || loading || !klines?.length}
          style={{
            flex: 1, padding: '8px 0', borderRadius: 6, cursor: 'pointer',
            fontSize: 9, fontFamily: 'monospace', fontWeight: 700, letterSpacing: 1,
            background: 'rgba(170,102,255,.12)', border: '1px solid rgba(170,102,255,.3)',
            color: '#aa66ff', opacity: (optRunning || loading || !klines?.length) ? 0.4 : 1,
            transition: 'all .15s',
          }}
        >
          {optRunning ? `⚙ ${optProgress}%` : '⚙ OPTİMİZE'}
        </button>
      </div>

      {/* Optimizör sonucu */}
      {optResult && !optResult.error && (
        <div style={{ background: '#0a0a1c', border: '1px solid rgba(170,102,255,.2)', borderRadius: 6, padding: '10px 12px' }}>
          <div style={{ fontSize: 8, color: '#6644aa', letterSpacing: 2, marginBottom: 8, fontFamily: 'monospace', textTransform: 'uppercase' }}>
            ⚙ En İyi Parametreler — {optResult.testedCombos} kombinasyon test edildi
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 6, marginBottom: 8 }}>
            {[
              { k: 'RF Period', v: optResult.bestParams?.rfPer },
              { k: 'RF Mult',   v: optResult.bestParams?.rfMult },
              { k: 'Mod',       v: optResult.bestParams?.signalMode },
            ].map(({ k, v }) => (
              <div key={k} style={{ background: 'rgba(170,102,255,.08)', borderRadius: 4, padding: '6px 8px', border: '1px solid rgba(170,102,255,.15)', textAlign: 'center' }}>
                <div style={{ fontSize: 8, color: '#6644aa', fontFamily: 'monospace', marginBottom: 2 }}>{k}</div>
                <div style={{ fontSize: 13, fontFamily: 'monospace', fontWeight: 700, color: '#cc88ff' }}>{v}</div>
              </div>
            ))}
          </div>
          <div style={{ display: 'flex', gap: 12 }}>
            <span style={{ fontSize: 9, fontFamily: 'monospace', color: '#00e87a' }}>Win: %{optResult.bestWinRate}</span>
            <span style={{ fontSize: 9, fontFamily: 'monospace', color: '#00aaff' }}>Ort. PnL: {optResult.bestAvgPnl > 0 ? '+' : ''}{optResult.bestAvgPnl?.toFixed(2)}%</span>
          </div>
          {optResult.topN?.length > 1 && (
            <div style={{ marginTop: 8, borderTop: '1px solid rgba(170,102,255,.1)', paddingTop: 6 }}>
              <div style={{ fontSize: 8, color: '#3a2a60', fontFamily: 'monospace', marginBottom: 4 }}>Top 5</div>
              {optResult.topN.map((r, i) => (
                <div key={i} style={{ display: 'flex', gap: 8, padding: '2px 0', fontSize: 8, fontFamily: 'monospace', color: i === 0 ? '#cc88ff' : '#3a3a68' }}>
                  <span style={{ width: 14 }}>{i + 1}.</span>
                  <span>Per:{r.rfPer}</span>
                  <span>Mult:{r.rfMult}</span>
                  <span>{r.signalMode.slice(0,3)}</span>
                  <span style={{ marginLeft: 'auto', color: r.winRate >= 55 ? '#00e87a' : '#ffc800' }}>W:{r.winRate}%</span>
                  <span>{r.avgPnl > 0 ? '+' : ''}{r.avgPnl?.toFixed(1)}%</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Hata */}
      {error && (
        <div className="border border-[#ff446640] rounded p-2 bg-[#ff446608]">
          <p className="text-[9px] font-mono text-[#ff4466]">{error}</p>
        </div>
      )}

      {/* Yükleniyor — Web Worker progress bar */}
      {loading && (
        <div className="py-4 space-y-2">
          <div className="flex items-center justify-center gap-2 mb-2">
            <div className="w-1.5 h-1.5 rounded-full bg-[#ffd600] animate-bounce" />
            <span className="text-[9px] font-mono text-gray-600 animate-pulse">
              Pine sinyalleri hesaplanıyor… (arka plan iş parçacığı)
            </span>
          </div>
          {progress > 0 && (
            <div className="px-2">
              <div className="h-1 bg-[#0a0a1c] rounded overflow-hidden">
                <div
                  className="h-full rounded transition-all duration-300"
                  style={{ width: `${progress}%`, background: '#ffd600' }}
                />
              </div>
              <span className="text-[8px] font-mono text-gray-700">{progress}%</span>
            </div>
          )}
        </div>
      )}

      {/* Sonuçlar */}
      {!loading && periods.length > 0 && (
        <div className="space-y-2">
          <MultiPeriodComparisonChart periods={results.periods} initialCapital={10000} />
          {periods.map(([lbl, res]) => (
            <PeriodCard key={lbl} label={lbl} result={res} />
          ))}
          <div className="text-[8px] font-mono text-gray-700 text-center pt-1">
            Geçmiş performans gelecek sonuçları garanti etmez.
          </div>
        </div>
      )}

      {/* Veri yok */}
      {!loading && !results && !error && (
        <div className="text-center py-8">
          <p className="text-[9px] font-mono text-gray-600">
            Kline verisi bekleniyor…
          </p>
        </div>
      )}
    </div>
  );
}

// ─── INLINE VERSION (Dashboard içinde kullanım için) ──────────────────────────
// Dashboard_v4.jsx'te BacktestPanelInline olarak import edilir

export function BacktestPanelInline({ symbol, masterResult }) {
  // Dashboard'daki klineCache'i kullanamayız — fetch'i burada yaparız
  const [klines, setKlines] = useState([]);
  const [fetchStatus, setFetchStatus] = useState('idle');

  useEffect(() => {
    if (!symbol) return;
    setFetchStatus('loading');
    const base = symbol.replace('/', '').toUpperCase();
    fetch(`https://api.binance.com/api/v3/klines?symbol=${base}&interval=1h&limit=500`)
      .then(r => r.json())
      .then(data => {
        if (!Array.isArray(data)) throw new Error('API hatası');
        const candles = data.map(k => ({
          t: k[0], o: parseFloat(k[1]), h: parseFloat(k[2]),
          l: parseFloat(k[3]), c: parseFloat(k[4]), v: parseFloat(k[5]),
        }));
        setKlines(candles);
        setFetchStatus('ok');
      })
      .catch(() => setFetchStatus('error'));
  }, [symbol]);

  if (fetchStatus === 'loading') {
    return (
      <div className="flex items-center justify-center py-8 gap-2">
        <div className="w-1.5 h-1.5 rounded-full bg-[#ffd600] animate-pulse" />
        <span className="text-[9px] font-mono text-gray-600">Kline çekiliyor…</span>
      </div>
    );
  }
  if (fetchStatus === 'error') {
    return (
      <div className="text-center py-6">
        <p className="text-[9px] font-mono text-[#ff4466]">Veri alınamadı. Tekrar dene.</p>
      </div>
    );
  }

  return <BacktestPanel symbol={symbol} klines={klines} masterResult={masterResult} />;
}
