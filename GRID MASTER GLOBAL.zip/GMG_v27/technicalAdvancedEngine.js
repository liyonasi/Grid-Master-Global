/**
 * technicalAdvancedEngine.js — GMG v16
 * Gelişmiş Teknik Analiz Motorları:
 *   36. Trend Exhaustion Engine
 *   37. Candle Anatomy Engine
 *   38. Wick Manipulation Engine
 *   39. Gap Pressure Engine
 *   40. Fractal Structure Engine
 *   26. Breakout Filter Engine (gelişmiş)
 *   27. Trend Acceleration Engine
 *   28. Mean Reversion Engine
 */

const clamp = (v, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, v));

// ─── TREND EXHAUSTION ENGINE ──────────────────────────────────────────────────
export function runTrendExhaustionEngine(klines) {
  if (!klines || klines.length < 30) return { exhausted: false, score: 0 };

  const recent = klines.slice(-30);
  const closes = recent.map(k => k.c);
  const highs  = recent.map(k => k.h);
  const lows   = recent.map(k => k.l);

  // Trend yönü
  const trendUp = closes[closes.length-1] > closes[0];

  // Momentum kaybı: Son 5 ile önceki 5 mumu karşılaştır
  const last5Range  = Math.max(...highs.slice(-5))  - Math.min(...lows.slice(-5));
  const prev5Range  = Math.max(...highs.slice(-10,-5)) - Math.min(...lows.slice(-10,-5));
  const momentumLoss = prev5Range > 0 ? (prev5Range - last5Range) / prev5Range * 100 : 0;

  // Ardışık doji/küçük gövde
  let smallBodyCount = 0;
  for (let i = recent.length - 5; i < recent.length; i++) {
    const body  = Math.abs(recent[i].c - recent[i].o);
    const range = recent[i].h - recent[i].l;
    if (range > 0 && body / range < 0.3) smallBodyCount++;
  }

  // Higher highs (trend yukarıysa) ama daha az mesafe
  const recentMoves = [];
  for (let i = 1; i < Math.min(10, recent.length); i++) {
    recentMoves.push(Math.abs(recent[recent.length - i].c - recent[recent.length - i - 1].c));
  }
  const avgEarlyMove = recentMoves.slice(5).reduce((s, v) => s + v, 0) / Math.max(recentMoves.slice(5).length, 1);
  const avgLatMove   = recentMoves.slice(0, 5).reduce((s, v) => s + v, 0) / Math.max(recentMoves.slice(0, 5).length, 1);
  const deceleration = avgEarlyMove > 0 ? (avgEarlyMove - avgLatMove) / avgEarlyMove * 100 : 0;

  let score = 0;
  if (momentumLoss > 20)  score += 25;
  if (momentumLoss > 40)  score += 15;
  if (smallBodyCount >= 3) score += 25;
  if (deceleration > 30)  score += 20;
  if (deceleration > 50)  score += 10;

  return {
    exhausted: score >= 50,
    score: clamp(score),
    trendUp,
    momentumLoss:  parseFloat(momentumLoss.toFixed(1)),
    smallBodyCount,
    deceleration:  parseFloat(deceleration.toFixed(1)),
    verdict: score >= 70
      ? `⚠ TREND YORULDU — ${trendUp ? 'Yükseliş' : 'Düşüş'} zayıflıyor`
      : score >= 50
      ? `Trend güç kaybediyor`
      : `✓ Trend güçlü devam ediyor`,
    reverseWarning: score >= 60,
    timestamp: Date.now(),
  };
}

// ─── CANDLE ANATOMY ENGINE ────────────────────────────────────────────────────
export function runCandleAnatomyEngine(klines) {
  if (!klines || !klines.length) return { pattern: 'NONE', quality: 0 };

  const last = klines[klines.length - 1];
  const prev = klines.length > 1 ? klines[klines.length - 2] : null;

  const open  = last.o ?? last.c;
  const close = last.c;
  const high  = last.h ?? last.c;
  const low   = last.l ?? last.c;
  const range = high - low;

  if (range === 0) return { pattern: 'FLAT', quality: 0 };

  const body       = Math.abs(close - open);
  const upperWick  = high - Math.max(open, close);
  const lowerWick  = Math.min(open, close) - low;
  const bodyPct    = body / range;
  const uwPct      = upperWick / range;
  const lwPct      = lowerWick / range;
  const isBull     = close >= open;

  // Mum desenleri
  let pattern = 'NORMAL';
  let quality  = 50;
  let signal   = 'NEUTRAL';

  if (bodyPct < 0.1) {
    pattern = 'DOJI';
    quality = 60;
    signal  = 'REVERSAL';
  } else if (lwPct > 0.6 && bodyPct < 0.3) {
    pattern = isBull ? 'HAMMER' : 'HANGING_MAN';
    quality = isBull ? 75 : 65;
    signal  = isBull ? 'BULLISH_REVERSAL' : 'BEARISH_REVERSAL';
  } else if (uwPct > 0.6 && bodyPct < 0.3) {
    pattern = 'SHOOTING_STAR';
    quality = 72;
    signal  = 'BEARISH_REVERSAL';
  } else if (bodyPct > 0.7) {
    pattern = isBull ? 'BULL_MARUBOZU' : 'BEAR_MARUBOZU';
    quality = 80;
    signal  = isBull ? 'STRONG_BUY' : 'STRONG_SELL';
  } else if (lwPct > 0.4 && uwPct > 0.4 && bodyPct < 0.2) {
    pattern = 'SPINNING_TOP';
    quality = 55;
    signal  = 'INDECISION';
  }

  // Engulfing
  if (prev) {
    const prevBody = Math.abs(prev.c - (prev.o ?? prev.c));
    const prevBull = prev.c >= (prev.o ?? prev.c);
    if (isBull && !prevBull && body > prevBody * 1.1) {
      pattern = 'BULL_ENGULFING'; quality = 82; signal = 'STRONG_BUY';
    }
    if (!isBull && prevBull && body > prevBody * 1.1) {
      pattern = 'BEAR_ENGULFING'; quality = 80; signal = 'STRONG_SELL';
    }
  }

  return {
    pattern,
    quality,
    signal,
    isBull,
    bodyPct:   parseFloat(bodyPct.toFixed(3)),
    uwPct:     parseFloat(uwPct.toFixed(3)),
    lwPct:     parseFloat(lwPct.toFixed(3)),
    verdict: signal === 'STRONG_BUY' ? `🕯 ${pattern} — Güçlü AL sinyali` : signal === 'STRONG_SELL' ? `🕯 ${pattern} — Güçlü SAT sinyali` : signal === 'REVERSAL' ? `🕯 ${pattern} — Dönüş ihtimali` : `🕯 ${pattern}`,
    timestamp: Date.now(),
  };
}

// ─── WICK MANIPULATION ENGINE ─────────────────────────────────────────────────
export function runWickManipulationEngine(klines, recentTrades = []) {
  if (!klines || klines.length < 5) return { detected: false, score: 0 };

  const recent5 = klines.slice(-5);
  const manipulations = [];

  recent5.forEach((k, i) => {
    const body  = Math.abs(k.c - (k.o ?? k.c));
    const range = k.h - k.l;
    if (range === 0) return;

    const uwPct = (k.h - Math.max(k.c, k.o ?? k.c)) / range;
    const lwPct = (Math.min(k.c, k.o ?? k.c) - k.l) / range;

    // Uzun üst fitil + kapanış dip = satış baskısı ile fitil
    if (uwPct > 0.55 && body / range < 0.2) {
      manipulations.push({ type: 'UPPER_WICK_MANIP', severity: uwPct * 100, index: i });
    }
    // Uzun alt fitil + kapanış tepe = alış baskısı ile fitil
    if (lwPct > 0.55 && body / range < 0.2) {
      manipulations.push({ type: 'LOWER_WICK_MANIP', severity: lwPct * 100, index: i });
    }
  });

  const score = clamp(manipulations.length * 20 + manipulations.reduce((s, m) => s + m.severity * 0.2, 0));

  return {
    detected:      manipulations.length > 0,
    score:         clamp(score),
    manipulations,
    count:         manipulations.length,
    verdict: manipulations.length >= 3
      ? '⚠ Yoğun fitil manipülasyonu — bekleme önerilir'
      : manipulations.length >= 1
      ? 'Fitil manipülasyon belirtisi'
      : '✓ Fitil yapısı normal',
    timestamp: Date.now(),
  };
}

// ─── GAP PRESSURE ENGINE ──────────────────────────────────────────────────────
export function runGapPressureEngine(klines) {
  if (!klines || klines.length < 3) return { gaps: [], totalPressure: 0 };

  const gaps = [];
  for (let i = 1; i < klines.length; i++) {
    const prev  = klines[i - 1];
    const curr  = klines[i];
    const gapUp   = curr.o > prev.h;
    const gapDown = curr.o < prev.l;

    if (gapUp || gapDown) {
      const size = gapUp
        ? (curr.o - prev.h) / prev.h * 100
        : (prev.l - curr.o) / prev.l * 100;
      if (size > 0.1) { // %0.1'den büyük gap
        gaps.push({
          idx: i,
          type:   gapUp ? 'GAP_UP' : 'GAP_DOWN',
          size:   parseFloat(size.toFixed(3)),
          level1: gapUp ? prev.h : curr.o,
          level2: gapUp ? curr.o : prev.l,
          filled: false, // Gap dolduruldu mu?
        });
      }
    }
  }

  // Son N gap içinde doldurulanlar
  gaps.forEach(gap => {
    const afterGap = klines.slice(gap.idx + 1);
    if (gap.type === 'GAP_UP') {
      gap.filled = afterGap.some(k => k.l <= gap.level1);
    } else {
      gap.filled = afterGap.some(k => k.h >= gap.level1);
    }
  });

  const openGaps     = gaps.filter(g => !g.filled);
  const totalPressure = openGaps.reduce((s, g) => s + g.size, 0);

  return {
    gaps,
    openGaps,
    totalPressure: parseFloat(totalPressure.toFixed(2)),
    nearestGap:    openGaps.sort((a, b) => b.idx - a.idx)[0] || null,
    verdict: openGaps.length > 0
      ? `📊 ${openGaps.length} açık gap var — fiyat doldurabilir`
      : '✓ Açık gap yok',
    timestamp: Date.now(),
  };
}

// ─── FRACTAL STRUCTURE ENGINE ─────────────────────────────────────────────────
export function runFractalStructureEngine(klines) {
  if (!klines || klines.length < 10) return { fractals: [], alignment: false };

  const fractals = [];

  // Basit fractal: 5 mumun ortası HH veya LL
  for (let i = 2; i < klines.length - 2; i++) {
    const center = klines[i];
    const isTopFractal = center.h > klines[i-1].h && center.h > klines[i-2].h &&
                         center.h > klines[i+1].h && center.h > klines[i+2].h;
    const isBotFractal = center.l < klines[i-1].l && center.l < klines[i-2].l &&
                         center.l < klines[i+1].l && center.l < klines[i+2].l;

    if (isTopFractal) fractals.push({ type: 'TOP', price: center.h, idx: i });
    if (isBotFractal) fractals.push({ type: 'BOT', price: center.l, idx: i });
  }

  // Son 10 fractal'in yapısı
  const recent = fractals.slice(-10);
  const tops = recent.filter(f => f.type === 'TOP').map(f => f.price);
  const bots = recent.filter(f => f.type === 'BOT').map(f => f.price);

  // Trend: Higher Highs + Higher Lows
  const isHH = tops.length >= 2 && tops[tops.length-1] > tops[tops.length-2];
  const isHL = bots.length >= 2 && bots[bots.length-1] > bots[bots.length-2];
  const isLH = tops.length >= 2 && tops[tops.length-1] < tops[tops.length-2];
  const isLL = bots.length >= 2 && bots[bots.length-1] < bots[bots.length-2];

  const structure = isHH && isHL ? 'YUKARI_TREND' : isLH && isLL ? 'AŞAĞI_TREND' : 'KARMAŞIK';
  const alignment = isHH && isHL || isLH && isLL;

  return {
    fractals,
    recent: recent.slice(-6),
    structure,
    alignment,
    isHH, isHL, isLH, isLL,
    lastTopFractal: tops[tops.length-1] || null,
    lastBotFractal: bots[bots.length-1] || null,
    verdict: structure === 'YUKARI_TREND'
      ? '✅ Yükselen kanalda HH+HL yapısı — trend sağlam'
      : structure === 'AŞAĞI_TREND'
      ? '⚠ Alçalan kanalda LH+LL yapısı — düşüş devam'
      : '📊 Karmaşık fraktal yapı',
    timestamp: Date.now(),
  };
}

// ─── BREAKOUT FILTER ENGINE (gelişmiş) ───────────────────────────────────────
export function runBreakoutFilterEngine(klines, volume = 0, avgVolume = 0) {
  if (!klines || klines.length < 20) return { isBreakout: false, isFake: false, score: 0 };

  const last   = klines[klines.length - 1];
  const prev20 = klines.slice(-21, -1);
  const rangeH = Math.max(...prev20.map(k => k.h));
  const rangeL = Math.min(...prev20.map(k => k.l));

  const breakoutUp   = last.c > rangeH;
  const breakoutDown = last.c < rangeL;

  if (!breakoutUp && !breakoutDown) return { isBreakout: false, isFake: false, score: 0, type: 'NONE' };

  const breakoutSize = breakoutUp
    ? (last.c - rangeH) / rangeH * 100
    : (rangeL - last.c) / rangeL * 100;

  // Volüm teyidi
  const volConfirm = avgVolume > 0 && volume > avgVolume * 1.5;

  // Kapanış kırılımı teyidi
  const closeConfirm = breakoutUp
    ? last.c > rangeH * 1.001
    : last.c < rangeL * 0.999;

  // Geri dönüş ihtimali
  const fakeSignals = [
    !volConfirm,
    breakoutSize < 0.2,
    !closeConfirm,
    (last.h - last.l) > 0 && Math.abs(last.c - (last.o ?? last.c)) / (last.h - last.l) < 0.3,
  ].filter(Boolean).length;

  const isReal = fakeSignals <= 1 && closeConfirm && volConfirm;
  const isFake = fakeSignals >= 3 || (!volConfirm && breakoutSize < 0.5);

  return {
    isBreakout: true,
    isReal,
    isFake,
    type:          breakoutUp ? 'UP' : 'DOWN',
    breakoutSize:  parseFloat(breakoutSize.toFixed(3)),
    volConfirm,
    closeConfirm,
    fakeSignals,
    score: clamp(isReal ? 70 + breakoutSize * 10 : isFake ? 20 : 50),
    verdict: isReal
      ? `✅ GERÇEK KIRILIM ${breakoutUp ? '▲' : '▼'} (+${breakoutSize.toFixed(2)}%) — Hacim teyitli`
      : isFake
      ? `⚠ SAHTE KIRILIM — ${fakeSignals} red sinyali`
      : `📊 Kırılım doğrulanıyor — bekle`,
    timestamp: Date.now(),
  };
}

// ─── TREND ACCELERATION ENGINE ────────────────────────────────────────────────
export function runTrendAccelerationEngine(klines) {
  if (!klines || klines.length < 15) return { accelerating: false, score: 0 };

  const closes = klines.slice(-15).map(k => k.c);

  // İlk 5, orta 5, son 5 mumun hareketleri
  const seg1 = Math.abs(closes[4] - closes[0]) / closes[0] * 100;
  const seg2 = Math.abs(closes[9] - closes[5]) / closes[5] * 100;
  const seg3 = Math.abs(closes[14] - closes[10]) / closes[10] * 100;

  const accelerating = seg3 > seg2 * 1.3 && seg2 > seg1 * 1.1;
  const decelerating = seg3 < seg2 * 0.7;

  const ratio = seg2 > 0 ? seg3 / seg2 : 1;
  const score = clamp(accelerating ? ratio * 40 : decelerating ? 20 : 50);

  const trendUp = closes[closes.length-1] > closes[0];

  return {
    accelerating,
    decelerating,
    score,
    seg1: parseFloat(seg1.toFixed(3)),
    seg2: parseFloat(seg2.toFixed(3)),
    seg3: parseFloat(seg3.toFixed(3)),
    ratio: parseFloat(ratio.toFixed(2)),
    trendUp,
    verdict: accelerating
      ? `🚀 Trend hızlanıyor — momentum ${trendUp ? '▲' : '▼'}`
      : decelerating
      ? `🐢 Trend yavaşlıyor`
      : `📊 Sabit tempo`,
    timestamp: Date.now(),
  };
}

// ─── MEAN REVERSION ENGINE ────────────────────────────────────────────────────
export function runMeanReversionEngine(klines, lookback = 20) {
  if (!klines || klines.length < lookback) return { score: 0, revertProb: 0 };

  const closes = klines.slice(-lookback).map(k => k.c);
  const mean   = closes.reduce((s, v) => s + v, 0) / closes.length;
  const std    = Math.sqrt(closes.reduce((s, v) => s + (v - mean) ** 2, 0) / closes.length);
  const last   = closes[closes.length - 1];

  const zScore = std > 0 ? (last - mean) / std : 0;
  const devPct = mean > 0 ? (last - mean) / mean * 100 : 0;

  // Ortalamaya dönüş olasılığı Z-skora göre
  const revertProb = Math.min(Math.abs(zScore) * 25, 90);

  const isExtended = Math.abs(zScore) > 2;
  const isOverbought = zScore > 2;
  const isOversold   = zScore < -2;

  return {
    score:      clamp(revertProb),
    zScore:     parseFloat(zScore.toFixed(3)),
    devPct:     parseFloat(devPct.toFixed(2)),
    revertProb: parseFloat(revertProb.toFixed(1)),
    mean:       parseFloat(mean.toFixed(2)),
    std:        parseFloat(std.toFixed(2)),
    isExtended,
    isOverbought,
    isOversold,
    verdict: isOverbought
      ? `⚠ Fiyat ortalamadan +${devPct.toFixed(1)}% uzak — geri dönüş beklenebilir`
      : isOversold
      ? `✅ Fiyat ortalamadan ${devPct.toFixed(1)}% aşağı — top-up fırsatı`
      : `✓ Fiyat ortalama civarında`,
    timestamp: Date.now(),
  };
}
