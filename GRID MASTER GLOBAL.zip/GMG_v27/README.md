# GRID MASTER GLOBAL — TAM SİSTEM DOKÜMANTASYONU
## Kayıt Tarihi: 2026-03-15

---

## DOSYA LİSTESİ

| Dosya | Açıklama |
|---|---|
| `GMGChart_v3.jsx` | Ana grafik bileşeni — React |
| `exchangeAPI_multi.js` | 7 borsa API + WebSocket yöneticisi |
| `engineCore.js` | 16 tarama modülü + 4 Konsey motoru |
| `moduleRegistry.js` | 95 modülün 4 konseye dağılımı |
| `aiCouncilEngine.js` | AI konsey motoru (detaylı versiyon) |
| `chartModule.js` | Pattern recognition + historical match |
| `LiquidityRadar.jsx` | Likidite Radar bileşeni |
| `MultiTimeframePanel.jsx` | Çoklu zaman dilimi paneli |
| `FundingPanel.jsx` | Funding + OI + Market Structure |
| `MarketIntelPanel.jsx` | Piyasa istihbarat paneli (7 sekme) |
| `CouncilPanel.jsx` | 4 Konsey karar paneli |

---

## KURULUM

### React Projesi

```bash
# Gerekli paketler
npm install framer-motion lucide-react

# Dosyaları kopyala
cp GMGChart_v3.jsx src/components/grid-master/
cp exchangeAPI_multi.js src/components/grid-master/
cp engineCore.js src/components/grid-master/
```

### Temel Kullanım

```jsx
import GMGChart from './components/grid-master/GMGChart_v3';
import { runAllScanners, runCouncils } from './components/grid-master/engineCore';

function App() {
  const [councilData, setCouncilData] = useState(null);

  return (
    <div style={{ height: '100vh' }}>
      <GMGChart
        symbol="BTC/USDT"
        onCouncilUpdate={setCouncilData}
      />
    </div>
  );
}
```

---

## MİMARİ

### Veri Akışı

```
Borsalar (7 adet)
    ↓
exchangeAPI_multi.js
├── fetchBestKlines()     — En iyi kline kaynağı
├── fetchAggregatedPrice() — 7 borsadan ağırlıklı fiyat
├── MultiExchangeWS       — WebSocket, biri düşse diğerine geçer
└── fetchOrderbook()      — Çok kaynaklı orderbook

    ↓
GMGChart_v3.jsx
├── computeMagnets()      — Likidite mıknatısı
├── computeCouncil()      — 4 Konsey kararı
├── computeSignals()      — PB-AL / PB-SAT / BUY / SELL
└── draw()                — Canvas render

    ↓
Panel gösterimi
```

### 4 Konsey Yapısı

```
ALPHA COUNCIL (24 modül)
├── Teknik analiz (RSI, EMA, MACD, BB, Stoch, ADX, CCI)
├── Grafik formasyonları (Pattern Matrix, Chart Formation)
├── Tarihsel eşleşme (Historical Match)
└── MFI, OBV

FLOW COUNCIL (24 modül)  
├── Orderbook analizi (Bid/Ask Imbalance, Wall Tracker)
├── Likidite haritası (Liquidity Map, Void Engine)
├── Hacim analizi (Volume Spike, CVD Pulse)
└── Türev (Funding Bias, Open Interest)

RISK COUNCIL (24 modül)
├── Manipülasyon (Stop Hunt, Fake Move, Spoofing)
├── Likidasyon bölgeleri
├── Volatilite rejimi
└── Pump/Dump erken tarama

MACRO COUNCIL (23 modül)
├── BTC Dominans
├── Alt Sezon İndeksi
├── Sektör gücü
└── AI karar sentezi

FINAL COUNCIL
├── ALPHA × 0.28
├── FLOW  × 0.27
├── RISK  × 0.22
└── MACRO × 0.23
```

---

## GRAFİK TİPLERİ

| Tip | Açıklama |
|---|---|
| Mum (Candlestick) | Klasik OHLC |
| Heikin Ashi | Gürültü filtrelenmiş trend |
| Hollow Candle | Boğa=içi boş, Ayı=dolu |
| Bar (OHLC) | Çizgi bazlı |
| Çizgi | Sadece kapanış |
| Alan | Gradient dolu alan |
| Renko | ATR bazlı brick |

---

## İNDİKATÖRLER

### Grafik Üzerinde (toggle ile)
- EMA 9, EMA 21, EMA 50, EMA 200
- VWAP (Volume Weighted Average Price)
- Bollinger Bands (20 period, 2σ)
- Liq Map (Likidite mıknatısı haritası)
- Magnet Arrow (MM yön tahmini)
- S/R Seviyeleri (Swing cluster)
- Hacim barları
- Sinyal etiketleri (PB-AL, PB-SAT, BUY, SELL)
- Konsey overlay paneli

### Osilatörler (altta)
- RSI (14 period)
- MACD (12/26/9)
- Stochastic (%K/%D)
- ADX (14 period)
- CCI (20 period)
- MFI (Money Flow Index)
- OBV (On Balance Volume)

---

## BORSA DESTEĞI

| Borsa | Kline | Ticker | WebSocket | Orderbook | Funding |
|---|---|---|---|---|---|
| Binance | ✅ | ✅ | ✅ | ✅ | ✅ |
| Bybit | ✅ | ✅ | ✅ | ✅ | ✅ |
| OKX | ✅ | ✅ | ✅ | ✅ | — |
| Gate.io | ✅ | ✅ | — | — | — |
| KuCoin | — | ✅ | — | — | — |
| MEXC | ✅ | ✅ | ✅ | — | — |
| Kraken | — | ✅ | — | — | — |

**Fallback zinciri:** Binance → Bybit → OKX → Gate → MEXC

---

## LİKİDİTE MIKNATISI

Piyasanın fiyatı nereye çekeceğini tahmin eder.

### Hesaplama
1. **Swing High/Low** — 4 mum penceresi ile yerel zirveler/dipler
2. **Yuvarlak Sayılar** — $84000, $84500 gibi psikolojik seviyeler (⊙ işareti)
3. **Yüksek Hacim Nodları** — Ortalamanın 2.2x üstü hacimli seviyeler (◉ işareti)
4. **Cluster Birleştirme** — %0.7 toleransla yakın seviyeler birleştirilir
5. **Güç Skoru** — Dokunma sayısı + hacim + yuvarlak seviye + yakınlık

### Çıktı
- **Strength %** — Mıknatıs gücü (20-98)
- **Stop Prob %** — Stop hunt olasılığı
- **Magnet Arrow** — En güçlü mıknatıs yönünü ok ile gösterir

---

## PB-AL / PB-SAT SİNYAL MANTĞI

### PB-AL koşulları (7 faktör, ≥7 puan gerekli)
- RSI < 42 → +3 puan
- RSI < 50 → +1 puan
- MACD Histogram > 0 → +2 puan
- EMA9 > EMA21 → +2 puan
- BB pozisyon < 0.35 → +2 puan
- Magnet yönü YUKARI → +3 puan
- ADX > 20 → +1 puan
- MFI < 35 → +2 puan

### PB-SAT koşulları (aynı mantık, ters yönde)

---

## CROSSHAIR & HOVER
- Mum üzerine gelince: OHLCV göstergesi üst bara yazar
- Mıknatıs çizgisi üzerinde: Strength % ve Stop probability gösterir
- Fare sürükle → grafik kayar (pan)
- Scroll → zoom (0.3x — 10x)
- Touch desteği var (mobil)

---

## STATE PERSISTENCE
localStorage'da saklanır:
- Zoom seviyesi (sX)
- Pan pozisyonu (oX)
- Aktif indikatörler
- Osilatör seçimi
- Grafik tipi
- Zaman dilimi

Sayfa yenilenince sıfırlanmaz.

---

## GELİŞTİRİLECEK ALANLAR (Sonraki versiyon)
- [ ] TradingView webhook entegrasyonu
- [ ] Alert / Alarm sistemi (hedef fiyata gelince bildirim)
- [ ] Pattern recognition (H&S, Double Top/Bottom otomatik)
- [ ] Historical pattern compare (geçmişte aynısı oluşunca ne olmuş)
- [ ] Multi-coin heatmap grafiğe entegre
- [ ] Telegram/Discord bot çıktısı
- [ ] Futures liquidation map gerçek OI verisi
- [ ] News sentiment feed
- [ ] Portfolio tracker

---

## ÖNEMLİ NOTLAR
- Sistem karar DESTEK motorudur, kesin sinyal vermez
- Her zaman kendi analizini ekle
- Stop loss her zaman kullan
- Küçük pozisyonlarla test et

---

Grid Master Global © 2026
