/**
 * GRID MASTER GLOBAL — ADVANCED ONCHAIN ENGINE v1
 * =================================================
 * Exchange reserve, smart money davranışı, active addresses ve transfer spike.
 *
 * VERİ KAYNAKLARI:
 *   - CryptoQuant API (ücretsiz endpoint'ler)
 *   - Glassnode (sınırlı ücretsiz)
 *   - Blockchain.com (BTC)
 *   - Etherscan (ETH)
 *
 * MODÜLLER:
 *   1. ExchangeReserve — Borsalardaki coin miktarı değişimi
 *   2. SmartMoney      — Büyük cüzdan davranışı
 *   3. ActiveAddresses — Aktif adres trendi
 *   4. TransferSpike   — Ani büyük transfer tespiti
 *   5. MinerFlow       — Madenci çıkışı (BTC)
 */

import { clamp } from './engineCore.js';

// ─── ÖNBELLEK ─────────────────────────────────────────────────────────────────
const _cache = new Map();
const CACHE_TTL = 10 * 60 * 1000; // 10 dakika (zincir verisi sık değişmez)

function cacheGet(k) { const e = _cache.get(k); return e && Date.now() - e.ts < CACHE_TTL ? e.v : null; }
function cacheSet(k, v) { _cache.set(k, { v, ts: Date.now() }); }

// ─── CRYPTOQUANT FREE API ─────────────────────────────────────────────────────
// Not: Bazı endpoint'ler API key ister, ücretsiz olanlar burada
const CQ_BASE = 'https://api.cryptoquant.com/v1';

async function fetchCQ(path) {
  const cached = cacheGet(`cq_${path}`);
  if (cached) return cached;

  try {
    const res  = await fetch(`${CQ_BASE}${path}`, { signal: AbortSignal.timeout(8000) });
    if (!res.ok) return null;
    const data = await res.json();
    cacheSet(`cq_${path}`, data);
    return data;
  } catch (e) {
    console.error('[ONCHAIN] CryptoQuant fetch hatası:', e.message);
    return null;
  }
}

// ─── BLOCKCHAIN.COM (BTC ücretsiz) ───────────────────────────────────────────
async function fetchBTCStats() {
  const cached = cacheGet('btc_stats');
  if (cached) return cached;

  try {
    const res  = await fetch('https://blockchain.info/stats?format=json', { signal: AbortSignal.timeout(6000) });
    const data = await res.json();
    cacheSet('btc_stats', data);
    return data;
  } catch (e) {
    console.error('[ONCHAIN] BTC stats hatası:', e.message);
    return null;
  }
}

// ─── ETHERSCAN (ETH zincir istatistikleri) ────────────────────────────────────
async function fetchETHSupply() {
  const cached = cacheGet('eth_supply');
  if (cached) return cached;

  try {
    const url  = 'https://api.etherscan.io/api?module=stats&action=ethsupply&apikey=YourApiKeyToken';
    const res  = await fetch(url, { signal: AbortSignal.timeout(6000) });
    const data = await res.json();
    cacheSet('eth_supply', data);
    return data;
  } catch (e) {
    return null;
  }
}

// ─── 1. EXCHANGE RESERVE ─────────────────────────────────────────────────────
/**
 * analyzeExchangeReserve
 * Borsalardaki coin miktarı:
 *   - Azalıyorsa → Çekim artıyor → Bullish (uzun vade tutma)
 *   - Artıyorsa  → Satış baskısı yaklaşıyor → Bearish
 *
 * @param {object} params
 *   currentReserve   — Mevcut exchange reserve (USD veya coin)
 *   previousReserve  — Önceki periyot
 *   changePercent    — Hazır varsa direkt % değişim
 */
export function analyzeExchangeReserve({ currentReserve = 0, previousReserve = 0, changePercent = null }) {
  const pct = changePercent != null
    ? changePercent
    : previousReserve ? ((currentReserve - previousReserve) / previousReserve * 100) : 0;

  let score = 50;
  const signals = [];

  if (pct < -5)        { score += 25; signals.push(`Exchange reserve %${Math.abs(pct.toFixed(1))} azaldı — Çekim artıyor 🟢`); }
  else if (pct < -2)   { score += 12; signals.push(`Exchange reserve hafif azalıyor (%${pct.toFixed(1)})`); }
  else if (pct > 5)    { score -= 25; signals.push(`Exchange reserve %${pct.toFixed(1)} arttı — Satış baskısı ⚠️`); }
  else if (pct > 2)    { score -= 12; signals.push(`Exchange reserve hafif artıyor (%${pct.toFixed(1)})`); }
  else                 { signals.push('Exchange reserve sabit'); }

  return {
    score:           clamp(score),
    changePercent:   parseFloat(pct.toFixed(3)),
    direction:       pct < -1 ? 'AZALIYOR' : pct > 1 ? 'ARTIYYOR' : 'SABİT',
    bullish:         pct < -2,
    bearish:         pct > 2,
    signals,
    summary:         signals[0] || 'Veri yok',
    timestamp:       new Date().toISOString(),
  };
}

// ─── 2. SMART MONEY ──────────────────────────────────────────────────────────
/**
 * analyzeSmartMoney
 * Büyük cüzdan (whale) ve kurumsal davranış:
 *   - Biriktirme → Bullish
 *   - Dağıtım    → Bearish
 *
 * @param {object} params
 *   largeInflows    — Son 24s büyük giriş adedi
 *   largeOutflows   — Son 24s büyük çıkış adedi
 *   avgTxValue      — Ortalama büyük işlem değeri (USD)
 *   accumulationDays — Biriktirme süresi (gün)
 */
export function analyzeSmartMoney({ largeInflows = 0, largeOutflows = 0, avgTxValue = 0, accumulationDays = 0 }) {
  const netFlow = largeInflows - largeOutflows;
  let   score   = 50;
  const signals = [];

  // Net flow analizi
  if (netFlow >= 10)      { score += 20; signals.push(`Smart money: ${netFlow} net büyük giriş 🐳`); }
  else if (netFlow >= 5)  { score += 12; signals.push(`Hafif büyük para girişi (+${netFlow})`); }
  else if (netFlow <= -10){ score -= 20; signals.push(`Smart money çıkıyor: ${Math.abs(netFlow)} net çıkış ⚠️`); }
  else if (netFlow <= -5) { score -= 12; signals.push(`Hafif büyük para çıkışı (${netFlow})`); }

  // Biriktirme süresi
  if (accumulationDays >= 14)      { score += 15; signals.push(`${accumulationDays} gün biriktirme devam ediyor 📦`); }
  else if (accumulationDays >= 7)  { score += 8; }
  else if (accumulationDays <= -7) { score -= 15; signals.push(`${Math.abs(accumulationDays)} gün dağıtım süreci`); }

  // Büyük işlem büyüklüğü
  if (avgTxValue > 10_000_000)     { score += 8; signals.push(`Ortalama büyük işlem: $${(avgTxValue / 1e6).toFixed(1)}M`); }

  return {
    score:             clamp(score),
    netFlow,
    direction:         netFlow > 2 ? 'BİRİKTİRME' : netFlow < -2 ? 'DAĞITIM' : 'NÖTR',
    accumulating:      netFlow > 3 && accumulationDays > 5,
    distributing:      netFlow < -3,
    signals,
    summary:           signals[0] || 'Smart money: Nötr',
    timestamp:         new Date().toISOString(),
  };
}

// ─── 3. ACTIVE ADDRESSES ─────────────────────────────────────────────────────
/**
 * analyzeActiveAddresses
 * Aktif adres sayısı → Ağ kullanımı → Talep
 *
 * @param {object} params
 *   current7dAvg   — Son 7 günlük ortalama aktif adres
 *   previous7dAvg  — Önceki 7 günlük ortalama
 *   allTimeHigh    — ATH adres sayısı
 */
export function analyzeActiveAddresses({ current7dAvg = 0, previous7dAvg = 0, allTimeHigh = 1 }) {
  if (!current7dAvg) return { score: 50, summary: 'Veri yok', timestamp: new Date().toISOString() };

  const weekChange = previous7dAvg ? (current7dAvg - previous7dAvg) / previous7dAvg * 100 : 0;
  const athRatio   = allTimeHigh ? current7dAvg / allTimeHigh * 100 : 50;

  let score = 50;
  const signals = [];

  if (weekChange >= 20)      { score += 20; signals.push(`Aktif adres +%${weekChange.toFixed(0)} artış — Güçlü talep 📈`); }
  else if (weekChange >= 10) { score += 12; }
  else if (weekChange <= -20){ score -= 20; signals.push(`Aktif adres -%${Math.abs(weekChange).toFixed(0)} düşüş — Talep azalıyor`); }
  else if (weekChange <= -10){ score -= 10; }

  if (athRatio >= 85)        { score += 10; signals.push(`ATH'ye yakın (%${athRatio.toFixed(0)}) — Yoğun kullanım`); }
  else if (athRatio < 30)    { score -= 10; signals.push(`ATH'nin çok altında (%${athRatio.toFixed(0)})`); }

  return {
    score:        clamp(score),
    weekChange:   parseFloat(weekChange.toFixed(2)),
    athRatio:     parseFloat(athRatio.toFixed(1)),
    growing:      weekChange > 5,
    signals,
    summary:      signals[0] || `Aktif adres: ${weekChange >= 0 ? '+' : ''}${weekChange.toFixed(1)}% haftalık`,
    timestamp:    new Date().toISOString(),
  };
}

// ─── 4. TRANSFER SPIKE ────────────────────────────────────────────────────────
/**
 * analyzeTransferSpike
 * Ani büyük transfer tespiti:
 *   - Borsaya giden büyük transfer → Satış baskısı
 *   - Borsadan çıkan büyük transfer → Birikim (uzun vadeli tutma)
 *
 * @param {object} params
 *   transfers24h      — Son 24s toplam transfer adedi
 *   avgTransfers30d   — 30 günlük ortalama
 *   largeToExchange   — Borsaya giden büyük transfer adedi
 *   largeFromExchange — Borsadan çıkan büyük transfer adedi
 */
export function analyzeTransferSpike({ transfers24h = 0, avgTransfers30d = 0, largeToExchange = 0, largeFromExchange = 0 }) {
  let   score   = 50;
  const signals = [];
  const spikePct = avgTransfers30d ? (transfers24h - avgTransfers30d) / avgTransfers30d * 100 : 0;

  // Hacim spike
  if (spikePct >= 100)     { score += 15; signals.push(`Transfer hacmi 2x artış — Önemli hareket bekleniyor`); }
  else if (spikePct >= 50) { score += 8; }

  // Borsa yönü
  const netToBorsa = largeToExchange - largeFromExchange;
  if (netToBorsa >= 5)      { score -= 20; signals.push(`${largeToExchange} büyük transfer BORSAYA → Satış riski ⚠️`); }
  else if (netToBorsa <= -5){ score += 20; signals.push(`${largeFromExchange} büyük transfer BORSADAN → Birikim 🟢`); }
  else if (largeToExchange > 0 || largeFromExchange > 0) {
    signals.push(`Büyük transfer: ${largeToExchange} borsa girişi / ${largeFromExchange} borsa çıkışı`);
  }

  return {
    score:          clamp(score),
    spikePct:       parseFloat(spikePct.toFixed(2)),
    netToBorsa,
    exchangeInflow: largeToExchange,
    exchangeOutflow: largeFromExchange,
    spike:          spikePct >= 50,
    bearishFlow:    netToBorsa >= 5,
    bullishFlow:    netToBorsa <= -5,
    signals,
    summary:        signals[0] || 'Transfer akışı normal',
    timestamp:      new Date().toISOString(),
  };
}

// ─── 5. MINER FLOW (BTC) ─────────────────────────────────────────────────────
/**
 * analyzeMinerFlow
 * Madenci havuzdan borsa transferi:
 *   - Artıyorsa → Satış baskısı olabilir
 *
 * @param {object} params
 *   minerToExchange30dAvg  — 30 günlük ortalama
 *   minerToExchangeToday   — Bugünkü
 */
export function analyzeMinerFlow({ minerToExchange30dAvg = 0, minerToExchangeToday = 0 }) {
  if (!minerToExchange30dAvg) return { score: 50, summary: 'Madenci verisi yok', timestamp: new Date().toISOString() };

  const changePct = (minerToExchangeToday - minerToExchange30dAvg) / minerToExchange30dAvg * 100;
  let   score     = 50;
  const signals   = [];

  if (changePct >= 50)      { score -= 18; signals.push(`Madenci satışı +%${changePct.toFixed(0)} artış — Satış baskısı`); }
  else if (changePct >= 20) { score -= 8; }
  else if (changePct <= -30){ score += 12; signals.push(`Madenci satışı azaldı — Baskı hafifliyor 🟢`); }

  return {
    score:     clamp(score),
    changePct: parseFloat(changePct.toFixed(2)),
    increasing: changePct >= 20,
    signals,
    summary:   signals[0] || `Madenci akışı: ${changePct >= 0 ? '+' : ''}${changePct.toFixed(0)}%`,
    timestamp: new Date().toISOString(),
  };
}

// ─── ANA MOTOR ───────────────────────────────────────────────────────────────
/**
 * runAdvancedOnchainEngine — Tüm onchain modülleri çalıştır
 *
 * @param {object} onchainData — { reserve, smartMoney, addresses, transfers, miner }
 */
export function runAdvancedOnchainEngine(onchainData = {}) {
  const {
    reserve      = {},
    smartMoney   = {},
    addresses    = {},
    transfers    = {},
    miner        = {},
  } = onchainData;

  const reserveResult   = analyzeExchangeReserve(reserve);
  const smartResult     = analyzeSmartMoney(smartMoney);
  const addressResult   = analyzeActiveAddresses(addresses);
  const transferResult  = analyzeTransferSpike(transfers);
  const minerResult     = analyzeMinerFlow(miner);

  // Ağırlıklı ortalama skor
  const score = clamp(
    reserveResult.score  * 0.25 +
    smartResult.score    * 0.30 +
    addressResult.score  * 0.20 +
    transferResult.score * 0.15 +
    minerResult.score    * 0.10
  );

  const allSignals = [
    ...reserveResult.signals,
    ...smartResult.signals,
    ...addressResult.signals,
    ...transferResult.signals,
    ...minerResult.signals,
  ].filter(Boolean).slice(0, 6);

  const verdict = score >= 65 ? 'ZINCIR POZİTİF' : score <= 35 ? 'ZINCIR NEGATİF' : 'NÖTR';

  return {
    score:          parseFloat(score.toFixed(1)),
    verdict,
    modules: {
      reserve:  reserveResult,
      smart:    smartResult,
      address:  addressResult,
      transfer: transferResult,
      miner:    minerResult,
    },
    topSignals: allSignals,
    summary:    `${verdict} (${score.toFixed(0)}/100) — ${allSignals[0] || 'Normal onchain aktivite'}`,
    timestamp:  new Date().toISOString(),
  };
}

// ─── BTC GEÇMİŞ VERİ ÇEK (blockchain.info) ───────────────────────────────────
/**
 * fetchBTCOnchainData — Bitcoin zincir verisi çek
 */
export async function fetchBTCOnchainData() {
  const stats = await fetchBTCStats();
  if (!stats) return null;

  return {
    totalBTC:       stats.totalbc / 1e8,
    minedToday:     stats.n_btc_mined / 1e8,
    transactions24h: stats.n_tx,
    avgTxValue:     stats.total_fees_btc / 1e8,
    hashRate:       stats.hash_rate,
    difficulty:     stats.difficulty,
    timestamp:      new Date().toISOString(),
  };
}
