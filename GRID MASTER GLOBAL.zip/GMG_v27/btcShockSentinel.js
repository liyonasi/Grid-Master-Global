/**
 * GRID MASTER GLOBAL — BTC SHOCK SENTINEL v1
 * ============================================
 * BTC'nin ani dump veya pump hareketlerini ERKEN tespit eder.
 * Altcoinler etkilenmeden önce uyarı verir.
 *
 * MODÜLLER:
 *   1. Flash Crash Detector  — Kısa sürede sert düşüş
 *   2. Flash Pump Detector   — Kısa sürede sert yükseliş
 *   3. Cascade Risk Engine   — Domino etkisi riski
 *   4. BTC Correlation Guard — BTC hareketi altcoinleri ne kadar etkiler
 *   5. Shock Severity Score  — Şokun şiddeti ve süresi
 */

import { clamp, computeRSI } from './engineCore.js';

// ─── SABİTLER ────────────────────────────────────────────────────────────────
const FLASH_CRASH_THRESHOLD  = -3.0;  // %3 düşüş = uyarı
const FLASH_PUMP_THRESHOLD   =  4.0;  // %4 yükseliş = uyarı
const SEVERE_CRASH_THRESHOLD = -6.0;  // %6 = kritik
const SEVERE_PUMP_THRESHOLD  =  8.0;  // %8 = kritik
const SHOCK_WINDOW_CANDLES   = 3;     // Kaç mumda bakılacak

// ─── FLASH CRASH DETECTOR ────────────────────────────────────────────────────
/**
 * detectFlashCrash
 * Son N mumda BTC'nin ne kadar düştüğünü ölçer.
 *
 * @param {Array}  candles  — BTC mum dizisi
 * @param {number} window   — Kaç mum bakılacak (default: 3)
 */
export function detectFlashCrash(candles = [], window = SHOCK_WINDOW_CANDLES) {
  if (candles.length < window + 2) return { active: false, changePct: 0, severity: 'NONE' };

  const recent    = candles.slice(-window);
  const startPrice = candles[candles.length - window - 1]?.close || recent[0]?.open;
  const endPrice   = recent[recent.length - 1]?.close;

  if (!startPrice || !endPrice) return { active: false, changePct: 0, severity: 'NONE' };

  const changePct = (endPrice - startPrice) / startPrice * 100;
  const minLow    = Math.min(...recent.map(c => c.low));
  const wickDown  = (startPrice - minLow) / startPrice * 100; // Wick derinliği

  const severity = changePct <= SEVERE_CRASH_THRESHOLD ? 'KRİTİK' :
                   changePct <= FLASH_CRASH_THRESHOLD   ? 'UYARI'  : 'NONE';

  const active = changePct <= FLASH_CRASH_THRESHOLD;

  return {
    active,
    changePct:    parseFloat(changePct.toFixed(3)),
    wickDown:     parseFloat(wickDown.toFixed(3)),
    severity,
    startPrice,
    endPrice,
    candleCount:  window,
    message: active
      ? `⚡ BTC FLASH CRASH: ${changePct.toFixed(2)}% (${window} mumda)`
      : null,
  };
}

// ─── FLASH PUMP DETECTOR ─────────────────────────────────────────────────────
/**
 * detectFlashPump
 */
export function detectFlashPump(candles = [], window = SHOCK_WINDOW_CANDLES) {
  if (candles.length < window + 2) return { active: false, changePct: 0, severity: 'NONE' };

  const recent     = candles.slice(-window);
  const startPrice = candles[candles.length - window - 1]?.close || recent[0]?.open;
  const endPrice   = recent[recent.length - 1]?.close;

  if (!startPrice || !endPrice) return { active: false, changePct: 0, severity: 'NONE' };

  const changePct = (endPrice - startPrice) / startPrice * 100;
  const maxHigh   = Math.max(...recent.map(c => c.high));
  const wickUp    = (maxHigh - startPrice) / startPrice * 100;

  const severity = changePct >= SEVERE_PUMP_THRESHOLD ? 'KRİTİK' :
                   changePct >= FLASH_PUMP_THRESHOLD   ? 'UYARI'  : 'NONE';

  const active = changePct >= FLASH_PUMP_THRESHOLD;

  return {
    active,
    changePct: parseFloat(changePct.toFixed(3)),
    wickUp:    parseFloat(wickUp.toFixed(3)),
    severity,
    startPrice,
    endPrice,
    message: active
      ? `🚀 BTC FLASH PUMP: +${changePct.toFixed(2)}% (${window} mumda)`
      : null,
  };
}

// ─── CASCADE RISK ENGINE ──────────────────────────────────────────────────────
/**
 * computeCascadeRisk
 * Düşüş sonrası domino etkisi riski:
 *   - OI yüksekse → Long sıkışması olabilir
 *   - Funding pozitifse → Long ağırlıklı → Daha fazla likidasyon
 *   - Likidasyon seviyeleri yakınsa → Cascade tetikleyebilir
 *
 * @param {object} params
 *   openInterestChange — OI % değişim
 *   fundingRate        — Anlık funding (%)
 *   longRatio          — Long pozisyon oranı (0-1)
 *   crashPct           — Yaşanan düşüş %
 */
export function computeCascadeRisk({ openInterestChange = 0, fundingRate = 0, longRatio = 0.5, crashPct = 0 }) {
  let   riskScore = 30;
  const factors   = [];

  // OI düşüşü → likidasyon cascade
  if (openInterestChange <= -10) { riskScore += 25; factors.push(`OI %${openInterestChange.toFixed(1)} düştü — Likidasyon cascade`); }
  else if (openInterestChange <= -5) { riskScore += 12; }

  // Yüksek funding = aşırı long birikimi
  if (fundingRate >= 0.05)  { riskScore += 20; factors.push(`Funding %${fundingRate.toFixed(3)} — Aşırı long birikimi`); }
  else if (fundingRate >= 0.02) { riskScore += 10; }

  // Long ağırlığı
  if (longRatio >= 0.7)     { riskScore += 15; factors.push(`Long oranı %${(longRatio*100).toFixed(0)} — Sıkışma riski`); }
  else if (longRatio >= 0.6) { riskScore += 8; }

  // Crash şiddeti
  if (crashPct <= -5)       { riskScore += 15; }
  else if (crashPct <= -3)  { riskScore += 8; }

  riskScore = clamp(riskScore);

  return {
    riskScore,
    cascadelikely: riskScore >= 60,
    level:    riskScore >= 70 ? 'KRİTİK' : riskScore >= 50 ? 'YÜKSEK' : riskScore >= 30 ? 'ORTA' : 'DÜŞÜK',
    factors,
    warning:  riskScore >= 60 ? '⚠️ Cascade likidasyon riski yüksek — Pozisyon küçült' : null,
  };
}

// ─── BTC CORRELATION GUARD ───────────────────────────────────────────────────
/**
 * btcCorrelationGuard
 * BTC'nin altcoinlere yansıma gücünü ölçer.
 * BTC şok yaşıyorsa altcoin long açma.
 *
 * @param {number} btcChangePct   — BTC değişim %
 * @param {number} btcDominance   — BTC dominans %
 * @param {string} marketRegime   — 'BULL' | 'BEAR' | 'SIDEWAYS'
 */
export function btcCorrelationGuard({ btcChangePct = 0, btcDominance = 50, marketRegime = 'SIDEWAYS' }) {
  // BTC dominans yüksekse → altcoinler BTC'ye daha bağlı
  const corrStrength = clamp(btcDominance * 1.2); // 50% dom → 60 etki

  // BTC şok miktarı
  const shockMag = Math.abs(btcChangePct);
  let   altImpact = shockMag * (corrStrength / 100) * 1.3; // Altcoinler daha fazla sallanır

  // Bear piyasasında korelasyon güçlenir
  if (marketRegime === 'BEAR') altImpact *= 1.3;
  if (marketRegime === 'BULL') altImpact *= 0.9;

  const direction = btcChangePct < 0 ? 'DOWN' : 'UP';
  const blocked   = shockMag >= 3 && direction === 'DOWN'; // 3%+ crash = altcoin AL sinyali engelle

  return {
    btcChangePct,
    estimatedAltImpact: parseFloat(altImpact.toFixed(2)),
    direction,
    blocked,
    corrStrength,
    warning: blocked ? `🚨 BTC ${btcChangePct.toFixed(1)}% — Altcoin AL sinyalleri engellendi` : null,
    summary: `BTC ${btcChangePct >= 0 ? '+' : ''}${btcChangePct.toFixed(2)}% → Alt etki: ~${altImpact.toFixed(1)}%`,
  };
}

// ─── SHOCK SEVERITY SCORE ────────────────────────────────────────────────────
/**
 * computeShockSeverity — Şokun toplam şiddeti
 */
function computeShockSeverity(crashResult, pumpResult, cascadeRisk) {
  let score = 50;

  if (crashResult.active) {
    score -= Math.abs(crashResult.changePct) * 3;
    if (crashResult.severity === 'KRİTİK') score -= 20;
  }
  if (pumpResult.active) {
    score += pumpResult.changePct * 1.5;
    if (pumpResult.severity === 'KRİTİK') score += 10;
  }
  if (cascadeRisk.cascadelikely) score -= 15;

  return clamp(score);
}

// ─── ANA MOTOR ───────────────────────────────────────────────────────────────
/**
 * runBTCShockSentinel — Tüm BTC şok modüllerini çalıştır
 *
 * @param {object} params
 *   btcCandles         — BTC mum dizisi
 *   openInterestChange — OI değişim %
 *   fundingRate        — Funding oranı
 *   longRatio          — Long oranı
 *   btcDominance       — BTC dominans %
 *   marketRegime       — Piyasa rejimi
 */
export function runBTCShockSentinel({
  btcCandles         = [],
  openInterestChange = 0,
  fundingRate        = 0,
  longRatio          = 0.5,
  btcDominance       = 50,
  marketRegime       = 'SIDEWAYS',
} = {}) {

  const flashCrash   = detectFlashCrash(btcCandles);
  const flashPump    = detectFlashPump(btcCandles);
  const lastChange   = btcCandles.length >= 2
    ? (btcCandles[btcCandles.length - 1].close - btcCandles[btcCandles.length - 2].close)
      / btcCandles[btcCandles.length - 2].close * 100
    : 0;

  const cascadeRisk  = computeCascadeRisk({
    openInterestChange,
    fundingRate,
    longRatio,
    crashPct: flashCrash.active ? flashCrash.changePct : 0,
  });

  const corrGuard    = btcCorrelationGuard({ btcChangePct: lastChange, btcDominance, marketRegime });
  const shockScore   = computeShockSeverity(flashCrash, flashPump, cascadeRisk);

  const shockActive  = flashCrash.active || (cascadeRisk.cascadelikely && flashCrash.changePct < -2);
  const pumpActive   = flashPump.active;

  // Eğer şok varsa AL sinyallerini engelle
  const blockBuy     = shockActive || corrGuard.blocked;

  const alerts = [
    flashCrash.message,
    flashPump.message,
    cascadeRisk.warning,
    corrGuard.warning,
  ].filter(Boolean);

  return {
    score:          shockScore,
    shockActive,
    pumpActive,
    blockBuy,
    flashCrash,
    flashPump,
    cascadeRisk,
    corrGuard,
    alerts,
    severity: shockActive
      ? (flashCrash.severity === 'KRİTİK' ? 'KRİTİK' : 'UYARI')
      : pumpActive ? 'PUMP' : 'NORMAL',
    summary: alerts.length
      ? alerts[0]
      : `BTC Sentinel: Normal (${lastChange >= 0 ? '+' : ''}${lastChange.toFixed(2)}%)`,
    timestamp: new Date().toISOString(),
  };
}
