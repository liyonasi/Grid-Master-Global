/**
 * GRID MASTER GLOBAL — STRUCTURE ENGINES
 * ========================================
 * STRUCTURE_DETECTOR   — BOS, CHoCH, HH/HL/LL/LH tespiti
 * SR_TOUCH_ENGINE      — S/R dokunuş ve güç analizi
 * PULLBACK_ESTIMATOR   — Sağlıklı geri çekilme seviyeleri
 */

const clamp = (v, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, v));

// ═══════════════════════════════════════════════════════════════════════════════
// 1. STRUCTURE DETECTOR — BOS / CHoCH / HH / HL / LL / LH
// ═══════════════════════════════════════════════════════════════════════════════
/**
 * Market yapısı analizi.
 * BOS  (Break of Structure) — trend devam
 * CHoCH (Change of Character) — trend dönüşü
 * HH/HL — bullish yapı
 * LH/LL — bearish yapı
 */
export function detectMarketStructure(klines) {
  if (!klines || klines.length < 20) {
    return { structure: 'UNKNOWN', bos: null, choch: null, bias: 'neutral', swings: [] };
  }

  const highs  = klines.map(k => k.h ?? k.high  ?? k.c ?? k.price ?? 0);
  const lows   = klines.map(k => k.l ?? k.low   ?? k.c ?? k.price ?? 0);
  const closes = klines.map(k => k.c ?? k.close ?? k.price ?? 0);
  const n      = closes.length;

  // Swing high/low tespiti (3 mum window)
  const swingHighs = [], swingLows = [];
  for (let i = 2; i < n - 2; i++) {
    const isSwingH = highs[i] > highs[i-1] && highs[i] > highs[i-2] &&
                     highs[i] > highs[i+1] && highs[i] > highs[i+2];
    const isSwingL = lows[i]  < lows[i-1]  && lows[i]  < lows[i-2]  &&
                     lows[i]  < lows[i+1]  && lows[i]  < lows[i+2];
    if (isSwingH) swingHighs.push({ price: highs[i], idx: i });
    if (isSwingL) swingLows.push({ price: lows[i],   idx: i });
  }

  // Son 4 swing noktasından yapıyı oku
  const lastHighs = swingHighs.slice(-3);
  const lastLows  = swingLows.slice(-3);

  // HH/HL analizi (bullish)
  const hh = lastHighs.length >= 2 && lastHighs[lastHighs.length-1].price > lastHighs[lastHighs.length-2].price;
  const hl = lastLows.length  >= 2 && lastLows[lastLows.length-1].price   > lastLows[lastLows.length-2].price;
  // LH/LL analizi (bearish)
  const lh = lastHighs.length >= 2 && lastHighs[lastHighs.length-1].price < lastHighs[lastHighs.length-2].price;
  const ll = lastLows.length  >= 2 && lastLows[lastLows.length-1].price   < lastLows[lastLows.length-2].price;

  // Yapı belirleme
  let structure = 'RANGING';
  let bias = 'neutral';
  if (hh && hl)   { structure = 'BULLISH'; bias = 'bullish'; }
  else if (lh && ll) { structure = 'BEARISH'; bias = 'bearish'; }
  else if (hh && ll) { structure = 'DAĞILIM'; bias = 'bearish'; }
  else if (hl && lh) { structure = 'BİRİKİM'; bias = 'bullish'; }

  // BOS (Break of Structure) tespiti
  let bos = null;
  const curPrice = closes[n-1];
  const lastSwingH = swingHighs[swingHighs.length-1];
  const lastSwingL = swingLows[swingLows.length-1];

  if (lastSwingH && curPrice > lastSwingH.price) {
    bos = { type: 'BOS_YUKARI', level: lastSwingH.price, current: curPrice,
            break_pct: ((curPrice - lastSwingH.price) / lastSwingH.price * 100).toFixed(2) };
  } else if (lastSwingL && curPrice < lastSwingL.price) {
    bos = { type: 'BOS_ASAGI', level: lastSwingL.price, current: curPrice,
            break_pct: ((lastSwingL.price - curPrice) / lastSwingL.price * 100).toFixed(2) };
  }

  // CHoCH (Change of Character) tespiti
  // Bullish yapıda ilk LL = CHoCH (dönüş sinyali)
  // Bearish yapıda ilk HH = CHoCH
  let choch = null;
  if (structure === 'BULLISH' && ll) {
    choch = { type: 'CHOCH_BEARISH', message: 'Bullish yapıda LL kırıldı — dönüş ihtimali', strength: 75 };
  } else if (structure === 'BEARISH' && hh) {
    choch = { type: 'CHOCH_BULLISH', message: 'Bearish yapıda HH kırıldı — dönüş ihtimali', strength: 75 };
  }

  // İç yapı (internal structure) — kısa vadeli dönüş
  const internalHighs = swingHighs.slice(-2);
  const internalLows  = swingLows.slice(-2);
  const internalBias  =
    internalHighs.length >= 2 && internalLows.length >= 2
      ? (internalHighs[1].price > internalHighs[0].price &&
         internalLows[1].price  > internalLows[0].price ? 'bullish' : 'bearish')
      : 'neutral';

  return {
    structure,
    bias,
    internalBias,
    hh, hl, lh, ll,
    bos,
    choch,
    swingHighs: swingHighs.slice(-5),
    swingLows:  swingLows.slice(-5),
    lastSwingHigh: lastSwingH || null,
    lastSwingLow:  lastSwingL || null,
    score: clamp(
      50 +
      (bias === 'bullish' ? 20 : bias === 'bearish' ? -20 : 0) +
      (bos?.type === 'BOS_YUKARI' ? 15 : bos?.type === 'BOS_ASAGI' ? -15 : 0) +
      (choch?.type === 'CHOCH_BULLISH' ? 10 : choch?.type === 'CHOCH_BEARISH' ? -10 : 0)
    ),
    summary: `${structure} | ${bos ? bos.type : 'BOS yok'} | ${choch ? choch.type : 'CHoCH yok'}`,
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// 2. S/R TOUCH ENGINE — Destek/Direnç Dokunuş Analizi
// ═══════════════════════════════════════════════════════════════════════════════
/**
 * Seviyenin gücünü dokunuş sayısı + tepki gücüyle ölçer.
 * Kırılım sonrası retest tespiti.
 * Rejection (güçlü red/pin bar) analizi.
 */
export function analyzeSRLevels(klines, currentPrice) {
  if (!klines || klines.length < 30 || !currentPrice) return { supports: [], resistances: [], nearestSupport: null, nearestResistance: null };

  const highs  = klines.map(k => k.h ?? k.high  ?? k.c ?? 0);
  const lows   = klines.map(k => k.l ?? k.low   ?? k.c ?? 0);
  const closes = klines.map(k => k.c ?? k.close ?? 0);
  const n      = closes.length;

  // Swing noktaları topla
  const swingH = [], swingL = [];
  for (let i = 3; i < n - 3; i++) {
    let mxH = true, mnL = true;
    for (let j = i-3; j <= i+3; j++) {
      if (j !== i && highs[j] >= highs[i]) mxH = false;
      if (j !== i && lows[j]  <= lows[i])  mnL = false;
    }
    if (mxH) swingH.push({ price: highs[i], idx: i });
    if (mnL) swingL.push({ price: lows[i],  idx: i });
  }

  // Cluster oluştur (yakın seviyeleri birleştir)
  function cluster(points, above) {
    const tolerance = 0.006;
    const zones = [];
    for (const p of points) {
      const ex = zones.find(z => Math.abs(z.price - p.price) / p.price < tolerance);
      if (ex) {
        ex.touches++;
        ex.price = (ex.price * (ex.touches-1) + p.price) / ex.touches;
        ex.lastIdx = Math.max(ex.lastIdx, p.idx);
      } else {
        zones.push({ price: p.price, touches: 1, lastIdx: p.idx, rejections: 0, strength: 0 });
      }
    }

    // Güç hesapla
    return zones.map(z => {
      // Dokunuş sayısı
      const touchScore = Math.min(z.touches * 18, 60);
      // Yakınlık skoru (mevcut fiyata göre)
      const dist = Math.abs(currentPrice - z.price) / currentPrice * 100;
      const distScore = dist < 0.5 ? 20 : dist < 1 ? 14 : dist < 2 ? 8 : 2;
      // Güncellik
      const recency = (z.lastIdx / n) * 15;
      // Yuvarlak sayı bonusu
      const isRound = z.price % 100 < 5 || z.price % 100 > 95 ||
                      z.price % 500 < 10 || z.price % 1000 < 20;
      const roundBonus = isRound ? 15 : 0;

      z.strength = Math.round(clamp(touchScore + distScore + recency + roundBonus));
      z.dist     = parseFloat(dist.toFixed(2));
      z.isRound  = isRound;
      z.type     = above ? 'direnç' : 'destek';
      return z;
    }).sort((a, b) => b.strength - a.strength);
  }

  const resistances = cluster(swingH.filter(p => p.price > currentPrice * 1.001), true)
    .sort((a, b) => a.price - b.price).slice(0, 5);
  const supports    = cluster(swingL.filter(p => p.price < currentPrice * 0.999), false)
    .sort((a, b) => b.price - a.price).slice(0, 5);

  // Retest tespiti: son kırılım var mı?
  let retest = null;
  const lastHigh = swingH[swingH.length-1];
  const lastLow  = swingL[swingL.length-1];
  if (lastHigh && Math.abs(currentPrice - lastHigh.price) / currentPrice < 0.008) {
    retest = { type: 'RETEST_DİRENÇ', level: lastHigh.price,
               message: 'Kırılan direnç seviyesini test ediyor — potansiyel destek' };
  } else if (lastLow && Math.abs(currentPrice - lastLow.price) / currentPrice < 0.008) {
    retest = { type: 'RETEST_DESTEK', level: lastLow.price,
               message: 'Kırılan destek seviyesini test ediyor — potansiyel direnç' };
  }

  return {
    supports,
    resistances,
    nearestSupport:    supports[0]    || null,
    nearestResistance: resistances[0] || null,
    retest,
    score: clamp(
      50 +
      (supports[0]    ? Math.min(supports[0].strength    * 0.3, 20) : 0) -
      (resistances[0] ? Math.min(resistances[0].strength * 0.3, 20) : 0)
    ),
    summary: `En yakın destek: ${supports[0]?.price?.toFixed(2) || '—'} (güç: ${supports[0]?.strength || 0}) | Direnç: ${resistances[0]?.price?.toFixed(2) || '—'}`,
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// 3. PULLBACK ESTIMATOR — Geri Çekilme Seviye Tahmini
// ═══════════════════════════════════════════════════════════════════════════════
/**
 * Trendin devamında sağlıklı geri çekilme seviyelerini hesaplar.
 * Fibonacci + ATR + EMA yaklaşımı.
 * healthy pullback vs weak pullback ayrımı.
 */
export function estimatePullback(klines, direction = 'UP') {
  if (!klines || klines.length < 20) return null;

  const highs  = klines.map(k => k.h ?? k.high  ?? k.c ?? 0);
  const lows   = klines.map(k => k.l ?? k.low   ?? k.c ?? 0);
  const closes = klines.map(k => k.c ?? k.close ?? 0);
  const n      = closes.length;

  const cur     = closes[n-1];
  const recentH = Math.max(...highs.slice(-20));
  const recentL = Math.min(...lows.slice(-20));
  const move    = recentH - recentL;

  // ATR hesapla
  const trs = klines.slice(1).map((k, i) => {
    const h = k.h ?? 0, l = k.l ?? 0, pc = klines[i].c ?? 0;
    return Math.max(h - l, Math.abs(h - pc), Math.abs(l - pc));
  });
  const atr = trs.slice(-14).reduce((a, b) => a + b, 0) / 14;

  // EMA
  function ema(arr, p) {
    const k = 2/(p+1); let v = arr.slice(0,p).reduce((a,b)=>a+b,0)/p;
    for (let i = p; i < arr.length; i++) v = arr[i]*k + v*(1-k);
    return v;
  }
  const e21 = ema(closes, 21);
  const e50 = closes.length > 50 ? ema(closes, 50) : null;

  // Fibonacci seviyeleri
  const fib = {
    0:    direction === 'UP' ? recentH : recentL,
    0.236: direction === 'UP' ? recentH - move * 0.236 : recentL + move * 0.236,
    0.382: direction === 'UP' ? recentH - move * 0.382 : recentL + move * 0.382,
    0.5:   direction === 'UP' ? recentH - move * 0.5   : recentL + move * 0.5,
    0.618: direction === 'UP' ? recentH - move * 0.618 : recentL + move * 0.618,
    0.786: direction === 'UP' ? recentH - move * 0.786 : recentL + move * 0.786,
    1:    direction === 'UP' ? recentL : recentH,
  };

  // Sağlıklı geri çekilme bölgesi: Fib 0.382 - 0.618
  const healthyZone = {
    top:    fib[0.382],
    bottom: fib[0.618],
    ideal:  fib[0.5],
  };

  // Geri çekilme türü
  const pullbackDepth = direction === 'UP'
    ? (recentH - cur) / move * 100
    : (cur - recentL) / move * 100;

  let pullbackType = 'BEKLE';
  if (pullbackDepth < 23.6)  pullbackType = 'ÇOK SAĞLIKLI — GİRİŞ ERKEN';
  else if (pullbackDepth < 50)  pullbackType = 'SAĞLIKLI GERİ ÇEKİLME — GİRİŞ BÖLGESI';
  else if (pullbackDepth < 61.8) pullbackType = 'DERİN GERİ ÇEKİLME — DİKKATLİ GİR';
  else if (pullbackDepth < 78.6) pullbackType = 'ZAYIF GERİ ÇEKİLME — TREND BOZULUYOR';
  else pullbackType = 'TREND İPTALİ — GİRME';

  // İnvalidasyon noktası
  const invalidation = direction === 'UP' ? recentL - atr * 0.5 : recentH + atr * 0.5;

  // Giriş seviyeleri
  const entries = [
    { level: fib[0.382],  label: 'Fib 0.382 — Güçlü giriş',    quality: 'HIGH'   },
    { level: fib[0.5],    label: 'Fib 0.500 — Dengeli giriş',   quality: 'MEDIUM' },
    { level: e21,         label: 'EMA 21 — Dinamik destek',      quality: 'HIGH'   },
    { level: fib[0.618],  label: 'Fib 0.618 — Son şans girişi', quality: 'LOW'    },
    ...(e50 ? [{ level: e50, label: 'EMA 50 — Güçlü destek', quality: 'HIGH' }] : []),
  ].filter(e => {
    if (direction === 'UP') return e.level < cur && e.level > invalidation;
    return e.level > cur && e.level < invalidation;
  }).sort((a, b) => direction === 'UP' ? b.level - a.level : a.level - b.level);

  return {
    direction,
    currentPrice:  cur,
    moveSize:      parseFloat(move.toFixed(2)),
    pullbackDepth: parseFloat(pullbackDepth.toFixed(1)),
    pullbackType,
    fibonacci:     fib,
    healthyZone,
    entries,
    invalidation:  parseFloat(invalidation.toFixed(2)),
    atr:           parseFloat(atr.toFixed(4)),
    ema21:         parseFloat(e21.toFixed(2)),
    ema50:         e50 ? parseFloat(e50.toFixed(2)) : null,
    isHealthy:     pullbackDepth >= 23.6 && pullbackDepth <= 61.8,
    summary: `${pullbackType} | Derinlik: %${pullbackDepth.toFixed(1)} | İdeal giriş: ${fib[0.5].toFixed(2)}`,
  };
}
