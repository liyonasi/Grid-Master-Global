/**
 * backtestWorker.js — GMG v14
 * Vite + CRA (webpack4/5) uyumlu Web Worker
 *
 * KULLANIM:
 *   // Vite & CRA webpack5 (react-scripts >= 5):
 *   new Worker(new URL('./backtestWorker.js', import.meta.url), { type: 'module' })
 *   // CRA webpack4 (react-scripts < 5) — type:'module' desteklenmiyor:
 *   new Worker(new URL('./backtestWorker.js', import.meta.url))
 *   → Bu durumda inline fallback devreye girer (main thread)
 */

/* global self */
const IS_MODULE_WORKER = typeof importScripts === 'undefined';

let backtestReady = false;
let runBacktest = null;
let runMultiPeriodBacktest = null;

async function loadEngine() {
  if (backtestReady) return true;
  if (IS_MODULE_WORKER) {
    try {
      const mod = await import('./backtestEngine.js');
      runBacktest = mod.runBacktest;
      runMultiPeriodBacktest = mod.runMultiPeriodBacktest;
      backtestReady = true;
      return true;
    } catch (e) {
      console.warn('[backtestWorker] ES import hatası:', e.message);
    }
  }
  if (!IS_MODULE_WORKER) {
    try {
      importScripts('./backtestEngine.js');
      if (typeof self.runBacktest === 'function') {
        runBacktest = self.runBacktest;
        runMultiPeriodBacktest = self.runMultiPeriodBacktest;
        backtestReady = true;
        return true;
      }
    } catch (e) {
      console.warn('[backtestWorker] importScripts hatası:', e.message);
    }
  }
  return false;
}

function _daysLabel(d) {
  return d<=7?'1 Hafta':d<=14?'2 Hafta':d<=30?'1 Ay':d<=90?'3 Ay':d<=180?'6 Ay':d<=365?'1 Yıl':`${d} Gün`;
}

function _fallback(klines, params, config, periods) {
  return (periods||[30,90,180,365]).map(days=>({
    days, label:_daysLabel(days),
    stats:{totalTrades:0,winRate:0,totalReturn:0,maxDrawdown:0,profitFactor:0,avgTrade:0,sharpe:0},
    trades:[], equity:[{x:0,y:config?.initialCapital||10000}],
    error:'Engine yüklenemedi',
  }));
}

self.onmessage = async (event) => {
  const { type, id, klines, params, config, periods } = event.data;
  if (type !== 'RUN') return;
  self.postMessage({ type:'PROGRESS', id, progress:5 });
  try {
    const ok = await loadEngine();
    self.postMessage({ type:'PROGRESS', id, progress:20 });
    let result;
    if (ok && typeof runMultiPeriodBacktest === 'function') {
      result = runMultiPeriodBacktest(klines, params, config, periods);
      self.postMessage({ type:'PROGRESS', id, progress:90 });
    } else if (ok && typeof runBacktest === 'function') {
      const r = runBacktest(klines, params, config);
      result = (periods||[30,90,180,365]).map(days=>({days,label:_daysLabel(days),...r}));
      self.postMessage({ type:'PROGRESS', id, progress:90 });
    } else {
      result = _fallback(klines, params, config, periods);
    }
    self.postMessage({ type:'RESULT', id, result });
  } catch (err) {
    self.postMessage({ type:'ERROR', id, error:err.message });
  }
};
