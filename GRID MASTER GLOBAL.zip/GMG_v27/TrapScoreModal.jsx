/**
 * TrapScoreModal.jsx — GMG v19
 * TrapScore widget'a tıklanınca açılan detay modal.
 * trapDetectionEngine.runTrapScoreEngine() çıktısını görselleştirir.
 *
 * Props:
 *   trapData  — runTrapScoreEngine() return objesi
 *   onClose   — modal kapat callback
 */
import React from 'react';

// ─── RENK HESABI ─────────────────────────────────────────────────────────────
function scoreColor(s) {
  if (s >= 71) return '#ff2233';
  if (s >= 41) return '#ffcc00';
  return '#00ff88';
}

function ScoreBar({ label, value, weight }) {
  const pct   = Math.min(100, Math.max(0, value));
  const color = scoreColor(value);
  return (
    <div style={{ marginBottom: 8 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 3 }}>
        <span style={{ fontSize: 9, color: '#9090c0', fontFamily: 'monospace' }}>{label}</span>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <span style={{ fontSize: 8, color: '#404070', fontFamily: 'monospace' }}>ağ:{(weight * 100).toFixed(0)}%</span>
          <span style={{ fontSize: 10, fontWeight: 700, color, fontFamily: 'monospace' }}>{value}</span>
        </div>
      </div>
      <div style={{ height: 5, background: '#0a0a1c', borderRadius: 3, overflow: 'hidden' }}>
        <div style={{
          width: `${pct}%`, height: '100%',
          background: color,
          borderRadius: 3,
          transition: 'width .4s',
          boxShadow: value >= 71 ? `0 0 6px ${color}88` : 'none',
        }} />
      </div>
    </div>
  );
}

// ─── ANA MODAL ────────────────────────────────────────────────────────────────
export default function TrapScoreModal({ trapData, onClose }) {
  if (!trapData) return null;

  const { totalScore, score, riskLevel, action, activeTraps, scores, verdict, recommendation } = trapData;
  const finalScore = totalScore ?? score ?? 0;
  const mainColor  = scoreColor(finalScore);

  const WEIGHTS = {
    stopHunt:     0.22,
    doubleStop:   0.18,
    sweep:        0.15,
    hft:          0.13,
    bait:         0.12,
    fakeBreakout: 0.12,
    spoofing:     0.08,
  };
  const LABELS = {
    stopHunt:     '🎯 Stop Hunt',
    doubleStop:   '🎯🎯 Çift Stop Hunt',
    sweep:        '🌊 Likidite Sweep',
    hft:          '⚡ HFT Pulse',
    bait:         '🪝 Bait / Tuzak',
    fakeBreakout: '💥 Sahte Kırılım',
    spoofing:     '👻 Spoofing',
  };

  return (
    /* Overlay */
    <div
      onClick={onClose}
      style={{
        position: 'fixed', inset: 0, zIndex: 9999,
        background: 'rgba(0,0,0,0.75)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        backdropFilter: 'blur(3px)',
      }}
    >
      {/* Panel — tıklama propagation'ı durdur */}
      <div
        onClick={e => e.stopPropagation()}
        style={{
          width: 340, maxWidth: '95vw',
          background: '#07070f',
          border: `1px solid ${mainColor}44`,
          borderRadius: 10,
          padding: '18px 20px',
          fontFamily: 'monospace',
          boxShadow: `0 0 30px ${mainColor}22`,
          position: 'relative',
        }}
      >
        {/* Kapat butonu */}
        <button
          onClick={onClose}
          style={{
            position: 'absolute', top: 10, right: 12,
            background: 'none', border: 'none',
            color: '#404070', fontSize: 16, cursor: 'pointer',
            lineHeight: 1,
          }}
        >✕</button>

        {/* Başlık */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
          <span style={{ fontSize: 16 }}>🪤</span>
          <span style={{ fontSize: 12, fontWeight: 700, color: mainColor, letterSpacing: 2 }}>
            TUZAK SKORU
          </span>
          <span style={{
            marginLeft: 'auto', fontSize: 22, fontWeight: 900, color: mainColor,
            textShadow: `0 0 12px ${mainColor}88`,
          }}>
            {finalScore}
          </span>
        </div>

        {/* Verdict banner */}
        <div style={{
          background: `${mainColor}12`,
          border: `1px solid ${mainColor}44`,
          borderRadius: 6, padding: '6px 10px', marginBottom: 14,
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        }}>
          <span style={{ fontSize: 10, color: mainColor, fontWeight: 700 }}>{verdict}</span>
          <span style={{
            fontSize: 9, padding: '1px 6px', borderRadius: 3,
            background: action === 'WAIT' ? '#ff223320' : '#00ff8820',
            color: action === 'WAIT' ? '#ff2233' : '#00ff88',
            fontWeight: 700,
          }}>
            {action === 'WAIT' ? '⛔ BEKLE' : '✓ DEVAM'}
          </span>
        </div>

        {/* Risk seviyesi */}
        <div style={{ display: 'flex', gap: 10, marginBottom: 14 }}>
          <div style={{ flex: 1, textAlign: 'center', background: '#0a0a1c', borderRadius: 5, padding: '5px 0' }}>
            <div style={{ fontSize: 8, color: '#404070', marginBottom: 2 }}>RİSK SEVİYESİ</div>
            <div style={{ fontSize: 11, fontWeight: 700, color: mainColor }}>{riskLevel || '—'}</div>
          </div>
          <div style={{ flex: 1, textAlign: 'center', background: '#0a0a1c', borderRadius: 5, padding: '5px 0' }}>
            <div style={{ fontSize: 8, color: '#404070', marginBottom: 2 }}>AKTİF TUZAK</div>
            <div style={{ fontSize: 11, fontWeight: 700, color: activeTraps?.length ? '#ff2233' : '#00ff88' }}>
              {activeTraps?.length || 0}
            </div>
          </div>
        </div>

        {/* Aktif tuzaklar */}
        {activeTraps?.length > 0 && (
          <div style={{ marginBottom: 14 }}>
            <div style={{ fontSize: 8, color: '#404070', letterSpacing: 1, marginBottom: 5 }}>AKTİF TUZAKLAR</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
              {activeTraps.map((t, i) => (
                <span key={i} style={{
                  fontSize: 8, padding: '2px 7px', borderRadius: 3,
                  background: '#ff223318', border: '1px solid #ff223340',
                  color: '#ff2233', fontWeight: 700,
                }}>
                  {t}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Bileşen skorları */}
        {scores && (
          <div style={{ marginBottom: 10 }}>
            <div style={{ fontSize: 8, color: '#404070', letterSpacing: 1, marginBottom: 8 }}>BİLEŞEN SKORLARI</div>
            {Object.entries(scores).map(([key, val]) => (
              <ScoreBar
                key={key}
                label={LABELS[key] || key}
                value={val || 0}
                weight={WEIGHTS[key] || 0}
              />
            ))}
          </div>
        )}

        {/* Tavsiye */}
        <div style={{
          fontSize: 9, color: '#6060a0', lineHeight: 1.5,
          borderTop: '1px solid #1a1a2e', paddingTop: 8, marginTop: 4,
        }}>
          {recommendation || 'Tuzak verisi yok.'}
        </div>

        {/* Zaman damgası */}
        <div style={{ fontSize: 7, color: '#2a2a4a', marginTop: 6, textAlign: 'right' }}>
          {new Date(trapData.timestamp || Date.now()).toLocaleTimeString('tr-TR')}
        </div>
      </div>
    </div>
  );
}
