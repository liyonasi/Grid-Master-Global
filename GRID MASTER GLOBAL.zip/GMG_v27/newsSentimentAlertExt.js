/**
 * GRID MASTER GLOBAL — NEWS SENTIMENT EXT + AI DECISION EXT + ALERT EXT v1
 * ===========================================================================
 *
 * NEWS & SENTIMENT:
 *   GLOBAL SENTIMENT ENGINE
 *   EVENT IMPACT ENGINE
 *   MEDIA HYPE ANALYZER
 *
 * AI DECISION:
 *   MARKET STATE ENGINE (tam)
 *   FALSE SIGNAL FILTER
 *   WEIGHTED VOTING SYSTEM
 *   DOUBLE CONFIRMATION PROTOCOL
 *
 * ALERT:
 *   WEB PUSH ALERT ENGINE
 *   EMAIL ALERT ENGINE
 *   SCALP SIGNAL ALERT
 *   TRAP ALERT
 *   FINAL COUNCIL ALERT
 */

import { clamp } from './engineCore.js';

// ════════════════════════════════════════════════════════════════════════════════
// NEWS & SENTIMENT EXTENSIONS
// ════════════════════════════════════════════════════════════════════════════════

// ─── 1. GLOBAL SENTIMENT ENGINE ───────────────────────────────────────────────
/**
 * Küresel piyasa sentiment'ini birleştirir.
 * Kaynak: Fear & Greed + VIX + Kredi spreadi + Para akışı
 */
export function runGlobalSentimentEngine({
  fearGreed      = 50,
  vixLevel       = 20,
  highYieldSpread= 400,  // bps
  cryptoFlow     = 0,    // $mlr
  twitterSentiment = 0,  // -100 ile +100 arası
  redditBullRatio  = 0.5,
} = {}) {

  let   score   = 50;
  const signals = [];

  // Fear & Greed (ağırlık: 30)
  score += (fearGreed - 50) * 0.30;

  // VIX (ağırlık: 25)
  if (vixLevel >= 30)    { score -= 20; signals.push(`VIX ${vixLevel} — Panik piyasası`); }
  else if (vixLevel <= 15) { score += 15; signals.push('VIX düşük — Olumlu sentiment'); }
  else score += (15 - vixLevel) * 0.8;

  // Kredi spreadi (ağırlık: 20)
  if (highYieldSpread <= 300) { score += 12; }
  else if (highYieldSpread >= 600) { score -= 15; signals.push('HY spreadi geniş — Risk kaçınımı'); }

  // Sosyal medya (ağırlık: 15)
  score += twitterSentiment * 0.08;
  if (redditBullRatio >= 0.7)  { score += 8; signals.push('Reddit aşırı bullish — FOMO riski'); }
  else if (redditBullRatio <= 0.3) { score += 5; signals.push('Reddit bearish — Dip fırsatı olabilir'); }

  // Para akışı (ağırlık: 10)
  if (cryptoFlow >= 1)    { score += 10; }
  else if (cryptoFlow <= -1) { score -= 10; }

  score = clamp(Math.round(score));

  return {
    score,
    fearGreed, vixLevel, highYieldSpread, cryptoFlow,
    twitterSentiment, redditBullRatio,
    sentiment:  score >= 65 ? 'AŞIRI İYİMSER' : score >= 55 ? 'İYİMSER' :
                score >= 45 ? 'NÖTR' : score >= 35 ? 'KÖTÜMSER' : 'AŞIRI KÖTÜMSER',
    signals,
    summary:    signals[0] || `Küresel sentiment: ${score}/100`,
    timestamp:  new Date().toISOString(),
  };
}

// ─── 2. EVENT IMPACT ENGINE ───────────────────────────────────────────────────
/**
 * Belirli bir olayın piyasa etkisini ölçer.
 */
export const EVENT_TYPES = {
  FED_PIVOT:          { impact: 90, direction: 'BULLISH', duration: '1-3ay' },
  FED_RATE_HIKE:      { impact: 75, direction: 'BEARISH', duration: '1-2hafta' },
  ETF_APPROVAL:       { impact: 85, direction: 'BULLISH', duration: '2-4hafta' },
  EXCHANGE_HACK:      { impact: 80, direction: 'BEARISH', duration: '3-7gün' },
  REGULATION_BAN:     { impact: 85, direction: 'BEARISH', duration: '1-2hafta' },
  REGULATION_POSITIVE:{ impact: 70, direction: 'BULLISH', duration: '1-2hafta' },
  BTC_HALVING:        { impact: 80, direction: 'BULLISH', duration: '3-6ay' },
  MACRO_CRISIS:       { impact: 90, direction: 'BEARISH', duration: '2-8hafta' },
  INSTITUTIONAL_BUY:  { impact: 65, direction: 'BULLISH', duration: '3-7gün' },
  STABLECOIN_DEPEG:   { impact: 85, direction: 'BEARISH', duration: '1-5gün' },
};

export function runEventImpactEngine({ eventType = null, daysAgo = 0, magnitude = 1.0 } = {}) {
  if (!eventType || !EVENT_TYPES[eventType]) {
    return { score: 50, impact: 0, summary: 'Aktif olay yok', timestamp: new Date().toISOString() };
  }

  const event   = EVENT_TYPES[eventType];
  const decayFactor = Math.max(0, 1 - daysAgo * 0.1); // Her gün %10 azalır
  const impact  = event.impact * magnitude * decayFactor;

  const score = event.direction === 'BULLISH'
    ? clamp(50 + impact * 0.5)
    : clamp(50 - impact * 0.5);

  return {
    score,
    eventType,
    direction:    event.direction,
    rawImpact:    event.impact,
    currentImpact: parseFloat(impact.toFixed(1)),
    daysAgo,
    decayFactor:  parseFloat(decayFactor.toFixed(2)),
    duration:     event.duration,
    active:       daysAgo <= 7,
    summary:      `${eventType}: ${event.direction} (etki: ${impact.toFixed(0)}/100, ${daysAgo}g önce)`,
    timestamp:    new Date().toISOString(),
  };
}

// ─── 3. MEDIA HYPE ANALYZER ───────────────────────────────────────────────────
/**
 * Ana akım medyanın kripto haberlerini analiz eder.
 * Aşırı hype = tepe, Sessizlik = dip fırsatı
 */
export function runMediaHypeAnalyzer({
  mainStreamMentions = 0,  // Ana akım medyada haftalık haber sayısı
  cryptoMediaScore   = 50, // Kripto medya olumlu/olumsuz skoru
  googleTrendsScore  = 50, // Google Trends 0-100
  youtubeVideoCount  = 0,  // Haftalık kripto video sayısı
} = {}) {

  let   hypeScore = 0;
  const signals   = [];

  if (mainStreamMentions >= 50)     { hypeScore += 30; signals.push('Ana akım medyada aşırı haber — Tepe yakın olabilir'); }
  else if (mainStreamMentions >= 20){ hypeScore += 15; }
  else if (mainStreamMentions <= 3) { hypeScore -= 10; signals.push('Medya sessizliği — Birikim fırsatı'); }

  if (googleTrendsScore >= 80)      { hypeScore += 25; signals.push('Google arama patlaması — FOMO sinyali'); }
  else if (googleTrendsScore <= 20) { hypeScore -= 10; signals.push('Arama düşük — Piyasa ilgisi azalmış'); }

  if (youtubeVideoCount >= 500)     { hypeScore += 20; signals.push('YouTube kripto içeriği patladı — Retail FOMO'); }

  hypeScore = clamp(hypeScore);

  // Yüksek hype = tepe riski = düşük skor (trading için)
  const tradingScore = clamp(100 - hypeScore);

  return {
    score:        tradingScore,
    hypeScore,
    mainStreamMentions, googleTrendsScore, youtubeVideoCount,
    hypePeak:     hypeScore >= 70,
    silent:       hypeScore <= 20,
    signals,
    warning:      hypeScore >= 70 ? '⚠️ Medya aşırı hype — Tepe yakın olabilir, dikkatli' : null,
    summary:      signals[0] || `Medya hype: ${hypeScore}/100`,
    timestamp:    new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// AI DECISION EXTENSIONS
// ════════════════════════════════════════════════════════════════════════════════

// ─── 1. MARKET STATE ENGINE (tam versiyon) ────────────────────────────────────
export function runMarketStateEngine({
  btcChange7d    = 0,
  totalMcapChg   = 0,
  altcoinRatio   = 0.5,
  fearGreed      = 50,
  btcDominance   = 50,
  vixLevel       = 20,
  globalLiquidity = 50,
} = {}) {

  // Piyasa fazı belirleme
  let   bullStrength = 0, bearStrength = 0;

  if (btcChange7d >= 10)    bullStrength += 25;
  else if (btcChange7d >= 3) bullStrength += 12;
  else if (btcChange7d <= -10) bearStrength += 25;
  else if (btcChange7d <= -3)  bearStrength += 12;

  if (fearGreed >= 65)      bullStrength += 15;
  else if (fearGreed <= 35) bearStrength += 15;

  if (vixLevel <= 15)       bullStrength += 12;
  else if (vixLevel >= 25)  bearStrength += 12;

  if (globalLiquidity >= 60) bullStrength += 10;
  else if (globalLiquidity <= 40) bearStrength += 10;

  if (altcoinRatio >= 0.6)  bullStrength += 8; // Alt season
  if (btcDominance >= 60)   bearStrength += 8; // BTC dominance yüksek = altlar zayıf

  const netBull = bullStrength - bearStrength;

  const state =
    netBull >= 40 ? 'STRONG_BULL' :
    netBull >= 20 ? 'BULL'        :
    netBull >=  5 ? 'MILD_BULL'   :
    netBull >= -5 ? 'NEUTRAL'     :
    netBull >= -20? 'MILD_BEAR'   :
    netBull >= -40? 'BEAR'        : 'STRONG_BEAR';

  const score = clamp(50 + netBull * 0.7);

  const stateColors = {
    STRONG_BULL: '#00ff88', BULL: '#00cc66', MILD_BULL: '#88cc44',
    NEUTRAL: '#ffcc00', MILD_BEAR: '#cc8844', BEAR: '#ff6633', STRONG_BEAR: '#ff2200',
  };

  return {
    score:    parseFloat(score.toFixed(1)),
    state, netBull, bullStrength, bearStrength,
    color:    stateColors[state] || '#ffcc00',
    isBull:   netBull >= 5,
    isBear:   netBull <= -5,
    altSeason: altcoinRatio >= 0.6 && bullStrength >= 30,
    summary:  `Piyasa durumu: ${state} (${score.toFixed(0)}/100)`,
    timestamp: new Date().toISOString(),
  };
}

// ─── 2. FALSE SIGNAL FILTER ───────────────────────────────────────────────────
/**
 * Yanlış sinyal olasılığını hesaplar.
 * Birden fazla çelişkili sinyal varsa filtrele.
 */
export function runFalseSignalFilter({
  councilAgreement = 3,   // 4 üzerinden kaçı aynı fikirde
  signalStrength   = 60,  // Sinyal gücü 0-100
  historicalFPR    = 0.2, // Geçmiş yanlış pozitif oranı
  volumeConfirm    = true,
  timeframeConfirm = true,
} = {}) {

  let falseProb = 20; // Başlangıç yanlış sinyal ihtimali %

  if (councilAgreement <= 2)   { falseProb += 25; }
  if (signalStrength < 55)     { falseProb += 20; }
  if (historicalFPR >= 0.3)    { falseProb += 15; }
  if (!volumeConfirm)          { falseProb += 15; }
  if (!timeframeConfirm)       { falseProb += 15; }

  falseProb = clamp(falseProb);
  const genuine = clamp(100 - falseProb);

  return {
    score:        genuine,
    falseProb,
    genuineProb:  genuine,
    reliable:     falseProb <= 30,
    suspicious:   falseProb >= 50,
    summary:      `Yanlış sinyal ihtimali: %${falseProb} | Güvenilirlik: %${genuine}`,
    timestamp:    new Date().toISOString(),
  };
}

// ─── 3. WEIGHTED VOTING SYSTEM ────────────────────────────────────────────────
/**
 * Council oylarını ağırlıklı sistem ile birleştirir.
 */
export function runWeightedVotingSystem(councilVotes = {}) {
  const weights = {
    technical:  0.25,
    flow:       0.25,
    risk:       0.20,
    macro:      0.15,
    news:       0.10,
    crypto:     0.05,
  };

  let   weightedScore = 0;
  let   totalWeight   = 0;
  const breakdown     = [];

  for (const [council, weight] of Object.entries(weights)) {
    const vote = councilVotes[council];
    if (vote == null) continue;
    weightedScore += vote * weight;
    totalWeight   += weight;
    breakdown.push({ council, vote, weight, contribution: parseFloat((vote * weight).toFixed(2)) });
  }

  const finalScore = totalWeight ? clamp(weightedScore / totalWeight) : 50;

  const action =
    finalScore >= 65 ? 'AL' :
    finalScore <= 35 ? 'SAT' : 'BEKLE';

  return {
    score:      parseFloat(finalScore.toFixed(1)),
    action,
    breakdown,
    totalWeight: parseFloat(totalWeight.toFixed(2)),
    summary:    `Ağırlıklı karar: ${action} (${finalScore.toFixed(0)}/100)`,
    timestamp:  new Date().toISOString(),
  };
}

// ─── 4. DOUBLE CONFIRMATION PROTOCOL ─────────────────────────────────────────
/**
 * Sinyali iki kez onaylar: İlk sinyal + Teyit sinyali.
 * Teyit olmadan giriş yapma.
 */
const _pendingSignals = new Map();

export function runDoubleConfirmationProtocol({
  symbol       = 'BTCUSDT',
  action       = 'AL',
  score        = 60,
  requireMinutes = 5,   // Kaç dakika sonra teyit bekleniyor
} = {}) {

  const key      = `${symbol}_${action}`;
  const existing = _pendingSignals.get(key);
  const now      = Date.now();

  if (!existing) {
    // İlk sinyal — beklemede kaydet
    _pendingSignals.set(key, { action, score, ts: now, confirmed: false });
    return {
      status:    'FIRST_SIGNAL',
      confirmed: false,
      waitMinutes: requireMinutes,
      summary:   `İlk ${action} sinyali — ${requireMinutes}dk sonra teyit bekleniyor`,
      timestamp: new Date().toISOString(),
    };
  }

  // Teyit sinyali kontrolü
  const ageMinutes = (now - existing.ts) / 60_000;
  if (ageMinutes >= requireMinutes) {
    _pendingSignals.delete(key);
    return {
      status:    'CONFIRMED',
      confirmed: true,
      firstScore:  existing.score,
      secondScore: score,
      avgScore:    (existing.score + score) / 2,
      waitedMin:   parseFloat(ageMinutes.toFixed(1)),
      summary:   `✅ ${action} ONAYLANDI — İki sinyal teyit edildi (${requireMinutes}dk)`,
      timestamp: new Date().toISOString(),
    };
  }

  return {
    status:       'WAITING',
    confirmed:    false,
    waitedMin:    parseFloat(ageMinutes.toFixed(1)),
    remainingMin: parseFloat((requireMinutes - ageMinutes).toFixed(1)),
    summary:      `Teyit bekleniyor... ${(requireMinutes - ageMinutes).toFixed(1)}dk kaldı`,
    timestamp:    new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// ALERT EXTENSIONS
// ════════════════════════════════════════════════════════════════════════════════

// ─── 1. WEB PUSH ALERT ENGINE ────────────────────────────────────────────────
const _pushSubscriptions = new Set();

export function registerPushSubscription(endpoint) {
  _pushSubscriptions.add(endpoint);
  return { success: true, total: _pushSubscriptions.size };
}

export async function sendWebPushAlert({ title, body, icon = '📊', urgency = 'normal', data = {} }) {
  // Tarayıcı Push API entegrasyonu (service worker gerektirir)
  const payload = { title, body, icon, urgency, data, timestamp: new Date().toISOString() };

  if (typeof window !== 'undefined' && 'Notification' in window) {
    if (Notification.permission === 'granted') {
      new Notification(title, { body, icon: '📊' });
    } else if (Notification.permission !== 'denied') {
      const perm = await Notification.requestPermission();
      if (perm === 'granted') new Notification(title, { body });
    }
  }

  console.log(`[WEB PUSH] ${title}: ${body}`);
  return { sent: true, payload, subscribers: _pushSubscriptions.size };
}

// ─── 2. EMAIL ALERT ENGINE ────────────────────────────────────────────────────
export async function sendEmailAlert({
  to       = '',
  subject  = 'GMG Sinyal Alarmı',
  body     = '',
  apiKey   = '',   // EmailJS veya SendGrid API key
  urgent   = false,
} = {}) {
  if (!to || !apiKey) {
    console.log(`[EMAIL] ${subject} → ${to} (API key yok, simüle edildi)`);
    return { sent: false, reason: 'API key veya alıcı eksik', simulated: true };
  }

  // EmailJS entegrasyonu örneği
  try {
    const res = await fetch('https://api.emailjs.com/api/v1.0/email/send', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        service_id:  'gmg_service',
        template_id: urgent ? 'template_urgent' : 'template_normal',
        user_id:     apiKey,
        template_params: { to_email: to, subject, message: body },
      }),
    });
    return { sent: res.ok, status: res.status };
  } catch (e) {
    return { sent: false, error: e.message };
  }
}

// ─── 3. SCALP SIGNAL ALERT ────────────────────────────────────────────────────
/**
 * Kısa vadeli scalp fırsatı tespiti ve anında alert
 */
export function runScalpSignalAlert({
  symbol     = 'BTCUSDT',
  scoreSpike = false,   // Skor ani sıçrama yaptı mı?
  volumeSpike = false,  // Hacim patlaması var mı?
  spreadTight = false,  // Spread dar mı? (likidite yüksek)
  score       = 50,
  priceChange = 0,
} = {}) {

  const scalpReady = score >= 65 && volumeSpike && spreadTight;
  const microScalp = scoreSpike && Math.abs(priceChange) >= 0.5;

  const signal = {
    type:       scalpReady ? 'SCALP' : microScalp ? 'MICRO_SCALP' : null,
    symbol,
    score,
    active:     scalpReady || microScalp,
    urgency:    scalpReady ? 'HIGH' : microScalp ? 'MEDIUM' : 'LOW',
    message:    scalpReady
      ? `⚡ SCALP FIRSATI: ${symbol} — Hacim+Spread+Skor (${score})`
      : microScalp
      ? `🔹 Micro scalp: ${symbol} ${priceChange >= 0 ? '+' : ''}${priceChange.toFixed(2)}%`
      : null,
    timestamp:  new Date().toISOString(),
  };

  if (signal.active) console.log(`[SCALP ALERT] ${signal.message}`);
  return signal;
}

// ─── 4. TRAP ALERT ────────────────────────────────────────────────────────────
/**
 * Tuzak/Sahte hareket tespiti ve acil alarm
 */
export function runTrapAlert({
  symbol           = 'BTCUSDT',
  stopHuntPhase    = null,
  exchangeAnomaly  = false,
  liquidityTrap    = false,
  fakeMoveScore    = 0,
  baitDurationActive = false,
} = {}) {

  const traps = [];

  if (stopHuntPhase === 'FAKE_RESET') traps.push({ type: 'STOP_HUNT_FAKE_RESET', severity: 'CRITICAL', msg: `🚨 ${symbol}: SAHTE RESET — Stop hunt devam ediyor!` });
  if (exchangeAnomaly)                traps.push({ type: 'EXCHANGE_MANIPULATION', severity: 'CRITICAL', msg: `🚨 ${symbol}: Exchange manipülasyonu tespit edildi!` });
  if (liquidityTrap)                  traps.push({ type: 'LIQUIDITY_TRAP', severity: 'HIGH', msg: `⚠️ ${symbol}: Likidite tuzağı bölgesi!` });
  if (baitDurationActive)             traps.push({ type: 'BAIT_DURATION', severity: 'HIGH', msg: `⚠️ ${symbol}: İkinci tur yaklaşıyor — Yemleme süresi!` });
  if (fakeMoveScore >= 70)            traps.push({ type: 'FAKE_MOVE', severity: 'MEDIUM', msg: `🔶 ${symbol}: Sahte hareket ihtimali yüksek (%${fakeMoveScore})` });

  const hasCritical = traps.some(t => t.severity === 'CRITICAL');
  traps.forEach(t => console.warn(`[TRAP ALERT] ${t.msg}`));

  return {
    traps,
    trapCount:   traps.length,
    hasCritical,
    blockEntry:  hasCritical,
    topTrap:     traps[0] || null,
    summary:     traps[0]?.msg || `${symbol}: Tuzak yok`,
    timestamp:   new Date().toISOString(),
  };
}

// ─── 5. FINAL COUNCIL ALERT ───────────────────────────────────────────────────
/**
 * Final Council kararı sonrası alarm üretir.
 * Tüm kanallardan (push, telegram, email) eş zamanlı gönderir.
 */
export async function runFinalCouncilAlert({
  symbol     = 'BTCUSDT',
  action     = 'AL',
  score      = 70,
  approved   = true,
  price      = 0,
  alerts     = {},    // { telegram: fn, email: { to, apiKey }, push: true }
  riskMode   = 'NORMAL',
} = {}) {

  if (!approved || action === 'BEKLE') {
    return { sent: false, reason: 'Sinyal onaylanmadı veya BEKLE', timestamp: new Date().toISOString() };
  }

  const title    = `🎯 GMG ${action} SİNYALİ: ${symbol}`;
  const body     = `Council skoru: ${score}/100 | Fiyat: $${price} | Mod: ${riskMode}`;
  const results  = {};

  // Web Push
  if (alerts.push) {
    results.push = await sendWebPushAlert({ title, body, urgency: score >= 75 ? 'high' : 'normal' });
  }

  // Email
  if (alerts.email?.to) {
    results.email = await sendEmailAlert({ to: alerts.email.to, subject: title, body, apiKey: alerts.email.apiKey || '', urgent: score >= 75 });
  }

  // Telegram (mevcut alertMonitorEngines.js'e bağlanır)
  if (typeof alerts.telegram === 'function') {
    try {
      results.telegram = await alerts.telegram({ symbol, action, score, price });
    } catch (e) {
      results.telegram = { sent: false, error: e.message };
    }
  }

  console.log(`[FINAL COUNCIL ALERT] ${title} — Kanallar: ${Object.keys(results).join(', ')}`);

  return {
    sent:      true,
    symbol, action, score, price, approved,
    channels:  results,
    summary:   `${title} — ${Object.keys(results).length} kanal`,
    timestamp: new Date().toISOString(),
  };
}
