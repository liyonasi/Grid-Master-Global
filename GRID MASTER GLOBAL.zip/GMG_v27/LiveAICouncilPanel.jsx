/**
 * LiveAICouncilPanel.jsx
 * ========================
 * 5 Konsey canlı skoru + Execution Layer durumu + Confidence gauge
 * masterCouncil.js çıktısını görselleştirir.
 */
import React, { useState, useEffect } from 'react';
import { CouncilMemoryEngine } from '../components/grid-master/councilAdvancedEngine';
import { RefreshCw, Shield, Zap, TrendingUp, Globe, BarChart2, AlertTriangle } from 'lucide-react';

// ─── YARDIMCI ─────────────────────────────────────────────────────────────────
function ScoreBar({ score = 50, color = '#00aaff', height = 6 }) {
  const pct = Math.max(0, Math.min(100, score));
  return (
    <div style={{ width:'100%', height, background:'#0a0a1c', borderRadius:3, overflow:'hidden' }}>
      <div style={{ width:`${pct}%`, height:'100%', background:color, borderRadius:3, transition:'width .4s ease' }} />
    </div>
  );
}

function CouncilRow({ icon: Icon, name, score, action, color, signals = [], debate = [] }) {
  const [open, setOpen] = useState(false);
  const s = Math.max(0, Math.min(100, score ?? 50));
  return (
    <div style={{ marginBottom:6 }}>
      <div
        onClick={() => setOpen(o => !o)}
        style={{
          display:'flex', alignItems:'center', gap:8, padding:'6px 8px',
          background:'#07070f', border:`1px solid ${color}30`,
          borderRadius:6, cursor:'pointer', userSelect:'none',
        }}
      >
        {Icon && <Icon style={{ width:11, height:11, color, flexShrink:0 }} />}
        <span style={{ fontSize:10, fontWeight:700, color, fontFamily:'monospace', flex:1 }}>{name}</span>
        <span style={{ fontSize:11, fontWeight:700, color, fontFamily:'monospace', minWidth:28, textAlign:'right' }}>{s}</span>
        <div style={{ width:60 }}>
          <ScoreBar score={s} color={color} height={5} />
        </div>
        <span style={{
          fontSize:9, fontWeight:700, padding:'1px 6px', borderRadius:3,
          background:`${color}18`, color, fontFamily:'monospace', minWidth:48, textAlign:'center',
        }}>{action || '—'}</span>
        <span style={{ fontSize:9, color:'#444', marginLeft:2 }}>{open ? '▲' : '▼'}</span>
      </div>

      {open && (
        <div style={{
          background:'#05050d', border:`1px solid ${color}20`, borderTop:'none',
          borderRadius:'0 0 6px 6px', padding:'6px 10px',
        }}>
          {debate?.slice(0,4).map((d, i) => (
            <div key={i} style={{ fontSize:9, color:'#6060a0', fontFamily:'monospace', marginBottom:2, lineHeight:1.4 }}>
              › {d}
            </div>
          ))}
          {signals?.slice(0,4).map((s2, i) => (
            <div key={i} style={{
              display:'flex', justifyContent:'space-between', alignItems:'center',
              fontSize:9, color:'#9090c0', fontFamily:'monospace', padding:'2px 0',
            }}>
              <span>{s2.label}</span>
              <span style={{ color: s2.score >= 60 ? '#00ff88' : s2.score <= 40 ? '#ff4466' : '#ffcc00' }}>
                {s2.score}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── ANA BİLEŞEN ──────────────────────────────────────────────────────────────
export default function LiveAICouncilPanel({ masterResult, jsonOutputs, loading, symbol, onRefresh }) {

  if (loading && !masterResult) {
    return (
      <div style={{ padding:'24px 0', textAlign:'center' }}>
        <div style={{ fontSize:10, color:'#aa88ff', fontFamily:'monospace', letterSpacing:2 }}
          className="animate-pulse">
          ⚡ AI ANALİZ EDİYOR...
        </div>
      </div>
    );
  }

  if (!masterResult) {
    return (
      <div style={{ padding:'16px', textAlign:'center' }}>
        <div style={{ fontSize:10, color:'#404070', fontFamily:'monospace', marginBottom:12 }}>
          Master Council bekleniyor
        </div>
        <button onClick={onRefresh}
          style={{ fontSize:9, fontFamily:'monospace', padding:'4px 12px',
            background:'#0a0a1f', border:'1px solid #1a1a3e', color:'#6060a0',
            borderRadius:4, cursor:'pointer' }}>
          Başlat
        </button>
      </div>
    );
  }

  const { councils, finalCouncil, execution, score, label, color, confidence, riskLevel, riskColor, pineData, summary } = masterResult;
  const veto = execution?.filters?.veto?.wasVetoed;

  // Konsey meta
  const councilMeta = [
    { key:'technical', name:'Technical Council', icon:BarChart2,  color:'#00aaff' },
    { key:'flow',      name:'Flow Council',      icon:TrendingUp, color:'#00ff88' },
    { key:'risk',      name:'Risk Council',      icon:Shield,     color:'#ff3366' },
    { key:'asset',     name:'Asset Specialist',  icon:Zap,        color:'#ffcc00' },
    { key:'newsMacro', name:'News & Macro',      icon:Globe,      color:'#aa88ff' },
    { key:'specialist',name:'Specialist Council',icon:BarChart2,  color:'#00bcd4' },
  ];

  return (
    <div style={{ fontFamily:'monospace', fontSize:10 }}>

      {/* ── Header ── */}
      <div style={{
        display:'flex', alignItems:'center', justifyContent:'space-between',
        marginBottom:10, padding:'0 2px',
      }}>
        <div style={{ display:'flex', alignItems:'center', gap:6 }}>
          <Zap style={{ width:12, height:12, color:'#aa88ff' }} />
          <span style={{ fontSize:11, fontWeight:700, color:'#aa88ff', letterSpacing:2 }}>
            MASTER AI COUNCIL
          </span>
        </div>
        <div style={{ display:'flex', alignItems:'center', gap:6 }}>
          {loading && (
            <span style={{ fontSize:8, color:'#aa88ff', letterSpacing:1 }} className="animate-pulse">
              ANALİZ...
            </span>
          )}
          <button onClick={onRefresh}
            style={{ background:'none', border:'none', cursor:'pointer', color:'#404070', padding:2 }}>
            <RefreshCw style={{ width:10, height:10 }} />
          </button>
        </div>
      </div>

      {/* ── Nihai Karar Kutusu ── */}
      <div style={{
        background:`${color}0e`, border:`1.5px solid ${color}50`,
        borderRadius:8, padding:'10px 12px', marginBottom:10,
      }}>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:6 }}>
          <span style={{ fontSize:16, fontWeight:700, color, letterSpacing:1 }}>{label}</span>
          <div style={{ textAlign:'right' }}>
            <div style={{ fontSize:20, fontWeight:700, color }}>{score}</div>
            <div style={{ fontSize:8, color:'#6060a0' }}>/ 100</div>
          </div>
        </div>

        {/* Confidence bar */}
        <div style={{ marginBottom:6 }}>
          <div style={{ display:'flex', justifyContent:'space-between', marginBottom:3 }}>
            <span style={{ fontSize:9, color:'#6060a0' }}>Güven</span>
            <span style={{ fontSize:9, color }}>%{confidence}</span>
          </div>
          <ScoreBar score={confidence} color={color} height={5} />
        </div>

        {/* Risk + Veto */}
        <div style={{ display:'flex', gap:8, alignItems:'center' }}>
          <span style={{
            fontSize:9, fontWeight:700, padding:'2px 8px', borderRadius:3,
            background:`${riskColor}18`, color:riskColor,
          }}>
            RİSK: {riskLevel}
          </span>
          {veto && (
            <span style={{
              fontSize:9, fontWeight:700, padding:'2px 8px', borderRadius:3,
              background:'#ff005520', color:'#ff0055', display:'flex', alignItems:'center', gap:3,
            }}>
              <AlertTriangle style={{ width:8, height:8 }} /> VETO AKTİF
            </span>
          )}
          {!veto && (
            <span style={{ fontSize:9, color:'#00ff8866' }}>✓ Veto yok</span>
          )}
        </div>
      </div>

      {/* ── Execution Layer Filtre Durumu ── */}
      {execution?.filters && (
        <div style={{
          background:'#06060e', border:'1px solid #1a1a2e',
          borderRadius:6, padding:'7px 10px', marginBottom:10,
        }}>
          <div style={{ fontSize:9, color:'#404070', marginBottom:5, letterSpacing:1 }}>
            EXECUTION LAYER
          </div>
          {Object.entries(execution.filters).map(([key, f]) => {
            if (!f || typeof f !== 'object') return null;
            const blocked = f.blocked || f.wasVetoed || false;
            const label2  = f.label || key.replace(/([A-Z])/g,' $1').toUpperCase();
            return (
              <div key={key} style={{
                display:'flex', alignItems:'center', gap:6,
                fontSize:9, color: blocked ? '#ff4466' : '#404070', marginBottom:2,
              }}>
                <div style={{
                  width:5, height:5, borderRadius:'50%', flexShrink:0,
                  background: blocked ? '#ff4466' : '#1D9E75',
                }} />
                <span style={{ flex:1 }}>{label2}</span>
                <span style={{ color: blocked ? '#ff4466' : '#1D9E75' }}>
                  {blocked ? 'ENGELLENDİ' : 'TEMİZ'}
                </span>
              </div>
            );
          })}
        </div>
      )}

      {/* ── 5 Konsey Satırları ── */}
      <div style={{ marginBottom:8 }}>
        <div style={{ fontSize:9, color:'#404070', marginBottom:6, letterSpacing:1 }}>5 KONSEY OYLARI</div>
        {councilMeta.map(cm => {
          const c = councils?.[cm.key];
          if (!c) return null;
          return (
            <CouncilRow
              key={cm.key}
              icon={cm.icon}
              name={cm.name}
              score={c.score}
              action={c.action || c.verdict || c.riskLevel || '—'}
              color={cm.color}
              signals={c.signals}
              debate={c.debate}
            />
          );
        })}
      </div>

      {/* ── Pine İndikatör Durumu ── */}
      {pineData && (
        <div style={{
          background:'#06060e', border:'1px solid #1a1a2e',
          borderRadius:6, padding:'7px 10px', marginBottom:10,
        }}>
          <div style={{ fontSize:9, color:'#404070', marginBottom:5, letterSpacing:1 }}>
            PINE İNDİKATÖR
          </div>
          <div style={{ display:'flex', gap:6, flexWrap:'wrap' }}>
            {[
              { label:'RF Trend', val: pineData.rf?.trendDir || '—', col: pineData.rf?.trendUp ? '#00e676' : pineData.rf?.trendDown ? '#ff1744' : '#888' },
              { label:'BUY',      val: pineData.rf?.buySignal  ? 'AKTİF' : '-', col: pineData.rf?.buySignal  ? '#00e676' : '#333' },
              { label:'SELL',     val: pineData.rf?.sellSignal ? 'AKTİF' : '-', col: pineData.rf?.sellSignal ? '#ff1744' : '#333' },
              { label:'PB-AL',    val: pineData.pb?.pbBuy  ? 'AKTİF' : '-', col: pineData.pb?.pbBuy  ? '#00e676' : '#333' },
              { label:'PB-SAT',   val: pineData.pb?.pbSell ? 'AKTİF' : '-', col: pineData.pb?.pbSell ? '#ff6d00' : '#333' },
              { label:'Council',  val: pineData.council?.councilAction || '—', col: '#00aaff' },
            ].map(item => (
              <div key={item.label} style={{
                background:'#09091a', border:`1px solid ${item.col}30`,
                borderRadius:4, padding:'3px 7px', fontSize:9,
              }}>
                <span style={{ color:'#404070' }}>{item.label} </span>
                <span style={{ color:item.col, fontWeight:700 }}>{item.val}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── Advanced Uyarılar ── */}
      {masterResult?.advanced && (() => {
        const adv = masterResult.advanced;
        const ls  = masterResult.liquiditySpecial;
        const warnings = [
          adv.trendExhaustion?.exhausted       && { msg:'⚡ Trend tükenmesi', col:'#ff8800' },
          adv.wickManip?.manipulationDetected  && { msg:'🎣 Wick manipülasyonu', col:'#ff0055' },
          adv.derivTrap?.isTrap                && { msg:'🚨 Türev tuzağı', col:'#ff0055' },
          adv.panicNews?.panicDetected         && { msg:'📰 Panik haberi', col:'#ff6d00' },
          adv.cascadeRisk?.risk==='CRITICAL'   && { msg:'💣 Cascade likidasyon', col:'#ff0055' },
          adv.leverageBuildup?.dangerous       && { msg:'⚠ Tehlikeli leverage', col:'#ff8800' },
          adv.marketStruct?.choch              && { msg:`🔄 ${adv.marketStruct.choch.type}`, col:'#aa88ff' },
          ls?.flashCrash?.detected             && { msg:`⚡ Flash Crash: ${ls.flashCrash.severity}`, col:'#ff0055' },
          ls?.darkPool?.detected               && { msg:`🕵 ${ls.darkPool.type?.replace('_',' ')}`, col:'#00bcd4' },
        ].filter(Boolean);
        if (warnings.length===0) return null;
        return (
          <div style={{ background:'#06060e', border:'1px solid #2a0a0a', borderRadius:6, padding:'7px 10px', marginBottom:8 }}>
            <div style={{ fontSize:9, color:'#404070', marginBottom:4, letterSpacing:1 }}>ADVANCED UYARILAR</div>
            {warnings.map((w,i) => (
              <div key={i} style={{ fontSize:9, color:w.col, fontFamily:'monospace', marginBottom:2 }}>{w.msg}</div>
            ))}
          </div>
        );
      })()}

      {/* ── Missing Modules Panel ── */}
      {masterResult?.missingBundle && (() => {
        const mb = masterResult.missingBundle;
        // Sadece anlamlı veri varsa göster
        const hasData = mb.keltner || mb.supertrend || mb.trendCloud || mb.panic || mb.contagion || mb.indexStress || mb.rateExpect;
        if (!hasData) return null;

        const rows = [
          mb.supertrend && { label:'Supertrend', val: mb.supertrend.trend === 'UP' ? '▲ YUKARI' : '▼ AŞAĞI', score: mb.supertrend.score, col: mb.supertrend.trend==='UP'?'#00e676':'#ff1744' },
          mb.keltner    && { label:'Keltner',    val: mb.keltner.position || '—', score: mb.keltner.score, col:'#00bcd4' },
          mb.trendCloud && { label:'Trend Bulutu',val: mb.trendCloud.signal || '—', score: mb.trendCloud.score, col: mb.trendCloud.score>=55?'#00ff88':'#ff3366' },
          mb.sessionVol && { label:'Seans Vol',  val: mb.sessionVol.session || '—', score: mb.sessionVol.score, col:'#aa88ff' },
          mb.rateExpect && { label:'Fed Beklenti',val: mb.rateExpect.expectation || '—', score: mb.rateExpect.score, col:'#ffcc00' },
          mb.indexStress&& { label:'Endeks Stres',val: mb.indexStress.level || '—', score: mb.indexStress.score, col: mb.indexStress.score>=60?'#ff3366':'#00ff88' },
          mb.precious   && { label:'Değ.Metaller',val: mb.precious.signal || '—', score: mb.precious.score, col:'#ffd700' },
          mb.energyVol  && { label:'Enerji Vol',  val: mb.energyVol.level || '—', score: mb.energyVol.score, col:'#ff8800' },
          mb.contagion  && { label:'BTC Bulaşma', val: mb.contagion.contagion ? 'AKTİF' : 'YOK', score: mb.contagion.score, col: mb.contagion.contagion?'#ff0055':'#00ff88' },
          mb.panic      && { label:'Panik',        val: mb.panic.isPanic ? `⛔ ${mb.panic.level}` : '—', score: mb.panic.score, col: mb.panic.isPanic?'#ff0055':'#00ff8866' },
        ].filter(Boolean);

        return (
          <div style={{ background:'#06060e', border:'1px solid #0a1a2e', borderRadius:6, padding:'7px 10px', marginBottom:8 }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:5 }}>
              <span style={{ fontSize:9, color:'#404070', letterSpacing:1 }}>18 EKSİK MODÜL</span>
              <span style={{ fontSize:9, fontWeight:700, color: (mb.bonusScore||0)>=0?'#00ff88':'#ff3366', fontFamily:'monospace' }}>
                Katkı: {(mb.bonusScore||0)>=0?'+':''}{(mb.bonusScore||0).toFixed(2)}
              </span>
            </div>
            {rows.map((r,i) => {
              const s = Math.max(0, Math.min(100, r.score||50));
              return (
                <div key={i} style={{ display:'flex', alignItems:'center', gap:5, marginBottom:3 }}>
                  <span style={{ fontSize:9, color:'#6060a0', fontFamily:'monospace', width:80, flexShrink:0 }}>{r.label}</span>
                  <div style={{ flex:1, height:4, background:'#0a0a1c', borderRadius:2, overflow:'hidden' }}>
                    <div style={{ width:`${s}%`, height:'100%', background:r.col+'88', borderRadius:2 }} />
                  </div>
                  <span style={{ fontSize:9, color:r.col, fontFamily:'monospace', minWidth:50, textAlign:'right' }}>{r.val}</span>
                  <span style={{ fontSize:8, color:'#404070', fontFamily:'monospace', minWidth:22, textAlign:'right' }}>{s}</span>
                </div>
              );
            })}
            {mb.alerts?.length > 0 && (
              <div style={{ marginTop:5, borderTop:'1px solid #0a0a1c', paddingTop:4 }}>
                {mb.alerts.map((a,i) => (
                  <div key={i} style={{ fontSize:9, color:'#ff6d00', fontFamily:'monospace' }}>{a}</div>
                ))}
              </div>
            )}
          </div>
        );
      })()}




      {/* ── Council Memory Panel ── */}
      {(() => {
        const summary  = (() => { try { return CouncilMemoryEngine.getSummary(); } catch(e) { return []; } })();
        const stats    = (() => { try { return CouncilMemoryEngine.getStats();   } catch(e) { return null; } })();
        const history  = (() => { try { return CouncilMemoryEngine.getHistory(null, 10); } catch(e) { return []; } })();
        if (!summary.length) return null;
        const total    = stats?.total || summary.reduce((a,b) => a + (b.totalDecisions||0), 0);
        const winRate  = stats?.winRate ?? (() => {
          const avgAcc = summary.filter(s => s.accuracy !== null);
          return avgAcc.length ? (avgAcc.reduce((a,b) => a + (b.accuracy||0), 0) / avgAcc.length).toFixed(1) : null;
        })();
        const wrColor  = winRate >= 60 ? '#00ff88' : winRate >= 45 ? '#ffcc00' : '#ff3366';
        return (
          <div style={{ background:'#06060e', border:'1px solid #0a1a0a', borderRadius:6, padding:'7px 10px', marginBottom:8 }}>
            {/* Başlık + WinRate */}
            <div style={{ fontSize:9, color:'#404070', marginBottom:6, letterSpacing:1, display:'flex', justifyContent:'space-between', alignItems:'center' }}>
              <span>COUNCIL HAFIZA</span>
              <div style={{ display:'flex', gap:6, alignItems:'center' }}>
                {stats && (
                  <span style={{ fontSize:7, color:'#2a2a4a', fontFamily:'monospace' }}>
                    {stats.total}k · {stats.resolved}✓
                  </span>
                )}
                <span style={{ color: wrColor, fontSize:10, fontWeight:'bold' }}>
                  {winRate ? `${winRate}% DOĞRULUK` : 'VERİ BİRİKİYOR'}
                </span>
              </div>
            </div>
            {/* Konsey grid */}
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:3, marginBottom:6 }}>
              {summary.slice(0,6).map((s,i) => (
                <div key={i} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', background:'#0a0a1e', borderRadius:3, padding:'2px 5px' }}>
                  <span style={{ fontSize:8, color:'#404060', fontFamily:'monospace' }}>
                    {s.councilId?.replace('_COUNCIL','').replace('_SPECIALIST','').slice(0,8)}
                  </span>
                  <span style={{ fontSize:8, color: s.accuracy >= 60 ? '#00ff88' : s.accuracy >= 45 ? '#ffcc00' : '#6060a0', fontFamily:'monospace' }}>
                    {s.accuracy !== null ? `${s.accuracy}%` : `${s.totalDecisions}k`}
                  </span>
                </div>
              ))}
            </div>
            {/* Son 10 karar geçmişi */}
            {history.length > 0 && (
              <div style={{ borderTop:'1px solid #0a0a1e', paddingTop:5, marginTop:4 }}>
                <div style={{ fontSize:7, color:'#2a2a4a', marginBottom:3, letterSpacing:1 }}>SON KARARLAR</div>
                <div style={{ display:'flex', flexDirection:'column', gap:2 }}>
                  {history.slice(0,8).map((h,i) => {
                    const actionColor = h.action==='BUY'||h.action==='AL' ? '#00ff88' : h.action==='SELL'||h.action==='SAT' ? '#ff3366' : '#404070';
                    const outcomeIcon = h.resolved
                      ? (h.actualOutcome==='PROFIT'||h.actualOutcome==='AVOIDED_LOSS'||h.actualOutcome==='CORRECT_WAIT' ? '✓' : '✗')
                      : '·';
                    const outcomeColor = h.resolved
                      ? (outcomeIcon==='✓' ? '#00ff88' : '#ff3366') : '#2a2a4a';
                    return (
                      <div key={i} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', fontSize:7, fontFamily:'monospace', color:'#303050' }}>
                        <span style={{ color:'#2a2a4a' }}>{h.councilId?.slice(0,6)}</span>
                        <span style={{ color: actionColor, fontWeight:'bold' }}>{h.action}</span>
                        <span style={{ color:'#303050' }}>{h.score}</span>
                        <span style={{ color: outcomeColor, fontWeight:'bold' }}>{outcomeIcon}</span>
                        <span style={{ color:'#1a1a2e' }}>{new Date(h.timestamp).toLocaleTimeString('tr-TR',{hour:'2-digit',minute:'2-digit'})}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
            <div style={{ fontSize:7, color:'#2a2a4a', marginTop:4 }}>
              Toplam karar: {total} | {summary.length} konsey takip ediliyor
            </div>
          </div>
        );
      })()}

      {/* ── CryptoPanic Haberler — masterResult.advanced.socialSentiment ── */}
      {(() => {
        const ss = masterResult?.advanced?.socialSentiment;
        const cp = ss?.cryptoPanic;
        if (!cp?.items?.length) return null;
        const sentColor = cp.sentimentScore >= 60 ? '#00ff88' : cp.sentimentScore <= 40 ? '#ff4466' : '#ffd600';
        return (
          <div style={{ background:'#06060e', border:'1px solid #1a1a2e', borderRadius:6, padding:'7px 10px', marginBottom:8 }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:6 }}>
              <div style={{ fontSize:9, color:'#ff9900', letterSpacing:1, fontWeight:700, fontFamily:'monospace' }}>
                📰 CRYPTOPANIC HABERLERİ
              </div>
              <div style={{ display:'flex', alignItems:'center', gap:6 }}>
                <span style={{ fontSize:8, color: sentColor, fontFamily:'monospace', fontWeight:700 }}>
                  {cp.sentimentScore}/100
                </span>
                <span style={{ fontSize:7, color:'#303050', fontFamily:'monospace' }}>
                  {cp.summary?.split('—')[1]?.trim() || ''}
                </span>
              </div>
            </div>
            {cp.items.slice(0, 5).map((item, i) => {
              const sentEmoji = item.sentiment === 'positive' ? '🟢' : item.sentiment === 'negative' ? '🔴' : '🟡';
              const timeStr = item.published
                ? new Date(item.published).toLocaleTimeString('tr-TR', { hour:'2-digit', minute:'2-digit' })
                : '';
              return (
                <div key={i} style={{
                  padding:'4px 0', borderBottom: i < 4 ? '1px solid #0a0a1c' : 'none',
                  display:'flex', alignItems:'flex-start', gap:5,
                }}>
                  <span style={{ fontSize:8, marginTop:1 }}>{sentEmoji}</span>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ fontSize:8, color:'#9090c0', fontFamily:'monospace', lineHeight:1.4,
                      overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
                      {item.title}
                    </div>
                    <div style={{ display:'flex', gap:8, marginTop:2 }}>
                      <span style={{ fontSize:7, color:'#303058', fontFamily:'monospace' }}>{item.source}</span>
                      {timeStr && <span style={{ fontSize:7, color:'#303058', fontFamily:'monospace' }}>{timeStr}</span>}
                      {(item.votes?.positive || 0) > 0 && (
                        <span style={{ fontSize:7, color:'#00ff8860', fontFamily:'monospace' }}>
                          👍{item.votes.positive}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
            {cp.items.length > 5 && (
              <div style={{ fontSize:7, color:'#303050', fontFamily:'monospace', marginTop:4, textAlign:'right' }}>
                +{cp.items.length - 5} daha haber
              </div>
            )}
          </div>
        );
      })()}

      {/* ── JSON Outputs — jsonOutputEngine çıktıları ── */}
      {jsonOutputs && Object.keys(jsonOutputs).length > 0 && (() => {
        const keys = Object.keys(jsonOutputs);
        const keyLabels = {
          ai_decision_output:  '⚡ AI KARAR',
          council_output:      '🏛 KONSEY',
          live_bridge_output:  '🔗 LIVE',
          scalp_output:        '⚡ SCALP',
          health_output:       '❤ SAĞLIK',
          multi_asset_output:  '🌍 VARLIK',
        };
        return (
          <div style={{ background:'#06060e', border:'1px solid #1a1a2e', borderRadius:6, padding:'7px 10px', marginBottom:8 }}>
            <div style={{ fontSize:9, color:'#00bcd4', marginBottom:6, letterSpacing:1, fontWeight:700 }}>JSON OUTPUTS</div>
            {keys.map(k => {
              const out = jsonOutputs[k];
              if (!out) return null;
              const label = keyLabels[k] || k;
              // Özet satır
              const brief = out.action
                ? `${out.action} | skor:${out.score ?? '?'}`
                : out.summary
                  ? String(out.summary).slice(0, 50)
                  : JSON.stringify(out).slice(0, 60);
              return (
                <div key={k} style={{ marginBottom:4, padding:'3px 0', borderBottom:'1px solid #0a0a1c' }}>
                  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                    <span style={{ fontSize:8, color:'#00bcd4', fontFamily:'monospace', fontWeight:700 }}>{label}</span>
                    <span style={{ fontSize:7, color:'#303050', fontFamily:'monospace' }}>
                      {new Date(out.timestamp || Date.now()).toLocaleTimeString('tr-TR',{hour:'2-digit',minute:'2-digit',second:'2-digit'})}
                    </span>
                  </div>
                  <div style={{ fontSize:8, color:'#6060a0', fontFamily:'monospace', marginTop:1 }}>{brief}</div>
                </div>
              );
            })}
          </div>
        );
      })()}

      {/* ── Özet Satırları ── */}
      {summary?.length > 0 && (
        <div style={{
          background:'#06060e', border:'1px solid #1a1a2e',
          borderRadius:6, padding:'7px 10px',
        }}>
          <div style={{ fontSize:9, color:'#404070', marginBottom:4, letterSpacing:1 }}>ÖZET</div>
          {summary.map((s2, i) => (
            <div key={i} style={{ fontSize:9, color:'#6060a0', lineHeight:1.5, marginBottom:1 }}>
              {s2}
            </div>
          ))}
          <div style={{ fontSize:8, color:'#2a2a4a', marginTop:4 }}>
            {new Date(masterResult.timestamp).toLocaleTimeString('tr-TR')}
          </div>
        </div>
      )}
    </div>
  );
}
