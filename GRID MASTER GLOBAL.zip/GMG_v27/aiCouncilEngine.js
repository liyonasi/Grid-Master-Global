/**
 * GRID MASTER GLOBAL — AI COUNCIL ENGINE v2
 * ===========================================
 * 4 AI Konseyi — Her biri kendi modül domain'inde UZMAN
 * Ham modül verileri → Her konsey kendi verisini analiz eder
 * → Tartışma (debate) → Konsensüs → Final karar
 *
 * COUNCIL I:   ALPHA   — Teknik/Grafik/Pattern   (24 modül)
 * COUNCIL II:  FLOW    — Likidite/OB/Hacim        (24 modül)
 * COUNCIL III: RISK    — Manipülasyon/Risk/Vol    (24 modül)
 * COUNCIL IV:  MACRO   — Kripto/On-chain/AI       (23 modül)
 */

import { COUNCIL_META } from './moduleRegistry.js';

// ─── YARDIMCILAR ──────────────────────────────────────────────────────────────

const clamp = (v, min = 0, max = 100) => Math.min(max, Math.max(min, v));
const avg   = arr => arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : 50;

function scoreToVerdict(score) {
  if (score >= 75) return { action: 'GÜÇLÜ AL',  short: 'AL',    color: '#00ff88', emoji: '🟢' };
  if (score >= 60) return { action: 'AL',         short: 'AL',    color: '#00cc66', emoji: '🟢' };
  if (score >= 50) return { action: 'ZAYIF AL',   short: 'AL',    color: '#55aa66', emoji: '🟡' };
  if (score >= 45) return { action: 'BEKLE',      short: 'BEKLE', color: '#ffcc00', emoji: '🟡' };
  if (score >= 38) return { action: 'ZAYIF SAT',  short: 'SAT',   color: '#cc6644', emoji: '🔴' };
  if (score >= 25) return { action: 'SAT',         short: 'SAT',   color: '#ff6633', emoji: '🔴' };
  return              { action: 'GÜÇLÜ SAT',  short: 'SAT',   color: '#ff3366', emoji: '🔴' };
}

function confidenceScore(signals) {
  if (!signals.length) return 50;
  const variance = signals.reduce((s, v) => s + Math.pow(v - avg(signals), 2), 0) / signals.length;
  // Düşük varyans = yüksek konsensüs = yüksek güven
  const rawConf = clamp(100 - Math.sqrt(variance) * 2);
  return Math.round(rawConf);
}

// ─── COUNCIL I: ALPHA ─────────────────────────────────────────────────────────
// Domain: Teknik analiz + grafik formasyonları + pattern recognition
// Modül sayısı: 24

export function runAlphaCouncil({ klines, chartModule: cm, confidenceData }) {
  const prices  = klines?.map(k => k.price) || [];
  const n       = prices.length;
  if (n < 5) return buildEmptyCouncil('ALPHA');

  // ── Modül 1-4: Teknik osilatörler ─────────────────────
  const rsi = cm?.alphaSignal ? null : 50; // gelecek chartModule'den
  const lastPrice = prices[n - 1];
  const prev5     = prices.slice(-6, -1);
  const change5m  = prev5.length ? (lastPrice - prev5[0]) / prev5[0] * 100 : 0;

  // EMA sinyali
  const ema9  = ema(prices, 9),  ema21 = ema(prices, 21), ema50 = ema(prices, 50);
  const emaScore = ema9 && ema21
    ? clamp(50 + (ema9 > ema21 ? 20 : -20) + (ema21 > ema50 ? 10 : -10))
    : 50;

  // RSI
  const rsiVal = computeRSI(prices);
  const rsiScore = rsiVal < 30 ? 80 : rsiVal < 45 ? 65 : rsiVal < 55 ? 50 : rsiVal < 70 ? 40 : 25;

  // Bollinger
  const bbPos  = bollingerPosition(prices);
  const bbScore = bbPos < 0.2 ? 75 : bbPos < 0.4 ? 62 : bbPos > 0.8 ? 25 : bbPos > 0.6 ? 38 : 50;

  // MACD
  const macdData = computeMACD(prices);
  const macdScore = macdData.histogram > 0 && macdData.bullish ? 72 : macdData.histogram > 0 ? 62 : macdData.histogram < 0 ? 35 : 50;

  // ── Modül 5-8: Grafik formasyonları ───────────────────
  const formations   = cm?.formations     || [];
  const candlePats   = cm?.recentCandles  || [];
  const histMatch    = cm?.historicalMatch;
  const mmEst        = cm?.mmEstimate;

  const formScore = formations.length > 0
    ? clamp(50 + formations.reduce((s, f) => {
        const bias = f.bias || 'nötr';
        return s + (bias === 'bullish' ? 15 : bias === 'bearish' ? -15 : 0);
      }, 0))
    : 50;

  const candleScore = candlePats.length > 0
    ? clamp(50 + candlePats.reduce((s, c) => {
        const bias = c.info?.bias || 'nötr';
        return s + (bias === 'bullish' ? 12 : bias === 'bearish' ? -12 : 0);
      }, 0))
    : 50;

  const histScore = histMatch
    ? clamp(50 + histMatch.futureChange * 3)
    : 50;

  const mmScore = mmEst
    ? clamp(mmEst.bullPct)
    : 50;

  // ── Modül 9-12: Destek/Direnç ─────────────────────────
  const sr = cm?.srLevels;
  const nearSup = sr?.supports?.[0];
  const nearRes = sr?.resistances?.[0];
  const srScore = nearSup && nearRes
    ? clamp(50 + (nearRes.distance > nearSup.distance ? 15 : -15))
    : 50;

  // Tüm sinyalleri topla
  const signals = [
    { label: 'EMA Trend',          score: emaScore,    weight: 1.2, key: 'EMA_TREND' },
    { label: 'RSI',                score: rsiScore,    weight: 1.0, key: 'RSI_STATE' },
    { label: 'Bollinger Band',     score: bbScore,     weight: 0.9, key: 'BOLLINGER_BAND' },
    { label: 'MACD',               score: macdScore,   weight: 1.0, key: 'SUPERTRIGGER' },
    { label: 'Grafik Formasyonu',  score: formScore,   weight: 1.3, key: 'PATTERN_MATRIX' },
    { label: 'Mum Formasyonu',     score: candleScore, weight: 1.1, key: 'CANDLESTICK_ENGINE' },
    { label: 'Tarihsel Eşleşme',   score: histScore,   weight: 1.0, key: 'HISTORICAL_MATCH' },
    { label: 'MM Yön Tahmini',     score: mmScore,     weight: 1.4, key: 'CHART_FORMATION' },
    { label: 'S/R Konumu',         score: srScore,     weight: 0.9, key: 'SUPPORT_RESISTANCE' },
  ];

  const totalW    = signals.reduce((s, sig) => s + sig.weight, 0);
  const wScore    = signals.reduce((s, sig) => s + sig.score * sig.weight, 0) / totalW;
  const finalScore = Math.round(clamp(wScore));
  const verdict   = scoreToVerdict(finalScore);
  const conf      = confidenceScore(signals.map(s => s.score));

  return {
    id: 'ALPHA',
    ...COUNCIL_META.ALPHA,
    score: finalScore,
    ...verdict,
    confidence: conf,
    signals,
    highlights: {
      topFormation: formations[0] || null,
      topCandle:    candlePats[0] || null,
      historicalMatch: histMatch,
      mmEstimate:   mmEst,
      nearSupport:  nearSup,
      nearResistance: nearRes,
    },
    moduleData: { rsiVal, emaScore, bbPos, macdData },
    debate: [
      `EMA ${ema9?.toFixed(2) || '—'} / ${ema21?.toFixed(2) || '—'} → ${ema9 > ema21 ? 'Yükseliş trendi' : 'Düşüş trendi'}`,
      `RSI ${rsiVal} → ${rsiScore >= 60 ? 'Alım bölgesi' : rsiScore <= 40 ? 'Satım bölgesi' : 'Nötr'}`,
      formations.length ? `${formations.length} formasyon: ${formations[0]?.description || ''}` : 'Belirgin formasyon yok',
      histMatch ? `Tarihsel: ${histMatch.similarity * 100 | 0}% benzer → Sonuç ${histMatch.futureChange > 0 ? '+' : ''}${histMatch.futureChange}%` : 'Yeterli tarihsel veri yok',
      mmEst ? `MM Tahmini: ${mmEst.direction} (${mmEst.confidence | 0}% güven)` : '',
    ].filter(Boolean),
  };
}

// ─── COUNCIL II: FLOW ────────────────────────────────────────────────────────
// Domain: Orderbook, likidite, hacim, türev pozisyonlar

export function runFlowCouncil({ orderbook, tickerData, fundingData, openInterest, heatmapData, btcChange }) {
  // ── Orderbook metrikleri ──────────────────────────────
  let obBullScore = 50, wallScore = 50, imbalanceScore = 50;
  if (orderbook?.bids?.length && orderbook?.asks?.length) {
    const bidVol = orderbook.bids.slice(0, 15).reduce((s, b) => s + b.amount * b.price, 0);
    const askVol = orderbook.asks.slice(0, 15).reduce((s, a) => s + a.amount * a.price, 0);
    imbalanceScore = clamp((bidVol / (bidVol + askVol + 0.001)) * 100);
    obBullScore    = imbalanceScore;

    // Wall detection
    const medBid = orderbook.bids[orderbook.bids.length >> 1]?.amount || 1;
    const bigBids = orderbook.bids.filter(b => b.amount > medBid * 4).length;
    const bigAsks = orderbook.asks.filter(a => a.amount > medBid * 4).length;
    wallScore = clamp(50 + (bigBids - bigAsks) * 10);
  }

  // ── Volume & momentum ────────────────────────────────
  const totalCoins  = heatmapData?.length || 1;
  const posCoins    = heatmapData?.filter(c => (c.change_24h || 0) > 0).length || 0;
  const breadthScore = clamp((posCoins / totalCoins) * 100);

  // ── Funding rate ─────────────────────────────────────
  const fundingRate  = fundingData?.fundingRate || 0;
  // Çok yüksek pozitif funding = fazla long = düşüş riski
  const fundingScore = clamp(50 - fundingRate * 200);

  // ── Open Interest ─────────────────────────────────────
  const oiTrend = openInterest?.trend || 0; // +1 artıyor, -1 azalıyor
  const oiScore = clamp(50 + oiTrend * 15);

  // ── BTC momentum ─────────────────────────────────────
  const btcScore = clamp(50 + (btcChange || 0) * 4);

  // ── VWAP vs price ─────────────────────────────────────
  let vwapScore = 50;
  if (tickerData?.length) {
    const prices = tickerData.map(t => t.price).filter(Boolean);
    const vols   = tickerData.map(t => t.volume_24h).filter(Boolean);
    const vwap   = prices.reduce((s, p, i) => s + p * (vols[i] || 0), 0) / (vols.reduce((a, b) => a + b, 0) || 1);
    const current = prices[0] || vwap;
    vwapScore = current > vwap ? clamp(60 + (current - vwap) / vwap * 500) : clamp(40 - (vwap - current) / vwap * 500);
  }

  const signals = [
    { label: 'OB Alış/Satış Dengesi', score: imbalanceScore, weight: 1.3, key: 'BID_ASK_IMBALANCE' },
    { label: 'Duvar Analizi',         score: wallScore,       weight: 1.1, key: 'OB_WALL_TRACKER' },
    { label: 'Piyasa Genişliği',      score: breadthScore,    weight: 1.0, key: 'MOMENTUM_BIAS' },
    { label: 'Funding Bias',          score: fundingScore,    weight: 0.9, key: 'FUNDING_BIAS' },
    { label: 'Open Interest',         score: oiScore,         weight: 0.9, key: 'OPEN_INTEREST' },
    { label: 'BTC Momentum',          score: btcScore,        weight: 1.1, key: 'CVD_PULSE' },
    { label: 'VWAP Konumu',           score: vwapScore,       weight: 0.8, key: 'DELTA_FLOW' },
  ];

  const totalW = signals.reduce((s, sig) => s + sig.weight, 0);
  const wScore = signals.reduce((s, sig) => s + sig.score * sig.weight, 0) / totalW;
  const finalScore = Math.round(clamp(wScore));
  const verdict    = scoreToVerdict(finalScore);
  const conf       = confidenceScore(signals.map(s => s.score));

  return {
    id: 'FLOW',
    ...COUNCIL_META.FLOW,
    score: finalScore,
    ...verdict,
    confidence: conf,
    signals,
    highlights: {
      imbalancePct: Math.round(imbalanceScore),
      fundingRate,
      breadthPct: Math.round(breadthScore),
    },
    debate: [
      `Orderbook: %${Math.round(imbalanceScore)} alış baskısı`,
      `Funding: ${fundingRate > 0 ? '+' : ''}${fundingRate.toFixed(4)}% → ${fundingScore > 55 ? 'Kontrollü' : fundingScore < 40 ? 'Aşırı yüklü' : 'Normal'}`,
      `Piyasa genişliği: ${posCoins}/${totalCoins} coin pozitif`,
      `BTC ${btcChange >= 0 ? '+' : ''}${(btcChange || 0).toFixed(2)}% → ${btcScore >= 55 ? 'Destekleyici' : 'Baskılı'}`,
    ],
  };
}

// ─── COUNCIL III: RISK ───────────────────────────────────────────────────────
// Domain: Manipülasyon, tuzak, volatilite, risk sınıflandırma

export function runRiskCouncil({ scanResults }) {
  const {
    scalpTraps = [], stopHunts = [], suddenDumps = [], sessionRisks = [],
    liquiditySens = [], enrichedCoins = [],
  } = scanResults || {};

  // Risk yükseldikçe skor DÜŞER
  const trapScore    = clamp(100 - scalpTraps.length * 12);
  const huntScore    = clamp(100 - stopHunts.length * 18);
  const dumpScore    = clamp(100 - suddenDumps.filter(d => d.change <= -10).length * 22);
  const sessionScore = clamp(100 - sessionRisks.length * 15);
  const liqRiskScore = clamp(100 - liquiditySens.filter(l => l.riskLevel === 'YÜKSEK').length * 10);

  // Volatilite rejimi
  const volatileCoins = enrichedCoins.filter(c => Math.abs(c.change_24h || 0) > 8).length;
  const volScore = clamp(100 - volatileCoins * 5);

  const signals = [
    { label: 'Scalp Tuzak',       score: trapScore,    weight: 1.2, key: 'LIQ_TRAP_SCANNER' },
    { label: 'Stop Hunt',         score: huntScore,    weight: 1.3, key: 'STOP_HUNT_RADAR' },
    { label: 'Kritik Dump',       score: dumpScore,    weight: 1.1, key: 'DUMP_EARLY_SCAN' },
    { label: 'Seans Riski',       score: sessionScore, weight: 0.9, key: 'REGIME_DETECTOR' },
    { label: 'Liq Duyarlılığı',   score: liqRiskScore, weight: 1.0, key: 'LIQ_SWEEP_DETECT' },
    { label: 'Volatilite Rejimi', score: volScore,     weight: 0.9, key: 'VOL_REGIME' },
  ];

  const totalW = signals.reduce((s, sig) => s + sig.weight, 0);
  const wScore = signals.reduce((s, sig) => s + sig.score * sig.weight, 0) / totalW;
  const finalScore = Math.round(clamp(wScore));
  const verdict    = scoreToVerdict(finalScore);
  const conf       = confidenceScore(signals.map(s => s.score));

  const riskLevel = finalScore >= 70 ? 'DÜŞÜK' : finalScore >= 50 ? 'ORTA' : finalScore >= 30 ? 'YÜKSEK' : 'KRİTİK';
  const riskColor = finalScore >= 70 ? '#00ff88' : finalScore >= 50 ? '#ffcc00' : finalScore >= 30 ? '#ff8800' : '#ff3366';

  return {
    id: 'RISK',
    ...COUNCIL_META.RISK,
    score: finalScore,
    color: riskColor,        // override with risk color
    action: verdict.action,
    short: verdict.short,
    confidence: conf,
    riskLevel,
    riskColor,
    signals,
    highlights: {
      topTraps:   scalpTraps.slice(0, 4),
      topHunts:   stopHunts.slice(0, 4),
      topDumps:   suddenDumps.slice(0, 4),
    },
    debate: [
      `${scalpTraps.length} scalp tuzağı tespit edildi`,
      `${stopHunts.length} stop hunt sinyali aktif`,
      `${suddenDumps.filter(d => d.change <= -10).length} kritik dump (>-10%)`,
      `Volatilite: ${volatileCoins} coin ±8%+ hareket ediyor`,
      `Risk Seviyesi: ${riskLevel}`,
    ],
  };
}

// ─── COUNCIL IV: MACRO ──────────────────────────────────────────────────────
// Domain: BTC dominans, alt sezon, sektör, on-chain, haber sentiment

export function runMacroCouncil({ heatmapData = [], btcChange = 0, fearGreedIndex = 50 }) {
  const totalCoins = heatmapData.length || 1;
  const btcCoin = heatmapData.find(c => c.symbol === 'BTC/USDT' || c.symbol === 'BTC');

  // BTC Dominance proxy (rough: if BTC up more than alts → dominance rising)
  const altAvg   = heatmapData.slice(1, 51).reduce((s, c) => s + (c.change_24h || 0), 0) / 50;
  const altRelBTC = altAvg - btcChange;
  const altSeasonScore = clamp(50 + altRelBTC * 5);

  // Sektör gücü (meme, defi, ai, l1/l2 proxy via coin groups)
  const posRatio = heatmapData.filter(c => (c.change_24h || 0) > 0).length / totalCoins;
  const sectorScore = clamp(posRatio * 100);

  // Fear & Greed
  const fgScore = clamp(fearGreedIndex); // already 0-100

  // BTC + dominance combined
  const btcDomScore = btcChange > 2 ? 65 : btcChange > 0 ? 55 : btcChange > -2 ? 45 : 30;

  // Stablecoin flow proxy (if many coins pumping, stables relatively flat)
  const stableProxy = posRatio > 0.6 ? 60 : posRatio > 0.4 ? 50 : 38;

  // Rotation: BTC strong = alts might follow (momentum rotation)
  const rotationScore = clamp(50 + btcChange * 3 + altRelBTC * 2);

  const signals = [
    { label: 'Alt Sezon İndeksi',  score: altSeasonScore,  weight: 1.1, key: 'ALT_SEASON_ENG' },
    { label: 'Sektör Gücü',        score: sectorScore,     weight: 1.0, key: 'SECTOR_STRENGTH' },
    { label: 'Korku/Açgözlülük',   score: fgScore,         weight: 1.2, key: 'FEAR_GREED' },
    { label: 'BTC Dominans',       score: btcDomScore,     weight: 1.1, key: 'BTC_DOMINANCE' },
    { label: 'Stablecoin Akışı',   score: stableProxy,     weight: 0.8, key: 'STABLE_FLOW_ENG' },
    { label: 'Rotasyon Yönü',      score: rotationScore,   weight: 0.9, key: 'ALT_ROTATION' },
  ];

  const totalW = signals.reduce((s, sig) => s + sig.weight, 0);
  const wScore = signals.reduce((s, sig) => s + sig.score * sig.weight, 0) / totalW;
  const finalScore = Math.round(clamp(wScore));
  const verdict    = scoreToVerdict(finalScore);
  const conf       = confidenceScore(signals.map(s => s.score));

  const marketPhase = finalScore >= 65 ? 'RISK-ON' : finalScore <= 40 ? 'RISK-OFF' : 'KARMA';

  return {
    id: 'MACRO',
    ...COUNCIL_META.MACRO,
    score: finalScore,
    ...verdict,
    confidence: conf,
    marketPhase,
    fearGreedIndex: Math.round(fearGreedIndex),
    altSeasonIndex: Math.round(altSeasonScore),
    signals,
    highlights: {
      altVsBtc: parseFloat(altRelBTC.toFixed(2)),
      marketPhase,
      fearGreedLabel: fearGreedIndex >= 75 ? 'AŞIRI AÇGÖZLÜ' : fearGreedIndex >= 55 ? 'AÇGÖZLÜ' : fearGreedIndex >= 45 ? 'NÖTR' : fearGreedIndex >= 25 ? 'KORKU' : 'AŞIRI KORKU',
    },
    debate: [
      `BTC ${btcChange >= 0 ? '+' : ''}${btcChange.toFixed(2)}% | Alt ort. ${altAvg >= 0 ? '+' : ''}${altAvg.toFixed(2)}%`,
      `Alt-BTC relatif: ${altRelBTC >= 0 ? '+' : ''}${altRelBTC.toFixed(2)}% → ${altRelBTC > 1 ? 'Alt sezonu güçlü' : altRelBTC < -1 ? 'BTC dominansı' : 'Dengeli'}`,
      `Korku/Açgözlülük: ${Math.round(fearGreedIndex)} — ${fearGreedIndex >= 60 ? 'Açgözlü' : fearGreedIndex <= 40 ? 'Korku' : 'Nötr'}`,
      `Piyasa fazı: ${marketPhase}`,
    ],
  };
}

// ─── TARTIŞMA MASASI (DEBATE ENGINE) ─────────────────────────────────────────
/**
 * 4 konsey kararlarını masaya koyar.
 * Her konsey kendi alanında "savunur", diğerleri dinler.
 * Oylama → Konsensüs → Final karar.
 */
export function runDebateAndConsensus(councils) {
  const { alpha, flow, risk, macro } = councils;
  if (!alpha || !flow || !risk || !macro) return null;

  // Her konseyin ağırlıklı oyları
  // Risk konseyi ters: yüksek risk skoru = güvenli = olumlu oy
  const weights  = { ALPHA: 0.30, FLOW: 0.25, RISK: 0.20, MACRO: 0.25 };
  const rawScores = {
    ALPHA: alpha.score,
    FLOW:  flow.score,
    RISK:  risk.score,  // zaten ters encode edilmiş
    MACRO: macro.score,
  };

  const weightedScore = Object.entries(rawScores).reduce((s, [k, v]) => s + v * weights[k], 0);
  const finalScore    = Math.round(clamp(weightedScore));
  const verdict       = scoreToVerdict(finalScore);

  // Konsensüs gücü: kaç konsey aynı yönde?
  const bullishCount = [alpha, flow, macro].filter(c => c.score >= 55).length;
  const bearishCount = [alpha, flow, macro].filter(c => c.score <= 45).length;
  const riskOk       = risk.score >= 50; // risk konseyi "güvenli" diyor mu?

  const consensusStrength =
    Math.max(bullishCount, bearishCount) === 3 ? 'TAM' :
    Math.max(bullishCount, bearishCount) === 2 ? 'ÇOĞUNLUK' : 'BÖLÜNMÜŞ';

  const confidence = clamp(Math.round(
    30 + Math.max(bullishCount, bearishCount) * 18 +
    (riskOk ? 8 : -8) +
    Math.abs(finalScore - 50) * 0.6
  ));

  // Market bias
  const marketBias =
    finalScore >= 68 ? 'GÜÇLÜ BULLISH' :
    finalScore >= 55 ? 'BULLISH' :
    finalScore >= 48 ? 'HAFIF BULLISH' :
    finalScore >= 42 ? 'HAFIF BEARISH' :
    finalScore >= 32 ? 'BEARISH' : 'GÜÇLÜ BEARISH';

  const biasColor =
    finalScore >= 55 ? '#00ff88' :
    finalScore <= 45 ? '#ff3366' : '#ffcc00';

  // Risk seviyesi final
  const riskLevel = risk.riskLevel || 'ORTA';
  const riskColor = risk.riskColor || '#ffcc00';

  // Tartışma özeti
  const debateSummary = [
    `◈ ALPHA (${alpha.score}/100): ${alpha.action} — ${alpha.debate?.[0] || ''}`,
    `⟁ FLOW  (${flow.score}/100): ${flow.action} — ${flow.debate?.[0] || ''}`,
    `⬡ RISK  (${risk.score}/100): Risk ${riskLevel} — ${risk.debate?.[0] || ''}`,
    `⎈ MACRO (${macro.score}/100): ${macro.action} — ${macro.debate?.[0] || ''}`,
  ];

  // Final karar gerekçesi
  const topCouncil = [alpha, flow, macro].sort((a, b) => b.score - a.score)[0];
  const reasoning = `${consensusStrength} konsensüs — En güçlü sinyal: ${topCouncil.id} (${topCouncil.score}/100). ${
    riskOk ? 'Risk uygun.' : 'Risk yüksek, dikkat!'
  }`;

  // Next liquidity target
  const mmDir       = alpha.highlights?.mmEstimate?.direction;
  const mmTarget    = alpha.highlights?.mmEstimate?.liqTargetPrice;
  const mmDist      = alpha.highlights?.mmEstimate?.liqTargetDist;

  return {
    finalScore,
    ...verdict,
    confidence,
    marketBias,
    biasColor,
    riskLevel,
    riskColor,
    consensusStrength,
    councils: { alpha, flow, risk, macro },
    votes: {
      bullish: [alpha, flow, macro].filter(c => c.score >= 55).length,
      bearish: [alpha, flow, macro].filter(c => c.score <= 45).length,
      neutral: [alpha, flow, macro].filter(c => c.score > 45 && c.score < 55).length,
    },
    debateSummary,
    reasoning,
    liquidityTarget: mmDir && mmTarget ? {
      direction: mmDir,
      price: mmTarget,
      distance: mmDist,
      color: mmDir === 'YUKARI' ? '#00ff88' : '#ff3366',
    } : null,
    fearGreedIndex: macro.fearGreedIndex,
    altSeasonIndex: macro.altSeasonIndex,
    marketPhase: macro.marketPhase,
    timestamp: Date.now(),
  };
}

// ─── ANA ÇALIŞTIRICI ─────────────────────────────────────────────────────────

export function runAllCouncils({
  klines, chartModuleData, orderbook, tickerData,
  fundingData, openInterest, heatmapData, scanResults,
  btcChange, fearGreedIndex = 50,
}) {
  const alpha = runAlphaCouncil({ klines, chartModule: chartModuleData, confidenceData: null });
  const flow  = runFlowCouncil({ orderbook, tickerData, fundingData, openInterest, heatmapData, btcChange });
  const risk  = runRiskCouncil({ scanResults });
  const macro = runMacroCouncil({ heatmapData, btcChange, fearGreedIndex });
  const final = runDebateAndConsensus({ alpha, flow, risk, macro });

  return { alpha, flow, risk, macro, final };
}

// ─── YERLEŞİK TEKNIK HESAPLAMALAR ────────────────────────────────────────────
// (Bağımlılık olmadan kendi içinde)

function ema(prices, period) {
  if (!prices || prices.length < period) return null;
  const k = 2 / (period + 1);
  let val = prices.slice(0, period).reduce((a, b) => a + b, 0) / period;
  for (let i = period; i < prices.length; i++) val = prices[i] * k + val * (1 - k);
  return val;
}

function computeRSI(prices, period = 14) {
  if (!prices || prices.length < period + 1) return 50;
  let gains = 0, losses = 0;
  for (let i = 1; i <= period; i++) {
    const d = prices[i] - prices[i - 1];
    d > 0 ? gains += d : losses += Math.abs(d);
  }
  let ag = gains / period, al = losses / period;
  for (let i = period + 1; i < prices.length; i++) {
    const d = prices[i] - prices[i - 1];
    ag = (ag * (period - 1) + (d > 0 ? d : 0)) / period;
    al = (al * (period - 1) + (d < 0 ? Math.abs(d) : 0)) / period;
  }
  return al === 0 ? 100 : parseFloat((100 - 100 / (1 + ag / al)).toFixed(1));
}

function computeMACD(prices, fast = 12, slow = 26, signal = 9) {
  if (!prices || prices.length < slow + signal) return { histogram: 0, bullish: false };
  const emaArr = (data, p) => {
    const k = 2 / (p + 1), r = [data[0]];
    for (let i = 1; i < data.length; i++) r.push(data[i] * k + r[i-1] * (1-k));
    return r;
  };
  const fastE  = emaArr(prices, fast), slowE = emaArr(prices, slow);
  const macdL  = fastE.map((v, i) => v - slowE[i]);
  const sigL   = emaArr(macdL.slice(slow - 1), signal);
  const lastM  = macdL[macdL.length - 1], lastS = sigL[sigL.length - 1];
  return { histogram: lastM - lastS, macd: lastM, signal: lastS, bullish: lastM > lastS && lastM > 0 };
}

function bollingerPosition(prices, period = 20) {
  if (!prices || prices.length < period) return 0.5;
  const recent = prices.slice(-period);
  const mean   = recent.reduce((a, b) => a + b, 0) / period;
  const std    = Math.sqrt(recent.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / period);
  const last   = prices[prices.length - 1];
  const upper  = mean + 2 * std, lower = mean - 2 * std;
  return upper !== lower ? Math.max(0, Math.min(1, (last - lower) / (upper - lower))) : 0.5;
}

function buildEmptyCouncil(id) {
  return { id, score: 50, action: 'BEKLE', short: 'BEKLE', color: '#ffcc00', confidence: 0, signals: [], debate: [], highlights: {} };
}
