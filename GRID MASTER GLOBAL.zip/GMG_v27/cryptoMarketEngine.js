/**
 * GRID MASTER GLOBAL — CRYPTO MARKET ENGINE v1
 * ==============================================
 * CRYPTO_MARKET_TEMPERATURE — Piyasa ısı ölçümü
 * ETF_FLOW_ENGINE           — Bitcoin/Ethereum ETF akışı
 */

import { clamp } from './engineCore.js';

// ─── ÖNBELLEK ─────────────────────────────────────────────────────────────────
const _cache = new Map();
function cacheGet(k, ttl = 5 * 60 * 1000) { const e = _cache.get(k); return e && Date.now() - e.ts < ttl ? e.v : null; }
function cacheSet(k, v) { _cache.set(k, { v, ts: Date.now() }); }

// ════════════════════════════════════════════════════════════════════════════════
// 1. CRYPTO MARKET TEMPERATURE
// ════════════════════════════════════════════════════════════════════════════════
/**
 * Piyasanın genel ısısını ölçer.
 * Çok sıcak = FOMO/tepe, Soğuk = dip/birikim fırsatı
 *
 * Faktörler:
 *   - Fear & Greed endeksi
 *   - BTC 30g değişimi
 *   - Toplam piyasa değeri değişimi
 *   - Stablecoin dominans
 *   - Aktif adres trendi
 *   - Sosyal hacim
 */
export function runCryptoMarketTemperature({
  fearGreed       = 50,
  btcChange30d    = 0,
  totalMcapChange = 0,
  stableDom       = 8,    // % — yüksekse para kenar'da bekliyor
  activeAddrTrend = 0,    // % haftalık değişim
  socialVolume    = 5000, // sosyal hacim birimi
  fundingAvg      = 0,    // Ortalama funding oranı
} = {}) {

  let temp = 50; // 0=Buzlu, 100=Alev
  const signals = [];

  // Fear & Greed (ağırlık: 25)
  temp += (fearGreed - 50) * 0.25;

  // BTC 30g değişim (ağırlık: 20)
  if (btcChange30d >= 50)       { temp += 20; signals.push(`BTC 30g +%${btcChange30d.toFixed(0)} — Piyasa çok sıcak`); }
  else if (btcChange30d >= 20)  { temp += 12; }
  else if (btcChange30d <= -30) { temp -= 18; signals.push(`BTC 30g %${btcChange30d.toFixed(0)} — Piyasa soğudu`); }
  else if (btcChange30d <= -10) { temp -= 8; }

  // Toplam mcap değişimi (ağırlık: 15)
  temp += (totalMcapChange / 10) * 15 * 0.1;

  // Stablecoin dominans (yüksekse para kenarda = soğuk)
  if (stableDom >= 12)  { temp -= 15; signals.push(`Stablecoin dom %${stableDom} — Para kenarda`); }
  else if (stableDom <= 5) { temp += 10; signals.push(`Stablecoin dom düşük — Para piyasada`); }

  // Funding (pozitif = ısınma)
  if (fundingAvg >= 0.05)  { temp += 12; signals.push('Funding yüksek — Aşırı uzun birikim'); }
  else if (fundingAvg < 0) { temp -= 8; signals.push('Negatif funding — Short baskısı'); }

  // Aktif adres trendi
  if (activeAddrTrend >= 20) { temp += 8; }
  else if (activeAddrTrend <= -20) { temp -= 8; }

  temp = clamp(Math.round(temp));

  const zone =
    temp >= 80 ? { label: '🔥 AŞIRI SICAK',  color: '#ff2200', action: 'SAT/BEKLE — Tepe riski' } :
    temp >= 65 ? { label: '♨️ SICAK',         color: '#ff8800', action: 'Dikkatli AL — Aşırı ısınma' } :
    temp >= 45 ? { label: '🟡 ILIMAN',        color: '#ffcc00', action: 'Normal işlem' } :
    temp >= 30 ? { label: '🔵 SERIN',         color: '#4488ff', action: 'Birikim fırsatı' } :
                 { label: '❄️ SOĞUK',         color: '#0044ff', action: 'Güçlü birikim — Dip bölgesi' };

  return {
    score:    temp,
    temp,
    zone:     zone.label,
    color:    zone.color,
    advice:   zone.action,
    signals,
    summary:  `${zone.label} (${temp}/100) — ${zone.action}`,
    timestamp: new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// 2. ETF FLOW ENGINE
// ════════════════════════════════════════════════════════════════════════════════
/**
 * Bitcoin ve Ethereum spot ETF giriş/çıkışlarını analiz eder.
 * ETF alımları = kurumsal talep = bullish
 * ETF çıkışları = kurumsal satış = bearish
 *
 * Veri kaynağı: farside.co.uk (manuel/API), CoinGlass
 */

// Bilinen ETF'ler (BTC Spot)
export const BTC_ETFS = [
  { ticker: 'IBIT',  name: 'BlackRock iShares',   weight: 1.0 },
  { ticker: 'FBTC',  name: 'Fidelity',            weight: 0.95 },
  { ticker: 'ARKB',  name: 'ARK 21Shares',        weight: 0.85 },
  { ticker: 'BITB',  name: 'Bitwise',             weight: 0.80 },
  { ticker: 'GBTC',  name: 'Grayscale',           weight: 0.90 }, // Çıkış kaynağı olabilir
  { ticker: 'HODL',  name: 'VanEck',              weight: 0.75 },
];

export const ETH_ETFS = [
  { ticker: 'ETHA',  name: 'BlackRock ETH',       weight: 1.0 },
  { ticker: 'FETH',  name: 'Fidelity ETH',        weight: 0.95 },
  { ticker: 'ETHE',  name: 'Grayscale ETH',       weight: 0.90 },
];

/**
 * analyzeETFFlows — ETF akış verilerini analiz et
 *
 * @param {object} flowData
 *   btcFlows  — [{ ticker, flowMln }] (pozitif=giriş, negatif=çıkış)
 *   ethFlows  — [{ ticker, flowMln }]
 *   daysBack  — Kaç günlük veri
 */
export function analyzeETFFlows({ btcFlows = [], ethFlows = [], daysBack = 1 } = {}) {
  // BTC ETF toplam
  const btcNet   = btcFlows.reduce((a, f) => a + (f.flowMln || 0), 0);
  const btcIn    = btcFlows.filter(f => f.flowMln > 0).reduce((a, f) => a + f.flowMln, 0);
  const btcOut   = Math.abs(btcFlows.filter(f => f.flowMln < 0).reduce((a, f) => a + f.flowMln, 0));

  // ETH ETF toplam
  const ethNet   = ethFlows.reduce((a, f) => a + (f.flowMln || 0), 0);

  // Toplam net
  const totalNet = btcNet + ethNet;

  // Skor hesabı
  let score = 50;
  if (totalNet >= 500)       { score += 30; }
  else if (totalNet >= 200)  { score += 20; }
  else if (totalNet >= 50)   { score += 10; }
  else if (totalNet <= -500) { score -= 30; }
  else if (totalNet <= -200) { score -= 20; }
  else if (totalNet <= -50)  { score -= 10; }

  // GBTC özel: Grayscale çıkışı baskı yaratır
  const gbtcFlow = btcFlows.find(f => f.ticker === 'GBTC');
  if (gbtcFlow && gbtcFlow.flowMln < -100) {
    score -= 8;
  }

  score = clamp(score);

  const trend =
    totalNet >= 200  ? '💰 GÜÇLÜ GİRİŞ — Kurumsal talep yüksek' :
    totalNet >= 50   ? '📈 GİRİŞ — Pozitif akış' :
    totalNet >= -50  ? '➡️ NÖTR' :
    totalNet >= -200 ? '📉 ÇIKIŞ — Satış baskısı' :
                       '🔴 GÜÇLÜ ÇIKIŞ — Kurumsal satış';

  return {
    score,
    btcNetMln:   parseFloat(btcNet.toFixed(2)),
    ethNetMln:   parseFloat(ethNet.toFixed(2)),
    totalNetMln: parseFloat(totalNet.toFixed(2)),
    btcInMln:    parseFloat(btcIn.toFixed(2)),
    btcOutMln:   parseFloat(btcOut.toFixed(2)),
    trend,
    bullish:     totalNet >= 100,
    bearish:     totalNet <= -100,
    topInflow:   btcFlows.sort((a, b) => b.flowMln - a.flowMln)[0] || null,
    daysBack,
    summary:     `${trend} | BTC ETF: $${btcNet.toFixed(0)}M | ETH ETF: $${ethNet.toFixed(0)}M`,
    timestamp:   new Date().toISOString(),
  };
}

/**
 * fetchETFFlowsFromCoinGlass — CoinGlass API'den ETF verisi çek
 * Not: Ücretsiz tier sınırlı
 */
export async function fetchETFFlowsFromCoinGlass(apiKey = '') {
  const cached = cacheGet('etf_flows');
  if (cached) return cached;

  if (!apiKey) {
    // Demo mod — simüle et
    return _demoETFFlows();
  }

  try {
    const url = `https://open-api.coinglass.com/public/v2/etf/bitcoin/fund-list?apiKey=${apiKey}`;
    const res = await fetch(url, { signal: AbortSignal.timeout(8000) });
    const data = await res.json();

    if (data.code !== '0' || !data.data) return _demoETFFlows();

    const btcFlows = data.data.map(etf => ({
      ticker:  etf.symbol,
      name:    etf.name,
      flowMln: parseFloat(etf.oneDayFlow || 0) / 1e6,
    }));

    const result = analyzeETFFlows({ btcFlows, ethFlows: [], daysBack: 1 });
    cacheSet('etf_flows', result);
    return result;
  } catch (e) {
    console.error('[ETF] Fetch hatası:', e.message);
    return _demoETFFlows();
  }
}

function _demoETFFlows() {
  const btcFlows = BTC_ETFS.map(etf => ({
    ticker:  etf.ticker,
    name:    etf.name,
    flowMln: parseFloat((Math.random() * 300 - 100).toFixed(2)),
  }));
  const ethFlows = ETH_ETFS.map(etf => ({
    ticker:  etf.ticker,
    name:    etf.name,
    flowMln: parseFloat((Math.random() * 100 - 40).toFixed(2)),
  }));
  return analyzeETFFlows({ btcFlows, ethFlows, daysBack: 1 });
}

/**
 * runCryptoMarketEngine — İki modülü birden çalıştır
 */
export async function runCryptoMarketEngine(params = {}, etfApiKey = '') {
  const [temp, etf] = await Promise.all([
    Promise.resolve(runCryptoMarketTemperature(params)),
    fetchETFFlowsFromCoinGlass(etfApiKey),
  ]);

  const score = clamp(temp.score * 0.55 + etf.score * 0.45);

  return {
    score:       parseFloat(score.toFixed(1)),
    temperature: temp,
    etfFlow:     etf,
    summary:     `Isı:${temp.temp} | ETF:$${etf.totalNetMln}M | ${score >= 60 ? 'POZİTİF' : score <= 40 ? 'NEGATİF' : 'NÖTR'}`,
    timestamp:   new Date().toISOString(),
  };
}
