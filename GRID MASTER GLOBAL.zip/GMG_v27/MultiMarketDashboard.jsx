/**
 * MultiMarketDashboard.jsx — GMG v21
 * ====================================
 * Tüm piyasalar tek sayfada, mobil uyumlu:
 *   • Forex      — EUR/USD, GBP/USD, USD/JPY, USD/CHF, AUD/USD, USD/CAD, DXY
 *   • Emtia      — Altın, Gümüş, Platin, WTI, Brent, Doğalgaz, Bakır, Buğday
 *   • Endeksler  — S&P500, Nasdaq, Dow, DAX, FTSE, Nikkei, VIX
 *   • Tahvil     — US10Y, US2Y, US30Y, Spread, Tersine Eğri uyarısı
 *   • Makro      — Fear&Greed, DXY baskısı, Risk-ON/OFF, Kripto korelasyon
 *
 * Responsive breakpoints:
 *   Mobile  < 640px  → 2 sütun kart
 *   Tablet  < 1024px → 3 sütun kart
 *   Desktop ≥ 1024px → 4-6 sütun kart
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  fetchAllMacro,
  fetchFearGreed,
  clearMacroCache,
} from './macroAPIEngine';
import { fetchAllAssets, computeCryptoCorrelationScore } from './multiAssetEngine';

// ─── SABITLER ─────────────────────────────────────────────────────────────────
const REFRESH_INTERVAL = 3 * 60 * 1000; // 3 dakika

const TABS = [
  { id: 'overview',   label: '🌍 Genel Bakış' },
  { id: 'forex',      label: '💱 Forex' },
  { id: 'commodity',  label: '🥇 Emtia' },
  { id: 'index',      label: '📈 Endeksler' },
  { id: 'bond',       label: '📊 Tahvil' },
  { id: 'macro',      label: '🧭 Makro' },
];

// ─── YARDIMCILAR ──────────────────────────────────────────────────────────────
const clamp = (v, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, v || 0));
const fmt2   = v => v != null ? v.toFixed(2) : '—';
const fmtChg = v => v != null ? `${v >= 0 ? '+' : ''}${v.toFixed(2)}%` : '—';
const chgCol = v => !v ? '#606090' : v > 0 ? '#00e676' : '#ff2255';

function ScoreBar({ score, color, height = 4 }) {
  return (
    <div style={{ background: '#0d0d28', borderRadius: 2, height, overflow: 'hidden', width: '100%' }}>
      <div style={{
        width: `${clamp(score)}%`, height: '100%',
        background: color, borderRadius: 2,
        transition: 'width 0.5s ease',
      }} />
    </div>
  );
}

function SignalBadge({ signal }) {
  const map = {
    'AL':        { bg: 'rgba(0,230,118,.15)',  border: 'rgba(0,230,118,.4)',  color: '#00e676' },
    'GÜÇLÜ AL':  { bg: 'rgba(0,230,118,.2)',   border: 'rgba(0,230,118,.5)',  color: '#00ff88' },
    'SAT':       { bg: 'rgba(255,34,85,.15)',   border: 'rgba(255,34,85,.4)',  color: '#ff2255' },
    'GÜÇLÜ SAT': { bg: 'rgba(255,34,85,.2)',    border: 'rgba(255,34,85,.5)',  color: '#ff0044' },
    'BEKLE':     { bg: 'rgba(255,215,0,.12)',   border: 'rgba(255,215,0,.3)',  color: '#ffd700' },
    'NÖTR':      { bg: 'rgba(96,96,144,.15)',   border: 'rgba(96,96,144,.3)',  color: '#9090c0' },
    'RISK_ON':   { bg: 'rgba(0,230,118,.15)',   border: 'rgba(0,230,118,.4)',  color: '#00e676' },
    'RISK_OFF':  { bg: 'rgba(255,34,85,.15)',   border: 'rgba(255,34,85,.4)',  color: '#ff2255' },
    'NEUTRAL':   { bg: 'rgba(255,215,0,.12)',   border: 'rgba(255,215,0,.3)',  color: '#ffd700' },
  };
  const s = map[signal] || map['NÖTR'];
  return (
    <span style={{
      fontSize: 9, fontWeight: 700, padding: '2px 7px', borderRadius: 3,
      background: s.bg, border: `1px solid ${s.border}`, color: s.color,
      letterSpacing: '0.5px', whiteSpace: 'nowrap',
    }}>{signal || 'NÖTR'}</span>
  );
}

function LoadingSpinner({ size = 16 }) {
  return (
    <div style={{
      width: size, height: size, border: `2px solid #1a1a3a`,
      borderTop: `2px solid #00b0ff`, borderRadius: '50%',
      animation: 'gmgSpin 0.8s linear infinite', flexShrink: 0,
    }} />
  );
}

// ─── VARlik KARTI ─────────────────────────────────────────────────────────────
function AssetCard({ asset, cryptoEffect }) {
  const { label, data, category } = asset;
  if (!data) return (
    <div style={styles.card}>
      <div style={{ fontSize: 10, color: '#606090', fontWeight: 700 }}>{label}</div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 6 }}>
        <LoadingSpinner size={12} />
        <span style={{ fontSize: 9, color: '#404070' }}>Yükleniyor...</span>
      </div>
    </div>
  );

  const price  = data.price;
  const change = data.change24h;
  const col    = chgCol(change);

  // Kripto korelasyon sinyali
  const corr = asset.cryptoCorr || 0;
  const corrSignal = () => {
    if (!change) return 'NÖTR';
    const effect = change * corr;
    if (effect > 0.3) return 'AL';
    if (effect < -0.3) return 'SAT';
    return 'NÖTR';
  };

  const categoryIcon = {
    forex:     '💱',
    commodity: '🪙',
    index:     '📈',
    bond:      '📊',
  }[category] || '•';

  return (
    <div style={styles.card}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 6 }}>
        <div>
          <div style={{ fontSize: 8, color: '#404080', marginBottom: 1, letterSpacing: '0.5px' }}>
            {categoryIcon} {category?.toUpperCase()}
          </div>
          <div style={{ fontSize: 11, fontWeight: 700, color: '#c0c0e0' }}>{label}</div>
        </div>
        <SignalBadge signal={corrSignal()} />
      </div>

      <div style={{ fontSize: 16, fontWeight: 900, color: '#e0e0ff', letterSpacing: '0.5px', marginBottom: 2 }}>
        {price != null
          ? (price > 100 ? `$${price.toLocaleString('en', { minimumFractionDigits: 2 })}` : `${price.toFixed(4)}`)
          : '—'}
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
        <span style={{ fontSize: 10, fontWeight: 700, color: col }}>
          {fmtChg(change)}
        </span>
        {asset.source && (
          <span style={{ fontSize: 7, color: '#303060', letterSpacing: '0.3px' }}>
            {data.source || 'stooq'}
          </span>
        )}
      </div>

      {/* Kripto korelasyon barı */}
      {corr !== 0 && (
        <div>
          <div style={{ fontSize: 7, color: '#303060', marginBottom: 2 }}>
            Kripto Korelasyon: {corr > 0 ? '+' : ''}{(corr * 100).toFixed(0)}%
          </div>
          <ScoreBar
            score={50 + (change || 0) * corr * 15}
            color={chgCol((change || 0) * corr)}
          />
        </div>
      )}
    </div>
  );
}

// ─── BÜYÜK MAKRO GÖSTERGESI ────────────────────────────────────────────────────
function MacroGauge({ label, value, max, min = 0, color, unit = '', subtitle }) {
  const pct = max !== min ? clamp(((value - min) / (max - min)) * 100) : 50;
  return (
    <div style={{ ...styles.card, textAlign: 'center' }}>
      <div style={{ fontSize: 8, color: '#404080', letterSpacing: '1px', marginBottom: 6 }}>
        {label}
      </div>
      {/* Yarım daire gauge */}
      <div style={{ position: 'relative', width: 80, height: 44, margin: '0 auto 4px' }}>
        <svg viewBox="0 0 80 44" style={{ overflow: 'visible' }}>
          {/* BG arc */}
          <path d="M 8 40 A 32 32 0 0 1 72 40" fill="none" stroke="#0d0d28" strokeWidth="7" strokeLinecap="round" />
          {/* Value arc */}
          <path
            d={describeArc(40, 40, 32, -180, -180 + pct * 1.8)}
            fill="none" stroke={color} strokeWidth="7" strokeLinecap="round"
            style={{ transition: 'all 0.5s ease' }}
          />
          {/* Needle */}
          <line
            x1="40" y1="40"
            x2={40 + Math.cos((-180 + pct * 1.8) * Math.PI / 180) * 22}
            y2={40 + Math.sin((-180 + pct * 1.8) * Math.PI / 180) * 22}
            stroke={color} strokeWidth="1.5" strokeLinecap="round"
            style={{ transition: 'all 0.5s ease' }}
          />
          <circle cx="40" cy="40" r="3" fill={color} />
        </svg>
      </div>
      <div style={{ fontSize: 20, fontWeight: 900, color, lineHeight: 1 }}>
        {value != null ? `${value}${unit}` : '—'}
      </div>
      {subtitle && (
        <div style={{ fontSize: 9, fontWeight: 700, color, marginTop: 3 }}>{subtitle}</div>
      )}
    </div>
  );
}

function describeArc(cx, cy, r, startAngle, endAngle) {
  const s = polarToCartesian(cx, cy, r, endAngle);
  const e = polarToCartesian(cx, cy, r, startAngle);
  const large = endAngle - startAngle <= 180 ? '0' : '1';
  return `M ${s.x} ${s.y} A ${r} ${r} 0 ${large} 0 ${e.x} ${e.y}`;
}
function polarToCartesian(cx, cy, r, angle) {
  const a = (angle - 90) * Math.PI / 180;
  return { x: cx + r * Math.cos(a), y: cy + r * Math.sin(a) };
}

// ─── TAHVIL PANELİ ────────────────────────────────────────────────────────────
function BondPanel({ macro }) {
  if (!macro) return <div style={styles.loadingBox}>Tahvil verisi yükleniyor...</div>;
  const { us10y, us2y } = macro;
  const spread = macro.yieldSpread;
  const inverted = macro.isInvertedCurve;

  const bonds = [
    { label: 'US 10Y', value: us10y?.value, source: us10y?.source, change: us10y?.change },
    { label: 'US 2Y',  value: us2y?.value,  source: us2y?.source,  change: us2y?.change },
    { label: 'Spread (10Y-2Y)', value: spread, source: '—', change: null, special: true },
  ];

  return (
    <div>
      {/* Uyarı banner */}
      {inverted && (
        <div style={{
          background: 'rgba(255,34,85,.12)', border: '1px solid rgba(255,34,85,.3)',
          borderRadius: 6, padding: '8px 12px', marginBottom: 10,
          display: 'flex', alignItems: 'center', gap: 8,
        }}>
          <span style={{ fontSize: 16 }}>⚠️</span>
          <div>
            <div style={{ fontSize: 10, fontWeight: 700, color: '#ff2255' }}>TERSINE GETİRİ EĞRİSİ</div>
            <div style={{ fontSize: 9, color: '#9090c0' }}>
              10Y − 2Y = {spread?.toFixed(3)}% — Tarihsel resesyon sinyali
            </div>
          </div>
        </div>
      )}

      <div style={styles.cardGrid}>
        {bonds.map(b => (
          <div key={b.label} style={{
            ...styles.card,
            ...(b.special && inverted ? { borderColor: 'rgba(255,34,85,.3)' } : {}),
          }}>
            <div style={{ fontSize: 9, color: '#404080', marginBottom: 4 }}>{b.label}</div>
            <div style={{ fontSize: 18, fontWeight: 900, color: b.special && inverted ? '#ff2255' : '#e0e0ff' }}>
              {b.value != null ? `${b.value?.toFixed(2)}%` : '—'}
            </div>
            {b.change != null && (
              <div style={{ fontSize: 10, color: chgCol(b.change), marginTop: 2 }}>
                {fmtChg(b.change)} bugün
              </div>
            )}
            {b.source && b.source !== '—' && (
              <div style={{ fontSize: 7, color: '#303060', marginTop: 3 }}>{b.source}</div>
            )}
          </div>
        ))}
      </div>

      {/* Getiri eğrisi görselleştirme */}
      <div style={{ ...styles.card, marginTop: 8 }}>
        <div style={{ fontSize: 9, fontWeight: 700, color: '#606090', marginBottom: 8 }}>
          ABD GETİRİ EĞRİSİ
        </div>
        <div style={{ position: 'relative', height: 60 }}>
          <svg width="100%" height="60" viewBox="0 0 300 60" preserveAspectRatio="none">
            {/* BG grid */}
            {[0, 1, 2, 3].map(i => (
              <line key={i} x1="0" y1={i * 20} x2="300" y2={i * 20} stroke="#0d0d28" strokeWidth="0.5" />
            ))}
            {/* Curve */}
            <polyline
              points={yieldCurvePoints(us2y?.value, us10y?.value)}
              fill="none"
              stroke={inverted ? '#ff2255' : '#00b0ff'}
              strokeWidth="2"
              style={{ transition: 'all 0.5s' }}
            />
            {/* Fill */}
            <polygon
              points={`0,60 ${yieldCurvePoints(us2y?.value, us10y?.value)} 300,60`}
              fill={inverted ? 'rgba(255,34,85,.08)' : 'rgba(0,176,255,.08)'}
            />
          </svg>
          {/* Labels */}
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4 }}>
            {['3M', '2Y', '5Y', '10Y', '30Y'].map(t => (
              <span key={t} style={{ fontSize: 8, color: '#303060' }}>{t}</span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function yieldCurvePoints(us2y, us10y) {
  const y2  = us2y  || 4.8;
  const y10 = us10y || 4.3;
  // Basit 5 nokta interpolasyon
  const pts = [
    [0, 5.1],          // 3M (fed funds yakını)
    [75, y2],          // 2Y
    [150, (y2 + y10) / 2],  // 5Y (interpolated)
    [225, y10],        // 10Y
    [300, y10 - 0.1],  // 30Y (yaklaşık)
  ];
  const minY = Math.min(...pts.map(p => p[1])) - 0.2;
  const maxY = Math.max(...pts.map(p => p[1])) + 0.2;
  return pts.map(([x, y]) => `${x},${60 - ((y - minY) / (maxY - minY)) * 50}`).join(' ');
}

// ─── MAKRO PANELİ ─────────────────────────────────────────────────────────────
function MacroPanel({ macro }) {
  if (!macro) return <div style={styles.loadingBox}>Makro veri yükleniyor...</div>;

  const { dxy, vix, gold, oil, fearGreed, riskMode, riskScore, summary } = macro;
  const fearColor = fearGreed?.value > 75 ? '#ff6d00'
    : fearGreed?.value > 55 ? '#00e676'
    : fearGreed?.value > 45 ? '#ffd700'
    : fearGreed?.value > 25 ? '#ff6d00'
    : '#ff2255';
  const fearLabel = fearGreed?.value > 75 ? 'AŞIRI AÇGÖZLÜ'
    : fearGreed?.value > 55 ? 'AÇGÖZLÜ'
    : fearGreed?.value > 45 ? 'NÖTR'
    : fearGreed?.value > 25 ? 'KORKU'
    : 'AŞIRI KORKU';
  const vixColor = vix?.value > 30 ? '#ff2255' : vix?.value > 20 ? '#ffd700' : '#00e676';

  return (
    <div>
      {/* Risk modu banner */}
      <div style={{
        background: riskMode === 'RISK_ON' ? 'rgba(0,230,118,.1)' : riskMode === 'RISK_OFF' ? 'rgba(255,34,85,.1)' : 'rgba(255,215,0,.08)',
        border: `1px solid ${riskMode === 'RISK_ON' ? 'rgba(0,230,118,.3)' : riskMode === 'RISK_OFF' ? 'rgba(255,34,85,.3)' : 'rgba(255,215,0,.2)'}`,
        borderRadius: 6, padding: '10px 14px', marginBottom: 10,
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      }}>
        <div>
          <div style={{ fontSize: 8, color: '#606090', letterSpacing: '1px', marginBottom: 2 }}>GLOBAL RİSK MODU</div>
          <div style={{ fontSize: 16, fontWeight: 900, color: riskMode === 'RISK_ON' ? '#00e676' : riskMode === 'RISK_OFF' ? '#ff2255' : '#ffd700' }}>
            {riskMode === 'RISK_ON' ? '✅ RISK-ON' : riskMode === 'RISK_OFF' ? '⚠️ RISK-OFF' : '📊 NEUTRAL'}
          </div>
          <div style={{ fontSize: 9, color: '#606090', marginTop: 2 }}>
            Kripto için {riskMode === 'RISK_ON' ? 'OLUMLU' : riskMode === 'RISK_OFF' ? 'OLUMSUZ' : 'NÖTR'} ortam
          </div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontSize: 8, color: '#404080', marginBottom: 2 }}>Skor</div>
          <div style={{ fontSize: 22, fontWeight: 900, color: riskMode === 'RISK_ON' ? '#00e676' : riskMode === 'RISK_OFF' ? '#ff2255' : '#ffd700' }}>
            {riskScore >= 0 ? '+' : ''}{riskScore}
          </div>
        </div>
      </div>

      {/* 4 büyük gösterge */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 6, marginBottom: 8 }}>
        <MacroGauge label="KORKU & AÇGÖZLÜLÜK" value={fearGreed?.value} max={100} color={fearColor} subtitle={fearLabel} />
        <MacroGauge label="VIX — VOLATİLİTE" value={vix?.value?.toFixed(1)} max={60} color={vixColor} subtitle={vix?.level || '—'} />
        <MacroGauge label="DXY — DOLAR ENDEKSİ" value={dxy?.value?.toFixed(1)} max={115} min={90} color="#00b0ff" subtitle={dxy?.source} />
        <MacroGauge label="ALTIN ($/oz)" value={gold?.value?.toFixed(0)} max={3000} min={1500} color="#ffd700" unit="" subtitle={`${fmtChg(gold?.change)} bugün`} />
        {macro?.silver?.ok && (
          <MacroGauge label="GÜMÜŞ ($/oz)" value={macro.silver?.value?.toFixed(2)} max={50} min={15} color="#c0c0c0" unit="" subtitle={`${fmtChg(macro.silver?.change)} bugün`} />
        )}
        {macro?.sp500?.value > 0 && (
          <MacroGauge label="S&P 500" value={macro.sp500?.value?.toFixed(0)} max={7000} min={3000} color={macro.sp500?.change >= 0 ? '#00e676' : '#ff3366'} unit="" subtitle={`${fmtChg(macro.sp500?.change)} bugün`} />
        )}
        {macro?.nasdaq?.value > 0 && (
          <MacroGauge label="NASDAQ 100" value={macro.nasdaq?.value?.toFixed(0)} max={25000} min={10000} color={macro.nasdaq?.change >= 0 ? '#00e676' : '#ff3366'} unit="" subtitle={`${fmtChg(macro.nasdaq?.change)} bugün`} />
        )}
        {macro?.breadth != null && (
          <MacroGauge label="PİYASA GENİŞLİĞİ" value={Math.round(macro.breadth * 100)} max={100} color={macro.breadth > 0.6 ? '#00e676' : '#ff3366'} subtitle={macro.breadth > 0.6 ? 'Geniş Taban' : 'Dar Taban'} />
        )}
      </div>

      {/* Özet tablo */}
      <div style={styles.card}>
        <div style={{ fontSize: 9, fontWeight: 700, color: '#606090', marginBottom: 8 }}>KAYNAK VERİ ÖZETİ</div>
        {summary?.map((line, i) => (
          <div key={i} style={{
            fontSize: 9, color: '#9090c0', padding: '3px 0',
            borderBottom: i < summary.length - 1 ? '1px solid #0a0a1c' : 'none',
            fontFamily: 'monospace',
          }}>{line}</div>
        ))}
      </div>
    </div>
  );
}

// ─── GENEL BAKIŞ PANELİ ───────────────────────────────────────────────────────
function OverviewPanel({ macro, assets }) {
  const riskMode  = macro?.riskMode || 'NEUTRAL';
  const fearVal   = macro?.fearGreed?.value || 50;
  const vixVal    = macro?.vix?.value || 20;
  const dxyVal    = macro?.dxy?.value || 104;
  const dxyChange = macro?.dxy?.change || 0;
  const goldVal   = macro?.gold?.value || 2000;
  const goldChg   = macro?.gold?.change || 0;
  const oilVal    = macro?.oil?.value || 75;
  const oilChg    = macro?.oil?.change || 0;
  const spread    = macro?.yieldSpread || 0;
  const inverted  = macro?.isInvertedCurve || false;

  // Kripto için toplam sinyal
  const signals = [
    { label: 'Korku & Açgözlülük', value: fearVal, signal: fearVal > 75 ? 'BEKLE' : fearVal > 55 ? 'AL' : fearVal > 30 ? 'BEKLE' : 'AL', detail: `${fearVal}/100` },
    { label: 'VIX',                value: vixVal,  signal: vixVal > 30 ? 'SAT' : vixVal < 15 ? 'AL' : 'BEKLE', detail: vixVal.toFixed(1) },
    { label: 'DXY',                value: null,    signal: dxyChange < -0.5 ? 'AL' : dxyChange > 0.5 ? 'SAT' : 'BEKLE', detail: `${dxyVal.toFixed(1)} (${fmtChg(dxyChange)})` },
    { label: 'Altın',              value: null,    signal: goldChg > 1 ? 'SAT' : goldChg < -1 ? 'AL' : 'BEKLE', detail: `$${goldVal.toFixed(0)} (${fmtChg(goldChg)})` },
    { label: 'Petrol (WTI)',       value: null,    signal: oilChg > 3 ? 'BEKLE' : oilChg < -3 ? 'BEKLE' : 'NÖTR', detail: `$${oilVal.toFixed(1)} (${fmtChg(oilChg)})` },
    { label: 'Getiri Eğrisi',      value: null,    signal: inverted ? 'SAT' : spread > 0.5 ? 'AL' : 'BEKLE', detail: `${spread >= 0 ? '+' : ''}${spread.toFixed(3)}%` },
  ];

  const bullCount = signals.filter(s => s.signal === 'AL').length;
  const bearCount = signals.filter(s => s.signal === 'SAT').length;

  return (
    <div>
      {/* Makro sinyal özeti */}
      <div style={{ ...styles.card, marginBottom: 8 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
          <div style={{ fontSize: 9, fontWeight: 700, color: '#606090', letterSpacing: '1px' }}>KRİPTO İÇİN MAKRO SINYAL</div>
          <SignalBadge signal={riskMode} />
        </div>
        {/* Al/Sat barı */}
        <div style={{ background: '#0a0a1c', borderRadius: 4, height: 8, overflow: 'hidden', display: 'flex', marginBottom: 6 }}>
          <div style={{ width: `${(bullCount / signals.length) * 100}%`, background: '#00e676', transition: 'width 0.5s' }} />
          <div style={{ flex: 1, background: '#ffd700' }} />
          <div style={{ width: `${(bearCount / signals.length) * 100}%`, background: '#ff2255', transition: 'width 0.5s' }} />
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 9 }}>
          <span style={{ color: '#00e676', fontWeight: 700 }}>{bullCount} AL</span>
          <span style={{ color: '#ffd700', fontWeight: 700 }}>{signals.length - bullCount - bearCount} BEKLE</span>
          <span style={{ color: '#ff2255', fontWeight: 700 }}>{bearCount} SAT</span>
        </div>
      </div>

      {/* Sinyal detayları */}
      <div style={styles.card}>
        {signals.map((s, i) => (
          <div key={s.label} style={{
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            padding: '5px 0', borderBottom: i < signals.length - 1 ? '1px solid #0a0a1c' : 'none',
          }}>
            <span style={{ fontSize: 9, color: '#9090c0', flex: 1 }}>{s.label}</span>
            <span style={{ fontSize: 9, color: '#606090', flex: 1, textAlign: 'center', fontFamily: 'monospace' }}>{s.detail}</span>
            <SignalBadge signal={s.signal} />
          </div>
        ))}
      </div>

      {/* Piyasa korelasyon özeti */}
      {assets.length > 0 && (
        <div style={{ ...styles.card, marginTop: 8 }}>
          <div style={{ fontSize: 9, fontWeight: 700, color: '#606090', marginBottom: 8 }}>
            KRİPTO KORELASYON TABLOSU
          </div>
          {assets.slice(0, 8).map(a => {
            const change  = a.data?.change24h || 0;
            const corr    = a.cryptoCorr || 0;
            const effect  = change * corr;
            return (
              <div key={a.id} style={{
                display: 'flex', alignItems: 'center', gap: 6,
                padding: '3px 0', borderBottom: '1px solid #080818',
              }}>
                <span style={{ fontSize: 9, color: '#9090c0', width: 60, flexShrink: 0 }}>{a.label}</span>
                <span style={{ fontSize: 9, color: chgCol(change), width: 50, textAlign: 'right', fontFamily: 'monospace', flexShrink: 0 }}>{fmtChg(change)}</span>
                <div style={{ flex: 1, background: '#0a0a1c', borderRadius: 1, height: 4, overflow: 'hidden' }}>
                  <div style={{
                    width: `${clamp(50 + effect * 10)}%`, height: 4,
                    background: chgCol(effect), transition: 'width 0.5s',
                  }} />
                </div>
                <span style={{ fontSize: 8, color: '#404070', width: 28, textAlign: 'right', flexShrink: 0 }}>
                  {corr > 0 ? '+' : ''}{(corr * 100).toFixed(0)}%
                </span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ─── ANA BİLEŞEN ─────────────────────────────────────────────────────────────
export default function MultiMarketDashboard({ masterResult = null }) {
  const [activeTab, setActiveTab] = useState('overview');
  const [macro, setMacro]         = useState(null);
  const [assets, setAssets]       = useState([]);
  const [loading, setLoading]     = useState(true);
  const [lastUpdate, setLastUpdate] = useState(null);
  const [error, setError]         = useState(null);
  const timerRef                  = useRef(null);

  const load = useCallback(async (showLoading = true) => {
    if (showLoading) setLoading(true);
    setError(null);
    try {
      const [macroData, assetData] = await Promise.allSettled([
        fetchAllMacro(),
        fetchAllAssets(),
      ]);

      if (macroData.status === 'fulfilled') setMacro(macroData.value);
      else setMacro(null);

      if (assetData.status === 'fulfilled') setAssets(assetData.value);
      else setAssets([]);

      setLastUpdate(new Date().toLocaleTimeString('tr-TR'));
    } catch (e) {
      setError('Veri çekme hatası: ' + e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load(true);
    timerRef.current = setInterval(() => load(false), REFRESH_INTERVAL);
    return () => clearInterval(timerRef.current);
  }, [load]);

  const handleRefresh = () => {
    clearMacroCache();
    load(true);
  };

  // Varlıkları kategoriye göre grupla
  const forexAssets     = assets.filter(a => a.category === 'forex');
  const commodityAssets = assets.filter(a => a.category === 'commodity');
  const indexAssets     = assets.filter(a => a.category === 'index');

  // Emtia listesini genişlet (statik + API)
  const extendedCommodities = [
    ...commodityAssets,
    ...(macro?.gold  && !commodityAssets.find(a => a.id === 'XAUUSD') ? [{ id: 'XAUUSD', label: 'Altın',   category: 'commodity', cryptoCorr: 0.4,  data: { price: macro.gold.value,  change24h: macro.gold.change,  source: macro.gold.source  } }] : []),
    ...(macro?.oil   && !commodityAssets.find(a => a.id === 'WTIUSD') ? [{ id: 'WTIUSD', label: 'WTI Ham', category: 'commodity', cryptoCorr: 0.1,  data: { price: macro.oil.value,   change24h: macro.oil.change,   source: macro.oil.source   } }] : []),
  ];

  return (
    <div style={styles.root}>
      {/* ── HEADER ── */}
      <div style={styles.header}>
        <div>
          <div style={{ fontSize: 10, fontWeight: 700, color: '#00b0ff', letterSpacing: '2px' }}>
            🌍 GLOBAL PİYASALAR
          </div>
          {lastUpdate && (
            <div style={{ fontSize: 8, color: '#303060', marginTop: 2 }}>
              Son güncelleme: {lastUpdate}
            </div>
          )}
        </div>
        <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
          {loading && <LoadingSpinner size={14} />}
          <button onClick={handleRefresh} style={styles.refreshBtn}>
            ↺ Yenile
          </button>
        </div>
      </div>

      {/* ── TABS ── */}
      <div style={styles.tabBar}>
        {TABS.map(t => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id)}
            style={{
              ...styles.tab,
              ...(activeTab === t.id ? styles.tabActive : {}),
            }}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* ── İÇERİK ── */}
      <div style={styles.content}>
        {error && (
          <div style={{ fontSize: 9, color: '#ff4466', padding: '8px 12px', background: 'rgba(255,34,85,.08)', borderRadius: 5, marginBottom: 8 }}>
            ⚠️ {error}
          </div>
        )}

        {activeTab === 'overview' && (
          <OverviewPanel macro={macro} assets={assets} />
        )}

        {activeTab === 'forex' && (
          <div>
            <div style={styles.sectionTitle}>💱 FOREX PİYASALARI</div>
            {/* DXY öne çıkan */}
            {macro?.dxy && (
              <div style={{ ...styles.card, marginBottom: 8, borderColor: 'rgba(0,176,255,.2)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div>
                    <div style={{ fontSize: 8, color: '#404080' }}>🇺🇸 DXY — ABD DOLAR ENDEKSİ</div>
                    <div style={{ fontSize: 22, fontWeight: 900, color: '#00b0ff', marginTop: 2 }}>
                      {macro.dxy.value?.toFixed(3)}
                    </div>
                    <div style={{ fontSize: 9, color: chgCol(macro.dxy.change), marginTop: 2 }}>
                      {fmtChg(macro.dxy.change)} 24s
                    </div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <SignalBadge signal={macro.dxy.change < -0.3 ? 'AL' : macro.dxy.change > 0.3 ? 'SAT' : 'NÖTR'} />
                    <div style={{ fontSize: 8, color: '#404080', marginTop: 4 }}>Kaynak: {macro.dxy.source}</div>
                    <div style={{ fontSize: 8, color: '#404080', marginTop: 2 }}>
                      DXY ↑ = Kripto ↓ (korelasyon: -60%)
                    </div>
                  </div>
                </div>
                <div style={{ marginTop: 8 }}>
                  <ScoreBar score={clamp(50 - (macro.dxy.change || 0) * 10 + (50 - (macro.dxy.value - 90) / 25 * 100))} color="#00b0ff" height={5} />
                </div>
              </div>
            )}
            <div style={styles.cardGrid}>
              {forexAssets.filter(a => a.id !== 'DXY').map(a => (
                <AssetCard key={a.id} asset={a} />
              ))}
              {/* Fallback: forex yoksa mesaj */}
              {forexAssets.length === 0 && (
                <div style={{ gridColumn: '1 / -1', ...styles.loadingBox }}>
                  {loading ? 'Forex verileri yükleniyor...' : 'Forex verisi alınamadı (proxy gerekli)'}
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'commodity' && (
          <div>
            <div style={styles.sectionTitle}>🥇 EMTİA PİYASALARI</div>
            {/* Altın öne çıkan */}
            {macro?.gold && (
              <div style={{ ...styles.card, marginBottom: 8, borderColor: 'rgba(255,215,0,.2)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 8 }}>
                  <div>
                    <div style={{ fontSize: 8, color: '#404080' }}>🥇 ALTIN (XAU/USD)</div>
                    <div style={{ fontSize: 24, fontWeight: 900, color: '#ffd700', marginTop: 2 }}>
                      ${macro.gold.value?.toFixed(2)}
                    </div>
                    <div style={{ fontSize: 10, color: chgCol(macro.gold.change) }}>
                      {fmtChg(macro.gold.change)} 24s
                    </div>
                  </div>
                  <div>
                    <div style={{ fontSize: 8, color: '#404080' }}>🛢️ WTI HAM PETROL</div>
                    <div style={{ fontSize: 24, fontWeight: 900, color: '#ff8800', marginTop: 2 }}>
                      ${macro.oil?.value?.toFixed(2) || '—'}
                    </div>
                    <div style={{ fontSize: 10, color: chgCol(macro.oil?.change) }}>
                      {fmtChg(macro.oil?.change)} — {macro.oil?.type || 'WTI'}
                    </div>
                  </div>
                </div>
                <div style={{ marginTop: 8, fontSize: 8, color: '#404080' }}>
                  Kaynak: {macro.gold.source} · Güncelleme: her 2 dakika
                </div>
              </div>
            )}
            <div style={styles.cardGrid}>
              {extendedCommodities.map(a => (
                <AssetCard key={a.id} asset={a} />
              ))}
              {extendedCommodities.length === 0 && (
                <div style={{ gridColumn: '1 / -1', ...styles.loadingBox }}>
                  {loading ? 'Emtia verileri yükleniyor...' : 'Emtia verisi yükleniyor...'}
                </div>
              )}
            </div>
            {/* Emtia & Kripto korelasyon açıklaması */}
            <div style={{ ...styles.card, marginTop: 8 }}>
              <div style={{ fontSize: 9, fontWeight: 700, color: '#606090', marginBottom: 6 }}>
                EMTİA → KRİPTO ETKİSİ
              </div>
              {[
                { label: 'Altın ↑',     effect: 'Enflasyon koruması ihtiyacı → Kripto pozitif' },
                { label: 'Petrol ↑',    effect: 'Enflasyon riski ↑ → Risk-OFF → Kripto negatif' },
                { label: 'VIX ↑',       effect: 'Piyasa korkusu ↑ → Risk-OFF → Kripto satış' },
                { label: 'DXY ↑',       effect: 'Dolar güçleniyor → Kripto üzerinde baskı' },
              ].map(r => (
                <div key={r.label} style={{ display: 'flex', gap: 8, padding: '3px 0', borderBottom: '1px solid #0a0a1c', fontSize: 9 }}>
                  <span style={{ color: '#ffd700', width: 60, flexShrink: 0, fontWeight: 700 }}>{r.label}</span>
                  <span style={{ color: '#9090c0' }}>{r.effect}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'index' && (
          <div>
            <div style={styles.sectionTitle}>📈 KÜRESEL HİSSE ENDEKSLERİ</div>
            <div style={styles.cardGrid}>
              {indexAssets.map(a => <AssetCard key={a.id} asset={a} />)}
              {/* VIX öne çıkan */}
              {macro?.vix && (
                <div style={{ ...styles.card, borderColor: macro.vix.value > 30 ? 'rgba(255,34,85,.3)' : 'rgba(0,230,118,.2)' }}>
                  <div style={{ fontSize: 8, color: '#404080', marginBottom: 4 }}>📊 VIX — KORKU ENDEKSİ</div>
                  <div style={{ fontSize: 20, fontWeight: 900, color: macro.vix.value > 30 ? '#ff2255' : macro.vix.value > 20 ? '#ffd700' : '#00e676' }}>
                    {macro.vix.value?.toFixed(2)}
                  </div>
                  <div style={{ fontSize: 9, color: '#9090c0', marginTop: 2 }}>{macro.vix.level}</div>
                  <div style={{ fontSize: 7, color: '#303060', marginTop: 3 }}>Kaynak: {macro.vix.source}</div>
                  <div style={{ marginTop: 6 }}>
                    <ScoreBar score={clamp(macro.vix.value / 60 * 100)} color={macro.vix.value > 30 ? '#ff2255' : '#00e676'} />
                  </div>
                </div>
              )}
              {indexAssets.length === 0 && !macro?.vix && (
                <div style={{ gridColumn: '1 / -1', ...styles.loadingBox }}>
                  {loading ? 'Endeks verileri yükleniyor...' : 'Endeks verisi alınamadı'}
                </div>
              )}
            </div>
            {/* Endeks-Kripto korelasyon */}
            <div style={{ ...styles.card, marginTop: 8 }}>
              <div style={{ fontSize: 9, fontWeight: 700, color: '#606090', marginBottom: 6 }}>ENDEKSLERİN KRİPTOYA ETKİSİ</div>
              {[
                { label: 'Nasdaq',   corr: '+70%', effect: 'En güçlü pozitif korelasyon — tech hisseleriyle birlikte hareket' },
                { label: 'S&P 500',  corr: '+65%', effect: 'Risk iştahını yansıtır — S&P düşünce kripto da düşer' },
                { label: 'VIX',      corr: '-55%', effect: 'VIX > 30 → piyasa korkusu → kripto satışı tetikler' },
              ].map(r => (
                <div key={r.label} style={{ display: 'flex', gap: 8, padding: '4px 0', borderBottom: '1px solid #0a0a1c', fontSize: 9 }}>
                  <span style={{ color: '#00b0ff', width: 55, flexShrink: 0, fontWeight: 700 }}>{r.label}</span>
                  <span style={{ color: '#ffd700', width: 38, flexShrink: 0 }}>{r.corr}</span>
                  <span style={{ color: '#9090c0' }}>{r.effect}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'bond' && <BondPanel macro={macro} />}
        {activeTab === 'macro'  && <MacroPanel macro={macro} />}
      </div>

      <style>{`
        @keyframes gmgSpin { to { transform: rotate(360deg); } }
        @media (max-width: 640px) {
          .gmg-card-grid { grid-template-columns: repeat(2, 1fr) !important; }
        }
        @media (min-width: 641px) and (max-width: 1023px) {
          .gmg-card-grid { grid-template-columns: repeat(3, 1fr) !important; }
        }
      `}</style>
    </div>
  );
}

// ─── STILLER ─────────────────────────────────────────────────────────────────
const styles = {
  root: {
    background: '#03030e',
    minHeight: '100%',
    fontFamily: "'Courier New', monospace",
    color: '#c0c0e0',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '10px 12px 6px',
    borderBottom: '1px solid #14143a',
  },
  tabBar: {
    display: 'flex',
    overflowX: 'auto',
    borderBottom: '1px solid #14143a',
    background: '#04040f',
    scrollbarWidth: 'none',
    WebkitOverflowScrolling: 'touch',
  },
  tab: {
    padding: '7px 12px',
    fontSize: 9,
    fontWeight: 700,
    letterSpacing: '0.5px',
    background: 'transparent',
    border: 'none',
    borderBottom: '2px solid transparent',
    color: '#303065',
    cursor: 'pointer',
    whiteSpace: 'nowrap',
    fontFamily: "'Courier New', monospace",
    transition: 'all 0.15s',
  },
  tabActive: {
    color: '#00b0ff',
    borderBottomColor: '#00b0ff',
    background: 'rgba(0,176,255,.06)',
  },
  content: {
    padding: 10,
  },
  card: {
    background: '#06061a',
    border: '1px solid #12122e',
    borderRadius: 6,
    padding: '8px 10px',
  },
  cardGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))',
    gap: 6,
  },
  sectionTitle: {
    fontSize: 8,
    fontWeight: 700,
    letterSpacing: '2px',
    color: '#303065',
    marginBottom: 8,
    textTransform: 'uppercase',
  },
  loadingBox: {
    padding: '20px 12px',
    fontSize: 9,
    color: '#404070',
    textAlign: 'center',
    background: '#06061a',
    border: '1px solid #12122e',
    borderRadius: 6,
  },
  refreshBtn: {
    background: 'transparent',
    border: '1px solid #14143a',
    color: '#404080',
    fontSize: 9,
    fontFamily: "'Courier New', monospace",
    fontWeight: 700,
    padding: '3px 10px',
    borderRadius: 4,
    cursor: 'pointer',
  },
};
