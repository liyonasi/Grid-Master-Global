/**
 * GRID MASTER GLOBAL — COUNCIL ENGINE
 * =====================================
 * 4 Karar Konseyi: Her biri farklı açıdan piyasayı değerlendirir.
 * Ham sinyaller → Konseyler → Nihai karar
 *
 * KONSEYler:
 * 1. MOMENTUM COUNCIL    — Fiyat hareketi, trend, ivme
 * 2. RISK COUNCIL        — Tuzak, dump, stop hunt, volatilite
 * 3. STRUCTURE COUNCIL   — Long/short hazır, patlama, akümülasyon
 * 4. FLOW COUNCIL        — Orderbook, likidite, BTC relatif güç
 */

// ─── YARDIMCILAR ──────────────────────────────────────────────────────────────

function clamp(val, min = 0, max = 100) {
  return Math.min(max, Math.max(min, val));
}

function weightedAvg(signals) {
  // signals: [{score: 0-100, weight: 0-1, label: string}]
  const totalWeight = signals.reduce((s, sig) => s + sig.weight, 0);
  if (totalWeight === 0) return 50;
  return clamp(
    signals.reduce((s, sig) => s + sig.score * sig.weight, 0) / totalWeight
  );
}

function scoreToAction(score) {
  if (score >= 72) return { action: 'GÜÇLÜ AL',  color: '#00ff88', short: 'AL' };
  if (score >= 58) return { action: 'AL',         color: '#00cc66', short: 'AL' };
  if (score >= 45) return { action: 'BEKLE',      color: '#ffcc00', short: 'BEKLE' };
  if (score >= 32) return { action: 'SAT',        color: '#ff6633', short: 'SAT' };
  return              { action: 'GÜÇLÜ SAT',  color: '#ff3366', short: 'SAT' };
}

function confidenceFromCount(positiveCount, totalCount) {
  if (totalCount === 0) return 50;
  const ratio = positiveCount / totalCount;
  // Maps to 20-95% confidence range
  return clamp(Math.round(20 + ratio * 75));
}

// ─── 1. MOMENTUM COUNCIL ─────────────────────────────────────────────────────
/**
 * Sorumluluk: Piyasa hareketi güçlü mü? Trend var mı? İvme kazanıyor mu?
 * Besleyen modüller:
 *   - suddenPumps / suddenDumps (ani hareket)
 *   - stealthRising / stealthFalling (gizli trend)
 *   - btcStrong / btcWeak (relatif güç)
 *   - scalpLongs / scalpShorts (momentum sinyal)
 */
export function runMomentumCouncil(scanResults) {
  const {
    suddenPumps, suddenDumps, stealthRising, stealthFalling,
    btcStrong, btcWeak, scalpLongs, scalpShorts, btcChange, enrichedCoins,
  } = scanResults;

  const totalCoins = enrichedCoins.length || 1;
  const positiveCoins = enrichedCoins.filter(c => (c.change_24h || 0) > 0).length;
  const marketBreadth = positiveCoins / totalCoins; // 0-1

  // Her sinyal 0-100 puan
  const signals = [
    {
      label: 'Piyasa genişliği',
      score: clamp(marketBreadth * 100),
      weight: 0.25,
      detail: `${positiveCoins}/${totalCoins} coin pozitif`,
    },
    {
      label: 'BTC momentum',
      score: clamp(50 + btcChange * 5),
      weight: 0.25,
      detail: `BTC 24s: ${btcChange >= 0 ? '+' : ''}${btcChange?.toFixed(2) || 0}%`,
    },
    {
      label: 'Pump/Dump dengesi',
      score: clamp(50 + (suddenPumps.length - suddenDumps.length) * 8),
      weight: 0.20,
      detail: `${suddenPumps.length} pump | ${suddenDumps.length} dump`,
    },
    {
      label: 'Stealth trend',
      score: clamp(50 + (stealthRising.length - stealthFalling.length) * 6),
      weight: 0.15,
      detail: `${stealthRising.length} gizli yükseliş | ${stealthFalling.length} gizli düşüş`,
    },
    {
      label: 'Relatif güç',
      score: clamp(50 + (btcStrong.length - btcWeak.length) * 4),
      weight: 0.15,
      detail: `BTC'ye rağmen güçlü: ${btcStrong.length} | zayıf: ${btcWeak.length}`,
    },
  ];

  const score = Math.round(weightedAvg(signals));
  const { action, color } = scoreToAction(score);
  const confidence = confidenceFromCount(
    signals.filter(s => s.score >= 55).length,
    signals.length
  );

  // Top movers to highlight
  const topMovers = [
    ...suddenPumps.slice(0, 3).map(c => ({ ...c, dir: 'UP' })),
    ...suddenDumps.slice(0, 3).map(c => ({ ...c, dir: 'DOWN' })),
  ].sort((a, b) => Math.abs(b.change) - Math.abs(a.change)).slice(0, 5);

  return {
    id: 'MOMENTUM',
    name: 'Momentum Konseyi',
    icon: '⚡',
    score,
    action,
    color,
    confidence,
    signals,
    highlights: {
      topPumps:      suddenPumps.slice(0, 5),
      topDumps:      suddenDumps.slice(0, 5),
      stealthRising: stealthRising.slice(0, 4),
      stealthFalling:stealthFalling.slice(0, 4),
      topMovers,
    },
    verdict: `${action} — Piyasa yönü ${score >= 55 ? 'YUKARI' : score <= 45 ? 'AŞAĞI' : 'YATAY'} baskısı`,
  };
}

// ─── 2. RISK COUNCIL ─────────────────────────────────────────────────────────
/**
 * Sorumluluk: Piyasada tuzak var mı? Stop hunt var mı? Risk yüksek mi?
 * Besleyen modüller:
 *   - scalpTraps (scalp tuzak)
 *   - stopHunts (stop avı)
 *   - liquiditySens (likidite duyarlılığı)
 *   - sessionRisks (zaman dilimi riski)
 *   - suddenDumps > -10 (kritik düşüşler)
 */
export function runRiskCouncil(scanResults) {
  const {
    scalpTraps, stopHunts, liquiditySens, sessionRisks, suddenDumps,
    activeSession, enrichedCoins,
  } = scanResults;

  const criticalDumps = suddenDumps.filter(d => d.change <= -10);
  const highRiskLiq   = liquiditySens.filter(l => l.riskLevel === 'YÜKSEK').length;
  const activeRisks   = sessionRisks.length;

  // Risk yükseldikçe skor DÜŞER (risk konseyi ters çalışır)
  const signals = [
    {
      label: 'Scalp tuzak yoğunluğu',
      score: clamp(100 - scalpTraps.length * 15),
      weight: 0.20,
      detail: `${scalpTraps.length} tuzak tespit edildi`,
    },
    {
      label: 'Stop Hunt aktivitesi',
      score: clamp(100 - stopHunts.length * 20),
      weight: 0.25,
      detail: `${stopHunts.length} stop hunt sinyali`,
    },
    {
      label: 'Kritik dump',
      score: clamp(100 - criticalDumps.length * 25),
      weight: 0.20,
      detail: `${criticalDumps.length} coin -10% altında`,
    },
    {
      label: 'Likidite duyarlılığı',
      score: clamp(100 - highRiskLiq * 12),
      weight: 0.20,
      detail: `${highRiskLiq} coin yüksek liq riski`,
    },
    {
      label: 'Seans riski',
      score: clamp(100 - activeRisks * 18),
      weight: 0.15,
      detail: activeSession.length
        ? `Aktif seans: ${activeSession.map(s => ({ASIA:'ASYA',EUROPE:'AVRUPA',USA:'ABD'}[s])).join(', ')}`
        : 'Düşük aktivite saati',
    },
  ];

  const score      = Math.round(weightedAvg(signals));
  const riskLevel  = score >= 70 ? 'DÜŞÜK' : score >= 50 ? 'ORTA' : score >= 30 ? 'YÜKSEK' : 'KRİTİK';
  const riskColor  = score >= 70 ? '#00ff88' : score >= 50 ? '#ffcc00' : score >= 30 ? '#ff8800' : '#ff3366';
  const { action, color } = scoreToAction(score);
  const confidence = confidenceFromCount(
    signals.filter(s => s.score >= 60).length,
    signals.length
  );

  return {
    id: 'RISK',
    name: 'Risk Konseyi',
    icon: '🛡',
    score,
    action,
    color: riskColor,
    confidence,
    riskLevel,
    signals,
    highlights: {
      scalpTraps:   scalpTraps.slice(0, 5),
      stopHunts:    stopHunts.slice(0, 5),
      sessionRisks: sessionRisks.slice(0, 4),
      criticalDumps:criticalDumps.slice(0, 4),
      liquiditySens:liquiditySens.slice(0, 4),
    },
    verdict: `Risk Seviyesi: ${riskLevel} — ${
      score < 40 ? 'Piyasa tehlikeli, dikkatli ol' : score < 60 ? 'Orta risk, seçici ol' : 'Görece güvenli ortam'
    }`,
  };
}

// ─── 3. STRUCTURE COUNCIL ────────────────────────────────────────────────────
/**
 * Sorumluluk: Yapısal fırsatlar var mı? Long/short hazır mı? Patlama yakın mı?
 * Besleyen modüller:
 *   - longReady (long için hazır coinler)
 *   - shortReady (short için hazır coinler)
 *   - explosionReady (patlamaya hazır)
 *   - scalpLongs / scalpShorts
 */
export function runStructureCouncil(scanResults) {
  const {
    longReady, shortReady, explosionReady, scalpLongs, scalpShorts, btcChange,
  } = scanResults;

  const longSignals  = longReady.length + scalpLongs.length;
  const shortSignals = shortReady.length + scalpShorts.length;
  const explosions   = explosionReady.length;
  const bias         = btcChange > 0 ? 'LONG' : 'SHORT';

  const signals = [
    {
      label: 'Long yapısı',
      score: clamp(50 + longSignals * 6),
      weight: 0.30,
      detail: `${longReady.length} hazır + ${scalpLongs.length} scalp long`,
    },
    {
      label: 'Short yapısı',
      // Short hazır çok = aşağı baskı = long skor düşer
      score: clamp(80 - shortSignals * 6),
      weight: 0.20,
      detail: `${shortReady.length} short hazır + ${scalpShorts.length} scalp short`,
    },
    {
      label: 'Patlama hazır',
      score: clamp(50 + explosions * 10),
      weight: 0.25,
      detail: `${explosions} coin patlama eşiğinde`,
    },
    {
      label: 'BTC yön uyumu',
      score: btcChange > 1 ? 72 : btcChange > 0 ? 58 : btcChange > -1 ? 45 : 30,
      weight: 0.25,
      detail: `BTC yönü: ${btcChange > 0 ? 'YUKARI' : 'AŞAĞI'}`,
    },
  ];

  const score = Math.round(weightedAvg(signals));
  const { action, color } = scoreToAction(score);
  const confidence = confidenceFromCount(
    signals.filter(s => s.score >= 58).length,
    signals.length
  );

  // Best opportunities
  const opportunities = [
    ...longReady.slice(0, 4).map(c => ({ ...c, type: 'LONG HAZIR' })),
    ...shortReady.slice(0, 3).map(c => ({ ...c, type: 'SHORT HAZIR' })),
    ...explosionReady.slice(0, 3).map(c => ({ ...c, type: 'PATLAMA' })),
  ];

  return {
    id: 'STRUCTURE',
    name: 'Yapı Konseyi',
    icon: '🏗',
    score,
    action,
    color,
    confidence,
    signals,
    highlights: {
      longReady:      longReady.slice(0, 6),
      shortReady:     shortReady.slice(0, 6),
      explosionReady: explosionReady.slice(0, 5),
      scalpLongs:     scalpLongs.slice(0, 4),
      scalpShorts:    scalpShorts.slice(0, 4),
      opportunities:  opportunities.slice(0, 8),
    },
    verdict: `${action} — ${longSignals} long | ${shortSignals} short | ${explosions} patlama fırsatı`,
  };
}

// ─── 4. FLOW COUNCIL ─────────────────────────────────────────────────────────
/**
 * Sorumluluk: Para akışı nasıl? Orderbook sağlıklı mı? Liq durumu?
 * Besleyen modüller:
 *   - liquiditySens (imbalance, wall)
 *   - btcStrong / btcWeak (para rotasyonu)
 *   - multiExchange (tüm borsalar pump/dump)
 */
export function runFlowCouncil(scanResults) {
  const {
    liquiditySens, btcStrong, btcWeak, multiExchange, enrichedCoins,
  } = scanResults;

  const buyBiased  = liquiditySens.filter(l => l.bias === 'ALIŞ').length;
  const sellBiased = liquiditySens.filter(l => l.bias === 'SATIŞ').length;
  const neutral    = liquiditySens.filter(l => l.bias === 'NÖTR').length;
  const totalLiq   = liquiditySens.length || 1;

  const flowBias   = buyBiased / totalLiq; // 0-1, yüksek = alıcı baskısı

  const multiPumps = multiExchange?.pumps?.length || 0;
  const multiDumps = multiExchange?.dumps?.length || 0;

  // Rotasyon: BTC'den alts'a para gidiyor mu?
  const rotation = btcStrong.length / (btcStrong.length + btcWeak.length + 1);

  const signals = [
    {
      label: 'Orderbook akışı',
      score: clamp(flowBias * 100),
      weight: 0.30,
      detail: `${buyBiased} alış | ${sellBiased} satış | ${neutral} nötr`,
    },
    {
      label: 'Para rotasyonu',
      score: clamp(50 + (btcStrong.length - btcWeak.length) * 5),
      weight: 0.25,
      detail: `Güçlü: ${btcStrong.length} | Zayıf: ${btcWeak.length}`,
    },
    {
      label: 'Multi-exchange akış',
      score: clamp(50 + (multiPumps - multiDumps) * 6),
      weight: 0.25,
      detail: `Tüm borsa: ${multiPumps} pump | ${multiDumps} dump`,
    },
    {
      label: 'Rotasyon yönü',
      score: clamp(rotation * 100),
      weight: 0.20,
      detail: rotation > 0.6 ? 'Para altcoinlere akıyor' : rotation < 0.4 ? 'Para BTC\'ye sığınıyor' : 'Dengeli rotasyon',
    },
  ];

  const score = Math.round(weightedAvg(signals));
  const { action, color } = scoreToAction(score);
  const confidence = confidenceFromCount(
    signals.filter(s => s.score >= 55).length,
    signals.length
  );

  return {
    id: 'FLOW',
    name: 'Akış Konseyi',
    icon: '🌊',
    score,
    action,
    color,
    confidence,
    signals,
    highlights: {
      buyBiasedCoins:  liquiditySens.filter(l => l.bias === 'ALIŞ').slice(0, 4),
      sellBiasedCoins: liquiditySens.filter(l => l.bias === 'SATIŞ').slice(0, 4),
      multiPumps:      multiExchange?.pumps?.slice(0, 5) || [],
      multiDumps:      multiExchange?.dumps?.slice(0, 5) || [],
      btcStrong:       btcStrong.slice(0, 5),
      btcWeak:         btcWeak.slice(0, 5),
    },
    verdict: `${action} — Orderbook ${flowBias > 0.55 ? 'ALICI' : flowBias < 0.45 ? 'SATICI' : 'DENGELİ'} baskısı`,
  };
}

// ─── FİNAL COUNCIL — 4 Konseyi birleştir ─────────────────────────────────────
/**
 * Ağırlıklar:
 *   STRUCTURE  35% — En kritik (doğru coin doğru zamanda)
 *   MOMENTUM   30% — Piyasa yönü
 *   FLOW       20% — Para akışı
 *   RISK       15% — Risk filtresi (TERS: yüksek risk = düşük nihai skor)
 */
export function runFinalCouncil(councils) {
  const { momentum, risk, structure, flow } = councils;

  // Risk konseyi ters: risk yüksekse final skoru düşür
  const riskPenalty = 100 - (risk?.score || 50); // 0-100, yüksek = ceza
  const riskAdjustedScore = clamp(
    structure.score * 0.35 +
    momentum.score  * 0.30 +
    flow.score       * 0.20 +
    (risk.score)     * 0.15  // Risk skoru yüksek = güvenli = iyi
  );

  const finalScore     = Math.round(riskAdjustedScore);
  const { action, color } = scoreToAction(finalScore);

  // Tüm konseyler aynı yönde mi? → Yüksek güven
  const bullishCount = [momentum, structure, flow].filter(c => c.score >= 55).length;
  const bearishCount = [momentum, structure, flow].filter(c => c.score <= 45).length;
  const alignment    = Math.max(bullishCount, bearishCount);
  const confidence   = clamp(Math.round(30 + alignment * 20 + (finalScore > 50 ? (finalScore - 50) : (50 - finalScore))));

  // Market bias
  const marketBias =
    finalScore >= 65 ? 'BULLISH' :
    finalScore >= 55 ? 'ZAYIF BULLISH' :
    finalScore <= 35 ? 'BEARISH' :
    finalScore <= 45 ? 'ZAYIF BEARISH' : 'NÖTR';

  const biasColor =
    finalScore >= 55 ? '#00ff88' :
    finalScore <= 45 ? '#ff3366' : '#ffcc00';

  // Council unanimity
  const votes = {
    bullish: [momentum, risk, structure, flow].filter(c => c.score >= 55).length,
    bearish: [momentum, risk, structure, flow].filter(c => c.score <= 45).length,
    neutral: [momentum, risk, structure, flow].filter(c => c.score > 45 && c.score < 55).length,
  };

  return {
    finalScore,
    action,
    color,
    confidence,
    marketBias,
    biasColor,
    votes,
    riskLevel: risk.riskLevel || 'ORTA',
    riskColor: risk.color || '#ffcc00',
    councils: { momentum, risk, structure, flow },
    summary: [
      `${[momentum, structure, flow].filter(c => c.score >= 55).length}/3 konseyden AL oyu`,
      `Risk: ${risk.riskLevel || 'ORTA'} | Güven: ${confidence}%`,
      `Momentum: ${momentum.action} | Yapı: ${structure.action}`,
      `Akış: ${flow.action} | Piyasa: ${marketBias}`,
    ],
    timestamp: Date.now(),
  };
}

// ─── ANA ÇALIŞTIRICI ─────────────────────────────────────────────────────────
export function runCouncils(scanResults) {
  const momentum  = runMomentumCouncil(scanResults);
  const risk      = runRiskCouncil(scanResults);
  const structure = runStructureCouncil(scanResults);
  const flow      = runFlowCouncil(scanResults);
  const final     = runFinalCouncil({ momentum, risk, structure, flow });

  return {
    momentum,
    risk,
    structure,
    flow,
    final,
  };
}
