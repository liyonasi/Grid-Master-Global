/**
 * councilAdvancedEngine.js — GMG v16
 * Gelişmiş Konsey Motorları:
 *   187. Crypto Specialist Council
 *   188. Forex Specialist Council
 *   189. Commodity Specialist Council
 *   190. Index Specialist Council
 *   195. Probability Engine (gelişmiş)
 *   197. Council Memory Engine
 */


// ─── SPECIALIST ENGINES ENTEGRASYONU ─────────────────────────────────────────
let _forexSpecialFn = null;
let _commoditySpecialFn = null;
try {
  const se = require("./specialistEngines");
  _forexSpecialFn     = se.runForexSpecialEngine;
  _commoditySpecialFn = se.runCommoditySpecialEngine;
} catch(e) { /* import edilemezse kendi iç fonksiyonlarla devam et */ }
const clamp = (v, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, v));

// ─── COUNCIL MEMORY ENGINE ────────────────────────────────────────────────────
const _councilHistory = {};
const MAX_HISTORY = 200;

export const CouncilMemoryEngine = {
  record({ councilId, action, score, actualOutcome = null, timestamp = Date.now() }) {
    if (!_councilHistory[councilId]) _councilHistory[councilId] = [];
    _councilHistory[councilId].push({ action, score, actualOutcome, timestamp, resolved: actualOutcome !== null });
    if (_councilHistory[councilId].length > MAX_HISTORY) _councilHistory[councilId].shift();
  },

  resolveOutcome(councilId, timestamp, actualOutcome) {
    const hist = _councilHistory[councilId] || [];
    const entry = hist.find(h => Math.abs(h.timestamp - timestamp) < 60000);
    if (entry) { entry.actualOutcome = actualOutcome; entry.resolved = true; }
  },

  getAccuracy(councilId) {
    const hist = (_councilHistory[councilId] || []).filter(h => h.resolved);
    if (!hist.length) return { accuracy: null, totalResolved: 0, message: 'Yeterli veri yok' };

    let correct = 0;
    hist.forEach(h => {
      if (h.action === 'BUY'  && h.actualOutcome === 'PROFIT') correct++;
      if (h.action === 'SELL' && h.actualOutcome === 'AVOIDED_LOSS') correct++;
      if (h.action === 'WAIT' && h.actualOutcome === 'CORRECT_WAIT') correct++;
    });

    const accuracy = correct / hist.length;
    return {
      accuracy: parseFloat((accuracy * 100).toFixed(1)),
      correct,
      total: hist.length,
      totalResolved: hist.length,
      trend: hist.slice(-10).filter(h => h.action === 'BUY' && h.actualOutcome === 'PROFIT').length,
    };
  },

  getWeightMultiplier(councilId) {
    const { accuracy } = this.getAccuracy(councilId);
    if (accuracy === null) return 1.0;
    // Doğruluk %70+ → ağırlık artar, %30- → azalır
    if (accuracy >= 70) return 1.2;
    if (accuracy >= 60) return 1.1;
    if (accuracy <= 30) return 0.7;
    if (accuracy <= 40) return 0.85;
    return 1.0;
  },

  getSummary() {
    return Object.entries(_councilHistory).map(([id, hist]) => ({
      councilId: id,
      totalDecisions: hist.length,
      ...this.getAccuracy(id),
      weightMultiplier: this.getWeightMultiplier(id),
    }));
  },

  // Son N kararı döndür
  getHistory(councilId = null, limit = 20) {
    if (councilId) {
      return (_councilHistory[councilId] || []).slice(-limit).reverse();
    }
    // Tüm konseylerin son kararlarını birleştir
    const all = Object.entries(_councilHistory).flatMap(([id, hist]) =>
      hist.map(h => ({ ...h, councilId: id }))
    );
    return all.sort((a, b) => b.timestamp - a.timestamp).slice(0, limit);
  },

  // Genel win rate (tüm konseyler)
  getWinRate() {
    const all = Object.values(_councilHistory).flat().filter(h => h.resolved);
    if (!all.length) return null;
    const correct = all.filter(h =>
      (h.action === 'BUY'  && h.actualOutcome === 'PROFIT') ||
      (h.action === 'SELL' && h.actualOutcome === 'AVOIDED_LOSS') ||
      (h.action === 'WAIT' && h.actualOutcome === 'CORRECT_WAIT')
    ).length;
    return parseFloat((correct / all.length * 100).toFixed(1));
  },

  // Karar sayısı özeti
  getStats() {
    const all = Object.values(_councilHistory).flat();
    const resolved = all.filter(h => h.resolved);
    return {
      total:      all.length,
      resolved:   resolved.length,
      pending:    all.length - resolved.length,
      winRate:    this.getWinRate(),
      councils:   Object.keys(_councilHistory).length,
      lastDecision: all.sort((a,b) => b.timestamp - a.timestamp)[0] || null,
    };
  },
};

// ─── CRYPTO SPECIALIST COUNCIL ────────────────────────────────────────────────
export function runCryptoSpecialistCouncil({
  btcDominance = 54,
  altSeasonIndex = 35,
  stablecoinDominance = 8,
  btcChange = 0,
  ethChange = 0,
  defiTVL = 0,
  fearGreedIndex = 50,
  cryptoTotalMarketCap = 0,
  etfInflow = 0,
  onchainActivity = 50,
} = {}) {
  let score = 50;
  const signals = [];

  // BTC dominans analizi
  if (btcDominance > 60) { score -= 10; signals.push('BTC hakimiyeti çok yüksek — alt zayıf'); }
  else if (btcDominance < 45) { score += 10; signals.push('Alt sezon potansiyeli'); }

  // Alt Sezon indeksi
  if (altSeasonIndex > 70) { score += 15; signals.push('Alt sezonu AKTİF'); }
  else if (altSeasonIndex < 25) { score -= 10; signals.push('BTC sezonu'); }

  // Stablecoin dominans
  if (stablecoinDominance > 12) { score -= 15; signals.push('Piyasadan çıkış var (stable yüksek)'); }
  else if (stablecoinDominance < 6) { score += 10; signals.push('Stable düşük — risk-on'); }

  // BTC hareketi
  if (btcChange > 3) { score += 15; signals.push('BTC güçlü — piyasa pozitif'); }
  else if (btcChange < -5) { score -= 20; signals.push('BTC büyük düşüş — risk azalt'); }

  // Fear & Greed
  if (fearGreedIndex > 75) { score -= 10; signals.push('Aşırı açgözlülük — dikkat'); }
  else if (fearGreedIndex < 25) { score += 15; signals.push('Aşırı korku — fırsat'); }

  // ETF akışı
  if (etfInflow > 1e8) { score += 12; signals.push(`ETF girişi: $${(etfInflow/1e6).toFixed(0)}M`); }
  else if (etfInflow < -1e8) { score -= 10; signals.push('ETF çıkışı'); }

  score = clamp(Math.round(score));
  const action = score >= 60 ? 'AL' : score <= 40 ? 'SAT' : 'BEKLE';

  return {
    councilId: 'CRYPTO_SPECIALIST',
    score,
    action,
    signals,
    btcDominance,
    altSeasonIndex,
    verdict: score >= 70 ? 'GÜÇLÜ KRIPTO ORTAMI' : score >= 55 ? 'POZİTİF' : score <= 35 ? 'ZAYIF' : 'NÖTR',
    timestamp: Date.now(),
  };
}

// ─── FOREX SPECIALIST COUNCIL ─────────────────────────────────────────────────
export function runForexSpecialistCouncil({
  dxyLevel = 104,
  dxyChange = 0,
  us10yYield = 4.3,
  fedTone = 'neutral',  // hawkish | neutral | dovish
  currencyStrengths = {},   // { USD: 75, EUR: 55, ... }
  carryTradeCondition = 'neutral',
  sessionActive = 'new_york',
} = {}) {
  let score = 50;
  const signals = [];

  // DXY etkisi (kripto ile ters korelasyon)
  if (dxyLevel > 108) { score -= 15; signals.push('DXY çok güçlü — kripto baskısı'); }
  else if (dxyLevel < 100) { score += 12; signals.push('DXY zayıf — kripto pozitif'); }

  if (dxyChange > 0.5) { score -= 8; signals.push('DXY yükselerek — dikkat'); }
  else if (dxyChange < -0.5) { score += 8; signals.push('DXY düşüyor — kripto için iyi'); }

  // Fed tonu
  if (fedTone === 'dovish') { score += 15; signals.push('Fed güvercin — risk-on'); }
  else if (fedTone === 'hawkish') { score -= 15; signals.push('Fed şahin — risk-off'); }

  // US10Y faizi
  if (us10yYield > 5) { score -= 12; signals.push('10Y faiz yüksek — risk-off'); }
  else if (us10yYield < 3.5) { score += 10; signals.push('10Y faiz düşük — risk-on'); }

  // Seans
  const sessionBonus = { new_york: 5, london: 3, london_new_york: 8, asia: -2 }[sessionActive] || 0;
  score += sessionBonus;

  score = clamp(Math.round(score));

  return {
    councilId: 'FOREX_SPECIALIST',
    score,
    action: score >= 58 ? 'AL' : score <= 42 ? 'SAT' : 'BEKLE',
    signals,
    dxyImpact: dxyLevel > 106 ? 'NEGATIF' : dxyLevel < 101 ? 'POZİTİF' : 'NÖTR',
    fedImpact: fedTone === 'dovish' ? 'POZİTİF' : fedTone === 'hawkish' ? 'NEGATİF' : 'NÖTR',
    timestamp: Date.now(),
  };
}

// ─── COMMODITY SPECIALIST COUNCIL ────────────────────────────────────────────
export function runCommoditySpecialistCouncil({
  goldPrice = 2000,
  goldChange = 0,
  oilPrice = 75,
  oilChange = 0,
  vixLevel = 20,
  inflationExpect = 2.5,
  riskAppetite = 'neutral',
} = {}) {
  let score = 50;
  const signals = [];

  // Altın hareketi (safe haven)
  if (goldChange > 1) { score -= 10; signals.push('Altın güçlü — risk-off ortam'); }
  else if (goldChange < -1) { score += 8; signals.push('Altın zayıf — risk-on'); }

  // VIX
  if (vixLevel > 30) { score -= 20; signals.push('VIX yüksek — piyasa korkulu'); }
  else if (vixLevel < 15) { score += 12; signals.push('VIX düşük — rahat ortam'); }
  else if (vixLevel < 20) { score += 5; }

  // Risk iştahı
  if (riskAppetite === 'risk_on')  { score += 15; signals.push('Risk-ON ortam'); }
  if (riskAppetite === 'risk_off') { score -= 15; signals.push('Risk-OFF ortam'); }

  // Petrol şoku
  if (oilChange > 5) { score -= 8; signals.push('Petrol spike — enflasyon riski'); }
  else if (oilChange < -5) { score += 5; signals.push('Petrol düşüyor — deflasyon baskısı'); }

  score = clamp(Math.round(score));

  return {
    councilId: 'COMMODITY_SPECIALIST',
    score,
    action: score >= 58 ? 'AL' : score <= 42 ? 'SAT' : 'BEKLE',
    signals,
    safeHavenFlow: goldChange > 0.5 ? 'AKTİF' : 'PASIF',
    vixRisk: vixLevel > 25 ? 'YÜKSEK' : vixLevel > 18 ? 'NORMAL' : 'DÜŞÜK',
    timestamp: Date.now(),
  };
}

// ─── INDEX SPECIALIST COUNCIL ─────────────────────────────────────────────────
export function runIndexSpecialistCouncil({
  sp500Change = 0,
  nasdaqChange = 0,
  globalIndexAvg = 0,
  institutionalFlow = 0,
  sectorRotation = 'tech',
  breadth = 0.6,  // Genişlik (0-1)
} = {}) {
  let score = 50;
  const signals = [];

  // S&P500 ve NASDAQ
  if (sp500Change > 1 && nasdaqChange > 1) { score += 15; signals.push('Hisse senetleri güçlü — risk iştahı yüksek'); }
  else if (sp500Change < -2) { score -= 15; signals.push('Endeks satışı — risk-off'); }

  // Kurumsal akış
  if (institutionalFlow > 0) { score += 8; signals.push('Kurumsal alım var'); }
  else if (institutionalFlow < 0) { score -= 8; signals.push('Kurumsal çıkış'); }

  // Piyasa genişliği
  if (breadth > 0.7) { score += 10; signals.push('Geniş tabanlı ralli'); }
  else if (breadth < 0.3) { score -= 10; signals.push('Dar tabanlı — güvenilmez'); }

  // Sektör rotasyonu
  if (sectorRotation === 'tech') { score += 5; signals.push('Teknoloji liderliği'); }
  if (sectorRotation === 'defensive') { score -= 5; signals.push('Defansif rotasyon — dikkat'); }

  score = clamp(Math.round(score));

  return {
    councilId: 'INDEX_SPECIALIST',
    score,
    action: score >= 58 ? 'AL' : score <= 42 ? 'SAT' : 'BEKLE',
    signals,
    equityRiskAppetite: sp500Change > 0.5 ? 'YÜKSEK' : sp500Change < -1 ? 'DÜŞÜK' : 'ORTA',
    timestamp: Date.now(),
  };
}

// ─── PROBABILITY ENGINE (gelişmiş) ───────────────────────────────────────────
export function runProbabilityEngine({
  councilScores = {},
  historicalAccuracy = {},
  marketCondition = 'normal',
  signalStrength = 0,
  riskScore = 50,
} = {}) {
  const councils = Object.entries(councilScores);
  if (!councils.length) return { buyProb: 0.33, sellProb: 0.33, waitProb: 0.34, confidence: 0 };

  // Ağırlıklı skor
  const weights = { alpha: 0.28, flow: 0.25, risk: 0.22, news: 0.12, asset: 0.13 };
  const accuracyWeights = Object.fromEntries(
    councils.map(([k]) => [k, historicalAccuracy[k] ? historicalAccuracy[k] / 100 : 1.0])
  );

  let weightedScore = 0, totalWeight = 0;
  councils.forEach(([k, v]) => {
    const w = (weights[k] || 0.1) * (accuracyWeights[k] || 1.0);
    weightedScore += v * w;
    totalWeight += w;
  });
  const avgScore = totalWeight > 0 ? weightedScore / totalWeight : 50;

  // Piyasa koşulu etkisi
  const mktMultiplier = { normal: 1.0, volatile: 0.8, trending: 1.1, choppy: 0.7 }[marketCondition] || 1.0;

  // Olasılıklar
  let buyProb = 0, sellProb = 0, waitProb = 0;
  if (avgScore >= 65) {
    buyProb  = clamp(0.3 + (avgScore - 65) * 0.02) * mktMultiplier;
    sellProb = clamp(0.1 + (100 - avgScore) * 0.005);
    waitProb = 1 - buyProb - sellProb;
  } else if (avgScore <= 35) {
    sellProb = clamp(0.3 + (35 - avgScore) * 0.02) * mktMultiplier;
    buyProb  = clamp(0.1 + avgScore * 0.005);
    waitProb = 1 - buyProb - sellProb;
  } else {
    waitProb = 0.5 + (0.5 - Math.abs(avgScore - 50) / 50) * 0.3;
    buyProb  = (1 - waitProb) * (avgScore / 100);
    sellProb = 1 - buyProb - waitProb;
  }

  // Normalize
  const total = buyProb + sellProb + waitProb;
  buyProb  = parseFloat((buyProb  / total).toFixed(3));
  sellProb = parseFloat((sellProb / total).toFixed(3));
  waitProb = parseFloat((1 - buyProb - sellProb).toFixed(3));

  // Güven skoru
  const maxProb = Math.max(buyProb, sellProb, waitProb);
  const confidence = parseFloat(((maxProb - 0.33) / 0.67 * 100).toFixed(1));

  const decision = buyProb > sellProb && buyProb > waitProb ? 'BUY'
    : sellProb > buyProb && sellProb > waitProb ? 'SELL'
    : 'WAIT';

  return {
    buyProb,
    sellProb,
    waitProb,
    confidence: clamp(confidence),
    decision,
    avgScore: parseFloat(avgScore.toFixed(1)),
    marketCondition,
    verdict: `${decision} — ${(maxProb * 100).toFixed(0)}% olasılık · Güven: ${clamp(confidence).toFixed(0)}%`,
    timestamp: Date.now(),
  };
}

// ─── SPECIALIST ENGINE ENTEGRASYON WRAPPER'LARI ───────────────────────────────
// runForexSpecialistCouncil ve runCommoditySpecialistCouncil'in üstüne bind edilir.
// specialistEngines.js varsa daha derin analiz; yoksa mevcut basit skor kullanılır.

export function runForexSpecialistFull(params = {}) {
  // 1. Mevcut internal council skoru
  const internal = runForexSpecialistCouncil(params);

  // 2. specialistEngines'den gelişmiş skor (varsa)
  let special = null;
  if (_forexSpecialFn) {
    try {
      special = _forexSpecialFn({
        interventionData: { dxyChange: params.dxyChange || 0 },
        rateData:         { usRate: 5.25, euRate: 4.5, jpRate: 0.1 },
        utcHour:          new Date().getUTCHours(),
        pairChanges:      params.pairChanges || {},
      });
    } catch(e) { /* specialist engine hatası — internal ile devam */ }
  }

  // 3. Birleştir: special varsa %40 ağırlık ver
  const finalScore = special
    ? Math.round(internal.score * 0.60 + special.score * 0.40)
    : internal.score;

  return {
    ...internal,
    score:       finalScore,
    action:      finalScore >= 58 ? 'AL' : finalScore <= 42 ? 'SAT' : 'BEKLE',
    specialData: special || null,
    enhanced:    !!special,
    summary:     special
      ? `${internal.summary || ''} | Seans:${special.modules?.sessionVol?.volLevel || '-'}`
      : internal.summary,
  };
}

export function runCommoditySpecialistFull(params = {}) {
  // 1. Internal skor
  const internal = runCommoditySpecialistCouncil(params);

  // 2. specialistEngines derinlemesine analiz
  let special = null;
  if (_commoditySpecialFn) {
    try {
      special = _commoditySpecialFn({
        metals:    { goldChange: params.goldChange || 0, silverChange: 0, goldLevel: params.goldPrice || 2000 },
        energy:    { naturalGasChange: 0, oilInventoryChange: 0 },
        opec:      { opecMeetingSoon: false, cutExpected: false, supplyChange: 0 },
        inflation: { cpiChange: 0, goldChange: params.goldChange || 0, btcChange7d: 0 },
      });
    } catch(e) { /* specialist engine hatası */ }
  }

  const finalScore = special
    ? Math.round(internal.score * 0.60 + special.score * 0.40)
    : internal.score;

  return {
    ...internal,
    score:       finalScore,
    action:      finalScore >= 58 ? 'AL' : finalScore <= 42 ? 'SAT' : 'BEKLE',
    specialData: special || null,
    enhanced:    !!special,
    summary:     special
      ? `${internal.summary || ''} | Metal:${special.modules?.metals?.summary || '-'}`
      : internal.summary,
  };
}
