/**
 * GRID MASTER GLOBAL — LIVE BRIDGE ENGINE v1
 * ============================================
 * Her coin için council sonuçlarını birleştirir ve
 * live_bridge_output.json formatında üretir.
 *
 * ÖZELLİKLER:
 *   - Tüm watchlist için toplu council sonucu
 *   - Panel entegrasyonu (Dashboard_v4.jsx)
 *   - Versiyon damgası + hash
 *   - Değişim delta'sı (önceki snapshot ile fark)
 *   - Kritik alarm sinyalleri
 */

import { clamp } from './engineCore.js';

// ─── TİP TANIMLARI (JSDoc) ────────────────────────────────────────────────────
/**
 * @typedef {object} CouncilResult
 * @property {string} symbol
 * @property {number} score
 * @property {string} action   — 'AL' | 'SAT' | 'BEKLE'
 * @property {string} verdict
 * @property {object} councils — { alpha, flow, risk, macro }
 * @property {boolean} approved
 * @property {string}  timestamp
 */

// ─── DURUM ────────────────────────────────────────────────────────────────────
let _lastOutput = null;
let _outputTs   = 0;
const _history  = []; // Son 10 snapshot

// ─── ONAY PROTOKOLÜ ─────────────────────────────────────────────────────────
/**
 * checkApprovalProtocol — 5 koşullu nihai onay
 */
function checkApprovalProtocol(councils, extraFlags = {}) {
  const { alpha = {}, flow = {}, risk = {}, macro = {} } = councils;
  const { exchangeAnomaly = false, liquidityMagnet = true } = extraFlags;

  const councilScores = [alpha.score ?? 50, flow.score ?? 50, risk.score ?? 50, macro.score ?? 50];
  const approvedCount = councilScores.filter(s => s >= 55).length;
  const riskVeto      = (risk.score ?? 50) < 40;
  const allScores     = councilScores.filter(s => s != null);
  const positiveRatio = allScores.filter(s => s >= 50).length / (allScores.length || 1);

  const conditions = {
    minCouncils:     approvedCount >= 3,
    riskNoVeto:      !riskVeto,
    modulePositive:  positiveRatio >= 0.75,
    noAnomaly:       !exchangeAnomaly,
    magnetGate:      liquidityMagnet,
  };

  const passCount = Object.values(conditions).filter(Boolean).length;
  const approved  = Object.values(conditions).every(Boolean);

  return {
    approved,
    passCount,
    totalConditions: 5,
    conditions,
    blockers: Object.entries(conditions)
      .filter(([, v]) => !v)
      .map(([k]) => k),
  };
}

// ─── TEKİL COIN SONUCU FORMATLA ──────────────────────────────────────────────
/**
 * formatCoinOutput — Bir coinin tüm sonuçlarını bridge formatına dönüştür
 */
export function formatCoinOutput(symbol, raw = {}) {
  const { price, change24h, councils = {}, extraFlags = {}, modules = {} } = raw;

  const alpha = councils.alpha || { score: 50 };
  const flow  = councils.flow  || { score: 50 };
  const risk  = councils.risk  || { score: 50 };
  const macro = councils.macro || { score: 50 };

  // Ağırlıklı ortalama
  const weightedScore = clamp(
    alpha.score * 0.28 +
    flow.score  * 0.28 +
    risk.score  * 0.22 +
    macro.score * 0.22
  );

  const approval = checkApprovalProtocol(councils, extraFlags);

  // Karar
  let action = 'BEKLE';
  if (approval.approved && weightedScore >= 65) action = 'AL';
  if (weightedScore <= 35)                       action = 'SAT';

  // Risk rengi
  const color = action === 'AL'  ? '#00ff88' :
                action === 'SAT' ? '#ff3366' : '#ffcc00';

  return {
    symbol,
    price:          price || null,
    change24h:      change24h != null ? parseFloat(change24h.toFixed(3)) : null,
    score:          parseFloat(weightedScore.toFixed(1)),
    action,
    color,
    approved:       approval.approved,
    approval,
    councils: {
      alpha: { score: alpha.score ?? 50, verdict: alpha.verdict ?? '—', signals: alpha.topSignals ?? [] },
      flow:  { score: flow.score  ?? 50, verdict: flow.verdict  ?? '—' },
      risk:  { score: risk.score  ?? 50, verdict: risk.verdict  ?? '—', warnings: risk.warnings ?? [] },
      macro: { score: macro.score ?? 50, verdict: macro.verdict ?? '—' },
    },
    extraFlags,
    moduleCount:    modules.total     || 95,
    modulePositive: modules.positive  || 0,
    timestamp:      new Date().toISOString(),
  };
}

// ─── TOPLU ÇIKTI ÜRET ────────────────────────────────────────────────────────
/**
 * generateBridgeOutput — Tüm semboller için bridge output üret
 *
 * @param {Array} coinResults — [{ symbol, price, councils, ... }]
 * @param {object} marketMeta — { btcDominance, totalMarketCap, fearGreed }
 */
export function generateBridgeOutput(coinResults = [], marketMeta = {}) {
  const coins = {};
  let   buySignals = 0, sellSignals = 0, waitSignals = 0;
  const criticalAlerts = [];

  for (const raw of coinResults) {
    const output = formatCoinOutput(raw.symbol, raw);
    coins[raw.symbol] = output;

    if (output.action === 'AL')   buySignals++;
    if (output.action === 'SAT')  sellSignals++;
    if (output.action === 'BEKLE') waitSignals++;

    // Kritik uyarılar
    if (raw.extraFlags?.exchangeAnomaly) {
      criticalAlerts.push({ type: 'EXCHANGE_ANOMALY', symbol: raw.symbol, message: `${raw.symbol}: Exchange anomali — Alım donduruldu` });
    }
    if (output.score >= 80 && output.approved) {
      criticalAlerts.push({ type: 'STRONG_BUY', symbol: raw.symbol, message: `${raw.symbol}: GÜÇLÜ AL sinyali (${output.score}/100)` });
    }
    if (output.score <= 20) {
      criticalAlerts.push({ type: 'STRONG_SELL', symbol: raw.symbol, message: `${raw.symbol}: GÜÇLÜ SAT sinyali (${output.score}/100)` });
    }
  }

  // Market özeti
  const marketSummary = {
    totalCoins:    coinResults.length,
    buySignals,
    sellSignals,
    waitSignals,
    bullishRatio:  coinResults.length ? parseFloat((buySignals / coinResults.length * 100).toFixed(1)) : 0,
    ...marketMeta,
  };

  // Genel piyasa durumu
  const marketState = marketSummary.bullishRatio >= 65 ? 'BOĞA' :
                      marketSummary.bullishRatio <= 35 ? 'AYI' : 'KARARSIZ';

  const output = {
    version:       'v4',
    generatedAt:   new Date().toISOString(),
    marketState,
    marketSummary,
    criticalAlerts: criticalAlerts.slice(0, 10),
    coins,
  };

  // Delta hesapla
  if (_lastOutput) {
    output.delta = computeDelta(_lastOutput, output);
  }

  // Snapshot geçmişe ekle
  _lastOutput = output;
  _outputTs   = Date.now();
  _history.push({ ts: _outputTs, marketState, buySignals, sellSignals });
  if (_history.length > 10) _history.shift();

  return output;
}

// ─── DELTA HESAPLA ────────────────────────────────────────────────────────────
function computeDelta(prev, curr) {
  const changed = [];

  for (const sym of Object.keys(curr.coins)) {
    const p = prev.coins?.[sym];
    const c = curr.coins[sym];
    if (!p) continue;

    if (p.action !== c.action) {
      changed.push({ symbol: sym, from: p.action, to: c.action, scoreDiff: c.score - p.score });
    }
  }

  return {
    actionChanges: changed,
    newSignals:    changed.length,
    marketStateChange: prev.marketState !== curr.marketState
      ? { from: prev.marketState, to: curr.marketState }
      : null,
  };
}

// ─── BRIDGE ÇIKTISINI PANE FORMATINA DÖNÜŞTÜR ────────────────────────────────
/**
 * bridgeToTableRows — Dashboard tablo satırlarına dönüştür
 */
export function bridgeToTableRows(bridgeOutput, sortBy = 'score') {
  if (!bridgeOutput?.coins) return [];

  const rows = Object.values(bridgeOutput.coins).map(c => ({
    symbol:      c.symbol,
    price:       c.price,
    change24h:   c.change24h,
    score:       c.score,
    action:      c.action,
    color:       c.color,
    approved:    c.approved,
    alpha:       c.councils.alpha.score,
    flow:        c.councils.flow.score,
    risk:        c.councils.risk.score,
    macro:       c.councils.macro.score,
    warnings:    c.councils.risk.warnings?.length || 0,
  }));

  // Sırala
  if (sortBy === 'score')   rows.sort((a, b) => b.score - a.score);
  if (sortBy === 'change')  rows.sort((a, b) => (b.change24h ?? 0) - (a.change24h ?? 0));
  if (sortBy === 'action')  rows.sort((a, b) => a.action.localeCompare(b.action));

  return rows;
}

// ─── SON OUTPUT & GEÇMİŞ ─────────────────────────────────────────────────────
export function getLastBridgeOutput()  { return _lastOutput; }
export function getBridgeHistory()     { return [..._history]; }
export function getBridgeAgeMs()       { return _outputTs ? Date.now() - _outputTs : null; }

/**
 * getSymbolFromBridge — Tek sembol sonucunu bridge'den çek
 */
export function getSymbolFromBridge(symbol) {
  return _lastOutput?.coins?.[symbol] || null;
}

// ─── DURUM RAPORU ─────────────────────────────────────────────────────────────
export function getBridgeStatus() {
  return {
    hasOutput:    !!_lastOutput,
    ageMs:        getBridgeAgeMs(),
    coinCount:    _lastOutput ? Object.keys(_lastOutput.coins).length : 0,
    marketState:  _lastOutput?.marketState || 'YOK',
    alerts:       _lastOutput?.criticalAlerts?.length || 0,
    history:      _history.length,
    timestamp:    new Date().toISOString(),
  };
}
