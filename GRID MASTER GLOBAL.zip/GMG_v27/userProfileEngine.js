/**
 * GRID MASTER GLOBAL — USER PROFILE ENGINE v1
 * =============================================
 * Kullanıcı izleme listesi, favori coinler, risk modu ve alarm tercihleri.
 *
 * DEPOLAMA: localStorage (tarayıcı) veya dışarıdan sağlanan storage adapter
 *
 * ÖZELLİKLER:
 *   - Watchlist (maksimum 50 sembol)
 *   - Favori coinler
 *   - Risk modu: AGGRESIF / NORMAL / MUHAFAZAKAR
 *   - Alarm eşikleri (fiyat, skor, değişim)
 *   - Oturum istatistikleri
 */

// ─── SABİTLER ────────────────────────────────────────────────────────────────
const STORAGE_KEY     = 'gmg_user_profile';
const MAX_WATCHLIST   = 50;
const MAX_FAVORITES   = 10;

export const RISK_MODES = {
  AGGRESIF:     { label: 'Agresif',     tpPct: 5,  slPct: 2,   minScore: 55, color: '#ff4444' },
  NORMAL:       { label: 'Normal',      tpPct: 3,  slPct: 1.5, minScore: 63, color: '#ffaa00' },
  MUHAFAZAKAR:  { label: 'Muhafazakâr', tpPct: 2,  slPct: 1,   minScore: 72, color: '#00cc88' },
};

// ─── VARSAYILAN PROFİL ────────────────────────────────────────────────────────
const DEFAULT_PROFILE = {
  watchlist:    ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT'],
  favorites:    ['BTCUSDT'],
  riskMode:     'NORMAL',
  alerts: {
    priceAlerts:    [],   // [{ symbol, price, direction:'above'|'below', active }]
    scoreAlerts:    [],   // [{ symbol, minScore, active }]
    changeAlerts:   [],   // [{ symbol, changePct, timeframe, active }]
  },
  settings: {
    defaultInterval:   '4h',
    defaultExchange:   'binance',
    notifications:     true,
    soundAlerts:       false,
    darkMode:          true,
    language:          'tr',
    autoRefreshSec:    30,
  },
  stats: {
    sessionsCount:     0,
    totalAlertsTriggered: 0,
    favoriteCoinsAdded: 0,
    createdAt:         null,
  },
};

// ─── DEPOLAMA ADAPTÖRÜ ────────────────────────────────────────────────────────
// localStorage fallback: bellek içi depo (SSR veya sandbox ortamları için)
const _memStore = {};

const storage = {
  get: (key) => {
    try { return JSON.parse(localStorage.getItem(key)); }
    catch { return _memStore[key] ?? null; }
  },
  set: (key, val) => {
    try { localStorage.setItem(key, JSON.stringify(val)); }
    catch { _memStore[key] = val; }
  },
};

// ─── PROFİL YÜKLEYİCİ ─────────────────────────────────────────────────────────
function loadProfile() {
  const saved = storage.get(STORAGE_KEY);
  if (!saved) return { ...DEFAULT_PROFILE, stats: { ...DEFAULT_PROFILE.stats, createdAt: new Date().toISOString() } };
  // Deep merge: kayıp alanları varsayılanla doldur
  return {
    ...DEFAULT_PROFILE,
    ...saved,
    alerts:   { ...DEFAULT_PROFILE.alerts,   ...saved.alerts },
    settings: { ...DEFAULT_PROFILE.settings, ...saved.settings },
    stats:    { ...DEFAULT_PROFILE.stats,    ...saved.stats },
  };
}

function saveProfile(profile) {
  storage.set(STORAGE_KEY, profile);
  return profile;
}

// ─── PROFİL NESNE ────────────────────────────────────────────────────────────
let _profile = loadProfile();

/**
 * getProfile — Mevcut profili döndür
 */
export function getProfile() {
  return { ..._profile };
}

/**
 * resetProfile — Profili sıfırla
 */
export function resetProfile() {
  _profile = { ...DEFAULT_PROFILE, stats: { ...DEFAULT_PROFILE.stats, createdAt: new Date().toISOString() } };
  saveProfile(_profile);
  return _profile;
}

// ─── WATCHLIST ────────────────────────────────────────────────────────────────
/**
 * addToWatchlist — Sembol ekle
 */
export function addToWatchlist(symbol) {
  const sym = symbol.toUpperCase();
  if (_profile.watchlist.includes(sym)) return { success: false, reason: 'Zaten listede' };
  if (_profile.watchlist.length >= MAX_WATCHLIST) return { success: false, reason: `Maksimum ${MAX_WATCHLIST} sembol` };

  _profile.watchlist.push(sym);
  saveProfile(_profile);
  return { success: true, watchlist: _profile.watchlist };
}

/**
 * removeFromWatchlist — Sembol çıkar
 */
export function removeFromWatchlist(symbol) {
  const sym = symbol.toUpperCase();
  _profile.watchlist = _profile.watchlist.filter(s => s !== sym);
  // Favorilerden de çıkar
  _profile.favorites = _profile.favorites.filter(s => s !== sym);
  saveProfile(_profile);
  return { success: true, watchlist: _profile.watchlist };
}

/**
 * getWatchlist — Güncel watchlist döndür
 */
export function getWatchlist() {
  return [..._profile.watchlist];
}

// ─── FAVORİLER ───────────────────────────────────────────────────────────────
/**
 * addFavorite — Favoriye ekle
 */
export function addFavorite(symbol) {
  const sym = symbol.toUpperCase();
  if (!_profile.watchlist.includes(sym)) addToWatchlist(sym); // Önce watchlist'e ekle
  if (_profile.favorites.includes(sym)) return { success: false, reason: 'Zaten favoride' };
  if (_profile.favorites.length >= MAX_FAVORITES) return { success: false, reason: `Maksimum ${MAX_FAVORITES} favori` };

  _profile.favorites.push(sym);
  _profile.stats.favoriteCoinsAdded++;
  saveProfile(_profile);
  return { success: true, favorites: _profile.favorites };
}

/**
 * removeFavorite — Favoriden çıkar
 */
export function removeFavorite(symbol) {
  const sym = symbol.toUpperCase();
  _profile.favorites = _profile.favorites.filter(s => s !== sym);
  saveProfile(_profile);
  return { success: true, favorites: _profile.favorites };
}

// ─── RİSK MODU ───────────────────────────────────────────────────────────────
/**
 * setRiskMode — Risk modunu değiştir
 */
export function setRiskMode(mode) {
  if (!RISK_MODES[mode]) return { success: false, reason: `Geçersiz mod: ${mode}` };
  _profile.riskMode = mode;
  saveProfile(_profile);
  return { success: true, riskMode: mode, config: RISK_MODES[mode] };
}

/**
 * getRiskConfig — Aktif risk modunun konfigürasyonunu döndür
 */
export function getRiskConfig() {
  return RISK_MODES[_profile.riskMode] || RISK_MODES.NORMAL;
}

// ─── ALARM SİSTEMİ ───────────────────────────────────────────────────────────
/**
 * addPriceAlert — Fiyat alarmı ekle
 */
export function addPriceAlert({ symbol, price, direction = 'above' }) {
  const alert = { id: Date.now(), symbol: symbol.toUpperCase(), price, direction, active: true, createdAt: new Date().toISOString() };
  _profile.alerts.priceAlerts.push(alert);
  saveProfile(_profile);
  return { success: true, alert };
}

/**
 * addScoreAlert — Konsey skoru alarmı ekle
 */
export function addScoreAlert({ symbol, minScore = 70 }) {
  const alert = { id: Date.now(), symbol: symbol.toUpperCase(), minScore, active: true, createdAt: new Date().toISOString() };
  _profile.alerts.scoreAlerts.push(alert);
  saveProfile(_profile);
  return { success: true, alert };
}

/**
 * addChangeAlert — Yüzdelik değişim alarmı ekle
 */
export function addChangeAlert({ symbol, changePct = 5, timeframe = '1h' }) {
  const alert = { id: Date.now(), symbol: symbol.toUpperCase(), changePct, timeframe, active: true, createdAt: new Date().toISOString() };
  _profile.alerts.changeAlerts.push(alert);
  saveProfile(_profile);
  return { success: true, alert };
}

/**
 * removeAlert — Alarm kaldır (id bazlı)
 */
export function removeAlert(alertId) {
  _profile.alerts.priceAlerts  = _profile.alerts.priceAlerts.filter(a => a.id !== alertId);
  _profile.alerts.scoreAlerts  = _profile.alerts.scoreAlerts.filter(a => a.id !== alertId);
  _profile.alerts.changeAlerts = _profile.alerts.changeAlerts.filter(a => a.id !== alertId);
  saveProfile(_profile);
  return { success: true };
}

/**
 * checkAlerts — Mevcut piyasa verisiyle alarmları kontrol et
 *
 * @param {object} marketData — { symbol, price, score, change1h }
 */
export function checkAlerts({ symbol, price, score, change1h = 0 }) {
  const sym       = symbol?.toUpperCase();
  const triggered = [];

  // Fiyat alarmları
  for (const a of _profile.alerts.priceAlerts) {
    if (!a.active || a.symbol !== sym) continue;
    const hit = (a.direction === 'above' && price >= a.price) ||
                (a.direction === 'below' && price <= a.price);
    if (hit) {
      triggered.push({ type: 'PRICE', alert: a, message: `${sym}: Fiyat $${price} hedef $${a.price} (${a.direction})` });
      a.active = false; // Bir kez tetikle
    }
  }

  // Skor alarmları
  for (const a of _profile.alerts.scoreAlerts) {
    if (!a.active || a.symbol !== sym) continue;
    if (score >= a.minScore) {
      triggered.push({ type: 'SCORE', alert: a, message: `${sym}: Council skoru ${score} ≥ hedef ${a.minScore}` });
      a.active = false;
    }
  }

  // Değişim alarmları
  for (const a of _profile.alerts.changeAlerts) {
    if (!a.active || a.symbol !== sym) continue;
    if (Math.abs(change1h) >= a.changePct) {
      triggered.push({ type: 'CHANGE', alert: a, message: `${sym}: ${change1h >= 0 ? '+' : ''}${change1h.toFixed(2)}% değişim tetiklendi` });
      a.active = false;
    }
  }

  if (triggered.length) {
    _profile.stats.totalAlertsTriggered += triggered.length;
    saveProfile(_profile);
  }

  return triggered;
}

// ─── AYARLAR ─────────────────────────────────────────────────────────────────
/**
 * updateSettings — Kullanıcı ayarlarını güncelle
 */
export function updateSettings(partial = {}) {
  _profile.settings = { ..._profile.settings, ...partial };
  saveProfile(_profile);
  return _profile.settings;
}

/**
 * getSettings — Ayarları döndür
 */
export function getSettings() {
  return { ..._profile.settings };
}

// ─── OTURUM İSTATİSTİKLERİ ───────────────────────────────────────────────────
/**
 * recordSession — Yeni oturum kaydet
 */
export function recordSession() {
  _profile.stats.sessionsCount++;
  saveProfile(_profile);
}

/**
 * getStats — İstatistikleri döndür
 */
export function getStats() {
  return { ..._profile.stats };
}

// ─── PROFİL ÖZET ─────────────────────────────────────────────────────────────
/**
 * getProfileSummary — Dashboard için kısa özet
 */
export function getProfileSummary() {
  const rm = RISK_MODES[_profile.riskMode];
  return {
    watchlistCount:   _profile.watchlist.length,
    favoritesCount:   _profile.favorites.length,
    riskMode:         _profile.riskMode,
    riskLabel:        rm?.label || 'Normal',
    riskColor:        rm?.color || '#ffaa00',
    activeAlerts:     [
      ..._profile.alerts.priceAlerts,
      ..._profile.alerts.scoreAlerts,
      ..._profile.alerts.changeAlerts,
    ].filter(a => a.active).length,
    settings:         _profile.settings,
    score:            50, // Profil motoru skora ihtiyaç duymaz
    summary:          `${_profile.watchlist.length} sembol | Risk: ${rm?.label} | ${_profile.favorites.length} favori`,
    timestamp:        new Date().toISOString(),
  };
}
