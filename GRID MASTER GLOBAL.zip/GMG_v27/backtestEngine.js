/**
 * GMG — BACKTESTING ENGINE
 * =========================
 * Geçmiş veride sistem performansını test eder.
 * pineEngine sinyallerini geçmiş klines üzerinde çalıştırır.
 */
import { runPineEngine } from './pineEngine.js';

const clamp = (v, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, v));

/**
 * Tek bir klines dizisi üzerinde backtest çalıştır.
 * @param {array}  klines     — OHLCV dizisi
 * @param {object} params     — pineEngine parametreleri
 * @param {object} config     — { tp1Mult, tp2Mult, slMult, initialCapital, positionSizePct }
 */
export function runBacktest(klines, params = {}, config = {}) {
  const {
    tp1Mult        = 1.0,
    tp2Mult        = 2.0,
    slMult         = 1.0,
    initialCapital = 10000,
    positionSizePct = 10,   // Her işlemde sermayenin %10'u
    minBars        = 50,
  } = config;

  if (!klines || klines.length < minBars + 30) {
    return { error: 'Yeterli veri yok', trades: [], stats: null };
  }

  const trades   = [];
  let capital    = initialCapital;
  let peak       = initialCapital;
  let maxDD      = 0;
  let inTrade    = false;
  let tradeEntry = null;

  // Her mum için sinyal üret
  for (let i = 30; i < klines.length - 1; i++) {
    const slice = klines.slice(0, i + 1);
    let pineData;
    try { pineData = runPineEngine(slice, params); } catch { continue; }
    if (!pineData) continue;

    const cur     = klines[i].c;
    const atr     = pineData.atrV || cur * 0.02;
    const signals = pineData.signals;

    // Mevcut işlem takibi
    if (inTrade && tradeEntry) {
      const { direction, entry, tp1, tp2, sl } = tradeEntry;
      const high = klines[i].h || cur;
      const low  = klines[i].l  || cur;

      let exitPrice = null, exitReason = null;

      if (direction === 'LONG') {
        if (low <= sl)   { exitPrice = sl;  exitReason = 'SL'; }
        else if (high >= tp2) { exitPrice = tp2; exitReason = 'TP2'; }
        else if (high >= tp1) { exitPrice = tp1; exitReason = 'TP1'; }
      } else {
        if (high >= sl)  { exitPrice = sl;  exitReason = 'SL'; }
        else if (low <= tp2) { exitPrice = tp2; exitReason = 'TP2'; }
        else if (low <= tp1) { exitPrice = tp1; exitReason = 'TP1'; }
      }

      if (exitPrice && exitReason) {
        const posSize  = capital * (positionSizePct / 100);
        const pnlPct   = direction === 'LONG'
          ? (exitPrice - entry) / entry
          : (entry - exitPrice) / entry;
        const pnl      = posSize * pnlPct;
        capital       += pnl;
        peak           = Math.max(peak, capital);
        maxDD          = Math.max(maxDD, (peak - capital) / peak * 100);

        // entryTime/exitTime: numeric timestamp tercih edilir (TradesTable tarih kolonunu açar)
        // klines[].ts varsa kullan, yoksa klines[].t (string) fallback
        const entryKline = klines[tradeEntry.entryBar];
        const exitKline  = klines[i];
        const entryTime  = entryKline?.ts ?? entryKline?.timestamp ?? entryKline?.t ?? null;
        const exitTime   = exitKline?.ts  ?? exitKline?.timestamp  ?? exitKline?.t  ?? null;

        trades.push({
          direction, entry,
          exitPrice,        // TradesTable için (eskisi 'exit' idi — ikisi de korunuyor)
          exit: exitPrice,  // geri uyumluluk
          exitReason,
          pnlPct:    parseFloat((pnlPct * 100).toFixed(2)),
          pnl:       parseFloat(pnl.toFixed(2)),
          capital:   parseFloat(capital.toFixed(2)),
          barsHeld:  i - tradeEntry.entryBar,  // TradesTable 'barsHeld' bekliyor
          bars:      i - tradeEntry.entryBar,  // geri uyumluluk
          entryTime,   // timestamp → TradesTable tarih kolonunu açar
          exitTime,
        });
        inTrade = false; tradeEntry = null;
      }
    }

    // Yeni sinyal
    if (!inTrade) {
      if (signals?.longSignal) {
        inTrade    = true;
        tradeEntry = {
          direction: 'LONG',
          entry:     cur,
          tp1:       cur + atr * tp1Mult,
          tp2:       cur + atr * tp2Mult,
          sl:        cur - atr * slMult,
          entryBar:  i,
        };
      } else if (signals?.shortSignal) {
        inTrade    = true;
        tradeEntry = {
          direction: 'SHORT',
          entry:     cur,
          tp1:       cur - atr * tp1Mult,
          tp2:       cur - atr * tp2Mult,
          sl:        cur + atr * slMult,
          entryBar:  i,
        };
      }
    }
  }

  // İstatistikler
  if (trades.length === 0) return { error: 'Sinyal üretilmedi', trades: [], stats: null };

  const wins     = trades.filter(t => t.pnl > 0);
  const losses   = trades.filter(t => t.pnl <= 0);
  const winRate  = Math.round(wins.length / trades.length * 100);
  const totalPnl = trades.reduce((s, t) => s + t.pnl, 0);
  const avgWin   = wins.length   ? wins.reduce((s,t)   => s + t.pnlPct, 0) / wins.length   : 0;
  const avgLoss  = losses.length ? losses.reduce((s,t) => s + t.pnlPct, 0) / losses.length : 0;
  const profitFactor = losses.reduce((s,t) => s + Math.abs(t.pnl), 0) > 0
    ? wins.reduce((s,t) => s + t.pnl, 0) / Math.abs(losses.reduce((s,t) => s + t.pnl, 0))
    : 999;
  const roi      = ((capital - initialCapital) / initialCapital * 100);
  const avgBars  = Math.round(trades.reduce((s,t) => s + t.bars, 0) / trades.length);

  return {
    trades,
    stats: {
      totalTrades:  trades.length,
      wins:         wins.length,
      losses:       losses.length,
      winRate,
      totalPnl:     parseFloat(totalPnl.toFixed(2)),
      roi:          parseFloat(roi.toFixed(2)),
      maxDrawdown:  parseFloat(maxDD.toFixed(2)),
      profitFactor: parseFloat(profitFactor.toFixed(2)),
      avgWin:       parseFloat(avgWin.toFixed(2)),
      avgLoss:      parseFloat(avgLoss.toFixed(2)),
      avgBars,
      finalCapital: parseFloat(capital.toFixed(2)),
      initialCapital,
    },
    summary: `${trades.length} işlem | Kazanma: %${winRate} | ROI: %${roi.toFixed(1)} | MaxDD: %${maxDD.toFixed(1)} | PF: ${profitFactor.toFixed(2)}`,
    timestamp: Date.now(),
  };
}

/**
 * Çoklu periyot backtest
 */
export function runMultiPeriodBacktest(klines, params = {}, config = {}) {
  const n = klines.length;
  const periods = [
    { label: '1 Ay',  bars: Math.min(n, 1440)  },
    { label: '3 Ay',  bars: Math.min(n, 4320)  },
    { label: '6 Ay',  bars: Math.min(n, 8640)  },
    { label: '1 Yıl', bars: Math.min(n, 17520) },
  ].filter(p => p.bars >= 80);

  const results = {};
  for (const p of periods) {
    const slice = klines.slice(-p.bars);
    results[p.label] = runBacktest(slice, params, config);
  }

  return { periods: results, timestamp: Date.now() };
}
