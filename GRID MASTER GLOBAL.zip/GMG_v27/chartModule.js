/**
 * GRID MASTER GLOBAL — CHART MODULE
 * ====================================
 * Grafik formasyonları, mum analizi, tarihsel eşleşme,
 * destek/direnç ve Market Maker yön tahmini.
 * Bu modül ALPHA COUNCIL'a bağlıdır.
 */

// ─── MUM FORMASYONLARI ────────────────────────────────────────────────────────

export const CANDLE_PATTERNS = {
  DOJI:              { name: 'Doji',             bias: 'nötr',    strength: 0.5, description: 'Kararsızlık, dönüş olabilir' },
  HAMMER:            { name: 'Çekiç',            bias: 'bullish', strength: 0.8, description: 'Düşüşten dönüş sinyali' },
  SHOOTING_STAR:     { name: 'Yıldız',           bias: 'bearish', strength: 0.8, description: 'Yükselişten dönüş sinyali' },
  ENGULFING_BULL:    { name: 'Yutan (Boğa)',     bias: 'bullish', strength: 0.9, description: 'Güçlü boğa tersine dönüş' },
  ENGULFING_BEAR:    { name: 'Yutan (Ayı)',      bias: 'bearish', strength: 0.9, description: 'Güçlü ayı tersine dönüş' },
  MORNING_STAR:      { name: 'Sabah Yıldızı',   bias: 'bullish', strength: 0.9, description: 'Üç mumlu güçlü dönüş' },
  EVENING_STAR:      { name: 'Akşam Yıldızı',   bias: 'bearish', strength: 0.9, description: 'Üç mumlu güçlü dönüş' },
  MARUBOZU_BULL:     { name: 'Marubozu (Boğa)', bias: 'bullish', strength: 0.7, description: 'Tam kontrol boğada' },
  MARUBOZU_BEAR:     { name: 'Marubozu (Ayı)',  bias: 'bearish', strength: 0.7, description: 'Tam kontrol ayıda' },
  PIN_BAR_BULL:      { name: 'Pin Bar (Alt)',    bias: 'bullish', strength: 0.85, description: 'Reddedilen düşük fiyat' },
  PIN_BAR_BEAR:      { name: 'Pin Bar (Üst)',    bias: 'bearish', strength: 0.85, description: 'Reddedilen yüksek fiyat' },
  INSIDE_BAR:        { name: 'İçe Bar',         bias: 'nötr',    strength: 0.6, description: 'Sıkışma, büyük hareket yakın' },
  SPINNING_TOP:      { name: 'Dönen Tepe',      bias: 'nötr',    strength: 0.4, description: 'Küçük gövde, yönü belirsiz' },
  THREE_WHITE_SOL:   { name: 'Üç Asker (Boğa)', bias: 'bullish', strength: 0.85, description: 'Güçlü yükseliş momentum' },
  THREE_BLACK_CROW:  { name: 'Üç Karga (Ayı)',  bias: 'bearish', strength: 0.85, description: 'Güçlü düşüş momentum' },
};

// ─── GRAFİK FORMASYONLARI ─────────────────────────────────────────────────────

export const CHART_FORMATIONS = {
  HEAD_SHOULDERS:    { name: 'Omuz-Baş-Omuz',     bias: 'bearish', reliability: 0.85, target_mult: 1.0 },
  INV_HEAD_SHOULDERS:{ name: 'Ters OBO',           bias: 'bullish', reliability: 0.85, target_mult: 1.0 },
  DOUBLE_TOP:        { name: 'Çift Tepe',          bias: 'bearish', reliability: 0.80, target_mult: 0.9 },
  DOUBLE_BOTTOM:     { name: 'Çift Dip',           bias: 'bullish', reliability: 0.80, target_mult: 0.9 },
  TRIPLE_TOP:        { name: 'Üçlü Tepe',          bias: 'bearish', reliability: 0.82, target_mult: 0.95 },
  TRIPLE_BOTTOM:     { name: 'Üçlü Dip',           bias: 'bullish', reliability: 0.82, target_mult: 0.95 },
  ASCENDING_TRIANGLE:{ name: 'Yükselen Üçgen',     bias: 'bullish', reliability: 0.75, target_mult: 0.8 },
  DESCENDING_TRIANGLE:{ name: 'Alçalan Üçgen',     bias: 'bearish', reliability: 0.75, target_mult: 0.8 },
  SYMMETRICAL_TRI:   { name: 'Simetrik Üçgen',     bias: 'nötr',    reliability: 0.65, target_mult: 0.7 },
  BULL_FLAG:         { name: 'Boğa Bayrağı',       bias: 'bullish', reliability: 0.78, target_mult: 0.9 },
  BEAR_FLAG:         { name: 'Ayı Bayrağı',        bias: 'bearish', reliability: 0.78, target_mult: 0.9 },
  BULL_PENNANT:      { name: 'Boğa Flaması',       bias: 'bullish', reliability: 0.72, target_mult: 0.8 },
  BEAR_PENNANT:      { name: 'Ayı Flaması',        bias: 'bearish', reliability: 0.72, target_mult: 0.8 },
  CUP_HANDLE:        { name: 'Fincan-Kulp',        bias: 'bullish', reliability: 0.80, target_mult: 1.0 },
  RISING_WEDGE:      { name: 'Yükselen Kama',      bias: 'bearish', reliability: 0.73, target_mult: 0.85 },
  FALLING_WEDGE:     { name: 'Alçalan Kama',       bias: 'bullish', reliability: 0.73, target_mult: 0.85 },
  RECTANGLE:         { name: 'Dikdörtgen',         bias: 'nötr',    reliability: 0.65, target_mult: 0.7 },
};

// ─── YARDIMCILAR ──────────────────────────────────────────────────────────────

function localMax(prices, i, window = 3) {
  for (let j = Math.max(0, i - window); j <= Math.min(prices.length - 1, i + window); j++) {
    if (j !== i && prices[j] >= prices[i]) return false;
  }
  return true;
}
function localMin(prices, i, window = 3) {
  for (let j = Math.max(0, i - window); j <= Math.min(prices.length - 1, i + window); j++) {
    if (j !== i && prices[j] <= prices[i]) return false;
  }
  return true;
}

// ─── MUM FORMASYON TESPİTİ ────────────────────────────────────────────────────

export function detectCandlePatterns(klines) {
  if (!klines || klines.length < 3) return [];
  const found = [];

  for (let i = 2; i < klines.length; i++) {
    const c  = klines[i];
    const p  = klines[i - 1];
    const pp = klines[i - 2];
    if (!c || !p || !pp) continue;

    const cO = c.open || c.price, cH = c.high || c.price, cL = c.low || c.price, cC = c.price;
    const pO = p.open || p.price, pH = p.high || p.price, pL = p.low || p.price, pC = p.price;
    const ppC = pp.price;

    const cBody = Math.abs(cC - cO);
    const cRange = cH - cL || 0.0001;
    const pBody = Math.abs(pC - pO);
    const pRange = pH - pL || 0.0001;

    // DOJI
    if (cBody / cRange < 0.1 && cRange > 0) {
      found.push({ pattern: 'DOJI', index: i, price: cC, time: c.time });
    }
    // HAMMER (düşüşte)
    if (cC > cO && (cC - cO) < (cO - cL) * 0.4 && (cH - cC) < cBody * 0.3 && pC < ppC) {
      found.push({ pattern: 'HAMMER', index: i, price: cC, time: c.time });
    }
    // SHOOTING STAR (yükselişte)
    if (cO > cC && (cH - cO) > (cO - cC) * 2 && (cC - cL) < cBody * 0.3 && pC > ppC) {
      found.push({ pattern: 'SHOOTING_STAR', index: i, price: cC, time: c.time });
    }
    // ENGULFING BULL
    if (pC < pO && cC > cO && cO < pC && cC > pO) {
      found.push({ pattern: 'ENGULFING_BULL', index: i, price: cC, time: c.time });
    }
    // ENGULFING BEAR
    if (pC > pO && cC < cO && cO > pC && cC < pO) {
      found.push({ pattern: 'ENGULFING_BEAR', index: i, price: cC, time: c.time });
    }
    // PIN BAR BULL
    if ((cO - cL) > cRange * 0.6 && cBody < cRange * 0.3) {
      found.push({ pattern: 'PIN_BAR_BULL', index: i, price: cC, time: c.time });
    }
    // PIN BAR BEAR
    if ((cH - cO) > cRange * 0.6 && cBody < cRange * 0.3) {
      found.push({ pattern: 'PIN_BAR_BEAR', index: i, price: cC, time: c.time });
    }
    // MARUBOZU BULL
    if (cC > cO && cBody / cRange > 0.9) {
      found.push({ pattern: 'MARUBOZU_BULL', index: i, price: cC, time: c.time });
    }
    // MARUBOZU BEAR
    if (cC < cO && cBody / cRange > 0.9) {
      found.push({ pattern: 'MARUBOZU_BEAR', index: i, price: cC, time: c.time });
    }
    // INSIDE BAR
    if (cH < pH && cL > pL) {
      found.push({ pattern: 'INSIDE_BAR', index: i, price: cC, time: c.time });
    }
    // THREE WHITE SOLDIERS
    if (i >= 2 && cC > cO && pC > pO && ppC > (pp.open || ppC) && cC > pC && pC > ppC) {
      found.push({ pattern: 'THREE_WHITE_SOL', index: i, price: cC, time: c.time });
    }
    // THREE BLACK CROWS
    if (i >= 2 && cC < cO && pC < pO && ppC < (pp.open || ppC) && cC < pC && pC < ppC) {
      found.push({ pattern: 'THREE_BLACK_CROW', index: i, price: cC, time: c.time });
    }
  }
  return found;
}

// ─── GRAFİK FORMASYON TESPİTİ ─────────────────────────────────────────────────

export function detectChartFormations(klines) {
  if (!klines || klines.length < 20) return [];
  const prices = klines.map(k => k.price);
  const highs  = klines.map(k => k.high  || k.price);
  const lows   = klines.map(k => k.low   || k.price);
  const n = prices.length;
  const found = [];

  // Swing points
  const swingH = [], swingL = [];
  for (let i = 3; i < n - 3; i++) {
    if (localMax(highs, i, 3)) swingH.push({ idx: i, price: highs[i] });
    if (localMin(lows,  i, 3)) swingL.push({ idx: i, price: lows[i] });
  }

  // DOUBLE TOP
  if (swingH.length >= 2) {
    const last = swingH[swingH.length - 1], prev = swingH[swingH.length - 2];
    const diff = Math.abs(last.price - prev.price) / prev.price;
    if (diff < 0.025 && last.idx - prev.idx > 5) {
      const neck = Math.min(...lows.slice(prev.idx, last.idx));
      found.push({
        pattern: 'DOUBLE_TOP', confidence: 0.80 - diff * 10,
        neckline: neck, target: neck - (prev.price - neck),
        description: `Çift tepe @ ${prev.price.toFixed(2)} & ${last.price.toFixed(2)}`,
      });
    }
  }

  // DOUBLE BOTTOM
  if (swingL.length >= 2) {
    const last = swingL[swingL.length - 1], prev = swingL[swingL.length - 2];
    const diff = Math.abs(last.price - prev.price) / prev.price;
    if (diff < 0.025 && last.idx - prev.idx > 5) {
      const neck = Math.max(...highs.slice(prev.idx, last.idx));
      found.push({
        pattern: 'DOUBLE_BOTTOM', confidence: 0.80 - diff * 10,
        neckline: neck, target: neck + (neck - prev.price),
        description: `Çift dip @ ${prev.price.toFixed(2)} & ${last.price.toFixed(2)}`,
      });
    }
  }

  // HEAD AND SHOULDERS
  if (swingH.length >= 3) {
    const [ls, h, rs] = swingH.slice(-3);
    if (h.price > ls.price && h.price > rs.price &&
        Math.abs(ls.price - rs.price) / ls.price < 0.04) {
      const neck = (lows[ls.idx] + lows[rs.idx]) / 2;
      found.push({
        pattern: 'HEAD_SHOULDERS', confidence: 0.85,
        neckline: neck, target: neck - (h.price - neck),
        description: `OBO: L@${ls.price.toFixed(2)} H@${h.price.toFixed(2)} R@${rs.price.toFixed(2)}`,
      });
    }
  }

  // ASCENDING TRIANGLE (higher lows, flat highs)
  if (swingH.length >= 2 && swingL.length >= 2) {
    const topFlat  = Math.abs(swingH[swingH.length-1].price - swingH[swingH.length-2].price) / swingH[swingH.length-1].price < 0.02;
    const risingLow = swingL[swingL.length-1].price > swingL[swingL.length-2].price;
    if (topFlat && risingLow) {
      found.push({
        pattern: 'ASCENDING_TRIANGLE', confidence: 0.75,
        resistance: swingH[swingH.length-1].price,
        target: swingH[swingH.length-1].price + (swingH[swingH.length-1].price - swingL[swingL.length-1].price),
        description: 'Yükselen üçgen — yukarı kırılım beklentisi',
      });
    }
  }

  // BULL FLAG (sharp rise + consolidation)
  if (n > 15) {
    const pole    = prices.slice(-20, -8);
    const flag    = prices.slice(-8);
    const poleRise = (Math.max(...pole) - Math.min(...pole.slice(0,3))) / Math.min(...pole.slice(0,3));
    const flagRange = (Math.max(...flag) - Math.min(...flag)) / Math.max(...flag);
    if (poleRise > 0.03 && flagRange < 0.02 && pole[pole.length-1] > pole[0]) {
      found.push({
        pattern: 'BULL_FLAG', confidence: 0.78,
        target: prices[n-1] * (1 + poleRise * 0.8),
        description: `Boğa bayrağı — Direk: +${(poleRise*100).toFixed(1)}%`,
      });
    }
  }

  return found;
}

// ─── TARİHSEL EŞLEŞME (Pattern Similarity) ───────────────────────────────────

export function findHistoricalMatch(klines, windowSize = 20) {
  if (!klines || klines.length < windowSize * 3) return null;
  const prices = klines.map(k => k.price);
  const n = prices.length;

  // Normalize current window
  const currentWindow = prices.slice(-windowSize);
  const cMin = Math.min(...currentWindow), cMax = Math.max(...currentWindow);
  const cRange = cMax - cMin || 1;
  const cNorm = currentWindow.map(p => (p - cMin) / cRange);

  let bestMatch = null, bestSim = 0;

  // Slide through history (skip last 2 windows to avoid self-match)
  for (let i = 0; i <= n - windowSize * 3; i++) {
    const window = prices.slice(i, i + windowSize);
    const wMin = Math.min(...window), wMax = Math.max(...window);
    const wRange = wMax - wMin || 1;
    const wNorm = window.map(p => (p - wMin) / wRange);

    // Cosine-like similarity
    let dot = 0, magA = 0, magB = 0;
    for (let j = 0; j < windowSize; j++) {
      dot  += cNorm[j] * wNorm[j];
      magA += cNorm[j] * cNorm[j];
      magB += wNorm[j] * wNorm[j];
    }
    const sim = dot / (Math.sqrt(magA) * Math.sqrt(magB) + 0.0001);

    if (sim > bestSim && sim > 0.85) {
      bestSim = sim;
      // What happened AFTER this historical match?
      const futureWindow = prices.slice(i + windowSize, i + windowSize + Math.floor(windowSize / 2));
      const futureChange = futureWindow.length > 0
        ? (futureWindow[futureWindow.length - 1] - window[window.length - 1]) / window[window.length - 1] * 100
        : 0;

      bestMatch = {
        similarity: parseFloat(sim.toFixed(3)),
        historyIndex: i,
        historyTime: klines[i]?.time || null,
        futureChange: parseFloat(futureChange.toFixed(2)),
        direction: futureChange > 0.5 ? 'YUKARI' : futureChange < -0.5 ? 'AŞAĞI' : 'YATAY',
        confidence: parseFloat((sim * 100).toFixed(1)),
        description: `Benzer formasyon ${Math.round((n - i) / 60)} saat önce oluştu`,
      };
    }
  }

  return bestMatch;
}

// ─── DESTEK / DİRENÇ ─────────────────────────────────────────────────────────

export function detectSupportResistance(klines, levels = 5) {
  if (!klines || klines.length < 20) return { supports: [], resistances: [] };
  const highs  = klines.map(k => k.high  || k.price);
  const lows   = klines.map(k => k.low   || k.price);
  const current = klines[klines.length - 1].price;

  // Cluster nearby swing highs/lows
  const allSwingH = [], allSwingL = [];
  for (let i = 3; i < klines.length - 3; i++) {
    if (localMax(highs, i)) allSwingH.push(highs[i]);
    if (localMin(lows, i))  allSwingL.push(lows[i]);
  }

  // Cluster into zones (merge if within 0.5%)
  function cluster(arr) {
    const sorted = [...arr].sort((a, b) => a - b);
    const zones = [];
    for (const price of sorted) {
      const existing = zones.find(z => Math.abs(z.price - price) / price < 0.005);
      if (existing) { existing.touches++; existing.price = (existing.price + price) / 2; }
      else zones.push({ price, touches: 1 });
    }
    return zones.sort((a, b) => b.touches - a.touches).slice(0, levels);
  }

  const resistances = cluster(allSwingH.filter(h => h > current))
    .map(z => ({ ...z, distance: parseFloat(((z.price - current) / current * 100).toFixed(2)) }));
  const supports = cluster(allSwingL.filter(l => l < current))
    .map(z => ({ ...z, distance: parseFloat(((current - z.price) / current * 100).toFixed(2)) }));

  return {
    supports:    supports.sort((a, b) => a.distance - b.distance),
    resistances: resistances.sort((a, b) => a.distance - b.distance),
  };
}

// ─── MARKET MAKER YÖN TAHMİNİ ────────────────────────────────────────────────
/**
 * Market maker nereye sürüyor?
 * Kriter: Büyük wick + düşük hacim rally/dump + orderbook duvarı arkasında akümülasyon
 */
export function marketMakerDirectionEstimate({
  klines, orderbook, formations, candlePatterns, srLevels,
}) {
  if (!klines || klines.length < 10) return null;

  const prices  = klines.map(k => k.price);
  const highs   = klines.map(k => k.high  || k.price);
  const lows    = klines.map(k => k.low   || k.price);
  const volumes = klines.map(k => k.volume || 0);
  const n = prices.length;
  const current = prices[n - 1];

  // 1. Wick asymmetry — büyük wick altında = MM aşağı basiyor ama toplanıyor (bull)
  const recentWickUp  = highs.slice(-5).map((h, i) => h - prices.slice(-5)[i]);
  const recentWickDn  = lows.slice(-5).map((l, i)  => prices.slice(-5)[i] - l);
  const avgWickUp  = recentWickUp.reduce((a, b) => a + b, 0) / 5;
  const avgWickDn  = recentWickDn.reduce((a, b) => a + b, 0) / 5;
  const wickBias   = avgWickDn > avgWickUp * 1.5 ? 'BULLISH_SWEEP' :
                     avgWickUp > avgWickDn * 1.5 ? 'BEARISH_SWEEP' : 'NEUTRAL';

  // 2. Volume on direction
  const upVolume  = klines.slice(-10).filter(k => k.price >= (k.open || k.price)).reduce((s, k) => s + (k.volume || 0), 0);
  const downVolume = klines.slice(-10).filter(k => k.price < (k.open || k.price)).reduce((s, k) => s + (k.volume || 0), 0);
  const volumeBias = upVolume > downVolume * 1.3 ? 'BULLISH' : downVolume > upVolume * 1.3 ? 'BEARISH' : 'NEUTRAL';

  // 3. Nearest liquidity pool (stop clusters above/below)
  const nearResistance = srLevels?.resistances?.[0];
  const nearSupport    = srLevels?.supports?.[0];
  const liqTarget = nearResistance && nearSupport
    ? (nearResistance.distance < nearSupport.distance ? 'YUKARI' : 'AŞAĞI')
    : null;

  // 4. Formation bias
  const formBias = formations.reduce((acc, f) => {
    const meta = CHART_FORMATIONS[f.pattern];
    if (!meta) return acc;
    return acc + (meta.bias === 'bullish' ? 1 : meta.bias === 'bearish' ? -1 : 0);
  }, 0);

  // 5. Orderbook imbalance
  let obBias = 'NEUTRAL';
  if (orderbook?.bids && orderbook?.asks) {
    const bidVol = orderbook.bids.slice(0, 10).reduce((s, b) => s + b.amount * b.price, 0);
    const askVol = orderbook.asks.slice(0, 10).reduce((s, a) => s + a.amount * a.price, 0);
    obBias = bidVol > askVol * 1.2 ? 'BULLISH' : askVol > bidVol * 1.2 ? 'BEARISH' : 'NEUTRAL';
  }

  // Aggregate
  let bullScore = 0, bearScore = 0;
  if (wickBias === 'BULLISH_SWEEP') bullScore += 2;
  else if (wickBias === 'BEARISH_SWEEP') bearScore += 2;
  if (volumeBias === 'BULLISH') bullScore += 2;
  else if (volumeBias === 'BEARISH') bearScore += 2;
  if (obBias === 'BULLISH') bullScore += 2;
  else if (obBias === 'BEARISH') bearScore += 2;
  if (liqTarget === 'YUKARI') bullScore += 1;
  else if (liqTarget === 'AŞAĞI') bearScore += 1;
  bullScore += Math.max(0, formBias);
  bearScore += Math.max(0, -formBias);

  const totalScore = bullScore + bearScore || 1;
  const bullPct = Math.round((bullScore / totalScore) * 100);
  const direction = bullPct >= 60 ? 'YUKARI' : bullPct <= 40 ? 'AŞAĞI' : 'YATAY';
  const dirColor  = direction === 'YUKARI' ? '#00ff88' : direction === 'AŞAĞI' ? '#ff3366' : '#ffcc00';
  const confidence = Math.abs(bullPct - 50) * 2;

  // Liquidity target
  const liqTargetPrice = direction === 'YUKARI'
    ? nearResistance?.price
    : direction === 'AŞAĞI'
    ? nearSupport?.price
    : null;

  return {
    direction,
    dirColor,
    bullPct,
    bearPct: 100 - bullPct,
    confidence: parseFloat(confidence.toFixed(1)),
    liqTargetPrice: liqTargetPrice ? parseFloat(liqTargetPrice.toFixed(6)) : null,
    liqTargetDist: liqTargetPrice
      ? parseFloat(Math.abs((liqTargetPrice - current) / current * 100).toFixed(2))
      : null,
    wickBias, volumeBias, obBias,
    nearResistance: nearResistance?.price || null,
    nearSupport:    nearSupport?.price    || null,
    summary: `MM yönü: ${direction} (${bullPct}% güven) | Liq hedef: ${
      liqTargetPrice ? `$${liqTargetPrice.toFixed(2)} (${liqTargetPrice > current ? '+' : ''}${
        liqTargetPrice && current ? ((liqTargetPrice - current)/current*100).toFixed(2) : '?'}%)` : '—'
    }`,
  };
}

// ─── ANA CHART MODÜLÜ ÇALIŞTIRICI ─────────────────────────────────────────────

export function runChartModule({ klines, orderbook, timeframe = '1m' }) {
  if (!klines || klines.length < 5) return null;

  const candlePatterns = detectCandlePatterns(klines);
  const formations     = detectChartFormations(klines);
  const historicalMatch = findHistoricalMatch(klines);
  const srLevels       = detectSupportResistance(klines);
  const mmEstimate     = marketMakerDirectionEstimate({
    klines, orderbook, formations, candlePatterns, srLevels,
  });

  // Son formasyonlar (son 5 mum)
  const recentCandles = candlePatterns.filter(p => p.index >= klines.length - 5);

  // Alpha Council'a gidecek sinyal paketi
  const alphaSignal = {
    score: mmEstimate
      ? (mmEstimate.direction === 'YUKARI' ? 50 + mmEstimate.confidence / 2
         : mmEstimate.direction === 'AŞAĞI' ? 50 - mmEstimate.confidence / 2
         : 50)
      : 50,
    bias: mmEstimate?.direction || 'YATAY',
    confidence: mmEstimate?.confidence || 0,
  };

  return {
    timeframe,
    candlePatterns,
    recentCandles,
    formations,
    historicalMatch,
    srLevels,
    mmEstimate,
    alphaSignal,
    timestamp: Date.now(),
  };
}
