# GMG ACCEPTANCE CHECKLIST v17
## Tarih: 2026-03-17

## ✅ TAMAMLANAN
- [x] masterCouncil.js — 9 advanced motor import + entegre edildi
- [x] executionLayer.js — trapScore + wickManip + panicNews veto eklendi
- [x] Dashboard_v4.jsx — riskMode state + RiskModeSelector toggle
- [x] Dashboard_v4.jsx — scalpEngine + accumulationEngine + trapScore çağrıları
- [x] LiveAICouncilPanel.jsx — 6. konsey (specialist) + advanced uyarılar
- [x] specialistEngines.js — 8 eksik modül yazıldı
- [x] jsonOutputEngine.js — tüm JSON çıktıları üretiliyor
- [x] docs/system_audit.md — sistem audit raporu

## ⚠️ KISMİ / DEGRADED
- [ ] infraEngine → masterCouncil: import eklendi, initInfra() çağrılıyor ama LoggingEngine null-safe gerekiyor
- [ ] specialistEngines.js → councilAdvancedEngine: henüz councilAdvancedEngine'e import edilmedi
- [ ] jsonOutputEngine → Dashboard: Dashboard'a import edilmedi, generateAll() çağrılmıyor

## ❌ SONRAKI OTURUMDA

### YÜKSEK ÖNCELİK
1. jsonOutputEngine → Dashboard entegrasyonu
   - runIntelligenceScan sonrası jsonOutputEngine.generateAll() çağır
   - Çıktılar state'e yaz → panellere dağıt

2. specialistEngines → councilAdvancedEngine entegrasyonu
   - runForexSpecialistCouncil içine runForexSpecialEngine() çağır
   - runCommoditySpecialistCouncil içine runCommoditySpecialEngine() çağır

3. infraEngine null-safe düzeltme
   - initInfra() her zaman geçerli obje dönsün
   - LoggingEngine.log() try-catch ile sarıl

### ORTA ÖNCELİK
4. TrapScore Widget — GMGChart veya Dashboard'da görsel gösterim
5. CouncilMemory Panel — Geçmiş karar başarı oranı
6. onchainEngine → Dashboard entegrasyonu
7. etfFlowEngine → MarketIntelPanel'e yeni sekme
8. socialSentimentEngine → canlı data (Twitter API gerekiyor)
9. listingMonitorEngine → HeatmapGrid'e yeni listing badge

### DÜŞÜK ÖNCELİK
10. BacktestPanel UI tamamlama
11. Telegram bot webhook entegrasyonu
12. Email alert sistemi
13. User watchlist localStorage

## MODÜL SAYIMI
Mevcut: ~185/235 (%79)
Bu oturumda eklendi: ~8 yeni modül
Kalan: ~50 modül bağlantı/entegrasyon
