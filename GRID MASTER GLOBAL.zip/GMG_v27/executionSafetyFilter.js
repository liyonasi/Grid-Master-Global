/**
 * GRID MASTER GLOBAL — EXECUTION SAFETY FILTER v1
 * =================================================
 * Nihai AL/SAT kararından önce son güvenlik kontrollerini yapar.
 * Yanlış giriş yapılmasını engelleyen 12 katmanlı güvenlik filtresi.
 *
 * KATMANLAR:
 *   1.  Council veto kontrolü
 *   2.  Exchange anomali bloğu
 *   3.  BTC şok bloğu
 *   4.  Likidite tuzağı tespiti
 *   5.  Stop hunt aktif mi?
 *   6.  Spread (slippage) kontrolü
 *   7.  Volatilite aşımı filtresi
 *   8.  Makro olay penceresi
 *   9.  Zaman dilimi çelişkisi
 *   10. Minimum skor kapısı (risk moduna göre)
 *   11. Duplicate sinyal filtresi (aynı sinyal tekrar mı?)
 *   12. Son giriş süresi (overtrading koruması)
 *
 * ÇIKTI:
 *   { allowed: boolean, blockers: [], warnings: [], safetyScore: 0-100 }
 */

import { clamp } from './engineCore.js';

// ─── DURUM ────────────────────────────────────────────────────────────────────
const _lastSignalTs = new Map(); // symbol → son sinyal timestamp
const _signalHistory = [];       // Son 20 sinyal kaydı

// ─── KATEGORİ AĞIRLIKLARI ────────────────────────────────────────────────────
const BLOCKER_WEIGHTS = {
  COUNCIL_VETO:       100, // Mutlak engel
  EXCHANGE_ANOMALY:   100, // Mutlak engel
  BTC_SHOCK:          90,  // Kritik engel
  LIQUIDITY_TRAP:     85,  // Kritik engel
  STOP_HUNT_ACTIVE:   80,
  SPREAD_TOO_HIGH:    70,
  VOLATILITY_EXTREME: 65,
  MACRO_EVENT_WINDOW: 60,
  TIMEFRAME_CONFLICT: 55,
  BELOW_MIN_SCORE:    50,
  DUPLICATE_SIGNAL:   40,
  OVERTRADING:        35,
};

// ─── KATMAN 1: COUNCIL VETO ───────────────────────────────────────────────────
function checkCouncilVeto({ councilScores = {}, action = 'AL' }) {
  const { risk = 50 } = councilScores;

  if (action === 'AL' && risk < 35) {
    return { blocked: true, reason: 'COUNCIL_VETO', message: `Risk Konseyi VETO etti (${risk}/100 < 35)` };
  }
  return { blocked: false };
}

// ─── KATMAN 2: EXCHANGE ANOMALİ ──────────────────────────────────────────────
function checkExchangeAnomaly({ exchangeAnomaly = false, frozenSymbols = [] }, symbol) {
  if (exchangeAnomaly || frozenSymbols.includes(symbol)) {
    return { blocked: true, reason: 'EXCHANGE_ANOMALY', message: `${symbol}: Exchange anomali — Borsa manipülasyonu tespit edildi` };
  }
  return { blocked: false };
}

// ─── KATMAN 3: BTC ŞOK ───────────────────────────────────────────────────────
function checkBTCShock({ btcShockActive = false, btcCrashPct = 0, action = 'AL' }) {
  if (action === 'AL' && btcShockActive) {
    return { blocked: true, reason: 'BTC_SHOCK', message: `BTC şoku aktif (${btcCrashPct?.toFixed(1)}%) — AL sinyali engellendi` };
  }
  return { blocked: false };
}

// ─── KATMAN 4: LİKİDİTE TUZAĞI ───────────────────────────────────────────────
function checkLiquidityTrap({ liquidityTrapScore = 0, liquidityMagnetGate = true }) {
  if (!liquidityMagnetGate) {
    return { blocked: true, reason: 'LIQUIDITY_TRAP', message: 'Likidite Mıknatısı Kapısı geçilmedi — Giriş yasaklandı' };
  }
  if (liquidityTrapScore >= 80) {
    return { blocked: true, reason: 'LIQUIDITY_TRAP', message: `Likidite tuzağı skoru çok yüksek (${liquidityTrapScore})` };
  }
  return { blocked: false };
}

// ─── KATMAN 5: STOP HUNT ──────────────────────────────────────────────────────
function checkStopHunt({ stopHuntRisk = 0, stopHuntPhase = null }) {
  const dangerPhases = ['PHASE_1_APPROACH', 'FAKE_RESET', 'PHASE_2_LOADING'];
  if (dangerPhases.includes(stopHuntPhase)) {
    return {
      blocked: stopHuntPhase === 'FAKE_RESET', // Sadece FAKE_RESET'te engelle
      reason:  'STOP_HUNT_ACTIVE',
      message: `Stop hunt fazı: ${stopHuntPhase} — ${stopHuntPhase === 'FAKE_RESET' ? 'BLOKE' : 'UYARI'}`,
    };
  }
  if (stopHuntRisk >= 75) {
    return { blocked: true, reason: 'STOP_HUNT_ACTIVE', message: `Stop hunt riski çok yüksek (%${stopHuntRisk})` };
  }
  return { blocked: false };
}

// ─── KATMAN 6: SPREAD (SLİPPAGE) KONTROLÜ ────────────────────────────────────
function checkSpread({ spreadPct = 0, maxSpreadPct = 0.15 }) {
  if (spreadPct > maxSpreadPct) {
    return { blocked: true, reason: 'SPREAD_TOO_HIGH', message: `Spread çok yüksek (%${spreadPct?.toFixed(3)}) — Slippage riski` };
  }
  return { blocked: false };
}

// ─── KATMAN 7: VOLATİLİTE AŞIMI ──────────────────────────────────────────────
function checkVolatility({ volRegime = 'NORMAL', atrPct = 0 }) {
  if (volRegime === 'EXTREME' || atrPct > 8) {
    return { blocked: true, reason: 'VOLATILITY_EXTREME', message: `Aşırı volatilite (${volRegime}, ATR=%${atrPct?.toFixed(1)}) — SL hesaplamak güç` };
  }
  return { blocked: false };
}

// ─── KATMAN 8: MAKRO OLAY PENCERESİ ─────────────────────────────────────────
function checkMacroWindow({ macroEventActive = false, macroEventName = '', minutesUntilEvent = 999 }) {
  if (macroEventActive || minutesUntilEvent <= 15) {
    return { blocked: true, reason: 'MACRO_EVENT_WINDOW', message: `Makro olay yakın: ${macroEventName} (${minutesUntilEvent}dk kaldı)` };
  }
  return { blocked: false };
}

// ─── KATMAN 9: ZAMAN DİLİMİ ÇELİŞKİSİ ───────────────────────────────────────
function checkTimeframeConflict({ timeframeAlignment = 'PARTIAL', action = 'AL' }) {
  if (timeframeAlignment === 'CONFLICT') {
    return {
      blocked: false, // Bloke etmez, sadece uyarı
      warn:    true,
      reason:  'TIMEFRAME_CONFLICT',
      message: 'Zaman dilimi çelişkisi — Yüksek zaman dilimini kontrol et',
    };
  }
  return { blocked: false };
}

// ─── KATMAN 10: MİNİMUM SKOR KAPISI ─────────────────────────────────────────
function checkMinScore({ finalScore = 50, riskMode = 'NORMAL', action = 'AL' }) {
  const minScores = { AGGRESIF: 55, NORMAL: 63, MUHAFAZAKAR: 72 };
  const minScore  = minScores[riskMode] || 63;

  if (action === 'AL' && finalScore < minScore) {
    return { blocked: true, reason: 'BELOW_MIN_SCORE', message: `Skor (${finalScore}) < ${riskMode} modu eşiği (${minScore})` };
  }
  return { blocked: false };
}

// ─── KATMAN 11: DUPLICATE SİNYAL ─────────────────────────────────────────────
function checkDuplicateSignal(symbol, action, score) {
  const recent = _signalHistory.filter(
    s => s.symbol === symbol && s.action === action && Date.now() - s.ts < 5 * 60 * 1000 // Son 5dk
  );
  if (recent.length >= 2) {
    return { blocked: false, warn: true, reason: 'DUPLICATE_SIGNAL', message: `Son 5dk içinde ${recent.length}x aynı sinyal — Teyit et` };
  }
  return { blocked: false };
}

// ─── KATMAN 12: OVERTRADING KORUMASI ─────────────────────────────────────────
function checkOvertrading(symbol, minIntervalSec = 300) {
  const last = _lastSignalTs.get(symbol);
  if (last && Date.now() - last < minIntervalSec * 1000) {
    const waitSec = Math.round((minIntervalSec * 1000 - (Date.now() - last)) / 1000);
    return { blocked: false, warn: true, reason: 'OVERTRADING', message: `${symbol} için ${waitSec}sn daha bekle (overtrading koruması)` };
  }
  return { blocked: false };
}

// ─── ANA FİLTRE ──────────────────────────────────────────────────────────────
/**
 * runExecutionSafetyFilter — 12 katmanlı güvenlik kontrolü
 *
 * @param {object} params
 *   symbol             — Sembol
 *   action             — 'AL' | 'SAT' | 'BEKLE'
 *   finalScore         — Council nihai skoru
 *   councilScores      — { alpha, flow, risk, macro }
 *   exchangeAnomaly    — boolean
 *   btcShockActive     — boolean
 *   btcCrashPct        — number
 *   liquidityTrapScore — 0-100
 *   liquidityMagnetGate — boolean
 *   stopHuntRisk       — 0-100
 *   stopHuntPhase      — string | null
 *   spreadPct          — number
 *   volRegime          — string
 *   atrPct             — number
 *   macroEventActive   — boolean
 *   macroEventName     — string
 *   minutesUntilEvent  — number
 *   timeframeAlignment — string
 *   riskMode           — string
 */
export function runExecutionSafetyFilter(params = {}) {
  const {
    symbol             = 'BTCUSDT',
    action             = 'AL',
    finalScore         = 50,
    councilScores      = {},
    exchangeAnomaly    = false,
    frozenSymbols      = [],
    btcShockActive     = false,
    btcCrashPct        = 0,
    liquidityTrapScore = 0,
    liquidityMagnetGate = true,
    stopHuntRisk       = 0,
    stopHuntPhase      = null,
    spreadPct          = 0,
    maxSpreadPct       = 0.15,
    volRegime          = 'NORMAL',
    atrPct             = 0,
    macroEventActive   = false,
    macroEventName     = '',
    minutesUntilEvent  = 999,
    timeframeAlignment = 'PARTIAL',
    riskMode           = 'NORMAL',
  } = params;

  const blockers  = [];
  const warnings  = [];

  // 12 katman çalıştır
  const checks = [
    checkCouncilVeto({ councilScores, action }),
    checkExchangeAnomaly({ exchangeAnomaly, frozenSymbols }, symbol),
    checkBTCShock({ btcShockActive, btcCrashPct, action }),
    checkLiquidityTrap({ liquidityTrapScore, liquidityMagnetGate }),
    checkStopHunt({ stopHuntRisk, stopHuntPhase }),
    checkSpread({ spreadPct, maxSpreadPct }),
    checkVolatility({ volRegime, atrPct }),
    checkMacroWindow({ macroEventActive, macroEventName, minutesUntilEvent }),
    checkTimeframeConflict({ timeframeAlignment, action }),
    checkMinScore({ finalScore, riskMode, action }),
    checkDuplicateSignal(symbol, action, finalScore),
    checkOvertrading(symbol),
  ];

  for (const check of checks) {
    if (check.blocked) blockers.push({ reason: check.reason, message: check.message });
    if (check.warn)    warnings.push({ reason: check.reason, message: check.message });
  }

  const allowed = blockers.length === 0 && action !== 'BEKLE';

  // Güvenlik skoru (ne kadar "temiz" bir set-up)
  const blockWeight = blockers.reduce((a, b) => a + (BLOCKER_WEIGHTS[b.reason] || 50), 0);
  const warnWeight  = warnings.reduce((a, w) => a + (BLOCKER_WEIGHTS[w.reason] || 30) * 0.3, 0);
  const safetyScore = clamp(100 - blockWeight * 0.5 - warnWeight);

  // Sonucu kaydet
  if (allowed) {
    _lastSignalTs.set(symbol, Date.now());
    _signalHistory.push({ symbol, action, score: finalScore, ts: Date.now() });
    if (_signalHistory.length > 20) _signalHistory.shift();
  }

  return {
    allowed,
    safetyScore:  parseFloat(safetyScore.toFixed(1)),
    blockers,
    warnings,
    blockerCount: blockers.length,
    warningCount: warnings.length,
    primaryBlocker: blockers[0]?.message || null,
    verdict:      allowed ? '✅ ONAYLANDI — Giriş güvenli'
                          : `❌ BLOKE (${blockers.length} engel): ${blockers[0]?.message || ''}`,
    summary:      allowed
      ? `Güvenlik geçildi (${safetyScore}/100) — ${action} sinyali onaylı`
      : `Engellendi: ${blockers.map(b => b.reason).join(', ')}`,
    timestamp:    new Date().toISOString(),
  };
}

// ─── YARDımcı ─────────────────────────────────────────────────────────────────
/**
 * getFilterStatus — Son sinyal geçmişi ve durum
 */
export function getFilterStatus() {
  return {
    recentSignals: _signalHistory.slice(-5),
    activeBlocks:  [..._lastSignalTs.entries()].map(([sym, ts]) => ({
      symbol: sym,
      lastSignal: new Date(ts).toISOString(),
      ageSec: Math.round((Date.now() - ts) / 1000),
    })),
    timestamp: new Date().toISOString(),
  };
}

/**
 * resetFilterState — Filtre durumunu sıfırla (test için)
 */
export function resetFilterState(symbol = null) {
  if (symbol) { _lastSignalTs.delete(symbol); }
  else        { _lastSignalTs.clear(); _signalHistory.splice(0); }
}
