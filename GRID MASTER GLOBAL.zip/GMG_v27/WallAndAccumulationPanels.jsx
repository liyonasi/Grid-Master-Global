/**
 * LiquidityWallPanel.jsx — Buy/Sell Wall görsel panel
 */
import React, { useMemo } from 'react';

export function LiquidityWallPanel({ orderbook, symbol }) {
  const analysis = useMemo(() => {
    if (!orderbook?.bids?.length || !orderbook?.asks?.length) return null;
    const bids = orderbook.bids.slice(0, 20);
    const asks = orderbook.asks.slice(0, 20);
    const maxBidV = Math.max(...bids.map(b => b.amount * b.price));
    const maxAskV = Math.max(...asks.map(a => a.amount * a.price));
    const maxV = Math.max(maxBidV, maxAskV, 1);
    const totalBid = bids.reduce((s, b) => s + b.amount * b.price, 0);
    const totalAsk = asks.reduce((s, a) => s + a.amount * a.price, 0);
    const imbal = Math.round(totalBid / (totalBid + totalAsk) * 100);
    const bigBids = bids.filter(b => b.amount * b.price > maxV * 0.35);
    const bigAsks = asks.filter(a => a.amount * a.price > maxV * 0.35);
    return { bids, asks, maxV, totalBid, totalAsk, imbal, bigBids, bigAsks };
  }, [orderbook]);

  if (!analysis) return (
    <div style={{ padding: 24, textAlign: 'center', color: '#404070', fontSize: 10, fontFamily: 'monospace' }}>
      Orderbook bekleniyor...
    </div>
  );

  const { bids, asks, maxV, imbal, bigBids, bigAsks } = analysis;
  const fmt = v => v > 1e6 ? (v/1e6).toFixed(2)+'M' : v > 1e3 ? (v/1e3).toFixed(1)+'K' : Math.round(v)+'';
  const fmtP = p => p > 10000 ? p.toFixed(0) : p > 100 ? p.toFixed(2) : p.toFixed(4);

  return (
    <div style={{ fontFamily: 'monospace', fontSize: 10, height: '100%', display: 'flex', flexDirection: 'column' }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8, padding: '0 2px' }}>
        <span style={{ fontSize: 11, fontWeight: 700, color: '#00aaff', letterSpacing: 2 }}>LİKİDİTE DUVARLARI</span>
        <div style={{ display: 'flex', gap: 8 }}>
          <span style={{ fontSize: 9, color: '#00ff88' }}>ALIŞ {imbal}%</span>
          <span style={{ fontSize: 9, color: '#ff3366' }}>SATIŞ {100-imbal}%</span>
        </div>
      </div>

      {/* Imbalance bar */}
      <div style={{ height: 5, background: '#ff3366', borderRadius: 3, marginBottom: 10, overflow: 'hidden' }}>
        <div style={{ width: `${imbal}%`, height: '100%', background: '#00ff88', borderRadius: 3 }} />
      </div>

      {/* Büyük duvarlar */}
      {(bigBids.length > 0 || bigAsks.length > 0) && (
        <div style={{ background: '#07070f', border: '1px solid #1a1a2e', borderRadius: 6, padding: '6px 8px', marginBottom: 8 }}>
          <div style={{ fontSize: 9, color: '#404070', marginBottom: 4 }}>BÜYÜK DUVARLAR</div>
          {bigBids.slice(0,2).map((b, i) => (
            <div key={`bb${i}`} style={{ display: 'flex', justifyContent: 'space-between', color: '#00ff88', fontSize: 9, marginBottom: 2 }}>
              <span>🟢 ALIŞ DUVARI @ {fmtP(b.price)}</span>
              <span style={{ color: '#00ff8899' }}>${fmt(b.amount * b.price)}</span>
            </div>
          ))}
          {bigAsks.slice(0,2).map((a, i) => (
            <div key={`ba${i}`} style={{ display: 'flex', justifyContent: 'space-between', color: '#ff3366', fontSize: 9, marginBottom: 2 }}>
              <span>🔴 SATIŞ DUVARI @ {fmtP(a.price)}</span>
              <span style={{ color: '#ff336699' }}>${fmt(a.amount * a.price)}</span>
            </div>
          ))}
        </div>
      )}

      {/* Orderbook görsel */}
      <div style={{ flex: 1, overflow: 'hidden', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
        {/* ALIŞ */}
        <div>
          <div style={{ fontSize: 9, color: '#00ff88', marginBottom: 4, textAlign: 'center' }}>ALIŞ EMİRLERİ</div>
          {bids.slice(0, 12).map((b, i) => {
            const pct = (b.amount * b.price / maxV) * 100;
            const isBig = b.amount * b.price > maxV * 0.35;
            return (
              <div key={i} style={{ position: 'relative', marginBottom: 1, height: 14 }}>
                <div style={{ position: 'absolute', right: 0, top: 0, height: '100%', width: `${pct}%`, background: isBig ? '#00ff8840' : '#00ff8818', borderRadius: '2px 0 0 2px' }} />
                <div style={{ position: 'relative', display: 'flex', justifyContent: 'space-between', padding: '0 4px', lineHeight: '14px', zIndex: 1 }}>
                  <span style={{ color: isBig ? '#00ff88' : '#00ff8866', fontSize: 9 }}>{fmtP(b.price)}</span>
                  <span style={{ color: '#00ff8866', fontSize: 8 }}>{fmt(b.amount * b.price)}</span>
                </div>
              </div>
            );
          })}
        </div>
        {/* SATIŞ */}
        <div>
          <div style={{ fontSize: 9, color: '#ff3366', marginBottom: 4, textAlign: 'center' }}>SATIŞ EMİRLERİ</div>
          {asks.slice(0, 12).map((a, i) => {
            const pct = (a.amount * a.price / maxV) * 100;
            const isBig = a.amount * a.price > maxV * 0.35;
            return (
              <div key={i} style={{ position: 'relative', marginBottom: 1, height: 14 }}>
                <div style={{ position: 'absolute', left: 0, top: 0, height: '100%', width: `${pct}%`, background: isBig ? '#ff336640' : '#ff336618', borderRadius: '0 2px 2px 0' }} />
                <div style={{ position: 'relative', display: 'flex', justifyContent: 'space-between', padding: '0 4px', lineHeight: '14px', zIndex: 1 }}>
                  <span style={{ color: isBig ? '#ff3366' : '#ff336666', fontSize: 9 }}>{fmtP(a.price)}</span>
                  <span style={{ color: '#ff336666', fontSize: 8 }}>{fmt(a.amount * a.price)}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

/**
 * AccumulationPlanPanel.jsx — Birikim planlama paneli
 */
export function AccumulationPlanPanel({ symbol, currentPrice, masterResult }) {
  if (!currentPrice) return (
    <div style={{ padding: 24, textAlign: 'center', color: '#404070', fontSize: 10, fontFamily: 'monospace' }}>
      Fiyat bekleniyor...
    </div>
  );

  const atr    = masterResult?.pineData?.atrV || currentPrice * 0.02;
  const score  = masterResult?.score || 50;
  const action = masterResult?.action || 'WAIT';

  // TP/SL hesapla
  const tp1   = currentPrice + atr * 1.0;
  const tp2   = currentPrice + atr * 2.0;
  const tp3   = currentPrice + atr * 3.5;
  const sl    = currentPrice - atr * 1.0;
  const rr1   = ((tp1 - currentPrice) / (currentPrice - sl)).toFixed(2);
  const rr2   = ((tp2 - currentPrice) / (currentPrice - sl)).toFixed(2);

  // Birikim seviyeleri
  const zones = [
    { label: 'Agresif Giriş', price: currentPrice, pct: 30, color: '#00aaff', note: 'Mevcut fiyat' },
    { label: '1. DCA', price: currentPrice - atr * 0.5, pct: 35, color: '#00cc66', note: '0.5 ATR aşağı' },
    { label: '2. DCA', price: currentPrice - atr * 1.2, pct: 25, color: '#00ff88', note: '1.2 ATR aşağı' },
    { label: 'Acil DCA', price: currentPrice - atr * 2.0, pct: 10, color: '#ffcc00', note: 'Destek bölgesi' },
  ];

  const fmtP = p => p > 10000 ? p.toFixed(0) : p > 100 ? p.toFixed(2) : p.toFixed(4);
  const scoreColor = score >= 65 ? '#00ff88' : score >= 45 ? '#ffcc00' : '#ff3366';

  return (
    <div style={{ fontFamily: 'monospace', fontSize: 10 }}>
      <div style={{ fontSize: 11, fontWeight: 700, color: '#00aaff', letterSpacing: 2, marginBottom: 10 }}>
        BİRİKİM PLANI
      </div>

      {/* Master karar */}
      <div style={{ background: `${scoreColor}10`, border: `1px solid ${scoreColor}40`, borderRadius: 6, padding: '8px 10px', marginBottom: 10 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span style={{ fontSize: 13, fontWeight: 700, color: scoreColor }}>{action}</span>
          <span style={{ fontSize: 11, color: scoreColor }}>{score}/100</span>
        </div>
        <div style={{ fontSize: 9, color: '#6060a0', marginTop: 3 }}>{symbol} · ${fmtP(currentPrice)}</div>
      </div>

      {/* TP/SL */}
      <div style={{ background: '#07070f', border: '1px solid #1a1a2e', borderRadius: 6, padding: '7px 10px', marginBottom: 10 }}>
        <div style={{ fontSize: 9, color: '#404070', marginBottom: 5 }}>HEDEFLER</div>
        {[
          { label: 'TP1', price: tp1, color: '#00cc66', rr: rr1 },
          { label: 'TP2', price: tp2, color: '#00ff88', rr: rr2 },
          { label: 'TP3', price: tp3, color: '#69f0ae', rr: '—' },
          { label: 'SL',  price: sl,  color: '#ff3366', rr: '1:1' },
        ].map(t => (
          <div key={t.label} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 3 }}>
            <span style={{ color: t.color, fontWeight: 700, width: 30 }}>{t.label}</span>
            <span style={{ color: '#9090c0' }}>${fmtP(t.price)}</span>
            <span style={{ color: '#6060a0', fontSize: 9 }}>R/R {t.rr}</span>
          </div>
        ))}
      </div>

      {/* DCA Planı */}
      <div style={{ background: '#07070f', border: '1px solid #1a1a2e', borderRadius: 6, padding: '7px 10px' }}>
        <div style={{ fontSize: 9, color: '#404070', marginBottom: 6 }}>DCA BİRİKİM SEVİYELERİ</div>
        {zones.map((z, i) => (
          <div key={i} style={{ marginBottom: 6 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 2 }}>
              <span style={{ color: z.color, fontSize: 9 }}>{z.label}</span>
              <span style={{ color: '#9090c0', fontSize: 9 }}>${fmtP(z.price)}</span>
              <span style={{ color: '#6060a0', fontSize: 9 }}>%{z.pct}</span>
            </div>
            <div style={{ height: 4, background: '#0a0a1c', borderRadius: 2, overflow: 'hidden' }}>
              <div style={{ width: `${z.pct}%`, height: '100%', background: z.color + '88', borderRadius: 2 }} />
            </div>
            <div style={{ fontSize: 8, color: '#404070', marginTop: 1 }}>{z.note}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
