/**
 * GRID MASTER GLOBAL — PERFORMANCE & CACHE ENGINE v1
 * ====================================================
 * Hızlı veri önbelleği, rate limit koruması ve WebSocket fallback.
 *
 * KATMANLAR:
 *   1. L1 Cache — Bellek içi, çok hızlı (TTL: 10sn - 5dk)
 *   2. Rate Limiter — Exchange API çağrısı throttle
 *   3. WS Monitor — WebSocket düştüğünde REST fallback
 *   4. Request Queue — Eş zamanlı istek sınırlaması
 *   5. Health Monitor — Veri tazeliği + gecikme izleme
 */

// ─── L1 ÖNBELLEK ─────────────────────────────────────────────────────────────
class L1Cache {
  constructor() {
    this._store = new Map();
    this._hits  = 0;
    this._miss  = 0;
  }

  get(key) {
    const entry = this._store.get(key);
    if (!entry) { this._miss++; return null; }
    if (Date.now() > entry.expiresAt) {
      this._store.delete(key);
      this._miss++;
      return null;
    }
    this._hits++;
    return entry.value;
  }

  set(key, value, ttlMs = 30_000) {
    this._store.set(key, { value, expiresAt: Date.now() + ttlMs, createdAt: Date.now() });
  }

  delete(key) { this._store.delete(key); }

  clear(prefix = null) {
    if (!prefix) { this._store.clear(); return; }
    for (const k of this._store.keys()) {
      if (k.startsWith(prefix)) this._store.delete(k);
    }
  }

  stats() {
    const total = this._hits + this._miss;
    return {
      size:     this._store.size,
      hits:     this._hits,
      misses:   this._miss,
      hitRate:  total ? parseFloat((this._hits / total * 100).toFixed(1)) : 0,
    };
  }

  // Süresi dolmuş kayıtları temizle
  purgeExpired() {
    const now = Date.now();
    let   count = 0;
    for (const [k, v] of this._store) {
      if (now > v.expiresAt) { this._store.delete(k); count++; }
    }
    return count;
  }
}

export const cache = new L1Cache();

// Otomatik temizleme (her 2 dakikada bir)
setInterval(() => cache.purgeExpired(), 2 * 60 * 1000);

// ─── TTL TANIMLARI ────────────────────────────────────────────────────────────
export const TTL = {
  TICKER:      10_000,    // 10 saniye — anlık fiyat
  ORDERBOOK:   5_000,     // 5 saniye — orderbook
  KLINES_1M:   30_000,    // 30 saniye — 1 dakika mumlar
  KLINES_5M:   60_000,    // 1 dakika
  KLINES_15M:  90_000,    // 1.5 dakika
  KLINES_1H:   3 * 60_000, // 3 dakika
  KLINES_4H:   5 * 60_000, // 5 dakika
  KLINES_1D:   15 * 60_000, // 15 dakika
  COUNCIL:     20_000,    // 20 saniye — council sonucu
  FUNDING:     60_000,    // 1 dakika
  OI:          30_000,    // 30 saniye
  FEAR_GREED:  10 * 60_000, // 10 dakika
  NEWS:        5 * 60_000,  // 5 dakika
  MULTI_ASSET: 5 * 60_000,  // 5 dakika
};

// ─── RATE LİMİTER ─────────────────────────────────────────────────────────────
class RateLimiter {
  constructor() {
    // Exchange başına dakikalık limit
    this._limits = {
      binance: { perMinute: 1200, weight: 0 },
      bybit:   { perMinute: 120,  weight: 0 },
      okx:     { perMinute: 60,   weight: 0 },
      default: { perMinute: 60,   weight: 0 },
    };
    this._calls     = new Map(); // exchange → [timestamp, ...]
    this._throttled = 0;

    // Her dakika sayaçları sıfırla
    setInterval(() => {
      for (const ex of this._calls.keys()) {
        this._calls.set(ex, []);
      }
    }, 60_000);
  }

  canCall(exchange = 'default') {
    const limit  = this._limits[exchange] || this._limits.default;
    const calls  = this._calls.get(exchange) || [];
    const recent = calls.filter(ts => Date.now() - ts < 60_000);
    this._calls.set(exchange, recent);
    return recent.length < limit.perMinute;
  }

  recordCall(exchange = 'default') {
    const calls = this._calls.get(exchange) || [];
    calls.push(Date.now());
    this._calls.set(exchange, calls);
  }

  async throttledFetch(url, options = {}, exchange = 'default') {
    if (!this.canCall(exchange)) {
      this._throttled++;
      console.warn(`[RATE LIMITER] ${exchange} rate limiti doldu — 2sn bekleniyor`);
      await new Promise(r => setTimeout(r, 2000));
    }
    this.recordCall(exchange);
    return fetch(url, { signal: AbortSignal.timeout(8000), ...options });
  }

  stats() {
    const usage = {};
    for (const [ex, calls] of this._calls) {
      const limit = this._limits[ex] || this._limits.default;
      const recent = calls.filter(ts => Date.now() - ts < 60_000).length;
      usage[ex] = { calls: recent, limit: limit.perMinute, pct: Math.round(recent / limit.perMinute * 100) };
    }
    return { usage, totalThrottled: this._throttled };
  }
}

export const rateLimiter = new RateLimiter();

// ─── REQUEST QUEUE ────────────────────────────────────────────────────────────
class RequestQueue {
  constructor(maxConcurrent = 5) {
    this._max     = maxConcurrent;
    this._active  = 0;
    this._queue   = [];
    this._done    = 0;
    this._errors  = 0;
  }

  async enqueue(fn) {
    return new Promise((resolve, reject) => {
      const task = async () => {
        this._active++;
        try {
          const result = await fn();
          this._done++;
          resolve(result);
        } catch (e) {
          this._errors++;
          reject(e);
        } finally {
          this._active--;
          this._processNext();
        }
      };

      if (this._active < this._max) {
        task();
      } else {
        this._queue.push(task);
      }
    });
  }

  _processNext() {
    if (this._queue.length > 0 && this._active < this._max) {
      const next = this._queue.shift();
      next();
    }
  }

  stats() {
    return {
      active:   this._active,
      queued:   this._queue.length,
      done:     this._done,
      errors:   this._errors,
    };
  }
}

export const requestQueue = new RequestQueue(6);

// ─── WEBSOCKET MONITOR ───────────────────────────────────────────────────────
const _wsRegistry = new Map(); // endpoint → { ws, lastPing, alive, fallback }

/**
 * monitorWebSocket — WS bağlantısını izle, düşerse callback çağır
 */
export function monitorWebSocket(id, ws, { onDead, pingIntervalMs = 15_000 } = {}) {
  const state = { ws, lastPing: Date.now(), alive: true };
  _wsRegistry.set(id, state);

  const interval = setInterval(() => {
    if (!state.ws || state.ws.readyState > 1) {
      // WS kapandı
      state.alive = false;
      clearInterval(interval);
      console.warn(`[WS MONITOR] ${id} kapandı — fallback tetikleniyor`);
      if (onDead) onDead(id);
      _wsRegistry.delete(id);
    } else {
      // Ping gönder
      try {
        if (state.ws.readyState === 1) {
          state.ws.send(JSON.stringify({ method: 'ping' }));
          state.lastPing = Date.now();
        }
      } catch (e) {}
    }
  }, pingIntervalMs);

  return () => clearInterval(interval); // cleanup
}

/**
 * getWSHealth — Tüm WS bağlantı durumu
 */
export function getWSHealth() {
  const result = {};
  for (const [id, state] of _wsRegistry) {
    result[id] = {
      alive:    state.alive,
      lastPing: state.lastPing,
      ageSec:   Math.round((Date.now() - state.lastPing) / 1000),
    };
  }
  return result;
}

// ─── AKILLI FETCH (Cache + Rate limit + Queue) ────────────────────────────────
/**
 * smartFetch — Cache kontrol ederek rate-limited fetch yapar
 *
 * @param {string} url
 * @param {string} cacheKey
 * @param {number} ttlMs
 * @param {string} exchange  — Rate limit için exchange adı
 */
export async function smartFetch(url, cacheKey, ttlMs = TTL.TICKER, exchange = 'default') {
  // 1. Cache kontrolü
  const cached = cache.get(cacheKey);
  if (cached !== null) return cached;

  // 2. Rate limited fetch
  return requestQueue.enqueue(async () => {
    const res  = await rateLimiter.throttledFetch(url, {}, exchange);
    const data = await res.json();
    cache.set(cacheKey, data, ttlMs);
    return data;
  });
}

// ─── PERFORMANCE MONITOR ──────────────────────────────────────────────────────
const _perfMetrics = {
  apiLatency:   [],
  cacheHitRate: 0,
  slowCalls:    0,
};

/**
 * recordLatency — API gecikme ölç
 */
export function recordLatency(exchange, latencyMs) {
  _perfMetrics.apiLatency.push({ exchange, latencyMs, ts: Date.now() });
  if (_perfMetrics.apiLatency.length > 100) _perfMetrics.apiLatency.shift();
  if (latencyMs > 3000) _perfMetrics.slowCalls++;
}

/**
 * getPerformanceReport — Genel performans raporu
 */
export function getPerformanceReport() {
  const latencies = _perfMetrics.apiLatency;
  const avgLat    = latencies.length
    ? latencies.reduce((a, l) => a + l.latencyMs, 0) / latencies.length
    : 0;

  return {
    cache:       cache.stats(),
    rateLimit:   rateLimiter.stats(),
    queue:       requestQueue.stats(),
    wsHealth:    getWSHealth(),
    avgLatencyMs: parseFloat(avgLat.toFixed(1)),
    slowCalls:   _perfMetrics.slowCalls,
    timestamp:   new Date().toISOString(),
    healthy:     avgLat < 1500 && cache.stats().hitRate > 30,
  };
}

// ─── VERI TAZELİĞİ KONTROLÜ ──────────────────────────────────────────────────
/**
 * isDataStale — Verinin eskimiş olup olmadığını kontrol et
 */
export function isDataStale(timestamp, maxAgeMs = 60_000) {
  if (!timestamp) return true;
  const ts = typeof timestamp === 'string' ? new Date(timestamp).getTime() : timestamp;
  return Date.now() - ts > maxAgeMs;
}

/**
 * getDataFreshness — Veri tazeliği yüzdesi (0-100)
 */
export function getDataFreshness(timestamp, ttlMs = 30_000) {
  if (!timestamp) return 0;
  const ts  = typeof timestamp === 'string' ? new Date(timestamp).getTime() : timestamp;
  const age = Date.now() - ts;
  return clamp(Math.round(Math.max(0, 1 - age / ttlMs) * 100));
}

function clamp(v, lo = 0, hi = 100) { return Math.max(lo, Math.min(hi, v)); }
