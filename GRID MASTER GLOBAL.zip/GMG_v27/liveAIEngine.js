/**
 * GMG — LIVE AI QUERY ENGINE
 * ===========================
 * Claude API ile canlı soru-cevap.
 * Kullanıcı coin sorunca → council verisiyle AI analiz yapar.
 */

const CLAUDE_API = 'https://api.anthropic.com/v1/messages';

export async function askLiveAI({ question, symbol, masterResult, scanResults, language = 'tr' }) {
  const council = masterResult?.councils;
  const exec    = masterResult?.execution;
  const pine    = masterResult?.pineData;

  const context = `
Sen Grid Master Global trading platformunun AI analistsin.
Şu anki piyasa durumu:
- Coin: ${symbol}
- Master Karar: ${masterResult?.label || '—'} (Skor: ${masterResult?.score || 50}/100)
- Güven: %${masterResult?.confidence || 0}
- Risk: ${masterResult?.riskLevel || '—'}
- Technical Council: ${council?.technical?.action || '—'} (${council?.technical?.score || 50})
- Flow Council: ${council?.flow?.action || '—'} (${council?.flow?.score || 50})
- Risk Council: ${council?.risk?.riskLevel || '—'} (${council?.risk?.score || 50})
- Pine RF Trend: ${pine?.rf?.trendDir || '—'}
- PB-AL: ${pine?.pb?.pbBuy ? 'AKTİF' : 'Yok'} | PB-SAT: ${pine?.pb?.pbSell ? 'AKTİF' : 'Yok'}
- Execution Veto: ${exec?.filters?.veto?.wasVetoed ? 'EVET' : 'Hayır'}
- Stop Hunt: ${scanResults?.stopHunts?.length || 0} tespit
${masterResult?.summary?.join('\n') || ''}

Kullanıcı sorusu: "${question}"
Kısa, net ve ${language === 'tr' ? 'Türkçe' : 'İngilizce'} cevap ver (max 3 cümle). Teknik terimler kullan.
  `.trim();

  try {
    const res = await fetch(CLAUDE_API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 300,
        messages: [{ role: 'user', content: context }],
      }),
    });
    const data = await res.json();
    const text = data.content?.map(c => c.text || '').join('') || 'Cevap alınamadı.';
    return { answer: text, timestamp: Date.now(), question, symbol };
  } catch (e) {
    return { answer: `AI hatası: ${e.message}`, error: true, timestamp: Date.now() };
  }
}

export async function autoMarketSummary({ masterResult, scanResults, symbol }) {
  const pumps  = scanResults?.suddenPumps?.slice(0,3).map(c => c.symbol).join(', ') || '—';
  const dumps  = scanResults?.suddenDumps?.slice(0,3).map(c => c.symbol).join(', ') || '—';
  const hunts  = scanResults?.stopHunts?.length || 0;
  const breadth = scanResults?.enrichedCoins
    ? Math.round(scanResults.enrichedCoins.filter(c => (c.change_24h||0) > 0).length / scanResults.enrichedCoins.length * 100)
    : 50;

  const prompt = `
Sen GMG trading analistsin. Şu an ${new Date().toLocaleTimeString('tr-TR')} UTC+3.
Piyasa verileri:
- Seçili coin: ${symbol} → ${masterResult?.label || 'BEKLE'} (${masterResult?.score || 50}/100)
- Piyasa genişliği: %${breadth} coin pozitif
- Pump: ${pumps} | Dump: ${dumps}
- Stop Hunt: ${hunts} tespit
- Risk: ${masterResult?.riskLevel || 'ORTA'}
- Pine Trend: ${masterResult?.pineData?.rf?.trendDir || 'BELİRSİZ'}

2-3 cümleyle genel piyasa özeti yaz. Türkçe. Net ve bilgilendirici.
  `.trim();

  try {
    const res = await fetch(CLAUDE_API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 200,
        messages: [{ role: 'user', content: prompt }],
      }),
    });
    const data = await res.json();
    return {
      summary: data.content?.map(c => c.text || '').join('') || '—',
      timestamp: Date.now(),
    };
  } catch (e) {
    return { summary: 'Özet alınamadı.', error: true, timestamp: Date.now() };
  }
}
