/**
 * bondMacroAdvancedEngine.js — GMG v16
 * Tahvil & Makro Gelişmiş Motorlar:
 *   141. Yield Curve Engine (gelişmiş)
 *   142. Bond Flow Engine
 *   143. Rate Expectation Engine
 *   144. Inflation Premium Engine
 *   148. Macro Event Calendar
 *   149. Global Risk Appetite Engine (gelişmiş)
 *   150. Geopolitical Risk Engine
 *   151. Global Money Flow Engine
 *   156. Macro Surprise Engine
 */

const clamp = (v, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, v));

// ─── YIELD CURVE ENGINE (gelişmiş) ───────────────────────────────────────────
export function runYieldCurveEngine({
  us2y = 4.8,
  us10y = 4.3,
  us30y = 4.5,
  us3m = 5.1,
} = {}) {
  const spread10y2y  = us10y - us2y;    // Normal = pozitif
  const spread10y3m  = us10y - us3m;    // Kriz göstergesi
  const spread30y10y = us30y - us10y;

  // Eğri tipi
  const isInverted   = spread10y2y < 0;
  const isDeepInvert = spread10y2y < -0.5;
  const isFlat       = Math.abs(spread10y2y) < 0.1;
  const isSteepening = spread10y2y > 0.5;

  // Ekonomik sinyal
  let recessionRisk = 0;
  if (isDeepInvert) recessionRisk += 50;
  else if (isInverted) recessionRisk += 30;
  if (spread10y3m < -0.5) recessionRisk += 25;

  // Kripto etkisi
  let cryptoImpact = 0;
  if (isInverted) cryptoImpact -= 20;       // Tersine eğri = risk-off
  if (isSteepening) cryptoImpact += 10;      // Normalleşme = risk-on
  if (us10y > 5) cryptoImpact -= 15;         // Yüksek faiz = likidite çekilir
  if (us10y < 3.5) cryptoImpact += 15;       // Düşük faiz = likidite bol

  const riskLevel = recessionRisk >= 50 ? 'YÜKSEK' : recessionRisk >= 30 ? 'ORTA' : 'DÜŞÜK';
  const score = clamp(50 + cryptoImpact);

  return {
    score,
    spread10y2y:  parseFloat(spread10y2y.toFixed(3)),
    spread10y3m:  parseFloat(spread10y3m.toFixed(3)),
    spread30y10y: parseFloat(spread30y10y.toFixed(3)),
    isInverted,
    isDeepInvert,
    isFlat,
    isSteepening,
    recessionRisk: clamp(recessionRisk),
    riskLevel,
    cryptoImpact,
    curveType: isDeepInvert ? 'DERIN_TERSINE' : isInverted ? 'TERSINE' : isFlat ? 'DÜZLEŞME' : isSteepening ? 'DİKLEŞME' : 'NORMAL',
    verdict: isDeepInvert
      ? '⛔ Derin tersine getiri eğrisi — resesyon riski yüksek'
      : isInverted
      ? '⚠ Tersine eğri — ekonomik yavaşlama sinyali'
      : isSteepening
      ? '✅ Eğri dikleşiyor — ekonomi canlanıyor'
      : '✓ Normal getiri eğrisi',
    timestamp: Date.now(),
  };
}

// ─── BOND FLOW ENGINE ─────────────────────────────────────────────────────────
export function runBondFlowEngine({
  bondInflows = 0,   // haftalık $
  treasuryAuctions = [],  // [{tenor, bidCoverage, yield}]
  foreignBuying = 0,
  fedBalance = 0,
} = {}) {
  // Hazine ihalesi güçlü mü?
  const avgBidCoverage = treasuryAuctions.length
    ? treasuryAuctions.reduce((s, a) => s + (a.bidCoverage || 2), 0) / treasuryAuctions.length
    : 2;
  const strongAuction = avgBidCoverage > 2.5;
  const weakAuction   = avgBidCoverage < 2.0;

  // Yabancı talep
  const foreignDemand = foreignBuying > 1e9 ? 'GÜÇLÜ' : foreignBuying < 0 ? 'ZAYIF' : 'NORMAL';

  let score = 50;
  if (strongAuction) { score += 15; }
  if (weakAuction)   { score -= 15; }
  if (bondInflows > 0) { score += 8; }
  if (bondInflows < -1e9) { score -= 10; }
  if (foreignDemand === 'GÜÇLÜ') score += 10;
  if (foreignDemand === 'ZAYIF') score -= 10;

  return {
    score: clamp(score),
    bondInflows: parseFloat((bondInflows / 1e6).toFixed(0)),
    avgBidCoverage: parseFloat(avgBidCoverage.toFixed(2)),
    strongAuction,
    weakAuction,
    foreignDemand,
    verdict: weakAuction
      ? '⚠ Zayıf tahvil ihalesi — hazine zorunlu satış yapabilir'
      : strongAuction
      ? '✅ Güçlü tahvil talebi — risk-on olabilir'
      : '✓ Normal tahvil akışı',
    timestamp: Date.now(),
  };
}

// ─── RATE EXPECTATION ENGINE ──────────────────────────────────────────────────
export function runRateExpectationEngine({
  fedFundsRate = 5.25,
  fedMeetingDate = null,
  cmeProbs = {},  // { '-50bps': 5, '-25bps': 30, 'hold': 55, '+25bps': 10 }
  inflationTrend = 'stable', // falling | stable | rising
  laborMarket = 'strong',    // weak | neutral | strong
} = {}) {
  // En yüksek olasılıklı Fed kararı
  const sortedProbs = Object.entries(cmeProbs).sort((a, b) => b[1] - a[1]);
  const mostLikelyAction = sortedProbs[0]?.[0] || 'hold';
  const mostLikelyProb   = sortedProbs[0]?.[1] || 50;

  const isCutExpected  = mostLikelyAction.includes('-');
  const isHikeExpected = mostLikelyAction.includes('+');

  let cryptoImpact = 0;
  if (isCutExpected) cryptoImpact += 20;
  if (isHikeExpected) cryptoImpact -= 20;
  if (inflationTrend === 'falling') cryptoImpact += 10;
  if (inflationTrend === 'rising') cryptoImpact -= 10;
  if (laborMarket === 'weak') cryptoImpact += 5; // Zayıf iş piyasası = faiz kesimi

  const score = clamp(50 + cryptoImpact);

  return {
    score,
    fedFundsRate,
    mostLikelyAction,
    mostLikelyProb,
    isCutExpected,
    isHikeExpected,
    cryptoImpact,
    inflationTrend,
    laborMarket,
    verdict: isCutExpected
      ? `✅ Faiz kesimi beklentisi (${mostLikelyProb}%) — kripto için pozitif`
      : isHikeExpected
      ? `⚠ Faiz artırımı beklentisi (${mostLikelyProb}%) — kripto için negatif`
      : `Fed sabit kalacak (${mostLikelyProb}%) — nötr`,
    timestamp: Date.now(),
  };
}

// ─── MACRO EVENT CALENDAR ─────────────────────────────────────────────────────
let _calendarEvents = [];

export const MacroEventCalendar = {
  loadEvents(events = []) {
    _calendarEvents = events.sort((a, b) => a.time - b.time);
  },

  getUpcoming(withinHours = 24) {
    const cutoff = Date.now() + withinHours * 3600000;
    return _calendarEvents.filter(e => e.time > Date.now() && e.time < cutoff);
  },

  getHighImpact(withinHours = 24) {
    return this.getUpcoming(withinHours).filter(e => e.impact === 'HIGH');
  },

  getRiskScore() {
    const upcoming = this.getHighImpact(6); // Sonraki 6 saat
    if (!upcoming.length) return { score: 0, events: [], message: 'Yakın vadede önemli olay yok' };
    const score = clamp(upcoming.length * 25);
    return {
      score,
      events: upcoming,
      message: `⚠ ${upcoming.length} yüksek etkili olay: ${upcoming.map(e => e.name).join(', ')}`,
    };
  },

  // Mock events (gerçek API'den doldurul)
  getMockEvents() {
    const now = Date.now();
    return [
      { name: 'FOMC Toplantısı', impact: 'HIGH',   time: now + 2 * 3600000, currency: 'USD', forecast: '+25bps' },
      { name: 'NFP Verileri',    impact: 'HIGH',   time: now + 24 * 3600000, currency: 'USD', forecast: '180K' },
      { name: 'CPI Enflasyon',   impact: 'HIGH',   time: now + 48 * 3600000, currency: 'USD', forecast: '3.1%' },
      { name: 'ETC Kararı',      impact: 'MEDIUM', time: now + 72 * 3600000, currency: 'EUR', forecast: 'Sabit' },
    ];
  },
};

// ─── GLOBAL RISK APPETITE ENGINE ─────────────────────────────────────────────
export function runGlobalRiskAppetiteEngine({
  vix = 20,
  sp500Change = 0,
  goldChange = 0,
  dxyChange = 0,
  bondYieldChange = 0,
  emergingMarketsChange = 0,
} = {}) {
  let riskOn = 0, riskOff = 0;

  // Risk-On sinyaller
  if (sp500Change > 0.5) riskOn += 25;
  if (vix < 15)          riskOn += 20;
  if (dxyChange < -0.3)  riskOn += 15;
  if (emergingMarketsChange > 0) riskOn += 10;

  // Risk-Off sinyaller
  if (vix > 25)          riskOff += 30;
  if (goldChange > 0.8)  riskOff += 20;
  if (sp500Change < -1)  riskOff += 25;
  if (dxyChange > 0.5)   riskOff += 15;
  if (bondYieldChange > 0.1) riskOff += 10;

  const balance = riskOn - riskOff;
  const score   = clamp(50 + balance);
  const mode    = balance > 15 ? 'RISK_ON' : balance < -15 ? 'RISK_OFF' : 'NEUTRAL';

  return {
    score,
    mode,
    riskOnSignals:  riskOn,
    riskOffSignals: riskOff,
    balance,
    vixLevel: vix,
    verdict: mode === 'RISK_ON'
      ? '✅ Risk-ON ortam — kripto için olumlu'
      : mode === 'RISK_OFF'
      ? '⚠ Risk-OFF ortam — kripto için olumsuz'
      : '📊 Risk iştahı nötr',
    timestamp: Date.now(),
  };
}

// ─── GEOPOLITICAL RISK ENGINE ─────────────────────────────────────────────────
const GEO_EVENTS = {
  WAR: { impact: 80, cryptoEffect: -20 },
  SANCTIONS: { impact: 60, cryptoEffect: -10 },
  ELECTION: { impact: 40, cryptoEffect: 5 },
  TRADE_WAR: { impact: 50, cryptoEffect: -15 },
  ENERGY_CRISIS: { impact: 65, cryptoEffect: -25 },
  BANKING_CRISIS: { impact: 75, cryptoEffect: 15 }, // Bankacılık krizi kripto için pozitif olabilir
  INFLATION_CRISIS: { impact: 70, cryptoEffect: 20 },
};

export function runGeopoliticalRiskEngine(activeEvents = []) {
  if (!activeEvents.length) return { score: 0, cryptoEffect: 0, risk: 'DÜŞÜK', events: [] };

  let totalImpact = 0, totalCryptoEffect = 0;
  const analyzed = activeEvents.map(event => {
    const template = GEO_EVENTS[event.type] || { impact: 30, cryptoEffect: 0 };
    const severity = event.severity || 1; // 0-1 arası
    return {
      ...event,
      impact:       template.impact * severity,
      cryptoEffect: template.cryptoEffect * severity,
    };
  });

  analyzed.forEach(e => { totalImpact += e.impact; totalCryptoEffect += e.cryptoEffect; });

  const avgImpact = analyzed.length ? totalImpact / analyzed.length : 0;
  const risk = avgImpact > 60 ? 'KRİTİK' : avgImpact > 40 ? 'YÜKSEK' : avgImpact > 20 ? 'ORTA' : 'DÜŞÜK';

  return {
    score:         clamp(avgImpact),
    cryptoEffect:  parseFloat(totalCryptoEffect.toFixed(1)),
    risk,
    events:        analyzed,
    topEvent:      analyzed.sort((a, b) => b.impact - a.impact)[0] || null,
    verdict: avgImpact > 60
      ? `⛔ Yüksek jeopolitik risk — ${analyzed.map(e => e.type).join(', ')}`
      : avgImpact > 30
      ? `⚠ Jeopolitik belirsizlik var`
      : `✓ Jeopolitik ortam sakin`,
    timestamp: Date.now(),
  };
}

// ─── GLOBAL MONEY FLOW ENGINE ─────────────────────────────────────────────────
export function runGlobalMoneyFlowEngine({
  m2Growth = 0,            // ABD M2 para arzı büyümesi %
  fedBalance = 0,          // Fed bilanço değişimi $
  globalLiquidity = 50,    // 0-100 skoru
  stablecoinMcap = 0,      // Stablecoin toplam market cap
  cryptoMarketCap = 0,
} = {}) {
  let score = globalLiquidity;

  // Para arzı büyümesi
  if (m2Growth > 5)  { score += 12; }
  if (m2Growth < -2) { score -= 12; }

  // Fed bilanço (QE/QT)
  if (fedBalance > 1e11)  { score += 15; } // QE
  if (fedBalance < -1e11) { score -= 15; } // QT

  // Stablecoin dominansı
  const stableRatio = cryptoMarketCap > 0 ? stablecoinMcap / cryptoMarketCap : 0;
  if (stableRatio > 0.12) { score -= 10; } // Para kripto dışında
  if (stableRatio < 0.06) { score += 8; }  // Para piyasada

  return {
    score: clamp(Math.round(score)),
    m2Growth:        parseFloat(m2Growth.toFixed(2)),
    globalLiquidity,
    stableRatio:     parseFloat((stableRatio * 100).toFixed(2)),
    liquidityMode:   score > 60 ? 'BOL' : score > 40 ? 'NORMAL' : 'KITN',
    verdict: score > 65
      ? '✅ Global likidite bol — kripto için pozitif'
      : score > 45
      ? '✓ Normal likidite ortamı'
      : '⚠ Sıkışan likidite — kripto için negatif',
    timestamp: Date.now(),
  };
}

// ─── MACRO SURPRISE ENGINE ────────────────────────────────────────────────────
export function runMacroSurpriseEngine(events = []) {
  // events: [{name, actual, forecast, impact}]
  if (!events.length) return { surpriseScore: 0, direction: 'NEUTRAL', events: [] };

  const analyzed = events.map(e => {
    if (!e.actual || !e.forecast) return { ...e, surprise: 0, direction: 'NEUTRAL' };
    const deviation = (e.actual - e.forecast) / Math.abs(e.forecast || 1) * 100;
    return {
      ...e,
      surprise:  parseFloat(Math.abs(deviation).toFixed(2)),
      direction: deviation > 0 ? 'BEAT' : 'MISS',
      cryptoEffect: e.type === 'NFP' && deviation > 2 ? -10
        : e.type === 'CPI' && deviation > 0.2 ? -15
        : e.type === 'GDP' && deviation > 0 ? 10
        : 0,
    };
  });

  const avgSurprise = analyzed.reduce((s, e) => s + e.surprise, 0) / Math.max(analyzed.length, 1);
  const totalEffect = analyzed.reduce((s, e) => s + (e.cryptoEffect || 0), 0);
  const direction   = totalEffect > 5 ? 'POSITIVE' : totalEffect < -5 ? 'NEGATIVE' : 'NEUTRAL';

  return {
    surpriseScore:  parseFloat(avgSurprise.toFixed(1)),
    direction,
    totalEffect:    parseFloat(totalEffect.toFixed(1)),
    events:         analyzed,
    verdict: direction === 'POSITIVE'
      ? `✅ Makro sürprizi pozitif — ${analyzed.filter(e => e.direction === 'BEAT').map(e => e.name).join(', ')}`
      : direction === 'NEGATIVE'
      ? `⚠ Makro sürprizi negatif — ${analyzed.filter(e => e.direction === 'MISS').map(e => e.name).join(', ')}`
      : `Makro veriler beklenti dahilinde`,
    timestamp: Date.now(),
  };
}
