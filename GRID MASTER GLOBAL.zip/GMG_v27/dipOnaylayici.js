/**
 * GRID MASTER GLOBAL — DİP ONAYLAYICI v1
 * ========================================
 * Tüm coinler için dip (dip/dip) onay motoru.
 *
 * Senin fikrin 5 kontrol içeriyordu.
 * Bu versiyon 8 katman + her coin için tam skorlama yapar.
 *
 * KATMAN 1 — ZAMAN UYUM KONTROLÜ       (TimeAlignmentCheck)
 * KATMAN 2 — MUHALEFET KONTROLÜ        (OppositionCheck)
 * KATMAN 3 — LİKİDİTE TUTARLILIK       (LiquidityConsistencyCheck)
 * KATMAN 4 — BTC UYUM KONTROLÜ         (BTCCompatibilityCheck)
 * KATMAN 5 — VOLATİLİTE ONAYI          (VolatilityApprovalCheck)
 * KATMAN 6 — MUM FORMASYON ONAYI       (CandleFormationCheck)   ← YENİ
 * KATMAN 7 — HACİM DİP ONAYI           (VolumeDipCheck)         ← YENİ
 * KATMAN 8 — ÇOKLU ZAMAN DİLİMİ UYUMU (MultiTimeframeCheck)    ← YENİ
 *
 * NİHAİ KARAR:
 *   dipScore >= 75 → GÜÇLÜ DİP — GİR
 *   dipScore >= 55 → DİP ONAYLI — DİKKATLİ GİR
 *   dipScore >= 40 → ŞÜPHELİ DİP — BEKLE
 *   dipScore  < 40 → DİP DEĞİL — KAPI KAPALI
 */

const clamp = (v, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, v));

// ─── YARDIMCI HESAPLAMALAR ────────────────────────────────────────────────────

function _ema(arr, p) {
  if (!arr || arr.length < p) return arr?.[arr.length - 1] ?? null;
  const k = 2 / (p + 1);
  let v = arr.slice(0, p).reduce((a, b) => a + b, 0) / p;
  for (let i = p; i < arr.length; i++) v = arr[i] * k + v * (1 - k);
  return v;
}

function _rsi(closes, p = 14) {
  if (!closes || closes.length < p + 2) return 50;
  let g = 0, l = 0;
  for (let i = 1; i <= p; i++) { const d = closes[i] - closes[i-1]; d > 0 ? g += d : l -= d; }
  let ag = g / p, al = l / p;
  for (let i = p + 1; i < closes.length; i++) {
    const d = closes[i] - closes[i-1];
    ag = (ag * (p-1) + Math.max(d, 0)) / p;
    al = (al * (p-1) + Math.max(-d, 0)) / p;
  }
  return al === 0 ? 100 : parseFloat((100 - 100 / (1 + ag / al)).toFixed(2));
}

function _macd(closes) {
  if (!closes || closes.length < 27) return { histogram: 0, histMomentum: 0, bullish: false };
  const k12 = 2/13, k26 = 2/27, k9 = 2/10;
  let e12 = closes[0], e26 = closes[0], sig = 0;
  const hist = [];
  for (let i = 1; i < closes.length; i++) {
    e12 = closes[i] * k12 + e12 * (1 - k12);
    e26 = closes[i] * k26 + e26 * (1 - k26);
    const ml = e12 - e26;
    sig = ml * k9 + sig * (1 - k9);
    hist.push(ml - sig);
  }
  const h = hist[hist.length - 1] ?? 0;
  const hp = hist[hist.length - 2] ?? h;
  const hp2 = hist[hist.length - 3] ?? hp;
  return { histogram: h, histMomentum: h - hp, histAccel: (h - hp) - (hp - hp2), bullish: h > 0 && h > hp };
}

function _bb(closes, p = 20) {
  if (!closes || closes.length < p) return { pos: 0.5, width: 0.05, squeeze: false, lower: closes?.[closes.length-1] ?? 0 };
  const sl = closes.slice(-p);
  const mean = sl.reduce((a, b) => a + b, 0) / p;
  const std = Math.sqrt(sl.reduce((a, b) => a + (b - mean) ** 2, 0) / p);
  const last = closes[closes.length - 1];
  const upper = mean + 2 * std, lower = mean - 2 * std;
  const pos = upper !== lower ? clamp((last - lower) / (upper - lower)) : 0.5;
  return { pos, width: (std * 2) / (mean || 1), squeeze: std * 2 / (mean || 1) < 0.03, lower, upper, mean };
}

function _atr(klines, p = 14) {
  if (!klines || klines.length < p + 1) return 0;
  const trs = klines.slice(1).map((k, i) => {
    const h = k.h ?? k.high ?? k.c ?? 0, l = k.l ?? k.low ?? k.c ?? 0, pc = klines[i].c ?? 0;
    return Math.max(h - l, Math.abs(h - pc), Math.abs(l - pc));
  });
  let v = trs.slice(0, p).reduce((a, b) => a + b, 0) / p;
  for (let i = p; i < trs.length; i++) v = (v * (p-1) + trs[i]) / p;
  return v;
}

// ═══════════════════════════════════════════════════════════════════════════════
// 8 KONTROL SINIFI
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * KATMAN 1 — ZAMAN UYUM KONTROLÜ
 * 4 konsey aynı zaman diliminde oy kullandı mı?
 * 15dk / 1saat / 4saat verisinin uyumu kontrol edilir.
 * Gecikmeli konsey varsa (timestamp farkı > 2dk) skor düşer.
 */
class TimeAlignmentCheck {
  verify(councilVotes, marketData) {
    const now      = Date.now();
    const maxDelay = 2 * 60 * 1000; // 2 dakika

    if (!councilVotes || !Array.isArray(councilVotes)) {
      return { passed: true, score: 55, label: 'Zaman Uyumu', detail: 'Timestamp verisi yok — varsayılan' };
    }

    const timestamps = councilVotes.map(v => v.timestamp || now).filter(Boolean);
    const oldest = Math.min(...timestamps);
    const newest = Math.max(...timestamps);
    const spread = newest - oldest;

    // Tüm konseylerin oy zamanı birbirine yakın mı?
    const aligned   = spread < maxDelay;
    // MTF uyum: 15dk → 1h → 4h hepsi aynı yönde mi?
    const mtfBias1h = marketData?.mtf1h  || 'neutral';
    const mtfBias4h = marketData?.mtf4h  || 'neutral';
    const direction = councilVotes.filter(v => v.short === 'AL').length > councilVotes.length / 2 ? 'bullish' : 'bearish';

    const mtfMatch1h = mtfBias1h === direction || mtfBias1h === 'neutral';
    const mtfMatch4h = mtfBias4h === direction || mtfBias4h === 'neutral';
    const mtfBonus   = (mtfMatch1h ? 10 : 0) + (mtfMatch4h ? 15 : 0);

    let score = aligned ? 65 : Math.max(25, 65 - (spread / maxDelay) * 30);
    score = clamp(score + mtfBonus);

    return {
      passed:  score >= 50,
      score:   Math.round(score),
      label:   'Zaman Uyumu',
      detail:  aligned
        ? `Konsey zamanları uyumlu (${(spread/1000).toFixed(0)}s fark) | MTF: ${mtfMatch1h?'1h✓':'1h✗'} ${mtfMatch4h?'4h✓':'4h✗'}`
        : `Konsey zaman farkı yüksek: ${(spread/1000).toFixed(0)}s — güven düşük`,
      warning: !aligned ? `Konsey zamanlaması uyumsuz (${(spread/1000).toFixed(0)}s)` : null,
    };
  }
}

/**
 * KATMAN 2 — MUHALEFET KONTROLÜ
 * 3 konsey AL dediyse, SAT diyen konsey var mı?
 * Muhalif konseyin skoru güçlüyse (> 65) → ciddi uyarı.
 * Risk konseyi her zaman daha ağırlıklı değerlendirilir.
 */
class OppositionCheck {
  verify(councilVotes, marketData) {
    if (!councilVotes?.length) {
      return { passed: true, score: 55, label: 'Muhalefet', detail: 'Konsey verisi yok' };
    }

    const buyVotes  = councilVotes.filter(v => v.short === 'AL');
    const sellVotes = councilVotes.filter(v => v.short === 'SAT');
    const majority  = buyVotes.length > sellVotes.length ? 'AL' : 'SAT';
    const minority  = majority === 'AL' ? sellVotes : buyVotes;

    // Risk Konseyi özel: o SAT diyorsa çok daha ağırlıklı
    const riskCouncil     = councilVotes.find(v => v.id === 'RISK');
    const riskOpposing    = riskCouncil && riskCouncil.short !== majority;
    const riskScore       = riskCouncil?.score ?? 50;
    const riskVetoStrong  = riskOpposing && riskScore <= 38; // Risk çok düşük = veto

    // Muhalif konseylerin ortalama gücü
    const minorityAvgScore = minority.length
      ? minority.reduce((s, v) => s + (v.score ?? 50), 0) / minority.length
      : 0;

    // Consensus gücü
    const consensusRatio = Math.max(buyVotes.length, sellVotes.length) / (councilVotes.length || 1);

    let score = clamp(
      consensusRatio * 70 +
      (minority.length === 0 ? 20 : 0) -
      (riskVetoStrong ? 35 : riskOpposing ? 15 : 0) -
      (minorityAvgScore > 65 ? 15 : minorityAvgScore > 50 ? 8 : 0)
    );

    const detail = minority.length === 0
      ? `Tam konsensüs — tüm konsey ${majority}`
      : `${majority} çoğunluk (${Math.max(buyVotes.length, sellVotes.length)}/${councilVotes.length}) | Muhalif: ${minority.map(v => v.id).join(', ')}${riskVetoStrong ? ' | 🚨 Risk Konseyi VETO' : ''}`;

    return {
      passed:  score >= 50 && !riskVetoStrong,
      score:   Math.round(score),
      label:   'Muhalefet',
      detail,
      warning: riskVetoStrong
        ? `Risk Konseyi güçlü itiraz (score: ${riskScore}) — DİP ŞÜPHELI`
        : minority.length > 1 ? `${minority.length} konsey muhalefet` : null,
      riskVeto: riskVetoStrong,
    };
  }
}

/**
 * KATMAN 3 — LİKİDİTE TUTARLILIK KONTROLÜ
 * Sinyal yönünde likidite desteği var mı?
 * Stop hunt riski gerçekten yok mu?
 * Mıknatıs bölgesine yakın mı, uzak mı?
 */
class LiquidityConsistencyCheck {
  verify(councilVotes, marketData) {
    const mags      = marketData?.mags;
    const stopHunts = marketData?.stopHunts  || [];
    const liqSens   = marketData?.liquiditySens || [];
    const direction = councilVotes?.filter(v => v.short === 'AL').length > (councilVotes?.length || 1) / 2 ? 'AL' : 'SAT';

    let score = 55; // başlangıç nötr

    // Mıknatıs analizi
    if (mags) {
      const nearMag = direction === 'AL' ? mags.dn?.[0] : mags.up?.[0]; // AL için aşağı mıknatıs, SAT için yukarı
      if (nearMag) {
        // Mıknatıs yakında ve güçlüyse → dip daha güvenilir (fiyat oraya çekilip dönmüş)
        if (nearMag.dist <= 0.5 && nearMag.strength >= 60) score += 15;
        else if (nearMag.dist <= 1.0) score += 7;
        // stopProb yüksekse → stop hunt hâlâ aktif olabilir
        if (nearMag.stopProb >= 65) score -= 18;
        else if (nearMag.stopProb >= 50) score -= 8;
      }
    }

    // Stop hunt aktif mi?
    if (stopHunts.length > 0) {
      score -= Math.min(stopHunts.length * 12, 30);
    }

    // Likidite duyarlılığı yüksek coinler varsa şüpheli
    const highRisk = liqSens.filter(l => l.riskLevel === 'YÜKSEK').length;
    score -= highRisk * 6;

    // Orderbook yönü
    const obImbalance = marketData?.obImbalance ?? 50;
    if (direction === 'AL') {
      score += obImbalance >= 60 ? 12 : obImbalance <= 40 ? -12 : 0;
    } else {
      score += obImbalance <= 40 ? 12 : obImbalance >= 60 ? -12 : 0;
    }

    score = clamp(score);

    return {
      passed:  score >= 50,
      score:   Math.round(score),
      label:   'Likidite Tutarlılık',
      detail:  `Stop hunt: ${stopHunts.length} | OB imbalance: %${Math.round(obImbalance)} | Yüksek risk liq: ${highRisk}`,
      warning: stopHunts.length > 0 ? `${stopHunts.length} aktif stop hunt — likidite riski var` : null,
    };
  }
}

/**
 * KATMAN 4 — BTC UYUM KONTROLÜ
 * AL sinyali BTC yükselirken mi verildi?
 * BTC düşerken AL sinyali şüphelidir.
 * BTC dominance trendi de kontrol edilir.
 */
class BTCCompatibilityCheck {
  verify(councilVotes, marketData) {
    const btcChange  = marketData?.btcChange  ?? 0;
    const btcRsi     = marketData?.btcRsi     ?? 50;
    const btcTrend   = marketData?.btcTrend   || 'neutral'; // 'up' | 'down' | 'neutral'
    const direction  = councilVotes?.filter(v => v.short === 'AL').length > (councilVotes?.length || 1) / 2 ? 'AL' : 'SAT';

    let score = 55;

    if (direction === 'AL') {
      // BTC güçlüyse AL daha güvenli
      if (btcChange >= 1.5)   score += 20;
      else if (btcChange >= 0) score += 10;
      else if (btcChange >= -1) score -= 5;
      else if (btcChange >= -3) score -= 18; // BTC düşerken AL = riskli
      else                      score -= 30; // BTC sert düşüş = çok riskli

      // BTC RSI aşırı satım bölgesindeyse ve AL sinyali = güvenilir dip
      if (btcRsi < 32)       score += 14; // BTC de dipte = gerçek dip
      else if (btcRsi < 42)  score += 7;
      else if (btcRsi > 72)  score -= 10; // BTC aşırı alımda = tepki düşüşü olabilir

      // BTC trend
      if (btcTrend === 'up')      score += 8;
      else if (btcTrend === 'down') score -= 15;
    } else {
      // SAT yönü için BTC uyumu ters
      if (btcChange <= -1.5)  score += 20;
      else if (btcChange <= 0) score += 8;
      else if (btcChange > 0)  score -= 15;
    }

    score = clamp(score);
    const uyumlu = direction === 'AL' ? btcChange >= -1 : btcChange <= 1;

    return {
      passed:  score >= 45,
      score:   Math.round(score),
      label:   'BTC Uyumu',
      detail:  `BTC: ${btcChange >= 0 ? '+' : ''}${btcChange.toFixed(2)}% | RSI: ${btcRsi.toFixed(0)} | Trend: ${btcTrend} | Uyum: ${uyumlu ? '✓' : '✗'}`,
      warning: !uyumlu && score < 45
        ? `BTC ${direction === 'AL' ? 'düşerken' : 'yükselirken'} ${direction} sinyali — dikkatli ol`
        : null,
    };
  }
}

/**
 * KATMAN 5 — VOLATİLİTE ONAYI
 * Aşırı volatilitede sinyaller güvenilir mi?
 * Vol rejimi normal mi, kaotik mi?
 * ATR tabanlı fiyat aralığı analizi.
 */
class VolatilityApprovalCheck {
  verify(councilVotes, marketData) {
    const volRegime   = marketData?.volRegime    || 'normal'; // 'low' | 'normal' | 'high' | 'chaos'
    const atrPct      = marketData?.atrPct       ?? 0.02;    // ATR / fiyat oranı
    const extremeCoins = marketData?.extremeCoins ?? 0;      // ±8%+ hareket eden coin sayısı
    const totalCoins  = marketData?.totalCoins   ?? 100;

    let score = 65;

    // Volatilite rejimi
    if (volRegime === 'low')    score += 15; // düşük volatilite = temiz sinyal
    else if (volRegime === 'normal') score += 5;
    else if (volRegime === 'high')   score -= 15;
    else if (volRegime === 'chaos')  score -= 35; // kaotik = sinyal güvenilmez

    // ATR oranı: çok yüksekse (>%3) tehlikeli
    if (atrPct > 0.05)        score -= 25;
    else if (atrPct > 0.03)   score -= 12;
    else if (atrPct < 0.01)   score += 10; // çok düşük ATR = sıkışma (patlama öncesi?)

    // Piyasanın genel durumu: çok fazla coin uçuyorsa kaotik
    const extremeRatio = extremeCoins / (totalCoins || 1);
    if (extremeRatio > 0.3)   score -= 20;
    else if (extremeRatio > 0.15) score -= 8;

    score = clamp(score);

    const volLabel = volRegime === 'low' ? '🟢 Düşük' : volRegime === 'normal' ? '🟡 Normal' :
                     volRegime === 'high' ? '🟠 Yüksek' : '🔴 Kaotik';

    return {
      passed:  score >= 45 && volRegime !== 'chaos',
      score:   Math.round(score),
      label:   'Volatilite Onayı',
      detail:  `Vol Rejimi: ${volLabel} | ATR/Fiyat: %${(atrPct * 100).toFixed(2)} | Extreme coin: ${extremeCoins}/${totalCoins}`,
      warning: volRegime === 'chaos'
        ? 'Kaotik volatilite — TÜM SİNYALLER GÜVENİLMEZ'
        : atrPct > 0.04 ? 'Yüksek ATR — stop hunt riski artmış' : null,
    };
  }
}

/**
 * KATMAN 6 — MUM FORMASYON ONAYI (YENİ)
 * Son mumda dönüş sinyali var mı?
 * Hammer, Engulfing, Doji, Morning Star gibi klasik dip formasyonları.
 * Coin'in kendi kline verisine bakılır.
 */
class CandleFormationCheck {
  verify(councilVotes, marketData) {
    const klines = marketData?.klines || [];
    if (klines.length < 3) {
      return { passed: true, score: 50, label: 'Mum Formasyonu', detail: 'Kline verisi yetersiz' };
    }

    const n    = klines.length;
    const c0   = klines[n-1]; // son mum
    const c1   = klines[n-2]; // bir önceki
    const c2   = klines[n-3]; // iki önceki

    const open0  = c0.o ?? c0.open  ?? c0.c ?? 0;
    const close0 = c0.c ?? c0.close ?? 0;
    const high0  = c0.h ?? c0.high  ?? c0.c ?? 0;
    const low0   = c0.l ?? c0.low   ?? c0.c ?? 0;

    const open1  = c1.o ?? c1.open  ?? c1.c ?? 0;
    const close1 = c1.c ?? c1.close ?? 0;
    const high1  = c1.h ?? c1.high  ?? c1.c ?? 0;
    const low1   = c1.l ?? c1.low   ?? c1.c ?? 0;

    const body0   = Math.abs(close0 - open0);
    const range0  = high0 - low0 || 0.0001;
    const lWick0  = Math.min(open0, close0) - low0;  // alt gölge
    const uWick0  = high0 - Math.max(open0, close0); // üst gölge
    const bull0   = close0 >= open0;

    const body1   = Math.abs(close1 - open1);
    const bull1   = close1 >= open1;

    let formScore = 50;
    const patterns = [];

    // HAMMER — alt gölge uzun, küçük gövde, düşüş sonrası = bullish reversal
    const isHammer = lWick0 >= body0 * 2.0 && uWick0 <= body0 * 0.5 && !bull1;
    if (isHammer) { formScore += 22; patterns.push('Hammer 🔨'); }

    // INVERTED HAMMER / SHOOTING STAR — üst gölge uzun
    const isInvHammer = uWick0 >= body0 * 2.0 && lWick0 <= body0 * 0.5 && !bull1;
    if (isInvHammer) { formScore += 12; patterns.push('Ters Hammer'); }

    // BULLISH ENGULFING — önceki ayı mumu, şimdiki onu tamamen yuttu
    const isBullEngulf = bull0 && !bull1 && close0 > open1 && open0 < close1;
    if (isBullEngulf) { formScore += 25; patterns.push('Boğa Yutması 🟢'); }

    // DOJI — gövde çok küçük = kararsızlık → dip onayı için pozitif
    const isDoji = body0 < range0 * 0.08;
    if (isDoji && !bull1) { formScore += 10; patterns.push('Doji'); }

    // MORNING STAR — 3 mum: düşüş + doji + yükseliş
    if (klines.length >= 3) {
      const bull2 = (c2.c ?? 0) >= (c2.o ?? 0);
      const isMorningStar = !bull2 && isDoji && bull0 && close0 > (open2_close2(c2));
      if (isMorningStar) { formScore += 28; patterns.push('Morning Star ⭐'); }
    }

    // CONSECUTIVE BEARISH — 3+ ardışık düşüş mumu + şimdi yükseliş = olası dip
    const closes = klines.slice(-5).map(k => k.c ?? k.close ?? 0);
    const consec = closes.slice(0, -1).every((c, i) => i === 0 || c < closes[i-1]);
    if (consec && bull0) { formScore += 15; patterns.push('Ardışık Düşüş Dönüşü'); }

    formScore = clamp(formScore);

    return {
      passed:   formScore >= 55,
      score:    Math.round(formScore),
      label:    'Mum Formasyonu',
      detail:   patterns.length ? `Formasyon: ${patterns.join(', ')}` : 'Belirgin dönüş formasyonu yok',
      patterns,
      warning:  formScore < 45 ? 'Dönüş formasyonu tespit edilemedi — dip teyidi zayıf' : null,
    };
  }
}
function open2_close2(c) { return Math.abs((c.o ?? 0) - (c.c ?? 0)) / 2 + Math.min(c.o ?? 0, c.c ?? 0); }

/**
 * KATMAN 7 — HACİM DİP ONAYI (YENİ)
 * Gerçek dipler yüksek hacimle gelir.
 * Düşük hacimli "dip" sahte dipdir.
 * Hacim z-score ve eğilimi analiz edilir.
 */
class VolumeDipCheck {
  verify(councilVotes, marketData) {
    const klines = marketData?.klines || [];
    if (klines.length < 8) {
      return { passed: true, score: 52, label: 'Hacim Dip Onayı', detail: 'Yeterli veri yok' };
    }

    const vols    = klines.map(k => k.v ?? k.volume ?? 0);
    const n       = vols.length;
    const curVol  = vols[n - 1];
    const avgVol  = vols.slice(-20).reduce((a, b) => a + b, 0) / Math.min(20, vols.length);
    const volRatio = avgVol > 0 ? curVol / avgVol : 1;

    // Son 5 mumun hacim trendi (artıyor mu?)
    const recent5  = vols.slice(-5);
    const volTrend = recent5.every((v, i) => i === 0 || v >= recent5[i-1] * 0.85)
      ? 'artıyor' : recent5.every((v, i) => i === 0 || v <= recent5[i-1] * 1.15)
      ? 'azalıyor' : 'karışık';

    // Dip anında hacim spike var mı? (son 3 mum içinde en yüksek hacim)
    const last3Vols = vols.slice(-3);
    const spikeInLast3 = last3Vols.some(v => v > avgVol * 1.8);

    let score = 50;

    // Hacim oranı
    if (volRatio >= 2.5)      score += 28; // çok güçlü hacim = gerçek dip
    else if (volRatio >= 1.5) score += 18;
    else if (volRatio >= 1.0) score += 5;
    else if (volRatio >= 0.6) score -= 10; // zayıf hacim
    else                      score -= 22; // çok zayıf = sahte dip

    // Hacim trendi
    if (volTrend === 'artıyor')  score += 12;
    else if (volTrend === 'azalıyor') score -= 10;

    // Dip bölgesinde spike
    if (spikeInLast3) score += 15;

    score = clamp(score);

    return {
      passed:  score >= 50,
      score:   Math.round(score),
      label:   'Hacim Dip Onayı',
      detail:  `Vol oran: x${volRatio.toFixed(2)} | Trend: ${volTrend} | Spike: ${spikeInLast3 ? '✓' : '✗'}`,
      warning: volRatio < 0.7
        ? 'Hacim çok düşük — dip teyidi yok, sahte dip olabilir'
        : volTrend === 'azalıyor' && !spikeInLast3 ? 'Hacim azalıyor — güç yetersiz' : null,
    };
  }
}

/**
 * KATMAN 8 — ÇOKLU ZAMAN DİLİMİ UYUMU (YENİ)
 * 1dk dipte iken 15dk, 1h, 4h trendiyle uyumlu mu?
 * Üst zaman dilimi koyuyor direnci yoksa çok daha güvenli.
 */
class MultiTimeframeCheck {
  verify(councilVotes, marketData) {
    const mtf = marketData?.mtf || {};
    // mtf.m15: { rsi, trend, ema: 'above'|'below', bb: 'low'|'mid'|'high' }
    // mtf.h1:  { ... }
    // mtf.h4:  { ... }

    const direction = councilVotes?.filter(v => v.short === 'AL').length > (councilVotes?.length || 1) / 2 ? 'AL' : 'SAT';

    let score = 55;
    const details = [];

    // 15 dakika kontrolü
    if (mtf.m15) {
      const m15ok = direction === 'AL'
        ? (mtf.m15.rsi ?? 50) < 55 && mtf.m15.trend !== 'down'
        : (mtf.m15.rsi ?? 50) > 45 && mtf.m15.trend !== 'up';
      score += m15ok ? 12 : -10;
      details.push(`15m: ${m15ok ? '✓' : '✗'}`);
    }

    // 1 saat kontrolü
    if (mtf.h1) {
      const h1ok = direction === 'AL'
        ? mtf.h1.ema !== 'below' && (mtf.h1.rsi ?? 50) < 65
        : mtf.h1.ema !== 'above' && (mtf.h1.rsi ?? 50) > 35;
      score += h1ok ? 15 : -18; // 1h daha ağırlıklı
      details.push(`1h: ${h1ok ? '✓' : '✗'}`);
    }

    // 4 saat kontrolü — en ağırlıklı
    if (mtf.h4) {
      const h4ok = direction === 'AL'
        ? mtf.h4.trend !== 'down' && mtf.h4.bb !== 'high'
        : mtf.h4.trend !== 'up'  && mtf.h4.bb !== 'low';
      const h4Bonus = h4ok ? 20 : -25;
      score += h4Bonus;
      details.push(`4h: ${h4ok ? '✓' : '✗'}`);
    }

    // MTF verisi yoksa nötr
    if (!mtf.m15 && !mtf.h1 && !mtf.h4) {
      return { passed: true, score: 55, label: 'MTF Uyumu', detail: 'MTF verisi yok — nötr' };
    }

    score = clamp(score);

    return {
      passed:  score >= 50,
      score:   Math.round(score),
      label:   'MTF Uyumu',
      detail:  details.join(' | ') || 'MTF verisi kısmi',
      warning: score < 40 ? `Üst zaman dilimi karşı yönde — dip girişi riskli` : null,
    };
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// ANA MOTOR — DeepApprovalEngine
// ═══════════════════════════════════════════════════════════════════════════════

export class DeepApprovalEngine {
  constructor() {
    this.checks = [
      new TimeAlignmentCheck(),
      new OppositionCheck(),
      new LiquidityConsistencyCheck(),
      new BTCCompatibilityCheck(),
      new VolatilityApprovalCheck(),
      new CandleFormationCheck(),
      new VolumeDipCheck(),
      new MultiTimeframeCheck(),
    ];

    // Her katmanın ağırlığı (toplam = 1.0)
    this.weights = [
      0.08,  // Zaman uyumu
      0.18,  // Muhalefet (en kritik)
      0.14,  // Likidite tutarlılık
      0.14,  // BTC uyumu
      0.12,  // Volatilite
      0.14,  // Mum formasyonu
      0.12,  // Hacim dip
      0.08,  // MTF
    ];
  }

  /**
   * Ana onay fonksiyonu
   * @param {Array}  councilVotes  — [{id, score, short, action, timestamp}]
   * @param {object} marketData    — {btcChange, btcRsi, mags, klines, mtf, ...}
   * @returns {object} Tam onay raporu
   */
  approve(councilVotes, marketData) {
    const results = this.checks.map((check, i) => {
      try {
        return check.verify(councilVotes, marketData);
      } catch (e) {
        return { passed: true, score: 50, label: `Katman ${i+1}`, detail: `Hata: ${e.message}` };
      }
    });

    // Ağırlıklı skor
    const weightedScore = results.reduce((s, r, i) => s + r.score * this.weights[i], 0);
    const dipScore      = Math.round(clamp(weightedScore));

    // Kaç katman geçti?
    const passedCount = results.filter(r => r.passed).length;
    const totalCount  = results.length;

    // Kritik başarısızlık: Muhalefet veya Volatilite'den biri tamamen çökmüşse
    const criticalFail = results[1]?.riskVeto ||          // Risk veto
                         results[4]?.score < 20 ||        // Kaotik volatilite
                         results[6]?.score < 25;          // Sıfır hacim

    // Uyarılar
    const warnings = results
      .map(r => r.warning)
      .filter(Boolean);

    // Nihai karar
    let decision, decisionColor, confidence;
    if (criticalFail) {
      decision = 'KRİTİK RED';
      decisionColor = '#ff0055';
      confidence = Math.min(dipScore, 25);
    } else if (dipScore >= 75 && passedCount >= 6) {
      decision = 'GÜÇLÜ DİP — GİR';
      decisionColor = '#00ff88';
      confidence = dipScore;
    } else if (dipScore >= 58 && passedCount >= 5) {
      decision = 'DİP ONAYLI — DİKKATLİ GİR';
      decisionColor = '#00cc66';
      confidence = dipScore;
    } else if (dipScore >= 42) {
      decision = 'ŞÜPHELİ DİP — BEKLE';
      decisionColor = '#ffcc00';
      confidence = dipScore;
    } else {
      decision = 'DİP DEĞİL — KAPI KAPALI';
      decisionColor = '#ff3366';
      confidence = dipScore;
    }

    // TP / SL hesapla (varsa ATR)
    const atrPct   = marketData?.atrPct || 0.02;
    const price    = marketData?.price  || 0;
    const tp1      = price > 0 ? parseFloat((price * (1 + atrPct * 1.5)).toFixed(8)) : null;
    const tp2      = price > 0 ? parseFloat((price * (1 + atrPct * 3.0)).toFixed(8)) : null;
    const sl       = price > 0 ? parseFloat((price * (1 - atrPct * 1.2)).toFixed(8)) : null;
    const riskReward = sl && tp1 && price ? parseFloat(((tp1 - price) / (price - sl)).toFixed(2)) : null;

    return {
      // Skor & karar
      dipScore,
      confidence,
      decision,
      decisionColor,
      approved:     dipScore >= 58 && !criticalFail,
      suspicious:   dipScore >= 42 && dipScore < 58,
      rejected:     dipScore < 42  || criticalFail,
      criticalFail,
      // Katman detayları
      checks:       results,
      passedCount,
      totalCount,
      passRate:     Math.round(passedCount / totalCount * 100),
      // Uyarılar
      warnings,
      // TP / SL
      price, tp1, tp2, sl, riskReward,
      // Özet
      summary: `${passedCount}/${totalCount} katman geçti | ${warnings.length > 0 ? warnings[0] : 'Uyarı yok'}`,
      timestamp: Date.now(),
    };
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// TÜM COİNLER İÇİN TOPLU TARAMA
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Tüm enrichedCoins için dip onaylayıcı çalıştırır.
 * runAllScanners() çıktısıyla doğrudan çalışır.
 *
 * @param {object} scanResults  — runAllScanners() çıktısı
 * @param {object} extras       — { klineMap, mags, obImbalance, mtfData }
 * @returns {{ confirmed, suspicious, rejected, all }}
 */
export function runBottomConfirmation(scanResults, extras = {}) {
  const engine = new DeepApprovalEngine();
  const {
    enrichedCoins = [],
    btcChange     = 0,
    stopHunts     = [],
    liquiditySens = [],
  } = scanResults;

  const {
    klineMap    = {},
    mags        = null,
    obImbalance = 50,
    mtfData     = {},
  } = extras;

  // Sadece potansiyel dip adaylarına bak:
  // RSI < 45 veya son 24s değişim < -3% veya BB pozisyonu < 0.35
  const candidates = enrichedCoins.filter(c =>
    (c.rsi != null && c.rsi < 48) ||
    (c.change_24h != null && c.change_24h < -2.5) ||
    (c.bb?.position != null && c.bb.position < 0.38)
  );

  // ATR hesapla
  function getAtrPct(coin) {
    const klines = klineMap[coin.symbol] || [];
    if (klines.length < 15) return 0.02;
    const atrArr = klines.slice(1).map((k, i) => {
      const h = k.h ?? k.price, l = k.l ?? k.price, pc = klines[i].c ?? klines[i].price ?? 0;
      return Math.max((h - l), Math.abs(h - pc), Math.abs(l - pc));
    });
    const atrVal = atrArr.slice(-14).reduce((a,b) => a+b, 0) / 14;
    return coin.price > 0 ? atrVal / coin.price : 0.02;
  }

  // Volatilite rejimi tahmini
  function getVolRegime(coin) {
    const atrPct = getAtrPct(coin);
    if (atrPct > 0.05)  return 'chaos';
    if (atrPct > 0.03)  return 'high';
    if (atrPct < 0.008) return 'low';
    return 'normal';
  }

  const results = candidates.map(coin => {
    const klines  = klineMap[coin.symbol] || [];
    const atrPct  = getAtrPct(coin);

    // Konsey oylarını simüle et (enriched coin verisinden)
    const councilVotes = [
      { id:'ALPHA', score: coin.rsi != null ? (coin.rsi < 35 ? 72 : coin.rsi < 50 ? 60 : 42) : 50,
        short: coin.trendUp ? 'AL' : 'BEKLE', timestamp: Date.now() },
      { id:'FLOW',  score: (coin.volumeZScore ?? 0) > 0.5 ? 65 : 48,
        short: (coin.macd?.bullish) ? 'AL' : 'BEKLE', timestamp: Date.now() },
      { id:'RISK',  score: stopHunts.some(s => s.symbol === coin.symbol?.replace('/USDT','')) ? 30 : 62,
        short: 'BEKLE', timestamp: Date.now() },
      { id:'MACRO', score: btcChange > 0 ? 60 : btcChange > -2 ? 50 : 35,
        short: btcChange > -1 ? 'AL' : 'BEKLE', timestamp: Date.now() },
    ];

    const marketData = {
      btcChange,
      btcRsi:        extras.btcRsi ?? 50, // Dashboard'dan gerçek BTC RSI gelir
      btcTrend:      btcChange > 1 ? 'up' : btcChange < -1 ? 'down' : 'neutral',
      mags,
      klines,
      stopHunts:     stopHunts.filter(s => s.symbol === coin.symbol?.replace('/USDT','')),
      liquiditySens: liquiditySens.filter(l => l.symbol === coin.symbol?.replace('/USDT','')),
      obImbalance,
      atrPct,
      volRegime:     getVolRegime(coin),
      extremeCoins:  enrichedCoins.filter(c => Math.abs(c.change_24h || 0) > 8).length,
      totalCoins:    enrichedCoins.length,
      mtf:           mtfData[coin.symbol] || {},
      price:         coin.price || 0,
    };

    const result = engine.approve(councilVotes, marketData);

    return {
      symbol:       coin.symbol?.replace('/USDT','') || coin.name,
      fullSymbol:   coin.symbol,
      price:        coin.price || 0,
      change24h:    coin.change_24h || 0,
      rsi:          coin.rsi || 50,
      bbPosition:   coin.bb?.position || 0.5,
      volumeZScore: coin.volumeZScore || 0,
      // Onay sonucu
      ...result,
    };
  });

  // Sırala ve grupla
  const sorted    = results.sort((a, b) => b.dipScore - a.dipScore);
  const confirmed = sorted.filter(r => r.approved && !r.criticalFail);
  const suspicious = sorted.filter(r => r.suspicious && !r.approved);
  const rejected  = sorted.filter(r => r.rejected || r.criticalFail);

  return {
    confirmed,   // GÜÇLÜ DİP + DİP ONAYLI
    suspicious,  // ŞÜPHELİ
    rejected,    // RED
    all:         sorted,
    stats: {
      total:        results.length,
      confirmed:    confirmed.length,
      suspicious:   suspicious.length,
      rejected:     rejected.length,
      topDip:       confirmed[0] || null,
    },
    timestamp: Date.now(),
  };
}
