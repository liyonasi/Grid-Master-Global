# GMG — DEVİR TESLİM v27
## Tarih: 2026-03-19 | 96 dosya | ~31.000+ satır

## YENİ OTURUMDA BAŞLARKEN
ZIP yükle → şunu yaz:
> "DEVIR_TESLIM_v27.md oku, kaldığın yerden devam et"

---

## v27'DE TAMAMLANANLAR

### 1. SystemMonitorPanel.jsx — API Key UI
- `APIKeyPanel` bileşeni eklendi (80 satır)
- Yeni sekme: **🔑 API Keys**
- 5 alan: Glassnode, CryptoQuant, CryptoPanic, Telegram Bot, Telegram Chat ID
- Özellikler: göster/gizle toggle, sil butonu, durum göstergesi (aktif/simüle)
- localStorage'a kayıt (`gmg_api_keys`)
- `onAPIKeysChange(keys)` callback prop eklendi

### 2. ScannerPage.jsx — LiquiditySpecial Gerçek Veri
- `jsonOutputs` prop eklendi (imza güncellendi)
- LiquiditySpecial paneli genişletildi:
  - Glassnode aktifse `◈ Glassnode` rozeti gösterilir
  - CryptoQuant aktifse `◈ CryptoQuant` rozeti gösterilir
  - Dark Pool kartında netFlow gösterilir (örn. `Net: +12.4M`)
  - OTC Akışı kartında CryptoQuant netFlow gösterilir

### 3. BacktestPanel.jsx — Multi-Period Karşılaştırma
- `MultiPeriodComparisonChart` bileşeni eklendi (140 satır)
  - 4 dönem aynı SVG'de normalize edilmiş % bazlı equity curve
  - Her dönem farklı renk: 1Ay=#00e87a, 3Ay=#00aaff, 6Ay=#ffc800, 1Yıl=#ff335c
  - Hover crosshair: dönem adı + anlık ROI tooltip
  - Normalize edilmiş % eksen (yatay grid çizgileri)
  - Alt özet satırı: ROI + Win Rate her dönem için
- Sonuçlar sayfasına `<MultiPeriodComparisonChart>` eklendi (PeriodCard'lardan önce)

### 4. alertMonitorEngines.js — Email + Web Push
- `EmailAlertEngine` sınıfı eklendi:
  - EmailJS SDK dinamik yükleme (CDN, backend yok)
  - `sendSignal({ symbol, action, score, confidence, tp1, sl, reason, phase })`
  - `sendRaw(subject, body)` — genel metin emaili
  - 1 dakika rate limit (spam önlem)
  - Token yoksa mock mod (console.log)
- `WebPushEngine` sınıfı eklendi:
  - `requestPermission()` — kullanıcı onayı iste
  - `send(title, body, options)` — tarayıcı bildirimi
  - `sendSignal(...)` — standart GMG sinyal formatı
  - `requireInteraction: true` → skor ≥ 75 sinyallerde otomatik
  - `getStatus()` — izin durumu sorgula
- Singleton export: `emailAlerts`, `webPush`

### 5. pineEngine.js — Parametre Optimizörü
- `runPineOptimizer(candles, options)` async fonksiyonu eklendi (100 satır):
  - `rfPerRange` × `rfMultRange` × `signalModes` grid search
  - Her kombinasyon için hafif backtest (TP/SL ile gerçek PnL)
  - `onProgress(pct)` callback ile %ilerleme
  - `compositeScore = winRate×0.6 + avgPnl×0.4` optimizasyon hedefi
  - Return: `{ bestParams, bestWinRate, bestAvgPnl, topN (top 5), results[] }`

### 6. BacktestPanel.jsx — Optimizör UI
- `optRunning`, `optProgress`, `optResult` state'leri eklendi
- `runOptimizer()` handler — pineEngine'den dinamik import
- Çalıştır butonu iki parçaya bölündü: **🔬 Backtest** + **⚙ OPTİMİZE**
- Optimizör sonuç kartı:
  - En iyi 3 parametre (rfPer, rfMult, signalMode) büyük gösterim
  - Win Rate + Ort. PnL özeti
  - Top 5 listesi (tüm kombinasyonların en iyileri)

### 7. Dashboard_v4.jsx — Tam Entegrasyon
- `EmailAlertEngine`, `WebPushEngine` import eklendi
- `emailRef`, `webPushRef` useRef ile singleton oluşturma
- `apiKeys` state — localStorage'dan başlatma
- `useEffect([apiKeys])` — keys değişince Telegram/Email engine'leri yeniden oluştur
- `runMasterCouncil()` çağrısına `glassnodeKey`, `cqKey` eklendi
- Sinyal gönderim bloğuna Email + WebPush eklendi (Telegram'ın yanına)
- `SystemMonitorPanel`'e `onAPIKeysChange` callback bağlandı

### 8. masterCouncil.js — Param Güncelleme
- `glassnodeKey = ''` ve `cqKey = ''` fonksiyon parametrelerine eklendi
- Dashboard'dan gelen değer **öncelikli**, env fallback **ikincil**
- `runLiquiditySpecialEngines` çağrısına `glassnodeKey`, `cqApiKey` geçildi

---

## API KURULUM KILAVUZU

### Glassnode (ücretsiz tier)
```
https://studio.glassnode.com → Kayıt → API → Key oluştur
Dashboard → System Monitor → 🔑 API Keys → Glassnode alanına yapıştır
```

### CryptoQuant (ücretsiz tier)
```
https://cryptoquant.com → Kayıt → API Keys → New Key
Dashboard → System Monitor → 🔑 API Keys → CryptoQuant alanına yapıştır
```

### EmailJS (200 email/ay ücretsiz)
```
https://emailjs.com → Kayıt → Add Service → Add Template
Template değişkenleri: {{to_email}} {{subject}} {{signal}} {{symbol}}
  {{action}} {{score}} {{confidence}} {{tp1}} {{sl}} {{reason}} {{time}}
Dashboard → System Monitor → 🔑 API Keys → EmailJS alanlarını doldur
```

### Telegram Bot
```
@BotFather → /newbot → token al
@userinfobot → Chat ID öğren
Dashboard → System Monitor → 🔑 API Keys → Telegram alanları
```

### Web Push (tarayıcı bildirimleri)
```
Otomatik — sinyal gelince tarayıcı izin ister
İzin verildikten sonra her BUY/SELL için bildirim gelir
Skor ≥ 75 → bildirim kapatılana kadar ekranda kalır
```

---

## SONRAKI OTURUMDA YAPILABİLECEKLER

### 1. liquiditySpecialEngines.js — glassnodeKey/cqKey prop desteği (30 dk)
```javascript
// Şu an runLiquiditySpecialEngines params almıyor, iç fonksiyonlara geçirilmiyor
// runDarkPoolEngineWithGlassnode ve runOTCFlowEngineWithAPI çağrısına key geçilmeli
export function runLiquiditySpecialEngines({ candles, orderbook, currentPrice,
  glassnodeKey = '', cqApiKey = '' }) {
  // darkPool = runDarkPoolEngineWithGlassnode(params, glassnodeKey)
  // otcFlow  = runOTCFlowEngineWithAPI(params, cqApiKey)
}
```

### 2. EmailJS template kurulumu yardımcı UI (20 dk)
- SystemMonitorPanel'de EmailJS alanları: Service ID, Template ID, Public Key, To Email
- Şu an sadece Glassnode/CryptoQuant/CryptoPanic/Telegram var

### 3. WebPush izin butonu Dashboard'a (15 dk)
- Topbar'da "🔔 Bildirimleri Aç" butonu
- `webPushRef.current.requestPermission()` çağırır

### 4. BacktestPanel — optimizör sonucunu pineParams'a otomatik uygula (20 dk)
- En iyi parametreleri bulduktan sonra `runTest()` otomatik tetikle

### 5. PineEngine — optimizör Web Worker'a taşı (45 dk)
- Şu an main thread'de çalışıyor, UI donabiliyor
- backtestWorker.js'e 'OPTIMIZE' mesaj tipi ekle

---

## DOSYA LİSTESİ (96 dosya)
### BU OTURUMDA DEĞİŞENLER
```
SystemMonitorPanel.jsx   — APIKeyPanel + 🔑 sekme (95 satır eklendi)
ScannerPage.jsx          — jsonOutputs prop + LiquiditySpecial Glassnode/CQ rozetleri
BacktestPanel.jsx        — MultiPeriodComparisonChart + Optimizör UI
alertMonitorEngines.js   — EmailAlertEngine + WebPushEngine (150 satır eklendi)
pineEngine.js            — runPineOptimizer (100 satır eklendi)
Dashboard_v4.jsx         — Email/WebPush entegrasyonu + apiKeys state
masterCouncil.js         — glassnodeKey/cqKey parametresi + liquiditySpecial geçişi
```

---

## KOD YAZIM KURALLARI
1. Tüm fonksiyonlar export edilmeli
2. Türkçe yorum satırları
3. clamp() ile 0-100 arası skor
4. Her modül { score, summary, timestamp } döndürür
5. Null-safe yazım (?. operatör)
6. Async/await ile API çağrıları
7. Her oturum sonunda ZIP yedek

---
Son güncelleme: 2026-03-19 | v27
Toplam dosya: 96 | ~31.000+ satır
