/**
 * GMG — SPECIALIST ENGINES (eksik modüller)
 * ===========================================
 * forexSpecialEngine, commoditySpecialEngine,
 * listingMonitorEngine, safeHavenEngine,
 * socialSentimentEngine, onchainEngine, etfFlowEngine, panicDetectorEngine
 */

const clamp = (v,lo=0,hi=100) => Math.max(lo, Math.min(hi, v||50));

// ═══════════════════════════════════════════════════════════════════════════════
// 1. FOREX SPECIAL ENGINE — Döviz Özel Analiz
// ═══════════════════════════════════════════════════════════════════════════════
export function runInterventionRiskEngine({ dxyChange=0, jpyChange=0, chfChange=0, bankMeetingSoon=false }={}) {
  const interventionRisk = (Math.abs(jpyChange)>2 || Math.abs(chfChange)>1.5) && bankMeetingSoon;
  let score = 50;
  if (interventionRisk) score -= 20;
  if (Math.abs(dxyChange)>1) score -= 10;
  return { score:Math.round(clamp(score)), interventionRisk, summary:`Müdahale riski: ${interventionRisk?'YÜKSEK':'DÜŞÜK'}` };
}

export function runRateDifferentialEngine({ usRate=5.25, euRate=4.5, jpRate=0.1 }={}) {
  const usdEurDiff = usRate - euRate;
  const usdJpyDiff = usRate - jpRate;
  // Yüksek faiz farkı → USD güçlü → kripto baskılı
  const bearishCrypto = usdEurDiff > 1 && usdJpyDiff > 4;
  let score = 50;
  if (bearishCrypto) score -= 15;
  if (usdEurDiff < 0.5) score += 8; // Faiz yaklaşıyor → risk-on
  return { score:Math.round(clamp(score)), usdEurDiff:parseFloat(usdEurDiff.toFixed(2)), usdJpyDiff:parseFloat(usdJpyDiff.toFixed(2)), bearishCrypto, summary:`Faiz farkı EUR: ${usdEurDiff.toFixed(2)} | JPY: ${usdJpyDiff.toFixed(2)}` };
}

export function runSessionVolatilityEngine(utcHour=new Date().getUTCHours()) {
  // NY+London overlap (13-16 UTC) = en yüksek volatilite
  const volLevel = (utcHour>=13&&utcHour<16)?'EKSTREM':(utcHour>=8&&utcHour<16)?'YÜKSEK':(utcHour>=0&&utcHour<8)?'DÜŞÜK':'ORTA';
  const volScore = volLevel==='EKSTREM'?80:volLevel==='YÜKSEK'?65:volLevel==='DÜŞÜK'?30:50;
  return { score:Math.round(volScore), volLevel, utcHour, cryptoBoost: volLevel==='EKSTREM'||volLevel==='YÜKSEK' };
}

export function runForexCorrelationEngine(pairChanges={}) {
  // Kripto ile korelasyonu yüksek çiftler
  const eurusd = pairChanges['EURUSD'] || 0;
  const btcCorr = eurusd * 8; // EURUSD yükselirse → kripto pozitif (~0.3-0.4 korelasyon)
  let score = clamp(50 + btcCorr);
  return { score:Math.round(score), eurusd, estimatedBtcCorrelation: parseFloat((btcCorr/100).toFixed(3)), summary:`EURUSD ${eurusd>=0?'+':''}${eurusd}% → Kripto tahmini etki: ${btcCorr>=0?'+':''}${btcCorr.toFixed(1)}%` };
}

export function runForexSpecialEngine(params={}) {
  const intervention = runInterventionRiskEngine(params.interventionData||{});
  const rateDiff     = runRateDifferentialEngine(params.rateData||{});
  const sessionVol   = runSessionVolatilityEngine(params.utcHour);
  const correlation  = runForexCorrelationEngine(params.pairChanges||{});
  const score = Math.round(clamp(intervention.score*0.25 + rateDiff.score*0.30 + sessionVol.score*0.20 + correlation.score*0.25));
  return {
    score, action: score>=60?'FOREX DESTEKLI':score<=40?'FOREX BASKILI':'NÖTR',
    modules: { intervention, rateDiff, sessionVol, correlation },
    summary: `Müdahale:${intervention.interventionRisk?'✗':'✓'} | Faiz Farkı:${rateDiff.usdEurDiff} | Seans:${sessionVol.volLevel}`,
    timestamp: Date.now(),
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// 2. COMMODITY SPECIAL ENGINE — Emtia Özel Analiz
// ═══════════════════════════════════════════════════════════════════════════════
export function runPreciousMetalMomentumEngine({ goldChange=0, silverChange=0, goldLevel=2000 }={}) {
  const rallyStrong = goldChange > 1.5 && silverChange > 2;
  const selloff     = goldChange < -1.5;
  let score = 50;
  if (rallyStrong) score -= 12; // Metal rallisi = risk-off = kripto kötü
  if (selloff)     score += 10; // Metal satışı = risk-on potansiyeli
  if (goldLevel > 2400) score -= 8; // Çok yüksek altın = ciddi risk-off
  return { score:Math.round(clamp(score)), goldChange, silverChange, goldLevel, rallyStrong, summary:`Altın ${goldChange>=0?'+':''}${goldChange}% @ $${goldLevel}` };
}

export function runEnergyDemandAnalyzer({ naturalGasChange=0, oilInventoryChange=0 }={}) {
  let score = 50;
  if (naturalGasChange > 3) score -= 8; // Enerji pahalılaşıyor = enflasyon riski
  if (oilInventoryChange < -3) score -= 5; // Stok azalıyor = petrol yükselir
  return { score:Math.round(clamp(score)), naturalGasChange, oilInventoryChange, summary:`Enerji baskısı: ${score<45?'YÜKSEK':'NORMAL'}` };
}

export function runOPECPolicyEngine({ opecMeetingSoon=false, cutExpected=false, supplyChange=0 }={}) {
  let score = 50;
  if (opecMeetingSoon && cutExpected) score -= 12; // Kesinti = petrol yükselir = enflasyon
  if (supplyChange > 0) score += 5; // Arz artışı = petrol düşer
  return { score:Math.round(clamp(score)), opecMeetingSoon, cutExpected, summary:`OPEC: ${cutExpected?'Kesinti bekleniyor':'Normal'}` };
}

export function runInflationHedgeEngine({ cpiChange=0, goldChange=0, btcChange7d=0 }={}) {
  // Yüksek enflasyon = BTC hedge etkisi artar
  const hedgeDemand = cpiChange > 0.4;
  let score = 50;
  if (hedgeDemand) score += 12;
  if (cpiChange > 0.8) score += 8; // Çok yüksek enflasyon
  return { score:Math.round(clamp(score)), hedgeDemand, cpiChange, summary:`Enflasyon hedge: ${hedgeDemand?'AKTİF':'PASIF'}` };
}

export function runCommoditySpecialEngine(params={}) {
  const metals  = runPreciousMetalMomentumEngine(params.metals||{});
  const energy  = runEnergyDemandAnalyzer(params.energy||{});
  const opec    = runOPECPolicyEngine(params.opec||{});
  const hedge   = runInflationHedgeEngine(params.inflation||{});
  const score   = Math.round(clamp(metals.score*0.30 + energy.score*0.25 + opec.score*0.25 + hedge.score*0.20));
  return {
    score, action: score>=60?'EMTIA DESTEKLI':score<=40?'EMTIA BASKILI':'NÖTR',
    modules: { metals, energy, opec, hedge },
    summary: `${metals.summary} | ${opec.summary}`,
    timestamp: Date.now(),
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// 3. LISTING MONITOR ENGINE — Yeni Listeleme Takibi
// ═══════════════════════════════════════════════════════════════════════════════
const listingCache = { items:[], lastFetch:0 };

export async function fetchNewListings() {
  const now = Date.now();
  if (now - listingCache.lastFetch < 300000) return listingCache.items; // 5dk cache
  try {
    const res  = await fetch('https://api.coingecko.com/api/v3/coins/list?include_platform=false');
    const data = await res.json();
    // Son 7 günde eklenen coinler (CoinGecko'da timestamp yok, simüle ediyoruz)
    listingCache.items = (data||[]).slice(-20).map(c => ({
      symbol: c.symbol?.toUpperCase(),
      name:   c.name,
      id:     c.id,
      isNew:  true,
      pumpRisk: Math.random() > 0.7, // Gerçekte volume spike ile tespit edilir
    }));
    listingCache.lastFetch = now;
    return listingCache.items;
  } catch {
    return [];
  }
}

export function runListingPumpDetector(symbol='', newListings=[]) {
  const found = newListings.find(l => l.symbol === symbol.replace('/USDT','').replace('USDT',''));
  if (!found) return { isNewListing:false, pumpRisk:false, warning:null };
  return {
    isNewListing: true,
    pumpRisk: found.pumpRisk,
    warning: found.pumpRisk ? `⚠ ${symbol} yeni listing + pump riski yüksek` : `${symbol} yeni listing — dikkatli ol`,
    score: found.pumpRisk ? 25 : 40, // Yeni listing = riskli
  };
}

export async function runListingMonitorEngine(watchlist=[]) {
  const listings = await fetchNewListings();
  const risks = watchlist.map(sym => runListingPumpDetector(sym, listings));
  return { listings, risks, highRiskCount: risks.filter(r=>r.pumpRisk).length, timestamp: Date.now() };
}

// ═══════════════════════════════════════════════════════════════════════════════
// 4. SAFE HAVEN FLOW ENGINE — Güvenli Liman Akışı
// ═══════════════════════════════════════════════════════════════════════════════
export function runSafeHavenFlowEngine({ goldChange=0, jpyChange=0, chfChange=0, usTreasuryChange=0, vixLevel=20 }={}) {
  // Safe haven varlıklar yükseliyorsa = risk-off
  const safeHavenScore = (
    (goldChange > 0.5 ? 2 : 0) +
    (jpyChange  > 0.3 ? 2 : 0) +
    (chfChange  > 0.3 ? 1 : 0) +
    (usTreasuryChange < -0.2 ? 1 : 0) + // Tahvil fiyatı düşüyor = yatırımcı kaçıyor
    (vixLevel > 25 ? 2 : vixLevel > 20 ? 1 : 0)
  );
  const isRiskOff = safeHavenScore >= 4;
  const isRiskOn  = safeHavenScore <= 1 && vixLevel < 16;
  let score = 50;
  if (isRiskOff) score -= 20;
  if (isRiskOn)  score += 15;
  return {
    score:Math.round(clamp(score)), safeHavenScore, isRiskOff, isRiskOn,
    goldChange, jpyChange, vixLevel,
    signal: isRiskOff ? '🔴 RISK-OFF — Güvenli liman talebi yüksek' : isRiskOn ? '🟢 RISK-ON — Güvenli liman satışı' : '🟡 NÖTR',
    cryptoImpact: isRiskOff ? 'OLUMSUZ' : isRiskOn ? 'OLUMLU' : 'NÖTR',
    timestamp: Date.now(),
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// 5. SOCIAL SENTIMENT ENGINE — Sosyal Medya Analizi
// ═══════════════════════════════════════════════════════════════════════════════
const sentimentKeywords = {
  bullish:  ['moon','pump','buy','long','hodl','bull','bullish','ath','rip','surge','🚀','💎','🟢'],
  bearish:  ['dump','sell','short','crash','bear','bearish','rekt','dead','rug','scam','🔴','📉'],
  panic:    ['crash','panic','fear','liquidation','margin call','emergency','collapse'],
  fomo:     ['don\'t miss','last chance','going up','breakout','100x','moonshot'],
};

export function analyzeSocialText(text='') {
  const t = text.toLowerCase();
  let bull=0, bear=0, panic=0, fomo=0;
  sentimentKeywords.bullish.forEach(w => { if(t.includes(w)) bull++; });
  sentimentKeywords.bearish.forEach(w => { if(t.includes(w)) bear++; });
  sentimentKeywords.panic.forEach(w   => { if(t.includes(w)) panic++; });
  sentimentKeywords.fomo.forEach(w    => { if(t.includes(w)) fomo++; });
  const total = bull + bear + 1;
  const sentiment = bull/total > 0.6 ? 'BULLISH' : bear/total > 0.6 ? 'BEARISH' : 'NÖTR';
  return { sentiment, bull, bear, panic, fomo, score: Math.round(clamp(50 + (bull-bear)*10)) };
}

export function runBotInflationDetector(posts=[]) {
  // Bot tespiti: çok kısa sürede benzer içerik
  if (posts.length < 5) return { botDetected:false, confidence:0 };
  const times = posts.map(p=>p.timestamp||0).sort();
  const avgInterval = times.length>1 ? (times[times.length-1]-times[0])/(times.length-1) : 9999;
  const botDetected = avgInterval < 2000; // 2 saniyeden hızlı = bot
  return { botDetected, avgIntervalMs: Math.round(avgInterval), confidence: botDetected ? 85 : 10 };
}

export function runFOMOPanicDetector({ sentimentScore=50, volumeSpike=false, priceChange=0 }={}) {
  const fomoActive  = sentimentScore > 75 && volumeSpike && priceChange > 5;
  const panicActive = sentimentScore < 25 && volumeSpike && priceChange < -5;
  let score = 50;
  if (fomoActive)  score -= 15; // FOMO = geç girme = risk
  if (panicActive) score += 10; // Panik = fırsat olabilir
  return { score:Math.round(clamp(score)), fomoActive, panicActive, summary: fomoActive?'⚠ FOMO TESPİT':panicActive?'📉 PANİK TESPİT':'NORMAL' };
}

export function runSocialSentimentEngine({ posts=[], symbol='', volumeSpike=false, priceChange=0 }={}) {
  const analyses    = posts.map(p => analyzeSocialText(p.text||p.content||''));
  const avgScore    = analyses.length ? Math.round(analyses.reduce((s,a)=>s+a.score,0)/analyses.length) : 50;
  const botCheck    = runBotInflationDetector(posts);
  const fomoPanic   = runFOMOPanicDetector({ sentimentScore:avgScore, volumeSpike, priceChange });
  const bullCount   = analyses.filter(a=>a.sentiment==='BULLISH').length;
  const bearCount   = analyses.filter(a=>a.sentiment==='BEARISH').length;
  const adjusted    = botCheck.botDetected ? 50 : avgScore; // Bot varsa nötrleştir
  return {
    score: Math.round(clamp(adjusted)),
    sentiment: adjusted>60?'POZİTİF':adjusted<40?'NEGATİF':'NÖTR',
    bullCount, bearCount, totalPosts: posts.length,
    botInflation: botCheck.botDetected,
    fomoActive: fomoPanic.fomoActive,
    panicActive: fomoPanic.panicActive,
    summary: `${symbol} sosyal: ${adjusted>60?'😊':adjusted<40?'😟':'😐'} ${bullCount}↑ ${bearCount}↓ ${botCheck.botDetected?'🤖BOT':''}`,
    timestamp: Date.now(),
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// 6. ONCHAIN ENGINE — Blockchain Analizi
// ═══════════════════════════════════════════════════════════════════════════════
export function runExchangeReserveEngine({ reserveChange7d=0, inflow24h=0, outflow24h=0 }={}) {
  // Borsaya giren coin = satış baskısı, çıkan = birikim
  const netFlow    = outflow24h - inflow24h;
  const isAccumulating = netFlow > 0; // Net çıkış = birikim
  let score = 50;
  if (reserveChange7d < -2) score += 15; // Rezerv azalıyor = birikim
  if (reserveChange7d > 2)  score -= 12; // Rezerv artıyor = satış riski
  if (isAccumulating)       score += 8;
  return { score:Math.round(clamp(score)), netFlow, isAccumulating, reserveChange7d, summary:`Borsa rezerv: ${reserveChange7d>=0?'+':''}${reserveChange7d}% | ${isAccumulating?'BİRİKİM':'DAĞITIM'}` };
}

export function runActiveAddressEngine({ activeAddresses=0, avgAddresses=0, change7d=0 }={}) {
  const aboveAvg = activeAddresses > avgAddresses * 1.1;
  let score = 50;
  if (aboveAvg) score += 10;
  if (change7d > 5)  score += 8;
  if (change7d < -10) score -= 10;
  return { score:Math.round(clamp(score)), activeAddresses, change7d, aboveAvg, summary:`Aktif adres: ${activeAddresses.toLocaleString()} (${change7d>=0?'+':''}${change7d}%)` };
}

export function runTransferSpikeEngine({ transferValue24h=0, avgTransferValue=0 }={}) {
  const spike = transferValue24h > avgTransferValue * 2;
  return { spike, ratio: avgTransferValue>0 ? parseFloat((transferValue24h/avgTransferValue).toFixed(2)):1, score: Math.round(clamp(50+(spike?15:0))), summary: spike?`⚠ Transfer spike: ${(transferValue24h/avgTransferValue).toFixed(1)}x ortalama`:'Normal transfer hacmi' };
}

export function runOnchainEngine(params={}) {
  const reserve   = runExchangeReserveEngine(params.reserveData||{});
  const addresses = runActiveAddressEngine(params.addressData||{});
  const transfer  = runTransferSpikeEngine(params.transferData||{});
  const score     = Math.round(clamp(reserve.score*0.40 + addresses.score*0.35 + transfer.score*0.25));
  return {
    score, action: score>=60?'ZİNCİR DESTEKLI':score<=40?'ZİNCİR BASKILI':'NÖTR',
    modules: { reserve, addresses, transfer },
    summary: `${reserve.summary} | ${addresses.summary}`,
    timestamp: Date.now(),
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// 7. ETF FLOW ENGINE — ETF Akışları
// ═══════════════════════════════════════════════════════════════════════════════
export function runETFFlowEngine({ btcETFInflow=0, btcETFOutflow=0, ethETFInflow=0, totalAUM=0 }={}) {
  const netFlow   = btcETFInflow - btcETFOutflow;
  const strongInflow = netFlow > 200; // $200M+ giriş = güçlü
  const outflowRisk  = btcETFOutflow > btcETFInflow * 1.5;
  let score = 50;
  if (strongInflow)  score += 20;
  if (netFlow > 0)   score += 8;
  if (outflowRisk)   score -= 15;
  if (btcETFOutflow > 500) score -= 10; // Büyük çıkış
  return {
    score: Math.round(clamp(score)),
    netFlow, strongInflow, outflowRisk,
    btcETFInflow, btcETFOutflow, totalAUM,
    signal: strongInflow ? '🟢 Güçlü ETF girişi' : outflowRisk ? '🔴 ETF çıkışı riski' : '🟡 Normal ETF akışı',
    summary: `BTC ETF net: $${netFlow}M | ${strongInflow?'GÜÇLÜ GİRİŞ':outflowRisk?'ÇIKIŞ RİSKİ':'NORMAL'}`,
    timestamp: Date.now(),
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// 8. PANIC DETECTOR ENGINE — Panik Tespiti
// ═══════════════════════════════════════════════════════════════════════════════
export function runPanicDetectorEngine({ priceChange=-5, volumeSpike=false, socialSentiment=50, fearGreedIndex=50, liquidationSpike=false }={}) {
  let panicScore = 0;
  if (priceChange < -5)  panicScore += 25;
  if (priceChange < -10) panicScore += 20;
  if (volumeSpike)       panicScore += 15;
  if (socialSentiment < 30) panicScore += 15;
  if (fearGreedIndex < 20)  panicScore += 15;
  if (liquidationSpike)  panicScore += 20;
  const panicLevel = panicScore >= 70 ? 'EKSTREM' : panicScore >= 45 ? 'YÜKSEK' : panicScore >= 25 ? 'ORTA' : 'DÜŞÜK';
  const isBuyOpportunity = panicScore >= 60; // Aşırı panik = potansiyel fırsat
  return {
    panicScore: Math.min(100, panicScore),
    panicLevel,
    isBuyOpportunity,
    score: Math.round(clamp(50 + (panicScore > 50 ? (panicScore-50)*0.6 : 0))), // Panik = fırsat skoru artar
    signal: panicLevel==='EKSTREM' ? '🚨 EKSTREM PANİK — Dikkatli fırsat penceresi' : panicLevel==='YÜKSEK' ? '⚠ Yüksek panik' : 'Normal',
    summary: `Panik: ${panicLevel} (${panicScore}/100) | ${isBuyOpportunity?'Potansiyel fırsat':'Normal'}`,
    timestamp: Date.now(),
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// CRYPTOPANIC API — Ücretsiz haber sentiment bağlantısı
// ═══════════════════════════════════════════════════════════════════════════════
const _cpCache = new Map();
const CP_TTL   = 5 * 60 * 1000; // 5dk cache

export async function fetchCryptoPanicNews(symbol = 'BTC', filter = 'hot') {
  const key    = `${symbol}_${filter}`;
  const cached = _cpCache.get(key);
  if (cached && Date.now() - cached.ts < CP_TTL) return cached.data;

  try {
    // Ücretsiz public endpoint — API key gerektirmez
    const url  = `https://cryptopanic.com/api/free/v1/posts/?auth_token=free&currencies=${symbol}&filter=${filter}&public=true`;
    const res  = await fetch(url, { signal: AbortSignal.timeout(6000) });
    if (!res.ok) throw new Error(`CryptoPanic HTTP ${res.status}`);
    const json = await res.json();
    const posts = (json.results || []).slice(0, 15).map(p => ({
      title:     p.title,
      text:      p.title, // analyzeSocialText için
      sentiment: (p.votes?.positive || 0) > (p.votes?.negative || 0) ? 'BULLISH' : 'BEARISH',
      positive:  p.votes?.positive  || 0,
      negative:  p.votes?.negative  || 0,
      source:    p.source?.title    || '',
      published: p.published_at,
      url:       p.url,
    }));
    _cpCache.set(key, { data: posts, ts: Date.now() });
    return posts;
  } catch(e) {
    console.warn('[CryptoPanic] hata:', e.message);
    return []; // Hata durumunda boş dön — mevcut sistem devam eder
  }
}

export async function runSocialSentimentWithAPI({ symbol = 'BTC', volumeSpike = false, priceChange = 0 } = {}) {
  const posts  = await fetchCryptoPanicNews(symbol, 'hot');
  const rising = await fetchCryptoPanicNews(symbol, 'rising').catch(() => []);
  const allPosts = [...posts, ...rising];

  // Mevcut engine ile birleştir
  const result = runSocialSentimentEngine({ posts: allPosts, symbol, volumeSpike, priceChange });

  return {
    ...result,
    source:   'CryptoPanic',
    postCount: allPosts.length,
    liveData:  allPosts.length > 0,
    topNews:   allPosts.slice(0, 3).map(p => ({ title: p.title, sentiment: p.sentiment, source: p.source })),
  };
}
