# GMG — DEVİR TESLİM v21
## Tarih: 2026-03-18 | ~27.342 satır | 89 dosya
## URL: http://46.224.185.115:8014/

---

## YENİ OTURUMA BAŞLARKEN
ZIP yükle → yaz: "DEVIR_TESLIM_v21.md oku, kaldığın yerden devam et"

---

## v21'DE TAMAMLANANLAR

### 1. macroAPIEngine.js — TAM YENİDEN YAZILDI
Artık gerçek veri çekiyor:

| Veri     | Kaynak 1      | Kaynak 2   | Kaynak 3       | Fallback |
|----------|---------------|------------|----------------|---------|
| DXY      | stooq (^dxy)  | FRED       | EUR/USD proxy  | 104.0   |
| US10Y    | stooq (10us.b)| FRED (DGS10)| —             | 4.3     |
| US2Y     | stooq (2us.b) | FRED (DGS2) | —             | 4.8     |
| VIX      | stooq (^vix)  | —          | BTC vol proxy  | 20      |
| GOLD     | stooq (xauusd)| metals.live| goldprice.org  | 2000    |
| OIL(WTI) | stooq (cl.f)  | Brent(brn.f)| —             | 75      |
| Fear&Greed| alternative.me| —         | —              | 50      |

Yeni exportlar:
- fetchDXYLevel()    → { value, change, source, ok }
- fetchUS10YYield()  → { value, change, source, ok }
- fetchUS2YYield()   → { value, change, source, ok }  ← YENİ
- fetchVIXLevel()    → { value, level, change, source, ok }  ← GERÇEK VIX
- fetchGoldPrice()   → { value, change, source, ok }  ← YENİ
- fetchOilPrice()    → { value, change, type, source, ok }  ← YENİ
- fetchFearGreed()   → { value, label, prev, change, ok }  ← GENİŞLETİLDİ
- fetchAllMacro()    → { dxy, us10y, us2y, vix, gold, oil, fearGreed, yieldSpread, isInvertedCurve, riskMode, riskScore, summary }  ← YENİ
- fetchMacroData()   → eskisi gibi { dxyLevel, us10yYield, ok }  ← GERİYE UYUMLU
- clearMacroCache(key?)  ← key ile tek varlık silinebilir
- testProxies()      ← var, değişmedi
- getMacroStatus()   → son çekme meta bilgisi  ← YENİ

Cache TTL: DXY/US10Y/US2Y=5dk, VIX=3dk, Gold/Oil=2dk, Fear=10dk

### 2. MultiMarketDashboard.jsx — YENİ DOSYA (841 satır)
Tüm piyasalar tek sayfada, mobil uyumlu:
- 6 sekme: Genel Bakış | Forex | Emtia | Endeksler | Tahvil | Makro
- Responsive: mobile=2 sütun, tablet=3 sütun, desktop=4+ sütun
- Genel Bakış: Kripto sinyal özeti (6 faktör), korelasyon tablosu
- Forex: DXY öne çıkan + 6 parite kartı, DXY-Kripto açıklaması
- Emtia: Altın + WTI büyük kart + 8 emtia kartı, etki açıklaması
- Endeksler: VIX öne çıkan + 7 endeks, korelasyon tablosu
- Tahvil: Tersine eğri uyarısı, getiri eğrisi SVG, 10Y/2Y/Spread
- Makro: 4 büyük gauge (Fear/VIX/DXY/Gold), Risk-ON/OFF banner

### 3. Dashboard_v4.jsx — 4. SAYFA EKLENDİ
- "04 — 🌍 Global Piyasalar" navigasyon butonu
- activePage === 'piyasalar' → <MultiMarketDashboard masterResult={masterResult} />

### 4. multiAssetEngine.js — EMTİA VE ENDEKSLERİ GENİŞLETİLDİ
Eski: 4 emtia (Au, Ag, WTI, Brent)
Yeni: 8 emtia (+ Platin, Doğalgaz, Bakır, Buğday)

Eski: 3 endeks (S&P, Nasdaq, VIX)
Yeni: 7 endeks (+ Dow, DAX, FTSE, Nikkei)

stooqMap güncellemeleri:
- XPTUSD → xptusd (Platin)
- GASUSD → ng.f (Doğalgaz vadeli)
- COPPUSD → hg.f (Bakır vadeli)
- WHTUSD → w.f (Buğday vadeli)
- DJIA → ^dji, DAX → ^dax, FTSE → ^ftse, NKY → ^nkx

### 5. newsMacroCouncil.js — DXY VE VIX GÜNCELLENDI
fetchDXY() artık macroAPIEngine.fetchDXYLevel()'i çağırıyor
fetchVIX() artık macroAPIEngine.fetchVIXLevel()'i çağırıyor
Her ikisi de fallback zinciri koruyor

---

## DASHBOARD SAYFA MİMARİSİ (v21)

01 — Grafik & Sinyal   → GMGChart + LiveAICouncilPanel + TP/SL
02 — Tarayıcılar       → ScannerPage (13 tarayıcı)
03 — Türev & Akış      → Likidasyon + Funding + Orderbook + Backtest
04 — 🌍 Global Piyasalar → MultiMarketDashboard (YENİ)

---

## MOBİL UYUMLULUK

MultiMarketDashboard.jsx mobil öncelikli tasarlandı:
- gridTemplateColumns: repeat(auto-fill, minmax(140px, 1fr))
- Tab bar: overflowX scroll, scrollbarWidth: none
- Gauge SVG: viewBox ile responsive
- Tüm kartlar: min-width 0, flex-wrap korumalı
- Yazı boyutu: 8-11px arası monospace (küçük ekranda okunur)

---

## SONRAKI OTURUMDA YAPILABİLECEKLER

### Öncelik 1 — fetchAllMacro Dashboard entegrasyonu
Dashboard_v4.jsx'te fetchMacroData() yerine fetchAllMacro() kullanılırsa:
- goldChange, oilChange masterCouncil'e gerçek geçilir
- vixLevel gerçek VIX olur (şu an sabit 50)

```javascript
// Dashboard_v4.jsx içinde (satır ~339):
// ESKİ:
const { dxyLevel, us10yYield } = await fetchMacroData()...
setMacroData({ dxyLevel, us10yYield });

// YENİ:
const macroAll = await fetchAllMacro().catch(() => null);
const dxyLevel   = macroAll?.dxy?.value   || 104.0;
const us10yYield = macroAll?.us10y?.value || 4.3;
setMacroData({
  dxyLevel, us10yYield,
  vixLevel:   macroAll?.vix?.value   || 50,
  goldChange: macroAll?.gold?.change  || 0,
  oilChange:  macroAll?.oil?.change   || 0,
  riskMode:   macroAll?.riskMode      || 'NEUTRAL',
  fearGreed:  macroAll?.fearGreed?.value || 50,
});
// masterCouncil çağrısında:
// vixLevel: macroData.vixLevel,
// goldChange: macroData.goldChange,
// oilChange: macroData.oilChange,
```

### Öncelik 2 — WebSocket batch subscription
Her coin için ayrı WS yerine tek stream:
wss://stream.binance.com/stream?streams=btcusdt@kline_5m/ethusdt@kline_5m/...

### Öncelik 3 — PWA / offline cache
service worker + son veriyi IndexedDB'de sakla

### Öncelik 4 — Kullanıcı ayarları localStorage
riskMode, selectedSymbol, activeTab localStorage'a kaydet

---

## DOSYALAR (89 adet)

Yeni/güncellenen:
  macroAPIEngine.js          ← TAM YENİDEN YAZILDI
  MultiMarketDashboard.jsx   ← YENİ (841 satır)
  Dashboard_v4.jsx           ← 4. sayfa eklendi
  multiAssetEngine.js        ← emtia/endeks genişletildi
  newsMacroCouncil.js        ← DXY/VIX gerçek kaynağa bağlandı

Değişmeyen: diğer 84 dosya

---
Son güncelleme: 2026-03-18 | v21 | 27.342 satır | 89 dosya
