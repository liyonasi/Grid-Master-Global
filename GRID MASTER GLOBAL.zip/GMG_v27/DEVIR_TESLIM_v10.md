# GMG — DEVİR TESLİM v10 — TAM SİSTEM
## Tarih: 2026-03-15
## Versiyon: v10 FINAL
## Hazırlayan: Claude (Anthropic)

---

## YENİ OTURUMA BAŞLARKEN — OKUMA SIRASI

1. Bu dosyayı oku (DEVIR_TESLIM_v10.md)
2. SISTEM_MIMARI.md oku
3. EKSIKLER_VE_SIRADAKILER.md oku
4. Kullanıcıya "Hazırım, devam edelim" de

---

## PROJE: GRID MASTER GLOBAL

Kripto piyasasında canlı veri, likidite, manipülasyon, teknik analiz,
AI karar ve coin bazlı planlama modüllerini tek ekranda toplayan
çok katmanlı piyasa karar destek platformu.

**URL:** http://46.224.185.115:8014/
**Stack:** React + Canvas + WebSocket + Binance/Bybit/OKX/Gate/KuCoin/MEXC/Kraken API

---

## DOSYA LİSTESİ VE GÖREVLERİ (21 dosya)

### ANA GİRİŞ NOKTASI
```
masterCouncil.js      — TÜM SİSTEMİ BAĞLAR. Bunu çağır.
                        runMasterCouncil({ candles, I, scanResults, ... })
                        → { action, label, score, confidence, riskLevel, ... }
```

### GRAFİK
```
GMGChart_v3.jsx       — Ana grafik bileşeni (51KB)
                        7 mum tipi: Candlestick, Heikin Ashi, Hollow, Bar, Çizgi, Alan, Renko
                        7 borsa: Binance, Bybit, OKX, Gate, KuCoin, MEXC, Kraken
                        7 osilatör: RSI, MACD, Stoch, ADX, CCI, MFI, OBV
                        Özellikler: Likidite mıknatısı, PB-AL/SAT, 4 Konsey overlay
                        State: localStorage'da (yenileme = sıfırlanmaz)
                        ⚠️ EKSIK: Pine çizgileri henüz eklenmedi (filtLine, srZones)
```

### BORSA API
```
exchangeAPI_multi.js  — 7 Borsa API + WebSocket
                        fetchBestKlines() — fallback zinciri
                        fetchAggregatedPrice() — 7 borsadan VWAP
                        MultiExchangeWS — otomatik fallback WebSocket
                        fetchOrderbook(), fetchFundingRates()
```

### KARAR MOTORLARI
```
pineEngine.js         — Pine Script indikatörünün JS karşılığı
                        runPineEngine(candles) → { rf, sr, pb, score, ... }
                        Range Filter + S/R Pivot Cluster + PB-AL/PB-SAT
                        Technical Council'a girdi sağlar

newsMacroCouncil.js   — News & Macro Council (async, API çağrısı yapar)
                        fetchFearGreed() — alternative.me
                        fetchDXY() — EUR/USD proxy
                        fetchVIX() — BTC volatilite proxy
                        fetchGlobalLiquidity() — CoinGecko
                        runNewsMacroCouncil() → konsey çıktısı

executionLayer.js     — Execution Layer (tüm filtreler)
                        falseSignalFilter() — konsey anlaşması + hacim
                        manipulationFilter() — stop hunt + spoofing
                        riskFilter() — VIX + funding + volatilite
                        applyRiskVeto() — KRİTİK risk = WAIT override
                        doubleConfirmProtocol() — Pine RF çift onay
                        runExecutionLayer() → final execution signal

engineCore.js         — 16 tarama modülü + eski 4 konsey
                        runAllScanners({ coins, btcChange, orderbookMap, klineMap })
                        runCouncils(scan) → { alpha, flow, risk, macro, final }

aiCouncilEngine.js    — AI konsey motoru (detaylı versiyon)
                        runAlphaCouncil(), runFlowCouncil(), runRiskCouncil(), runMacroCouncil()
                        runAllCouncils() → tüm konseyler

councilEngine.js      — Konsey karar motoru (basit versiyon)

intelligenceEngine.js — 16 tarama fonksiyonu
                        scalpTrapScanner, scalpLongScanner, scalpShortScanner
                        longReadyScanner, shortReadyScanner, explosionReadyScanner
                        suddenDumpScanner, suddenPumpScanner
                        stealthRisingScanner, stealthFallingScanner
                        stopHuntScanner, btcRelativeStrong, btcRelativeWeak
                        liquiditySensitivityScanner, multiExchangePumpDump
                        sessionRiskScanner

chartModule.js        — Pattern recognition + historical match
                        detectCandlePatterns() — 15 mum formasyonu
                        detectChartFormations() — 17 grafik formasyonu
                        findHistoricalMatch() — kosinüs benzerliği
                        detectSupportResistance()
                        marketMakerDirectionEstimate()
                        runChartModule() → tüm çıktı

moduleRegistry.js     — 95 modülün 4 konseye dağılımı
                        ALPHA_COUNCIL: 24 modül (teknik + grafik)
                        FLOW_COUNCIL:  24 modül (likidite + OB)
                        RISK_COUNCIL:  24 modül (manipülasyon + risk)
                        MACRO_COUNCIL: 23 modül (kripto + AI)

indexEngine.js        — Index modülleri
                        runVIXVolatilityEngine()
                        runSectorRotationEngine()
                        runIndexBreadthEngine()

alertMonitorEngines.js — Alert sistemi
                        runScalpSignalAlert()
                        runTrapAlert()
                        runFinalCouncilAlert()
                        sendWebPushAlert()
```

### PANEL BİLEŞENLERİ
```
CouncilPanel.jsx      — 4 Konsey karar paneli (tıklanınca sinyal detayı)
LiquidityRadar.jsx    — Likidite radar (buy/sell wall, stop hunt, sweep)
FundingPanel.jsx      — Funding rate + OI + Market Structure (BOS/CHoCH)
MarketIntelPanel.jsx  — 7 sekme piyasa istihbarat paneli
MultiTimeframePanel.jsx — Çoklu zaman dilimi (1m/5m/15m/1H/4H/1D)
Dashboard_v4.jsx      — Ana dashboard
                        ⚠️ EKSIK: masterCouncil.js bağlantısı yapılmadı
```

---

## TAM SİSTEM AKIŞI

```
BORSA VERİSİ (7 borsa — exchangeAPI_multi.js)
├── Binance (primary)
├── Bybit   (fallback 1)
├── OKX     (fallback 2)
├── Gate.io (fallback 3)
├── KuCoin  (fallback 4)
├── MEXC    (fallback 5)
└── Kraken  (fallback 6)
        ↓
ANALİZ MODÜLLERİ (95 modül — moduleRegistry.js)
├── Teknik (RSI, MACD, EMA, BB, Stoch, ADX, CCI, MFI, OBV, ATR)
├── Likidite (OB, CVD, Delta, Liq Map, Void, Wall)
├── Risk (Volatilite, Funding, OI, Liq Zones)
├── Kripto (BTC Dom, Alt Rotation, Onchain)
├── Forex/Emtia/Endeks (indexEngine.js)
├── News/Sentiment (Fear&Greed, VIX, DXY)
└── Pine İndikatör (pineEngine.js)
    ├── Range Filter (trend yönü + flip sinyal)
    ├── S/R Pivot Kümeleri (güç skoru)
    └── PB-AL / PB-SAT (pullback sinyali)
        ↓
5 KARAR KONSEYİ (masterCouncil.js)
├── TECHNICAL COUNCIL  (Pine entegre)  → BULLISH/BEARISH/NEUTRAL
├── FLOW COUNCIL       (OB + CVD)      → BUY/SELL PRESSURE
├── NEWS & MACRO       (async API)     → MACRO BULLISH/BEARISH
├── RISK COUNCIL       (veto yetkisi)  → LOW/MEDIUM/HIGH/CRITICAL
└── ASSET SPECIALIST   (BTC Dom + Alt) → ASSET BULLISH/BEARISH
        ↓
FINAL COUNCIL
├── Ağırlıklı oylama (Technical %30 + Flow %25 + Asset %20 + News %15 + Risk %10)
├── Konsensüs gücü (TAM/GÜÇLÜ/ÇOĞUNLUK/BÖLÜNMÜŞ)
└── Güven skoru (0-100%)
        ↓
EXECUTION LAYER (executionLayer.js)
├── False Signal Filter (konsey anlaşması + hacim + çift sinyal)
├── Manipulation Filter (stop hunt + spoofing + OB imbalance)
├── Risk Filter (VIX + funding + liq zones)
├── Risk VETO Mechanism (KRİTİK risk → tüm kararı WAIT'e çevirir)
└── Double Confirm (Pine RF onayı + bar devam)
        ↓
   BUY / SELL / WAIT
   + Güven %
   + Risk seviyesi
   + Gerekçe listesi
```

---

## KONSEYLERİN AĞIRLIKLARI

| Konsey | Ağırlık | Veto Yetkisi |
|--------|---------|--------------|
| Technical Council | %30 | Hayır |
| Flow Council | %25 | Hayır |
| Asset Specialist | %20 | Hayır |
| News & Macro | %15 | Hayır |
| Risk Council | %10 | **EVET — KRİTİK risk tüm kararı ezer** |

---

## PINE İNDİKATÖR ENTEGRASYONU

**Pine Script:** `LeventTaze | Grid Master Global — KLASİK ALSAT + S/R + PB-SAT/PB-AL (v6)`

**Pine → JS Eşleşmesi:**

| Pine | JS (pineEngine.js) |
|------|-------------------|
| `smoothrng()` | `smoothrng()` |
| `rngfilt()` | `rngfilt()` |
| `upward/downward` | `upward[], downward[]` |
| `CondIni` flip | `condIni[]` |
| `longConditionClassic` | `rf.buySignal` |
| `shortConditionClassic` | `rf.sellSignal` |
| `getSrVals()` | `getSrVals()` |
| `swapChannel()` | `swapChannel()` |
| `pbSell` | `pb.pbSell` |
| `pbBuy` | `pb.pbBuy` |
| `nearSupport` | `pb.nearSupport` |
| `nearRes` | `pb.nearRes` |

**Technical Council'a katkısı:**
- RF Trend Yönü → %15 ağırlık
- RF Flip Sinyali → %12 ağırlık
- S/R Yakınlık → %8 ağırlık
- PB-AL/SAT → %13 ağırlık

---

## GRAFİK — MUM TİPLERİ

| Tip | Açıklama | Özellik |
|-----|----------|---------|
| Candlestick | Klasik OHLC | Varsayılan |
| Heikin Ashi | Gürültü filtreli | buildHA() |
| Hollow | Boğa=içi boş | Trend gücü |
| Bar | OHLC çizgi | Compact |
| Çizgi | Sadece kapanış | Hızlı okuma |
| Alan | Gradient dolu | Trend görsel |
| Renko | ATR brick | Gürültüsüz |

---

## EKSIKLER — SIRADAKI OTURUMDA YAPILACAKLAR

### ÖNCELİK 1 — Grafik entegrasyonu
- [ ] `GMGChart_v3.jsx`'e Pine çizgileri ekle
  - `filtLine` (Range Filter çizgisi, renkli)
  - `hbandLine`, `lbandLine` (üst/alt bant, hafif)
  - `srZones` (S/R kutuları, Pine'daki gibi renkli)
  - `rfBuySignal` → grafik üzerinde BUY etiketi
  - `rfSellSignal` → grafik üzerinde SELL etiketi
  - `pbBuy` → PB-AL etiketi
  - `pbSell` → PB-SAT etiketi
  - Mum renklendirme (barColor mantığı)

### ÖNCELİK 2 — Dashboard bağlantısı
- [ ] `Dashboard_v4.jsx`'e `masterCouncil.js` bağla
  - Her 10 saniyede `runMasterCouncil()` çağır
  - Sonucu state'e yaz
  - Tüm panellere dağıt

### ÖNCELİK 3 — Eksik JSX paneller
- [ ] `MarketHeatmapPanel.jsx` — coin ısı haritası
- [ ] `LiveAICouncilPanel.jsx` — 5 konsey canlı panel
- [ ] `LiquidityWallPanel.jsx` — buy/sell wall görsel
- [ ] `AccumulationPlanPanel.jsx` — birikim planlama
- [ ] `ForexPanel.jsx` — Forex modülü UI
- [ ] `MultiMarketPanel.jsx` — tüm piyasalar özet

### ÖNCELİK 4 — Eksik engine dosyaları
- [ ] `forexEngine.js` (v7'de vardı, bu ZIP'te yok — yeniden yaz)
- [ ] `commodityEngine.js` (v7'de vardı)
- [ ] `bondMacroEngine.js` (v7'de vardı)
- [ ] `structureEngines.js` (BOS/CHoCH)
- [ ] `probabilityEngine.js`
- [ ] `technicalExtEngine.js`

### ÖNCELİK 5 — Özellikler
- [ ] Alert sistemi UI (web push + email)
- [ ] Backtest paneli
- [ ] Multi-coin watchlist
- [ ] TradingView webhook entegrasyonu
- [ ] Telegram bot çıktısı

---

## MEVCUT PANEL YAPISI

```
Dashboard_v4.jsx
├── Sol kolon (3/12)
│   ├── DecisionEngine.jsx    — AI karar kutusu
│   ├── [TAB: Sinyal]
│   │   ├── SignalPanel.jsx   — AL/SAT sinyal + TP/SL
│   │   ├── WhaleAlert.jsx    — Balina alarmları
│   │   └── LiquidationMap.jsx
│   └── [TAB: İstihbarat]
│       └── MarketIntelPanel.jsx — 7 sekme
│           ├── SCALP (long/short/tuzak)
│           ├── HAZIR (long/short/patlama)
│           ├── PUMP/DUMP
│           ├── GİZLİ (stealth)
│           ├── BTC REL. (güçlü/zayıf)
│           ├── RİSK (stop hunt, liq sens)
│           └── SEANS (zaman dilimi riski)
│
├── Orta kolon (6/12)
│   ├── GMGChart_v3.jsx       — Ana grafik
│   └── HeatmapGrid.jsx       — Coin ısı haritası
│
└── Sağ kolon (3/12)
    ├── [TAB: Konseyler]
    │   └── CouncilPanel.jsx  — 4 konsey
    ├── [TAB: Orderbook]
    │   └── LiquidityWall.jsx
    └── [TAB: Liq Radar]
        └── LiquidityRadar.jsx
```

---

## KULLANIM — MASTER COUNCIL

```javascript
import { runMasterCouncil } from './masterCouncil';
import { runAllScanners }   from './engineCore';
import { fetchBestKlines, fetchAggregatedPrice, fetchOrderbook, fetchFundingRates } from './exchangeAPI_multi';

// 1. Veri çek
const { klines } = await fetchBestKlines('BTC', 'USDT', '1m', 400);
const agg        = await fetchAggregatedPrice('BTC', 'USDT');
const ob         = await fetchOrderbook('BTC', 'USDT');
const funding    = await fetchFundingRates('BTC', 'USDT');

// 2. İndikatörler hesapla (GMGChart'tan veya ayrı)
const I = { rsi: rsiCalc(closes), macd: macdCalc(closes), ... };

// 3. Tarama yap
const scan = runAllScanners({
  coins: heatmapData,
  btcChange: agg?.change24 || 0,
  orderbookMap: { 'BTC/USDT': ob },
  klineMap: { 'BTC/USDT': klines },
});

// 4. Master karar
const result = await runMasterCouncil({
  candles:    klines,
  I,
  scanResults: scan,
  orderbook:  ob,
  heatmapData,
  fundingRates: funding,
  btcChange:  agg?.change24 || 0,
  vixLevel:   50,           // fetchVIX() ile al
  globalLiqData: null,      // fetchGlobalLiquidity() ile al
  lastSignalBarsAgo: 10,
  prevFinalScore:    50,
  signalBarCount:    0,
  pineParams: {
    rfPer: 100, rfMult: 3.0,
    srPrd: 10, srChannelW: 5,
    proxATRmult: 0.6,
  },
});

// 5. Sonuç
console.log(result.label);       // "GÜÇLÜ AL"
console.log(result.score);       // 78
console.log(result.confidence);  // 84
console.log(result.riskLevel);   // "DÜŞÜK"
console.log(result.summary);     // gerekçe listesi

// Grafik için
const { filtLine, hbandLine, lbandLine, srZones, pbBuy, pbSell } = result.chartOverlay;
```

---

## GRAFİĞE PINE ÇİZGİLERİ EKLEME (Sonraki oturumda yapılacak)

`GMGChart_v3.jsx` içinde `draw()` fonksiyonuna şunlar eklenecek:

```javascript
// Range Filter çizgisi
if (act.pine && chartOverlay?.filtLine) {
  drawLine(cx, chartOverlay.filtLine, vI, rfTrendUp ? '#00e676' : '#ff1744', 2, ...);
}

// hband / lband (hafif)
if (act.pine && chartOverlay?.hbandLine) {
  drawLine(cx, chartOverlay.hbandLine, vI, 'rgba(0,188,212,0.4)', 1, ...);
  drawLine(cx, chartOverlay.lbandLine, vI, 'rgba(213,0,249,0.4)', 1, ...);
}

// S/R Kutuları
if (act.pine && chartOverlay?.srZones) {
  for (const zone of chartOverlay.srZones) {
    const topY = pY(zone.hi, ...), botY = pY(zone.lo, ...);
    const col  = zone.hi < cur ? '#00e676' : '#ff1744';
    cx.fillStyle = col + '15';
    cx.fillRect(PL, topY, CW, botY - topY);
    cx.strokeStyle = col + '60';
    cx.strokeRect(PL, topY, CW, botY - topY);
  }
}

// PB-AL / PB-SAT etiketleri
if (chartOverlay?.pbBuy) {
  // Yeşil label: mum altında "PB-AL"
}
if (chartOverlay?.pbSell) {
  // Turuncu label: mum üstünde "PB-SAT"
}
```

---

## ÖNEMLİ NOTLAR

1. **masterCouncil.js** — `runNewsMacroCouncil()` async çağrı yapar, `await` gerekli
2. **pineEngine.js** — `rfPer=100` parametre kripto için biraz geç sinyal verebilir, `rfPer=50` dene
3. **exchangeAPI_multi.js** — CORS kısıtlaması olabilir, proxy gerekebilir
4. **GMGChart_v3.jsx** — `localStorage` state persistence var, production'da key prefix ekle
5. **Risk Veto** — `riskLevel === 'KRİTİK'` ise `runExecutionLayer()` her kararı `WAIT`'e çevirir

---

Son güncelleme: 2026-03-15 | v10 FINAL
Hazırlayan: Claude (Anthropic) — Grid Master Global Projesi
EOF