/**
 * GMG — MULTI EXCHANGE API
 * ========================
 * Binance, Bybit, OKX, Kraken, Gate.io, KuCoin, MEXC
 * Her borsadan veri çeker, normalize eder, birleştirir.
 * Binance düşse diğerleri devam eder.
 */

// LatencyMonitor — opsiyonel import (missingModules yüklüyse)
let _latency = null;
try { import('./missingModules.js').then(m => { _latency = m.LatencyMonitor; }); } catch {}
const lStart = (k) => { try { _latency?.start(k); } catch {} };
const lEnd   = (k) => { try { _latency?.end(k);   } catch {} };

// ─── EXCHANGE CONFIGS ─────────────────────────────────────────────────────────
export const EXCHANGES = {
  binance: {
    name: 'Binance',
    color: '#f0b90b',
    baseUrl: 'https://api.binance.com',
    wsUrl:   'wss://stream.binance.com:9443/ws',
    weight:  1.0,
  },
  bybit: {
    name: 'Bybit',
    color: '#f7a600',
    baseUrl: 'https://api.bybit.com',
    wsUrl:   'wss://stream.bybit.com/v5/public/spot',
    weight:  0.9,
  },
  okx: {
    name: 'OKX',
    color: '#00b0ff',
    baseUrl: 'https://www.okx.com',
    wsUrl:   'wss://ws.okx.com:8443/ws/v5/public',
    weight:  0.9,
  },
  kraken: {
    name: 'Kraken',
    color: '#5741d9',
    baseUrl: 'https://api.kraken.com',
    wsUrl:   'wss://ws.kraken.com',
    weight:  0.85,
  },
  gateio: {
    name: 'Gate.io',
    color: '#00c896',
    baseUrl: 'https://api.gateio.ws',
    wsUrl:   'wss://api.gateio.ws/ws/v4/',
    weight:  0.8,
  },
  kucoin: {
    name: 'KuCoin',
    color: '#00a8a8',
    baseUrl: 'https://api.kucoin.com',
    wsUrl:   '', // token required
    weight:  0.8,
  },
  mexc: {
    name: 'MEXC',
    color: '#1abaff',
    baseUrl: 'https://api.mexc.com',
    wsUrl:   'wss://wbs.mexc.com/ws',
    weight:  0.75,
  },
};

// ─── SYMBOL NORMALIZE ─────────────────────────────────────────────────────────
// Her borsa için sembol formatı farklı
export function symbolFor(exchange, base = 'BTC', quote = 'USDT') {
  switch (exchange) {
    case 'binance': return `${base}${quote}`;
    case 'bybit':   return `${base}${quote}`;
    case 'okx':     return `${base}-${quote}`;
    case 'kraken': {
      const map = { BTC: 'XBT', ETH: 'ETH', SOL: 'SOL', ADA: 'ADA', XRP: 'XRP', DOGE: 'XDG', LTC: 'LTC' };
      const b = map[base] || base;
      return `${b}USD${quote === 'USDT' ? 'T' : ''}`;
    }
    case 'gateio':  return `${base}_${quote}`;
    case 'kucoin':  return `${base}-${quote}`;
    case 'mexc':    return `${base}${quote}`;
    default:        return `${base}${quote}`;
  }
}

// ─── TICKER FETCHERS ──────────────────────────────────────────────────────────

export async function fetchBinanceTicker(symbol) {
  lStart('binance-ticker');
  const r = await fetch(`https://api.binance.com/api/v3/ticker/24hr?symbol=${symbol}`);
  lEnd('binance-ticker');
  const d = await r.json();
  return {
    exchange: 'binance',
    symbol,
    price:    +d.lastPrice,
    change24: +d.priceChangePercent,
    volume24: +d.quoteVolume,
    high24:   +d.highPrice,
    low24:    +d.lowPrice,
    bid:      +d.bidPrice,
    ask:      +d.askPrice,
    ok: true,
  };
}

export async function fetchBybitTicker(symbol) {
  const _t0 = Date.now(); lStart('bybit_ticker');
  const r = await fetch(`https://api.bybit.com/v5/market/tickers?category=spot&symbol=${symbol}`, { signal: AbortSignal.timeout(6000) });
  lEnd('bybit_ticker'); try { _latency?.record('bybit_ticker', Date.now()-_t0); } catch {}
  const d = await r.json();
  const t = d.result?.list?.[0];
  if (!t) throw new Error('Bybit no data');
  return {
    exchange: 'bybit',
    symbol,
    price:    +t.lastPrice,
    change24: +t.price24hPcnt * 100,
    volume24: +t.turnover24h,
    high24:   +t.highPrice24h,
    low24:    +t.lowPrice24h,
    bid:      +t.bid1Price,
    ask:      +t.ask1Price,
    ok: true,
  };
}

export async function fetchOKXTicker(symbol) {
  const _t0 = Date.now(); lStart('okx_ticker');
  const r = await fetch(`https://www.okx.com/api/v5/market/ticker?instId=${symbol}`, { signal: AbortSignal.timeout(6000) });
  lEnd('okx_ticker'); try { _latency?.record('okx_ticker', Date.now()-_t0); } catch {}
  const d = await r.json();
  const t = d.data?.[0];
  if (!t) throw new Error('OKX no data');
  const open = +t.open24h, last = +t.last;
  return {
    exchange: 'okx',
    symbol,
    price:    last,
    change24: open > 0 ? ((last - open) / open * 100) : 0,
    volume24: +t.volCcy24h,
    high24:   +t.high24h,
    low24:    +t.low24h,
    bid:      +t.bidPx,
    ask:      +t.askPx,
    ok: true,
  };
}

export async function fetchKrakenTicker(symbol) {
  const _t0 = Date.now(); lStart('kraken_ticker');
  const r = await fetch(`https://api.kraken.com/0/public/Ticker?pair=${symbol}`, { signal: AbortSignal.timeout(6000) });
  lEnd('kraken_ticker'); try { _latency?.record('kraken_ticker', Date.now()-_t0); } catch {}
  const d = await r.json();
  const keys = Object.keys(d.result || {});
  if (!keys.length) throw new Error('Kraken no data');
  const t = d.result[keys[0]];
  const price = +t.c[0], open = +t.o;
  return {
    exchange: 'kraken',
    symbol,
    price,
    change24: open > 0 ? ((price - open) / open * 100) : 0,
    volume24: +t.v[1] * price,
    high24:   +t.h[1],
    low24:    +t.l[1],
    bid:      +t.b[0],
    ask:      +t.a[0],
    ok: true,
  };
}

export async function fetchGateTicker(symbol) {
  const _t0 = Date.now(); lStart('gate_ticker');
  const r = await fetch(`https://api.gateio.ws/api/v4/spot/tickers?currency_pair=${symbol}`, { signal: AbortSignal.timeout(6000) });
  lEnd('gate_ticker'); try { _latency?.record('gate_ticker', Date.now()-_t0); } catch {}
  const d = await r.json();
  const t = Array.isArray(d) ? d[0] : d;
  if (!t) throw new Error('Gate no data');
  return {
    exchange: 'gateio',
    symbol,
    price:    +t.last,
    change24: +t.change_percentage,
    volume24: +t.quote_volume,
    high24:   +t.high_24h,
    low24:    +t.low_24h,
    bid:      +t.highest_bid,
    ask:      +t.lowest_ask,
    ok: true,
  };
}

export async function fetchKuCoinTicker(symbol) {
  const _t0 = Date.now(); lStart('kucoin_ticker');
  const r = await fetch(`https://api.kucoin.com/api/v1/market/stats?symbol=${symbol}`, { signal: AbortSignal.timeout(6000) });
  lEnd('kucoin_ticker'); try { _latency?.record('kucoin_ticker', Date.now()-_t0); } catch {}
  const d = await r.json();
  const t = d.data;
  if (!t) throw new Error('KuCoin no data');
  return {
    exchange: 'kucoin',
    symbol,
    price:    +t.last,
    change24: +t.changeRate * 100,
    volume24: +t.volValue,
    high24:   +t.high,
    low24:    +t.low,
    bid:      +t.buy,
    ask:      +t.sell,
    ok: true,
  };
}

export async function fetchMEXCTicker(symbol) {
  const r = await fetch(`https://api.mexc.com/api/v3/ticker/24hr?symbol=${symbol}`);
  const d = await r.json();
  return {
    exchange: 'mexc',
    symbol,
    price:    +d.lastPrice,
    change24: +d.priceChangePercent,
    volume24: +d.quoteVolume,
    high24:   +d.highPrice,
    low24:    +d.lowPrice,
    bid:      +d.bidPrice || +d.lastPrice,
    ask:      +d.askPrice || +d.lastPrice,
    ok: true,
  };
}

// ─── KLINES FETCHERS ──────────────────────────────────────────────────────────

export async function fetchBinanceKlines(symbol, interval = '1m', limit = 400) {
  lStart('binance-klines');
  const r = await fetch(`https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`);
  lEnd('binance-klines');
  const d = await r.json();
  return d.map(k => ({
    t:   new Date(k[0]).toLocaleTimeString('tr', { hour: '2-digit', minute: '2-digit' }),
    ts:  k[0],
    o:   +k[1], h: +k[2], l: +k[3], c: +k[4], v: +k[5],
  }));
}

export async function fetchBybitKlines(symbol, interval = '1', limit = 400) {
  const ivMap = { '1m': '1', '3m': '3', '5m': '5', '15m': '15', '30m': '30', '1h': '60', '4h': '240', '1d': 'D', '1w': 'W' };
  const iv = ivMap[interval] || interval;
  const _t0 = Date.now(); lStart('bybit_klines');
  const r = await fetch(`https://api.bybit.com/v5/market/kline?category=spot&symbol=${symbol}&interval=${iv}&limit=${limit}`, { signal: AbortSignal.timeout(8000) });
  lEnd('bybit_klines'); try { _latency?.record('bybit_klines', Date.now()-_t0); } catch {}
  const d = await r.json();
  return (d.result?.list || []).reverse().map(k => ({
    t:  new Date(+k[0]).toLocaleTimeString('tr', { hour: '2-digit', minute: '2-digit' }),
    ts: +k[0],
    o:  +k[1], h: +k[2], l: +k[3], c: +k[4], v: +k[5],
  }));
}

export async function fetchOKXKlines(symbol, interval = '1m', limit = 400) {
  const ivMap = { '1m': '1m', '3m': '3m', '5m': '5m', '15m': '15m', '30m': '30m', '1h': '1H', '4h': '4H', '1d': '1D', '1w': '1W' };
  const iv = ivMap[interval] || '1m';
  const _t0 = Date.now(); lStart('okx_klines');
  const r = await fetch(`https://www.okx.com/api/v5/market/candles?instId=${symbol}&bar=${iv}&limit=${limit}`, { signal: AbortSignal.timeout(8000) });
  lEnd('okx_klines'); try { _latency?.record('okx_klines', Date.now()-_t0); } catch {}
  const d = await r.json();
  return (d.data || []).reverse().map(k => ({
    t:  new Date(+k[0]).toLocaleTimeString('tr', { hour: '2-digit', minute: '2-digit' }),
    ts: +k[0],
    o:  +k[1], h: +k[2], l: +k[3], c: +k[4], v: +k[5],
  }));
}

export async function fetchGateKlines(symbol, interval = '1m', limit = 400) {
  const ivMap = { '1m': '1m', '5m': '5m', '15m': '15m', '30m': '30m', '1h': '1h', '4h': '4h', '1d': '1d', '1w': '7d' };
  const iv = ivMap[interval] || '1m';
  const _t0 = Date.now(); lStart('gate_klines');
  const r = await fetch(`https://api.gateio.ws/api/v4/spot/candlesticks?currency_pair=${symbol}&interval=${iv}&limit=${limit}`, { signal: AbortSignal.timeout(8000) });
  lEnd('gate_klines'); try { _latency?.record('gate_klines', Date.now()-_t0); } catch {}
  const d = await r.json();
  return (d || []).map(k => ({
    t:  new Date(+k[0] * 1000).toLocaleTimeString('tr', { hour: '2-digit', minute: '2-digit' }),
    ts: +k[0] * 1000,
    o:  +k[5], h: +k[3], l: +k[4], c: +k[2], v: +k[6],
  }));
}

export async function fetchMEXCKlines(symbol, interval = '1m', limit = 400) {
  const _t0 = Date.now(); lStart('mexc_klines');
  const r = await fetch(`https://api.mexc.com/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`, { signal: AbortSignal.timeout(8000) });
  lEnd('mexc_klines'); try { _latency?.record('mexc_klines', Date.now()-_t0); } catch {}
  const d = await r.json();
  return (d || []).map(k => ({
    t:  new Date(k[0]).toLocaleTimeString('tr', { hour: '2-digit', minute: '2-digit' }),
    ts: k[0],
    o:  +k[1], h: +k[2], l: +k[3], c: +k[4], v: +k[5],
  }));
}

// ─── AGGREGATED PRICE (VWAP across exchanges) ─────────────────────────────────
/**
 * Tüm borsalardan fiyat çeker, ağırlıklı ortalama verir.
 * Hangi borsa düşse diğerleri devam eder.
 */
export async function fetchAggregatedPrice(base = 'BTC', quote = 'USDT') {
  const fetchers = [
    { fn: fetchBinanceTicker, sym: symbolFor('binance', base, quote), ex: 'binance' },
    { fn: fetchBybitTicker,   sym: symbolFor('bybit',   base, quote), ex: 'bybit'   },
    { fn: fetchOKXTicker,     sym: symbolFor('okx',     base, quote), ex: 'okx'     },
    { fn: fetchGateTicker,    sym: symbolFor('gateio',  base, quote), ex: 'gateio'  },
    { fn: fetchMEXCTicker,    sym: symbolFor('mexc',    base, quote), ex: 'mexc'    },
    { fn: fetchKuCoinTicker,  sym: symbolFor('kucoin',  base, quote), ex: 'kucoin'  },
  ];

  const results = await Promise.allSettled(
    fetchers.map(f => f.fn(f.sym).then(d => ({ ...d, exchange: f.ex })))
  );

  const valid = results
    .filter(r => r.status === 'fulfilled' && r.value?.price > 0)
    .map(r => r.value);

  if (!valid.length) return null;

  const failed = results.filter(r => r.status === 'rejected').map((_, i) => fetchers[i].ex);

  // VWAP weighted average
  const totalVol = valid.reduce((s, t) => s + (t.volume24 || 0), 0) || 1;
  const vwap     = valid.reduce((s, t) => s + t.price * (t.volume24 || 0), 0) / totalVol;
  const avgPrice = valid.reduce((s, t) => s + t.price, 0) / valid.length;

  // Spread analysis
  const prices = valid.map(t => t.price).sort((a, b) => a - b);
  const spread = prices.length > 1 ? ((prices[prices.length - 1] - prices[0]) / prices[0] * 100) : 0;

  return {
    price:   avgPrice,
    vwap,
    change24: valid.reduce((s, t) => s + (t.change24 || 0), 0) / valid.length,
    volume24: valid.reduce((s, t) => s + (t.volume24 || 0), 0),
    spread:   parseFloat(spread.toFixed(4)),
    sources:  valid,
    failed,
    exchanges: valid.map(t => t.exchange),
  };
}

// ─── BEST KLINES SOURCE ───────────────────────────────────────────────────────
/**
 * Sırayla borsa dener, ilk başarılı olanı döner.
 * Primary: Binance → Bybit → OKX → Gate → MEXC
 */
export async function fetchBestKlines(base = 'BTC', quote = 'USDT', interval = '1m', limit = 400) {
  const chain = [
    { fn: fetchBinanceKlines, sym: symbolFor('binance', base, quote) },
    { fn: fetchBybitKlines,   sym: symbolFor('bybit',   base, quote) },
    { fn: fetchOKXKlines,     sym: symbolFor('okx',     base, quote) },
    { fn: fetchGateKlines,    sym: symbolFor('gateio',  base, quote) },
    { fn: fetchMEXCKlines,    sym: symbolFor('mexc',    base, quote) },
  ];

  for (const { fn, sym } of chain) {
    try {
      const klines = await fn(sym, interval, limit);
      if (klines && klines.length > 10) return { klines, source: sym };
    } catch (e) {
      continue;
    }
  }
  throw new Error('Tüm borsalar başarısız');
}

// ─── WEBSOCKET MANAGER ────────────────────────────────────────────────────────
/**
 * Birden fazla borsa WebSocket'ini yönetir.
 * Biri düşerse otomatik diğerine geçer.
 */
export class MultiExchangeWS {
  constructor(base = 'BTC', quote = 'USDT', onCandle, onTicker) {
    this.base     = base;
    this.quote    = quote;
    this.onCandle = onCandle;
    this.onTicker = onTicker;
    this.ws       = null;
    this.active   = null;
    this.interval = '1m';
    this.retries  = { binance: 0, bybit: 0, okx: 0, mexc: 0 };
  }

  connect(exchange = 'binance', interval = '1m') {
    this.interval = interval;
    if (this.ws) { try { this.ws.close(); } catch {} }

    const { base, quote } = this;
    let url, handler;

    if (exchange === 'binance') {
      const sym = `${base}${quote}`.toLowerCase();
      url = `wss://stream.binance.com:9443/ws/${sym}@kline_${interval}`;
      handler = (e) => {
        const d = JSON.parse(e.data), k = d.k; if (!k) return;
        this.onCandle?.({
          t:   new Date(k.t).toLocaleTimeString('tr', { hour: '2-digit', minute: '2-digit' }),
          ts:  k.t, o: +k.o, h: +k.h, l: +k.l, c: +k.c, v: +k.v,
          closed: k.x,
        });
        this.onTicker?.({ exchange: 'binance', price: +k.c, volume: +k.q });
      };
    } else if (exchange === 'bybit') {
      url = `wss://stream.bybit.com/v5/public/spot`;
      handler = (e) => {
        const d = JSON.parse(e.data);
        if (d.topic?.includes('kline')) {
          const k = d.data?.[0]; if (!k) return;
          this.onCandle?.({
            t:   new Date(+k.start).toLocaleTimeString('tr', { hour: '2-digit', minute: '2-digit' }),
            ts:  +k.start, o: +k.open, h: +k.high, l: +k.low, c: +k.close, v: +k.volume,
            closed: k.confirm,
          });
        }
      };
    } else if (exchange === 'okx') {
      url = `wss://ws.okx.com:8443/ws/v5/public`;
      handler = (e) => {
        const d = JSON.parse(e.data);
        if (d.arg?.channel === 'candle1m' || d.arg?.channel?.startsWith('candle')) {
          const k = d.data?.[0]; if (!k) return;
          this.onCandle?.({
            t:   new Date(+k[0]).toLocaleTimeString('tr', { hour: '2-digit', minute: '2-digit' }),
            ts:  +k[0], o: +k[1], h: +k[2], l: +k[3], c: +k[4], v: +k[5],
            closed: k[8] === '1',
          });
        }
      };
    } else if (exchange === 'mexc') {
      const sym = `${base}${quote}`;
      url = `wss://wbs.mexc.com/ws`;
      handler = (e) => {
        const d = JSON.parse(e.data);
        if (d.d?.k) {
          const k = d.d.k;
          this.onCandle?.({
            t:   new Date(k.t).toLocaleTimeString('tr', { hour: '2-digit', minute: '2-digit' }),
            ts:  k.t, o: +k.o, h: +k.h, l: +k.l, c: +k.c, v: +k.v,
            closed: k.x,
          });
        }
      };
    }

    try {
      const ws = new WebSocket(url);
      ws.onopen = () => {
        this.active = exchange;
        this.retries[exchange] = 0;
        // Subscribe messages
        if (exchange === 'bybit') {
          const ivMap = { '1m': '1', '5m': '5', '15m': '15', '1h': '60', '4h': '240', '1d': 'D' };
          ws.send(JSON.stringify({ op: 'subscribe', args: [`kline.${ivMap[interval]||'1'}.${base}${quote}`] }));
        } else if (exchange === 'okx') {
          const ivMap = { '1m': 'candle1m', '5m': 'candle5m', '15m': 'candle15m', '1h': 'candle1H', '4h': 'candle4H', '1d': 'candle1D' };
          ws.send(JSON.stringify({ op: 'subscribe', args: [{ channel: ivMap[interval] || 'candle1m', instId: `${base}-${quote}` }] }));
        } else if (exchange === 'mexc') {
          ws.send(JSON.stringify({ method: 'SUBSCRIPTION', params: [`spot@public.kline.v3.api@${base}${quote}@Min1`] }));
        }
      };
      ws.onmessage = handler;
      ws.onerror   = () => this._fallback(exchange);
      ws.onclose   = () => this._fallback(exchange);
      this.ws = ws;
    } catch {
      this._fallback(exchange);
    }
  }

  _fallback(failed) {
    const order = ['binance', 'bybit', 'okx', 'mexc'];
    const idx   = order.indexOf(failed);
    const next  = order[(idx + 1) % order.length];
    this.retries[failed] = (this.retries[failed] || 0) + 1;
    const delay = Math.min(30000, 3000 * this.retries[failed]);
    setTimeout(() => this.connect(next, this.interval), delay);
  }

  disconnect() {
    if (this.ws) { try { this.ws.close(); } catch {} }
    this.ws = null;
  }
}

// ─── ORDERBOOK (multi-source) ─────────────────────────────────────────────────
export async function fetchOrderbook(base = 'BTC', quote = 'USDT', depth = 20) {
  const fetchers = [
    async () => {
      const r = await fetch(`https://api.binance.com/api/v3/depth?symbol=${base}${quote}&limit=${depth}`);
      const d = await r.json();
      return { bids: d.bids.map(([p,a]) => ({ price: +p, amount: +a })), asks: d.asks.map(([p,a]) => ({ price: +p, amount: +a })), source: 'binance' };
    },
    async () => {
      const r = await fetch(`https://api.bybit.com/v5/market/orderbook?category=spot&symbol=${base}${quote}&limit=${depth}`);
      const d = await r.json();
      const ob = d.result;
      return { bids: ob.b.map(([p,a]) => ({ price: +p, amount: +a })), asks: ob.a.map(([p,a]) => ({ price: +p, amount: +a })), source: 'bybit' };
    },
    async () => {
      const r = await fetch(`https://www.okx.com/api/v5/market/books?instId=${base}-${quote}&sz=${depth}`);
      const d = await r.json();
      const ob = d.data?.[0];
      return { bids: ob.bids.map(([p,a]) => ({ price: +p, amount: +a })), asks: ob.asks.map(([p,a]) => ({ price: +p, amount: +a })), source: 'okx' };
    },
  ];

  for (const fn of fetchers) {
    try { return await fn(); } catch { continue; }
  }
  return null;
}

// ─── FUNDING RATE ─────────────────────────────────────────────────────────────
export async function fetchFundingRates(base = 'BTC', quote = 'USDT') {
  const sym = `${base}${quote}`;
  const results = await Promise.allSettled([
    fetch(`https://fapi.binance.com/fapi/v1/premiumIndex?symbol=${sym}`).then(r => r.json()).then(d => ({ ex: 'binance', rate: +d.lastFundingRate * 100 })),
    fetch(`https://api.bybit.com/v5/market/tickers?category=linear&symbol=${sym}`).then(r => r.json()).then(d => ({ ex: 'bybit', rate: +(d.result?.list?.[0]?.fundingRate || 0) * 100 })),
  ]);
  return results.filter(r => r.status === 'fulfilled').map(r => r.value);
}
