import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Zap, Shield, TrendingUp, TrendingDown, Target, Activity,
  Eye, AlertTriangle, Flame, Clock, BarChart2, Layers, RefreshCw,
  Database, Link,
} from 'lucide-react';

// ─── TAB TANIMLARI ────────────────────────────────────────────────────────────
const TABS = [
  { id: 'scalp',      label: 'SCALP',      icon: Zap,          color: '#00aaff' },
  { id: 'ready',      label: 'HAZIR',       icon: Target,       color: '#00ff88' },
  { id: 'pumpdump',   label: 'PUMP/DUMP',   icon: Flame,        color: '#ff8800' },
  { id: 'stealth',    label: 'GİZLİ',       icon: Eye,          color: '#aa88ff' },
  { id: 'btcrel',     label: 'BTC REL.',    icon: BarChart2,    color: '#ffcc00' },
  { id: 'risk',       label: 'RİSK',        icon: AlertTriangle,color: '#ff3366' },
  { id: 'session',    label: 'SEANS',       icon: Clock,        color: '#00ccaa' },
  { id: 'onchain',    label: 'ZİNCİR',      icon: Database,     color: '#ff88cc' },
  { id: 'etf',        label: 'ETF',         icon: Link,         color: '#88ffcc' },
];

// ─── ALT BİLEŞENLER ──────────────────────────────────────────────────────────

function TabBar({ active, onChange }) {
  return (
    <div className="flex flex-wrap gap-1">
      {TABS.map(t => {
        const Icon = t.icon;
        const isActive = active === t.id;
        return (
          <button
            key={t.id}
            onClick={() => onChange(t.id)}
            className="flex items-center gap-1 px-2 py-1 rounded text-[9px] font-mono font-bold tracking-wider uppercase transition-all"
            style={{
              background: isActive ? `${t.color}15` : '#0a0a0f',
              color: isActive ? t.color : '#4b5563',
              border: `1px solid ${isActive ? t.color + '40' : '#1a1a2e'}`,
            }}
          >
            <Icon style={{ width: 10, height: 10 }} />
            {t.label}
          </button>
        );
      })}
    </div>
  );
}

function CoinRow({ coin, index, colorScheme = 'green', showExtra }) {
  const isUp    = (coin.change || coin.relStrength || 0) >= 0;
  const mainColor =
    colorScheme === 'green' ? '#00ff88' :
    colorScheme === 'red'   ? '#ff3366' :
    colorScheme === 'blue'  ? '#00aaff' :
    colorScheme === 'orange'? '#ff8800' :
    colorScheme === 'purple'? '#aa88ff' : '#ffcc00';

  const change   = coin.change ?? coin.relStrength ?? 0;
  const barWidth = Math.min(100, Math.abs(change) * 4);

  return (
    <motion.div
      initial={{ opacity: 0, y: 4 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.03 }}
      className="flex items-center gap-2 px-2 py-1.5 rounded hover:bg-[#ffffff08] transition-colors group"
    >
      <span className="text-[9px] font-mono text-gray-600 w-4 text-right">{index + 1}</span>

      <span className="text-[10px] font-mono font-bold text-gray-200 w-14 truncate">
        {coin.symbol || coin.name || '—'}
      </span>

      <div className="flex-1 relative h-1.5 rounded-full overflow-hidden bg-[#1a1a2e]">
        <motion.div
          className="absolute left-0 top-0 h-full rounded-full"
          style={{ background: mainColor }}
          initial={{ width: 0 }}
          animate={{ width: `${barWidth}%` }}
          transition={{ duration: 0.5, delay: index * 0.03 }}
        />
      </div>

      <span
        className="text-[10px] font-mono font-bold w-14 text-right"
        style={{ color: change >= 0 ? '#00ff88' : '#ff3366' }}
      >
        {change >= 0 ? '+' : ''}{change.toFixed(2)}%
      </span>

      {showExtra && coin.riskLevel && (
        <span
          className="text-[8px] font-mono px-1 py-0.5 rounded"
          style={{
            background: coin.riskLevel === 'KRİTİK' ? '#ff336620' : coin.riskLevel === 'YÜKSEK' ? '#ff880020' : '#ffcc0020',
            color:      coin.riskLevel === 'KRİTİK' ? '#ff3366'   : coin.riskLevel === 'YÜKSEK' ? '#ff8800'   : '#ffcc00',
          }}
        >
          {coin.riskLevel}
        </span>
      )}

      {showExtra && coin.severity && (
        <span
          className="text-[8px] font-mono px-1 py-0.5 rounded"
          style={{
            background: coin.severity === 'KRİTİK' ? '#ff336620' : '#ff880020',
            color:      coin.severity === 'KRİTİK' ? '#ff3366'   : '#ff8800',
          }}
        >
          {coin.severity}
        </span>
      )}

      {showExtra && coin.confidence && (
        <span className="text-[8px] font-mono text-gray-600">{Math.round(coin.confidence)}%</span>
      )}

      {showExtra && coin.readyScore && (
        <span className="text-[8px] font-mono text-gray-600">{Math.round(coin.readyScore)}</span>
      )}
    </motion.div>
  );
}

function SectionHeader({ label, count, color = '#00aaff', icon: Icon }) {
  return (
    <div className="flex items-center justify-between mb-1.5">
      <div className="flex items-center gap-1.5">
        {Icon && <Icon style={{ width: 10, height: 10, color }} />}
        <span className="text-[9px] font-mono font-bold tracking-widest uppercase" style={{ color }}>
          {label}
        </span>
      </div>
      {count !== undefined && (
        <span className="text-[9px] font-mono text-gray-600">{count}</span>
      )}
    </div>
  );
}

function EmptyState({ text = 'Sinyal yok' }) {
  return (
    <div className="flex items-center justify-center py-4 text-[9px] font-mono text-gray-700">
      {text}
    </div>
  );
}

// ─── SEKME İÇERİKLERİ ────────────────────────────────────────────────────────

function ScalpTab({ data }) {
  const { scalpLongs, scalpShorts, scalpTraps } = data;
  return (
    <div className="space-y-3">
      {/* Long */}
      <div className="bg-[#0a0a0f] rounded-lg p-3">
        <SectionHeader label="Scalp Long" count={scalpLongs.length} color="#00ff88" icon={TrendingUp} />
        {scalpLongs.length
          ? scalpLongs.slice(0, 6).map((c, i) => <CoinRow key={c.symbol} coin={c} index={i} colorScheme="green" showExtra />)
          : <EmptyState text="Scalp long sinyali yok" />}
      </div>
      {/* Short */}
      <div className="bg-[#0a0a0f] rounded-lg p-3">
        <SectionHeader label="Scalp Short" count={scalpShorts.length} color="#ff3366" icon={TrendingDown} />
        {scalpShorts.length
          ? scalpShorts.slice(0, 6).map((c, i) => <CoinRow key={c.symbol} coin={c} index={i} colorScheme="red" showExtra />)
          : <EmptyState text="Scalp short sinyali yok" />}
      </div>
      {/* Traps */}
      <div className="bg-[#0a0a0f] rounded-lg p-3">
        <SectionHeader label="Scalp Tuzak" count={scalpTraps.length} color="#ff8800" icon={AlertTriangle} />
        {scalpTraps.length
          ? scalpTraps.slice(0, 5).map((c, i) => (
              <div key={c.symbol} className="flex items-center justify-between px-2 py-1.5">
                <span className="text-[10px] font-mono font-bold text-gray-300">{c.symbol}</span>
                <span className="text-[9px] font-mono text-[#ff8800]">{c.reason}</span>
                <span className="text-[10px] font-mono" style={{ color: c.change >= 0 ? '#00ff88' : '#ff3366' }}>
                  {c.change >= 0 ? '+' : ''}{c.change?.toFixed(2)}%
                </span>
              </div>
            ))
          : <EmptyState text="Tuzak tespit edilmedi" />}
      </div>
    </div>
  );
}

function ReadyTab({ data }) {
  const { longReady, shortReady, explosionReady } = data;
  return (
    <div className="space-y-3">
      <div className="bg-[#0a0a0f] rounded-lg p-3">
        <SectionHeader label="Long Girmeye Hazır" count={longReady.length} color="#00ff88" icon={TrendingUp} />
        {longReady.length
          ? longReady.slice(0, 6).map((c, i) => <CoinRow key={c.symbol} coin={c} index={i} colorScheme="green" showExtra />)
          : <EmptyState text="Long hazır coin yok" />}
      </div>
      <div className="bg-[#0a0a0f] rounded-lg p-3">
        <SectionHeader label="Short Yapılmaya Hazır" count={shortReady.length} color="#ff3366" icon={TrendingDown} />
        {shortReady.length
          ? shortReady.slice(0, 6).map((c, i) => <CoinRow key={c.symbol} coin={c} index={i} colorScheme="red" showExtra />)
          : <EmptyState text="Short hazır coin yok" />}
      </div>
      <div className="bg-[#0a0a0f] rounded-lg p-3">
        <SectionHeader label="Patlamaya Hazır" count={explosionReady.length} color="#aa88ff" icon={Zap} />
        {explosionReady.length
          ? explosionReady.slice(0, 6).map((c, i) => (
              <motion.div
                key={c.symbol}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: i * 0.04 }}
                className="flex items-center justify-between px-2 py-1.5"
              >
                <span className="text-[9px] font-mono text-gray-600 w-4">{i + 1}</span>
                <span className="text-[10px] font-mono font-bold text-gray-200 w-14 truncate">{c.symbol}</span>
                <div className="flex-1 mx-2 h-1.5 bg-[#1a1a2e] rounded-full overflow-hidden">
                  <motion.div
                    className="h-full rounded-full bg-[#aa88ff]"
                    initial={{ width: 0 }}
                    animate={{ width: `${Math.min(100, c.explosionScore)}%` }}
                    transition={{ duration: 0.5 }}
                  />
                </div>
                <span className="text-[9px] font-mono text-[#aa88ff]">{Math.round(c.explosionScore)}</span>
              </motion.div>
            ))
          : <EmptyState text="Patlama sinyali yok" />}
      </div>
    </div>
  );
}

function PumpDumpTab({ data }) {
  const { suddenPumps, suddenDumps, multiExchange } = data;
  const allPumps = [
    ...suddenPumps.map(c => ({ ...c, exchange: 'BNC' })),
    ...(multiExchange?.pumps || []).filter(c => c.exchange === 'MEXC'),
  ];
  const allDumps = [
    ...suddenDumps.map(c => ({ ...c, exchange: 'BNC' })),
    ...(multiExchange?.dumps || []).filter(c => c.exchange === 'MEXC'),
  ];
  return (
    <div className="space-y-3">
      <div className="bg-[#0a0a0f] rounded-lg p-3">
        <SectionHeader label="Ani Pump" count={allPumps.length} color="#00ff88" icon={Flame} />
        {allPumps.length
          ? allPumps.slice(0, 8).map((c, i) => (
              <div key={c.symbol + i} className="flex items-center justify-between px-2 py-1.5">
                <span className="text-[9px] font-mono text-gray-600 w-4">{i + 1}</span>
                <span className="text-[10px] font-mono font-bold text-gray-200 w-14 truncate">{c.symbol}</span>
                <span className="text-[8px] font-mono px-1.5 py-0.5 rounded" style={{ background: '#1a1a2e', color: '#6b7280' }}>{c.exchange || 'BNC'}</span>
                <div className="flex-1 mx-2 h-1.5 bg-[#1a1a2e] rounded-full overflow-hidden">
                  <motion.div
                    className="h-full bg-[#00ff88] rounded-full"
                    initial={{ width: 0 }}
                    animate={{ width: `${Math.min(100, Math.abs(c.change) * 3)}%` }}
                    transition={{ duration: 0.5, delay: i * 0.03 }}
                  />
                </div>
                <span className="text-[10px] font-mono font-bold text-[#00ff88] w-12 text-right">
                  +{c.change?.toFixed(2)}%
                </span>
                {c.pumpType && (
                  <span className="text-[8px] font-mono ml-1 text-[#ff8800]">{c.pumpType}</span>
                )}
              </div>
            ))
          : <EmptyState text="Pump sinyali yok" />}
      </div>
      <div className="bg-[#0a0a0f] rounded-lg p-3">
        <SectionHeader label="Ani Dump" count={allDumps.length} color="#ff3366" icon={TrendingDown} />
        {allDumps.length
          ? allDumps.slice(0, 8).map((c, i) => (
              <div key={c.symbol + i} className="flex items-center justify-between px-2 py-1.5">
                <span className="text-[9px] font-mono text-gray-600 w-4">{i + 1}</span>
                <span className="text-[10px] font-mono font-bold text-gray-200 w-14 truncate">{c.symbol}</span>
                <span className="text-[8px] font-mono px-1.5 py-0.5 rounded" style={{ background: '#1a1a2e', color: '#6b7280' }}>{c.exchange || 'BNC'}</span>
                <div className="flex-1 mx-2 h-1.5 bg-[#1a1a2e] rounded-full overflow-hidden">
                  <motion.div
                    className="h-full bg-[#ff3366] rounded-full"
                    initial={{ width: 0 }}
                    animate={{ width: `${Math.min(100, Math.abs(c.change) * 3)}%` }}
                    transition={{ duration: 0.5, delay: i * 0.03 }}
                  />
                </div>
                <span className="text-[10px] font-mono font-bold text-[#ff3366] w-12 text-right">
                  {c.change?.toFixed(2)}%
                </span>
              </div>
            ))
          : <EmptyState text="Dump sinyali yok" />}
      </div>
    </div>
  );
}

function StealthTab({ data }) {
  const { stealthRising, stealthFalling } = data;
  return (
    <div className="space-y-3">
      <div className="bg-[#0a0a0f] rounded-lg p-3">
        <SectionHeader label="Sessiz Yükselenler" count={stealthRising.length} color="#aa88ff" icon={Eye} />
        {stealthRising.length
          ? stealthRising.slice(0, 8).map((c, i) => <CoinRow key={c.symbol} coin={c} index={i} colorScheme="purple" showExtra />)
          : <EmptyState text="Sessiz yükseliş yok" />}
      </div>
      <div className="bg-[#0a0a0f] rounded-lg p-3">
        <SectionHeader label="Sessiz Düşenler" count={stealthFalling.length} color="#ff8800" icon={Eye} />
        {stealthFalling.length
          ? stealthFalling.slice(0, 8).map((c, i) => <CoinRow key={c.symbol} coin={{ ...c, change: c.change }} index={i} colorScheme="orange" showExtra />)
          : <EmptyState text="Sessiz düşüş yok" />}
      </div>
    </div>
  );
}

function BTCRelTab({ data }) {
  const { btcStrong, btcWeak, btcChange } = data;
  return (
    <div className="space-y-3">
      <div className="rounded-lg px-3 py-2 mb-1" style={{ background: '#ffcc0010', border: '1px solid #ffcc0025' }}>
        <div className="flex items-center justify-between">
          <span className="text-[9px] font-mono text-gray-500">BTC 24s Değişim</span>
          <span className="text-sm font-black font-mono" style={{ color: btcChange >= 0 ? '#00ff88' : '#ff3366' }}>
            {btcChange >= 0 ? '+' : ''}{btcChange?.toFixed(2) || 0}%
          </span>
        </div>
      </div>
      <div className="bg-[#0a0a0f] rounded-lg p-3">
        <SectionHeader label="BTC'ye Rağmen Güçlü" count={btcStrong.length} color="#00ff88" icon={TrendingUp} />
        {btcStrong.length
          ? btcStrong.slice(0, 8).map((c, i) => (
              <div key={c.symbol} className="flex items-center gap-2 px-2 py-1.5">
                <span className="text-[9px] font-mono text-gray-600 w-4">{i + 1}</span>
                <span className="text-[10px] font-mono font-bold text-gray-200 w-14 truncate">{c.symbol}</span>
                <div className="flex-1 h-1.5 bg-[#1a1a2e] rounded-full overflow-hidden">
                  <motion.div className="h-full bg-[#00ff88] rounded-full" style={{ width: `${Math.min(100, c.relStrength * 5)}%` }} initial={{ width: 0 }} animate={{ width: `${Math.min(100, c.relStrength * 5)}%` }} />
                </div>
                <span className="text-[9px] font-mono text-[#00aaff] w-10 text-right">+{c.relStrength}%</span>
                <span className="text-[10px] font-mono font-bold text-[#00ff88] w-12 text-right">{c.change >= 0 ? '+' : ''}{c.change?.toFixed(2)}%</span>
              </div>
            ))
          : <EmptyState text="BTC'ye rağmen güçlü coin yok" />}
      </div>
      <div className="bg-[#0a0a0f] rounded-lg p-3">
        <SectionHeader label="BTC'ye Rağmen Zayıf" count={btcWeak.length} color="#ff3366" icon={TrendingDown} />
        {btcWeak.length
          ? btcWeak.slice(0, 8).map((c, i) => (
              <div key={c.symbol} className="flex items-center gap-2 px-2 py-1.5">
                <span className="text-[9px] font-mono text-gray-600 w-4">{i + 1}</span>
                <span className="text-[10px] font-mono font-bold text-gray-200 w-14 truncate">{c.symbol}</span>
                <div className="flex-1 h-1.5 bg-[#1a1a2e] rounded-full overflow-hidden">
                  <motion.div className="h-full bg-[#ff3366] rounded-full" style={{ width: `${Math.min(100, Math.abs(c.relStrength) * 5)}%` }} initial={{ width: 0 }} animate={{ width: `${Math.min(100, Math.abs(c.relStrength) * 5)}%` }} />
                </div>
                <span className="text-[9px] font-mono text-[#ff8800] w-10 text-right">{c.relStrength}%</span>
                <span className="text-[10px] font-mono font-bold text-[#ff3366] w-12 text-right">{c.change?.toFixed(2)}%</span>
              </div>
            ))
          : <EmptyState text="BTC'ye rağmen zayıf coin yok" />}
      </div>
    </div>
  );
}

function RiskTab({ data }) {
  const { stopHunts, scalpTraps, liquiditySens } = data;
  return (
    <div className="space-y-3">
      <div className="bg-[#0a0a0f] rounded-lg p-3">
        <SectionHeader label="Stop Hunt Tespiti" count={stopHunts.length} color="#ff3366" icon={AlertTriangle} />
        {stopHunts.length
          ? stopHunts.slice(0, 6).map((c, i) => (
              <div key={c.symbol} className="flex items-center justify-between px-2 py-1.5">
                <span className="text-[9px] font-mono text-gray-600 w-4">{i + 1}</span>
                <span className="text-[10px] font-mono font-bold text-gray-200 w-14 truncate">{c.symbol}</span>
                <span className="text-[9px] font-mono text-[#ff8800]">{c.direction}</span>
                <span className="text-[8px] font-mono px-1 py-0.5 rounded"
                  style={{ background: c.riskLevel === 'YÜKSEK' ? '#ff336620' : '#ff880020',
                           color: c.riskLevel === 'YÜKSEK' ? '#ff3366' : '#ff8800' }}>
                  {c.riskLevel}
                </span>
              </div>
            ))
          : <EmptyState text="Stop hunt yok" />}
      </div>
      <div className="bg-[#0a0a0f] rounded-lg p-3">
        <SectionHeader label="Likidite Duyarlılığı" count={liquiditySens.length} color="#00aaff" icon={Layers} />
        {liquiditySens.length
          ? liquiditySens.slice(0, 6).map((c, i) => (
              <div key={c.symbol} className="flex items-center justify-between px-2 py-1.5">
                <span className="text-[9px] font-mono text-gray-600 w-4">{i + 1}</span>
                <span className="text-[10px] font-mono font-bold text-gray-200 w-14 truncate">{c.symbol}</span>
                <span className="text-[9px] font-mono" style={{ color: c.bias === 'ALIŞ' ? '#00ff88' : c.bias === 'SATIŞ' ? '#ff3366' : '#ffcc00' }}>
                  {c.bias}
                </span>
                <span className="text-[8px] font-mono text-gray-600">{(c.sensitivity * 100).toFixed(0)}%</span>
                <span className="text-[8px] font-mono px-1 py-0.5 rounded"
                  style={{ background: c.riskLevel === 'YÜKSEK' ? '#ff336620' : '#ffcc0020',
                           color: c.riskLevel === 'YÜKSEK' ? '#ff3366' : '#ffcc00' }}>
                  {c.riskLevel}
                </span>
              </div>
            ))
          : <EmptyState text="Likidite verisi yok" />}
      </div>
    </div>
  );
}

function SessionTab({ data }) {
  const { sessionRisks, activeSession } = data;
  const sessionLabels = { ASIA: 'ASYA', EUROPE: 'AVRUPA', USA: 'ABD' };
  const sessionColors = { ASIA: '#00aaff', EUROPE: '#ffcc00', USA: '#ff8800' };

  const now = new Date();
  const utcH = now.getUTCHours();
  const utcM = now.getUTCMinutes();

  return (
    <div className="space-y-3">
      {/* Active session display */}
      <div className="flex gap-2">
        {['ASIA','EUROPE','USA'].map(s => {
          const isActive = activeSession.includes(s);
          return (
            <div
              key={s}
              className="flex-1 rounded-lg p-2 text-center"
              style={{
                background: isActive ? `${sessionColors[s]}12` : '#0a0a0f',
                border: `1px solid ${isActive ? sessionColors[s] + '40' : '#1a1a2e'}`,
              }}
            >
              <div className="text-[9px] font-mono font-bold" style={{ color: isActive ? sessionColors[s] : '#4b5563' }}>
                {sessionLabels[s]}
                {isActive && (
                  <motion.span
                    className="inline-block ml-1 rounded-full"
                    style={{ width: 4, height: 4, background: sessionColors[s], display: 'inline-block', verticalAlign: 'middle' }}
                    animate={{ opacity: [1, 0, 1] }}
                    transition={{ duration: 1, repeat: Infinity }}
                  />
                )}
              </div>
              <div className="text-[8px] text-gray-600 font-mono mt-0.5">
                {isActive ? 'AKTİF' : 'KAPALI'}
              </div>
            </div>
          );
        })}
      </div>

      <div className="text-[9px] font-mono text-gray-600 text-center">
        UTC {String(utcH).padStart(2, '0')}:{String(utcM).padStart(2, '0')}
      </div>

      <div className="bg-[#0a0a0f] rounded-lg p-3">
        <SectionHeader label="Seans Riskli Coinler" count={sessionRisks.length} color="#00ccaa" icon={Clock} />
        {sessionRisks.length
          ? sessionRisks.slice(0, 8).map((c, i) => (
              <div key={c.symbol} className="flex items-center justify-between px-2 py-1.5">
                <span className="text-[9px] font-mono text-gray-600 w-4">{i + 1}</span>
                <span className="text-[10px] font-mono font-bold text-gray-200 w-14 truncate">{c.symbol}</span>
                <span className="text-[8px] font-mono text-[#00ccaa]">{c.session}</span>
                <span className="text-[9px] font-mono text-gray-500">{c.riskType}</span>
                <span className="text-[10px] font-mono font-bold" style={{ color: c.change >= 0 ? '#00ff88' : '#ff3366' }}>
                  {c.change >= 0 ? '+' : ''}{c.change?.toFixed(2)}%
                </span>
              </div>
            ))
          : <EmptyState text="Aktif seans riski yok" />}
      </div>
    </div>
  );
}

// ─── ONCHAIN TAB ──────────────────────────────────────────────────────────────
function OnchainTab({ masterResult }) {
  const onchain = masterResult?.advanced?.onchain || masterResult?.onchain || null;
  const whale   = masterResult?.advanced?.whaleTrace || null;
  if (!onchain && !whale) {
    return (
      <div style={{ padding:'16px 8px', textAlign:'center', color:'#2a2a4a', fontSize:9, fontFamily:'monospace' }}>
        Zincir verisi bekleniyor...
      </div>
    );
  }
  const rows = [
    onchain?.exchangeReserve && { label:'Borsa Rezervi', value: onchain.exchangeReserve.direction||'–', score: onchain.exchangeReserve.score, color:'#ff88cc' },
    onchain?.activeAddresses && { label:'Aktif Adres',   value: onchain.activeAddresses.trend||'–',     score: onchain.activeAddresses.score, color:'#ff88cc' },
    onchain?.transferSpike   && { label:'Transfer Spike',value: onchain.transferSpike.spikeDetected?'AKTİF':'–', score: onchain.transferSpike.score, color:'#ffaa44' },
    (whale?.score != null)   && { label:'Balina İzci',   value: whale.action||whale.verdict||'–',       score: whale.score, color:'#aa88ff' },
  ].filter(Boolean);
  return (
    <div style={{ display:'flex', flexDirection:'column', gap:4, padding:'4px 0' }}>
      {rows.map((r,i) => (
        <div key={i} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', background:'#0a0a1e', borderRadius:4, padding:'4px 8px' }}>
          <span style={{ fontSize:8, color:'#404060', fontFamily:'monospace' }}>{r.label}</span>
          <span style={{ fontSize:8, color:r.color, fontFamily:'monospace', fontWeight:'bold' }}>{r.value}</span>
          {r.score != null && (
            <div style={{ width:32, height:4, background:'#1a1a2e', borderRadius:2, overflow:'hidden' }}>
              <div style={{ width:`${r.score}%`, height:'100%', background:r.score>=60?'#00ff88':r.score>=40?'#ffcc00':'#ff3366', borderRadius:2 }}/>
            </div>
          )}
        </div>
      ))}
      {onchain?.summary && <div style={{ fontSize:7, color:'#2a2a4a', padding:'2px 4px', fontFamily:'monospace' }}>{onchain.summary}</div>}
    </div>
  );
}

// ─── ETF TAB ──────────────────────────────────────────────────────────────────
function ETFTab({ masterResult }) {
  const etf = masterResult?.advanced?.etfFlow || masterResult?.etfFlow || null;
  if (!etf) {
    return (
      <div style={{ padding:'16px 8px', textAlign:'center', color:'#2a2a4a', fontSize:9, fontFamily:'monospace' }}>
        ETF verisi bekleniyor...
      </div>
    );
  }
  const btcNet   = etf.btcNetMln ?? etf.btcNet ?? 0;
  const ethNet   = etf.ethNetMln ?? etf.ethNet ?? 0;
  const totalNet = etf.totalNetMln ?? etf.totalNet ?? (btcNet + ethNet);
  const isPos    = totalNet >= 0;
  const netColor = Math.abs(totalNet) < 50 ? '#404070' : isPos ? '#00ff88' : '#ff3366';
  return (
    <div style={{ display:'flex', flexDirection:'column', gap:4, padding:'4px 0' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', background:'#0a0a1e', borderRadius:4, padding:'5px 8px', border:`1px solid ${netColor}25` }}>
        <span style={{ fontSize:9, color:'#404070', fontFamily:'monospace' }}>TOPLAM ETF NET</span>
        <span style={{ fontSize:11, color:netColor, fontFamily:'monospace', fontWeight:'bold' }}>{isPos?'+':''}{totalNet.toFixed(0)}M$</span>
      </div>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', background:'#0a0a1e', borderRadius:4, padding:'4px 8px' }}>
        <span style={{ fontSize:8, color:'#404060', fontFamily:'monospace' }}>BTC ETF</span>
        <span style={{ fontSize:9, color:btcNet>=0?'#00ff88':'#ff3366', fontFamily:'monospace', fontWeight:'bold' }}>{btcNet>=0?'+':''}{btcNet.toFixed(0)}M$</span>
      </div>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', background:'#0a0a1e', borderRadius:4, padding:'4px 8px' }}>
        <span style={{ fontSize:8, color:'#404060', fontFamily:'monospace' }}>ETH ETF</span>
        <span style={{ fontSize:9, color:ethNet>=0?'#00ff88':'#ff3366', fontFamily:'monospace', fontWeight:'bold' }}>{ethNet>=0?'+':''}{ethNet.toFixed(0)}M$</span>
      </div>
      {etf.trend && <div style={{ fontSize:7, color:'#88ffcc', padding:'2px 4px', fontFamily:'monospace' }}>{etf.trend}</div>}
      {etf.score != null && (
        <div style={{ display:'flex', alignItems:'center', gap:6, padding:'2px 4px' }}>
          <span style={{ fontSize:7, color:'#2a2a4a', fontFamily:'monospace' }}>SKOR</span>
          <div style={{ flex:1, height:4, background:'#1a1a2e', borderRadius:2, overflow:'hidden' }}>
            <div style={{ width:`${etf.score}%`, height:'100%', background:etf.score>=60?'#00ff88':etf.score>=40?'#ffcc00':'#ff3366', borderRadius:2 }}/>
          </div>
          <span style={{ fontSize:7, color:'#404070', fontFamily:'monospace' }}>{etf.score}</span>
        </div>
      )}
    </div>
  );
}


// ─── ANA BİLEŞEN ─────────────────────────────────────────────────────────────
export default function MarketIntelPanel({ scanResults, masterResult, onRefresh, loading }) {
  const [activeTab, setActiveTab] = useState('scalp');

  if (!scanResults) {
    return (
      <div className="cyber-border rounded-lg p-8 flex items-center justify-center">
        <div className="text-[10px] font-mono text-gray-600 animate-pulse">Tarama başlatılıyor...</div>
      </div>
    );
  }

  const tabContent = {
    scalp:    <ScalpTab data={scanResults} />,
    ready:    <ReadyTab data={scanResults} />,
    pumpdump: <PumpDumpTab data={scanResults} />,
    stealth:  <StealthTab data={scanResults} />,
    btcrel:   <BTCRelTab data={{ ...scanResults }} />,
    risk:     <RiskTab data={scanResults} />,
    session:  <SessionTab data={scanResults} />,
    onchain:  <OnchainTab masterResult={masterResult} />,
    etf:      <ETFTab masterResult={masterResult} />,
  };

  // Summary counts per tab
  const counts = {
    scalp:    scanResults.scalpLongs.length + scanResults.scalpShorts.length,
    ready:    scanResults.longReady.length + scanResults.shortReady.length + scanResults.explosionReady.length,
    pumpdump: scanResults.suddenPumps.length + scanResults.suddenDumps.length,
    stealth:  scanResults.stealthRising.length + scanResults.stealthFalling.length,
    btcrel:   scanResults.btcStrong.length + scanResults.btcWeak.length,
    risk:     scanResults.stopHunts.length + scanResults.scalpTraps.length,
    session:  scanResults.sessionRisks.length,
  };

  return (
    <div className="cyber-border rounded-lg p-4 space-y-3">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-[#00aaff]" />
          <h3 className="text-xs font-bold tracking-widest uppercase text-[#00aaff]">
            Piyasa İstihbarat
          </h3>
        </div>
        <div className="flex items-center gap-2">
          {scanResults.timestamp && (
            <span className="text-[9px] font-mono text-gray-600">
              {new Date(scanResults.timestamp).toLocaleTimeString('tr-TR')}
            </span>
          )}
          <button
            onClick={onRefresh}
            disabled={loading}
            className="text-gray-600 hover:text-[#00aaff] transition-colors"
          >
            <RefreshCw style={{ width: 12, height: 12 }} className={loading ? 'animate-spin' : ''} />
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div>
        <div className="flex flex-wrap gap-1 mb-3">
          {TABS.map(t => {
            const Icon = t.icon;
            const isActive = activeTab === t.id;
            const count = counts[t.id] || 0;
            return (
              <button
                key={t.id}
                onClick={() => setActiveTab(t.id)}
                className="flex items-center gap-1 px-2 py-1 rounded text-[9px] font-mono font-bold tracking-wider uppercase transition-all relative"
                style={{
                  background: isActive ? `${t.color}15` : '#0a0a0f',
                  color: isActive ? t.color : '#4b5563',
                  border: `1px solid ${isActive ? t.color + '40' : '#1a1a2e'}`,
                }}
              >
                <Icon style={{ width: 9, height: 9 }} />
                {t.label}
                {count > 0 && (
                  <span
                    className="text-[8px] font-mono ml-0.5"
                    style={{ color: isActive ? t.color : '#6b7280' }}
                  >
                    {count}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Content */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.15 }}
          >
            {tabContent[activeTab]}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
