/**
 * GRID MASTER GLOBAL — TECHNICAL EXTENSION ENGINE v1
 * ====================================================
 * Eksik teknik ve liquidity modülleri:
 *
 * MACD ENGINE
 * BOS DETECTOR (ayrı modül)
 * CHOCH DETECTOR (ayrı modül)
 * STEALTH TREND ENGINE
 * BUY WALL DETECTOR
 * SELL WALL DETECTOR
 * LIQUIDITY CLUSTER DETECTOR
 * LONG SHORT RATIO ENGINE
 * SQUEEZE DETECTOR
 */

import { clamp, ema } from './engineCore.js';

// ════════════════════════════════════════════════════════════════════════════════
// 1. MACD ENGINE
// ════════════════════════════════════════════════════════════════════════════════
/**
 * MACD hesaplama ve sinyal üretimi.
 * MACD = EMA(12) - EMA(26)
 * Signal = EMA(9) of MACD
 * Histogram = MACD - Signal
 */
export function computeMACD(closes = [], fast = 12, slow = 26, signal = 9) {
  if (closes.length < slow + signal) {
    return { macd: null, signal: null, histogram: null, crossover: null };
  }

  // EMA serilerini hesapla
  function emaArr(data, period) {
    const k = 2 / (period + 1);
    const result = [];
    let sum = 0;
    for (let i = 0; i < period; i++) sum += data[i];
    result.push(sum / period);
    for (let i = period; i < data.length; i++) {
      result.push(data[i] * k + result[result.length - 1] * (1 - k));
    }
    return result;
  }

  const emaFast = emaArr(closes, fast);
  const emaSlow = emaArr(closes, slow);

  // MACD serisi: fast ve slow aynı başlangıç noktasına hizala
  const offset  = slow - fast;
  const macdArr = emaFast.slice(offset).map((v, i) => v - emaSlow[i]);

  const signalArr = emaArr(macdArr, signal);
  const histArr   = signalArr.map((s, i) => macdArr[i + (signal - 1)] - s);

  const lastMACD    = macdArr[macdArr.length - 1];
  const lastSignal  = signalArr[signalArr.length - 1];
  const lastHist    = histArr[histArr.length - 1];
  const prevHist    = histArr[histArr.length - 2] || 0;

  // Crossover tespiti
  const crossover =
    prevHist < 0 && lastHist >= 0 ? 'BULLISH_CROSS' :
    prevHist > 0 && lastHist <= 0 ? 'BEARISH_CROSS' : null;

  // Histogram momentum
  const histMomentum = lastHist - prevHist;

  return {
    macd:         parseFloat(lastMACD?.toFixed(6)    || 0),
    signal:       parseFloat(lastSignal?.toFixed(6)  || 0),
    histogram:    parseFloat(lastHist?.toFixed(6)    || 0),
    histMomentum: parseFloat(histMomentum?.toFixed(6)|| 0),
    crossover,
    bullish:      lastMACD > lastSignal,
    bearish:      lastMACD < lastSignal,
    increasing:   histMomentum > 0,
    macdArr:      macdArr.slice(-20),
    signalArr:    signalArr.slice(-20),
    histArr:      histArr.slice(-20),
  };
}

export function runMACDEngine(closes = []) {
  const macd  = computeMACD(closes);
  if (!macd.macd && macd.macd !== 0) {
    return { score: 50, summary: 'MACD: Yetersiz veri', timestamp: new Date().toISOString() };
  }

  let   score = 50;
  const signals = [];

  if (macd.crossover === 'BULLISH_CROSS') { score += 25; signals.push('🟢 MACD Bullish crossover — Alım sinyali'); }
  if (macd.crossover === 'BEARISH_CROSS') { score -= 25; signals.push('🔴 MACD Bearish crossover — Satım sinyali'); }

  if (macd.bullish && macd.increasing)    { score += 12; signals.push('MACD histogram genişliyor — Momentum artıyor'); }
  if (macd.bearish && !macd.increasing)   { score -= 12; }

  if (macd.histogram > 0 && macd.macd > 0) { score += 8; }
  else if (macd.histogram < 0 && macd.macd < 0) { score -= 8; }

  return {
    score:    clamp(score),
    ...macd,
    signals,
    summary:  macd.crossover || signals[0] || `MACD: ${macd.bullish ? 'Bullish' : 'Bearish'} (H:${macd.histogram?.toFixed(4)})`,
    timestamp: new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// 2. BOS DETECTOR (Break of Structure)
// ════════════════════════════════════════════════════════════════════════════════
/**
 * Ayrı modül — Trend devam sinyali.
 * BOS = Önceki swing high kırıldı (bullish) veya swing low kırıldı (bearish)
 */
export function runBOSDetector(candles = [], swingLookback = 5) {
  if (candles.length < swingLookback * 2 + 2) {
    return { score: 50, bos: null, summary: 'BOS: Yetersiz veri', timestamp: new Date().toISOString() };
  }

  const highs = candles.map(c => c.high);
  const lows  = candles.map(c => c.low);
  const n     = candles.length;

  // Son swing high/low bul
  let lastSwingHigh = -Infinity, lastSwingLow = Infinity;
  for (let i = swingLookback; i < n - 1; i++) {
    const isSwingHigh = highs[i] === Math.max(...highs.slice(i - swingLookback, i + swingLookback + 1));
    const isSwingLow  = lows[i]  === Math.min(...lows.slice(i - swingLookback, i + swingLookback + 1));
    if (isSwingHigh) lastSwingHigh = highs[i];
    if (isSwingLow)  lastSwingLow  = lows[i];
  }

  const lastClose   = candles[n - 1].close;
  const bullishBOS  = lastClose > lastSwingHigh && lastSwingHigh > -Infinity;
  const bearishBOS  = lastClose < lastSwingLow  && lastSwingLow  < Infinity;

  let   score = 50;
  if (bullishBOS) { score += 20; }
  if (bearishBOS) { score -= 20; }

  return {
    score:        clamp(score),
    bos:          bullishBOS ? 'BULLISH_BOS' : bearishBOS ? 'BEARISH_BOS' : null,
    bullishBOS,   bearishBOS,
    lastSwingHigh: parseFloat(lastSwingHigh.toFixed(4)),
    lastSwingLow:  parseFloat(lastSwingLow.toFixed(4)),
    lastClose,
    summary:       bullishBOS ? `🟢 Bullish BOS — ${lastSwingHigh.toFixed(4)} kırıldı` :
                   bearishBOS ? `🔴 Bearish BOS — ${lastSwingLow.toFixed(4)} kırıldı` : 'BOS: Yok',
    timestamp:     new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// 3. CHOCH DETECTOR (Change of Character)
// ════════════════════════════════════════════════════════════════════════════════
/**
 * Ayrı modül — Trend dönüş sinyali.
 * CHoCH = Düşüş trendindeyken önceki HL kırıldı (bullish CHoCH)
 */
export function runCHoCHDetector(candles = [], lookback = 10) {
  if (candles.length < lookback + 5) {
    return { score: 50, choch: null, summary: 'CHoCH: Yetersiz veri', timestamp: new Date().toISOString() };
  }

  const closes = candles.map(c => c.close);
  const n      = candles.length;

  // Trend yönü: son lookback mumda genel yön
  const startPrice = closes[n - lookback - 1];
  const midPrice   = closes[Math.floor(n - lookback / 2)];
  const endPrice   = closes[n - 1];

  const wasDowntrend = startPrice > midPrice && midPrice >= endPrice; // Düşüş trendi
  const wasUptrend   = startPrice < midPrice && midPrice <= endPrice; // Yükseliş trendi

  // CHoCH tespiti: Düşüş trendinde ani yükseliş
  const recentChange = (endPrice - closes[n - 4]) / closes[n - 4] * 100;

  let   choch = null;
  let   score = 50;

  if (wasDowntrend && recentChange >= 2) {
    choch = 'BULLISH_CHOCH';
    score += 22;
  } else if (wasUptrend && recentChange <= -2) {
    choch = 'BEARISH_CHOCH';
    score -= 22;
  }

  return {
    score:       clamp(score),
    choch,
    wasDowntrend, wasUptrend,
    recentChange: parseFloat(recentChange.toFixed(3)),
    bullishCHoCH: choch === 'BULLISH_CHOCH',
    bearishCHoCH: choch === 'BEARISH_CHOCH',
    summary:      choch === 'BULLISH_CHOCH' ? '🔄 Bullish CHoCH — Trend dönüş sinyali' :
                  choch === 'BEARISH_CHOCH' ? '🔄 Bearish CHoCH — Yukarı trend kırılıyor' : 'CHoCH: Yok',
    timestamp:    new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// 4. STEALTH TREND ENGINE
// ════════════════════════════════════════════════════════════════════════════════
/**
 * Sessiz/gizli trend tespiti.
 * Düşük volatilite + tutarlı yön + hacim artışı olmadan giden trend
 */
export function runStealthTrendEngine(candles = [], period = 20) {
  if (candles.length < period + 5) {
    return { score: 50, stealth: false, summary: 'Stealth: Yetersiz veri', timestamp: new Date().toISOString() };
  }

  const closes = candles.slice(-period).map(c => c.close);
  const vols   = candles.slice(-period).map(c => c.volume);

  // Yön tutarlılığı
  let   upBars = 0, downBars = 0;
  for (let i = 1; i < closes.length; i++) {
    if (closes[i] > closes[i-1]) upBars++;
    else downBars++;
  }

  const dirConsistency = Math.max(upBars, downBars) / (period - 1);
  const totalChange    = (closes[closes.length-1] - closes[0]) / closes[0] * 100;

  // Düşük volatilite tespiti
  const changes = closes.map((c, i) => i > 0 ? Math.abs(c - closes[i-1]) / closes[i-1] * 100 : 0).slice(1);
  const avgVol  = changes.reduce((a, b) => a + b, 0) / changes.length;
  const lowVol  = avgVol < 1.0;

  // Hacim: Stealth trend = yüksek hacim olmadan gidiyor
  const avgVolume = vols.reduce((a, b) => a + b, 0) / vols.length;
  const volStdDev = Math.sqrt(vols.map(v => (v - avgVolume)**2).reduce((a, b) => a + b, 0) / vols.length);
  const quietVolume = volStdDev / avgVolume < 0.3;

  const stealthUp   = dirConsistency >= 0.65 && totalChange >= 3 && lowVol && upBars > downBars;
  const stealthDown = dirConsistency >= 0.65 && totalChange <= -3 && lowVol && downBars > upBars;
  const stealth     = stealthUp || stealthDown;

  let   score = 50;
  if (stealthUp)   { score += 18; }
  if (stealthDown) { score -= 18; }
  if (stealth)     { score += (dirConsistency - 0.5) * 20; }

  return {
    score:        clamp(score),
    stealth, stealthUp, stealthDown,
    dirConsistency: parseFloat(dirConsistency.toFixed(3)),
    totalChange:    parseFloat(totalChange.toFixed(3)),
    avgVolatility:  parseFloat(avgVol.toFixed(3)),
    quietVolume,
    summary:        stealthUp   ? `📈 Stealth yükseliş tespiti (+${totalChange.toFixed(2)}%, sessiz)` :
                    stealthDown ? `📉 Stealth düşüş tespiti (${totalChange.toFixed(2)}%, sessiz)` : 'Stealth trend yok',
    timestamp:      new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// 5. BUY WALL DETECTOR
// ════════════════════════════════════════════════════════════════════════════════
export function runBuyWallDetector(orderbook = { bids: [], asks: [] }, currentPrice = 0) {
  const bids = orderbook.bids || [];
  if (!bids.length || !currentPrice) {
    return { score: 50, walls: [], summary: 'Buy wall: Veri yok', timestamp: new Date().toISOString() };
  }

  // Toplam bid hacmi
  const totalBidVol = bids.reduce((a, b) => a + (b[1] || 0), 0);
  const avgBidVol   = totalBidVol / (bids.length || 1);

  // Büyük duvarları bul (ortalama 3x üzeri)
  const walls = bids
    .filter(b => b[1] >= avgBidVol * 3)
    .map(b => ({
      price:    parseFloat(b[0]),
      size:     parseFloat(b[1]),
      distPct:  currentPrice ? parseFloat(((currentPrice - b[0]) / currentPrice * 100).toFixed(3)) : 0,
      strength: b[1] >= avgBidVol * 6 ? 'GÜÇLÜ' : 'ORTA',
    }))
    .sort((a, b) => a.distPct - b.distPct)
    .slice(0, 5);

  const nearestWall = walls[0] || null;
  const hasStrongWall = walls.some(w => w.strength === 'GÜÇLÜ' && w.distPct <= 1.5);

  let score = 50;
  if (hasStrongWall)      { score += 18; }
  if (walls.length >= 3)  { score += 8; }

  return {
    score:       clamp(score),
    walls, nearestWall,
    wallCount:   walls.length,
    hasStrongWall,
    summary:     walls.length
      ? `${walls.length} alış duvarı | En yakın: $${nearestWall?.price} (${nearestWall?.distPct}% uzakta)`
      : 'Belirgin alış duvarı yok',
    timestamp:   new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// 6. SELL WALL DETECTOR
// ════════════════════════════════════════════════════════════════════════════════
export function runSellWallDetector(orderbook = { bids: [], asks: [] }, currentPrice = 0) {
  const asks = orderbook.asks || [];
  if (!asks.length || !currentPrice) {
    return { score: 50, walls: [], summary: 'Sell wall: Veri yok', timestamp: new Date().toISOString() };
  }

  const totalAskVol = asks.reduce((a, b) => a + (b[1] || 0), 0);
  const avgAskVol   = totalAskVol / (asks.length || 1);

  const walls = asks
    .filter(a => a[1] >= avgAskVol * 3)
    .map(a => ({
      price:    parseFloat(a[0]),
      size:     parseFloat(a[1]),
      distPct:  currentPrice ? parseFloat(((a[0] - currentPrice) / currentPrice * 100).toFixed(3)) : 0,
      strength: a[1] >= avgAskVol * 6 ? 'GÜÇLÜ' : 'ORTA',
    }))
    .sort((a, b) => a.distPct - b.distPct)
    .slice(0, 5);

  const nearestWall   = walls[0] || null;
  const hasStrongWall = walls.some(w => w.strength === 'GÜÇLÜ' && w.distPct <= 1.5);

  let score = 50;
  if (hasStrongWall)   { score -= 18; } // Satış duvarı = direnç = düşük skor
  if (walls.length >= 3) { score -= 8; }

  return {
    score:       clamp(score),
    walls, nearestWall,
    wallCount:   walls.length,
    hasStrongWall,
    summary:     walls.length
      ? `${walls.length} satış duvarı | En yakın: $${nearestWall?.price} (${nearestWall?.distPct}% uzakta)`
      : 'Belirgin satış duvarı yok',
    timestamp:   new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// 7. LIQUIDITY CLUSTER DETECTOR
// ════════════════════════════════════════════════════════════════════════════════
/**
 * Hem alış hem satış tarafındaki likidite yoğunlaşmalarını tespit eder.
 */
export function runLiquidityClusterDetector(orderbook = {}, currentPrice = 0) {
  const buyWalls  = runBuyWallDetector(orderbook, currentPrice);
  const sellWalls = runSellWallDetector(orderbook, currentPrice);

  // En yakın likidite kümesi
  const allClusters = [
    ...buyWalls.walls.map(w => ({ ...w, side: 'BID' })),
    ...sellWalls.walls.map(w => ({ ...w, side: 'ASK' })),
  ].sort((a, b) => a.distPct - b.distPct);

  const nearestCluster = allClusters[0] || null;
  const bidAskBalance  = buyWalls.wallCount - sellWalls.wallCount;

  let score = 50;
  score += bidAskBalance * 5;
  if (nearestCluster?.side === 'BID') score += 8;
  if (nearestCluster?.side === 'ASK') score -= 8;

  return {
    score:          clamp(score),
    allClusters:    allClusters.slice(0, 8),
    nearestCluster,
    buyWallCount:   buyWalls.wallCount,
    sellWallCount:  sellWalls.wallCount,
    bidAskBalance,
    liquidityBias:  bidAskBalance > 0 ? 'ALICI AĞIRLIKLI' : bidAskBalance < 0 ? 'SATICI AĞIRLIKLI' : 'DENGELİ',
    summary:        nearestCluster
      ? `En yakın küme: $${nearestCluster.price} (${nearestCluster.side}, ${nearestCluster.distPct}% uzakta)`
      : 'Likidite kümesi yok',
    timestamp:      new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// 8. LONG SHORT RATIO ENGINE
// ════════════════════════════════════════════════════════════════════════════════
/**
 * Long/Short oranı analizi.
 * Aşırı long = potansiyel squeeze
 * Aşırı short = potansiyel short squeeze
 */
export function runLongShortRatioEngine({
  longRatio    = 0.5,   // 0-1 arası
  shortRatio   = 0.5,
  historicalAvg = 0.5,  // Tarihsel ortalama
  topTradersLS  = 0.5,  // Top trader long oranı (genelde daha doğru)
} = {}) {

  const netLong         = longRatio - 0.5;  // +0.5 = tamamen long, -0.5 = tamamen short
  const divergesFromTop = Math.abs(longRatio - topTradersLS) > 0.15;

  let   score   = 50;
  const signals = [];

  // Aşırı long = dikkat (dışbükey düşüş riski)
  if (longRatio >= 0.75)      { score -= 15; signals.push(`Aşırı long oranı: %${(longRatio*100).toFixed(0)} — Squeeze riski`); }
  else if (longRatio >= 0.65) { score -= 8; }

  // Aşırı short = short squeeze fırsatı
  else if (longRatio <= 0.35) { score += 20; signals.push(`Aşırı short: %${(shortRatio*100).toFixed(0)} — Short squeeze fırsatı 🔥`); }
  else if (longRatio <= 0.45) { score += 10; }

  // Top trader ile uyumsuzluk
  if (divergesFromTop && topTradersLS > longRatio) {
    score += 10;
    signals.push('Top trader long ağırlıklı — Retail short squeeze yakın');
  }

  score = clamp(score);

  return {
    score,
    longRatio:        parseFloat((longRatio * 100).toFixed(1)),
    shortRatio:       parseFloat((shortRatio * 100).toFixed(1)),
    topTradersLS:     parseFloat((topTradersLS * 100).toFixed(1)),
    netLong:          parseFloat(netLong.toFixed(3)),
    longSqueeze:      longRatio >= 0.70,
    shortSqueeze:     longRatio <= 0.35,
    signals,
    summary:          signals[0] || `L/S Oranı: %${(longRatio*100).toFixed(0)} Long / %${(shortRatio*100).toFixed(0)} Short`,
    timestamp:        new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// 9. SQUEEZE DETECTOR
// ════════════════════════════════════════════════════════════════════════════════
/**
 * Bollinger Band + Keltner Channel Squeeze tespiti.
 * BB içinde KC = Sıkışma = Büyük hareket yaklaşıyor
 */
export function runSqueezeDetector(candles = [], bbPeriod = 20, kcPeriod = 20, bbMult = 2, kcMult = 1.5) {
  if (candles.length < bbPeriod + 5) {
    return { score: 50, squeezing: false, summary: 'Squeeze: Yetersiz veri', timestamp: new Date().toISOString() };
  }

  const closes = candles.map(c => c.close);
  const highs  = candles.map(c => c.high);
  const lows   = candles.map(c => c.low);
  const n      = closes.length;

  // BB hesapla
  const sliceCL = closes.slice(-bbPeriod);
  const bbMean  = sliceCL.reduce((a, b) => a + b, 0) / bbPeriod;
  const bbStd   = Math.sqrt(sliceCL.map(v => (v - bbMean)**2).reduce((a, b) => a + b, 0) / bbPeriod);
  const bbUpper = bbMean + bbMult * bbStd;
  const bbLower = bbMean - bbMult * bbStd;
  const bbWidth = (bbUpper - bbLower) / bbMean * 100;

  // KC hesapla (EMA + ATR)
  const ema20   = ema(closes, kcPeriod) || bbMean;
  const trArr   = candles.slice(-kcPeriod).map((c, i, arr) =>
    i === 0 ? c.high - c.low :
    Math.max(c.high - c.low, Math.abs(c.high - arr[i-1].close), Math.abs(c.low - arr[i-1].close))
  );
  const atr     = trArr.reduce((a, b) => a + b, 0) / trArr.length;
  const kcUpper = ema20 + kcMult * atr;
  const kcLower = ema20 - kcMult * atr;

  // BB KC içinde mi? (sıkışma)
  const squeezing  = bbUpper <= kcUpper && bbLower >= kcLower;

  // Histogram: momentum yönü
  const histArr  = closes.slice(-5).map((c, i, arr) => i > 0 ? c - arr[i-1] : 0).slice(1);
  const histMom  = histArr[histArr.length-1] || 0;
  const histDir  = histMom > 0 ? 'UP' : histMom < 0 ? 'DOWN' : 'FLAT';

  let   score = 50;
  if (squeezing) {
    score += 15; // Sıkışma = büyük hareket yaklaşıyor
    if (histDir === 'UP')   score += 12;
    if (histDir === 'DOWN') score -= 12;
  }
  if (bbWidth <= 2.0) { score += 8; } // Çok dar = kuvvetli sıkışma

  return {
    score:     clamp(score),
    squeezing,
    bbWidth:   parseFloat(bbWidth.toFixed(3)),
    bbUpper:   parseFloat(bbUpper.toFixed(6)),
    bbLower:   parseFloat(bbLower.toFixed(6)),
    kcUpper:   parseFloat(kcUpper.toFixed(6)),
    kcLower:   parseFloat(kcLower.toFixed(6)),
    histDir,
    histMom:   parseFloat(histMom.toFixed(6)),
    breakoutDir: squeezing ? (histDir === 'UP' ? 'YUKARI KIRILIŞ BEKLENIYOR' : histDir === 'DOWN' ? 'AŞAĞI KIRILIŞ BEKLENIYOR' : 'KIRILIŞ BEKLENIYOR') : null,
    summary:   squeezing
      ? `🔥 SQUEEZE AKTİF — ${histDir === 'UP' ? 'Yukari' : 'Aşağı'} kırılış bekleniyor (BB:%${bbWidth.toFixed(2)})`
      : `Squeeze yok (BB genişliği:%${bbWidth.toFixed(2)})`,
    timestamp: new Date().toISOString(),
  };
}
