/**
 * GRID MASTER GLOBAL — HISTORICAL PATTERN ENGINE v1
 * ===================================================
 * Son N mumun geçmişteki benzeri bulur, ne olduğunu analiz eder.
 *
 * ALGORİTMA:
 *   1. Mevcut son 50 mumu normalize et (z-score)
 *   2. Tüm geçmiş veri üzerinde kayan pencere ile karşılaştır
 *   3. Öklid mesafesi ile %benzerlik hesapla
 *   4. En çok benzeyen 5 geçmiş pattern'i bul
 *   5. Bu pattern'lerden sonra ne olmuş → tahmin üret
 *
 * ÇIKTI:
 *   { score, prediction, confidence, matches, summary }
 */

import { clamp, computeRSI } from './engineCore.js';

// ─── SABİTLER ────────────────────────────────────────────────────────────────
const PATTERN_WINDOW  = 50;   // Kaç mum karşılaştırılacak
const FORECAST_BARS   = 10;   // Sonrasında kaç mum bakılacak
const TOP_MATCHES     = 5;    // Kaç benzer pattern seçilecek
const MIN_HISTORY     = 200;  // Minimum geçmiş mum sayısı

// ─── NORMALIZE (Z-SCORE) ─────────────────────────────────────────────────────
function zScore(arr) {
  if (!arr.length) return arr;
  const mean   = arr.reduce((a, b) => a + b, 0) / arr.length;
  const stddev = Math.sqrt(arr.map(v => (v - mean) ** 2).reduce((a, b) => a + b, 0) / arr.length);
  return stddev ? arr.map(v => (v - mean) / stddev) : arr.map(() => 0);
}

// ─── KAPANIŞ DEĞİŞİM DİZİSİ ─────────────────────────────────────────────────
// Ham fiyat yerine % değişim kullan → farklı fiyat bölgeleri karşılaştırılabilir
function toChangeArr(closes) {
  const changes = [0];
  for (let i = 1; i < closes.length; i++) {
    changes.push(closes[i - 1] ? (closes[i] - closes[i - 1]) / closes[i - 1] * 100 : 0);
  }
  return changes;
}

// ─── ÖKLİD MESAFESİ ──────────────────────────────────────────────────────────
function euclideanDistance(a, b) {
  const len = Math.min(a.length, b.length);
  let   sum = 0;
  for (let i = 0; i < len; i++) sum += (a[i] - b[i]) ** 2;
  return Math.sqrt(sum / len);
}

// ─── BENZERLİK PUANI ─────────────────────────────────────────────────────────
// Mesafe 0 → %100 benzer, mesafe büyüdükçe azalır
function distToSimilarity(dist) {
  return clamp(Math.round(Math.max(0, 1 - dist / 3) * 100));
}

// ─── GEÇMİŞ PATTERN ARAŞTIR ──────────────────────────────────────────────────
function findSimilarPatterns(candles, windowSize = PATTERN_WINDOW) {
  if (candles.length < MIN_HISTORY + FORECAST_BARS) return [];

  const closes = candles.map(c => c.close);

  // Mevcut son pattern
  const currentSlice   = closes.slice(-windowSize);
  const currentChanges = zScore(toChangeArr(currentSlice));

  const matches = [];
  // Tüm geçmişi tara (son windowSize + forecastBars kadar hariç)
  const limit = candles.length - windowSize - FORECAST_BARS;

  for (let i = 0; i < limit; i++) {
    const histSlice   = closes.slice(i, i + windowSize);
    const histChanges = zScore(toChangeArr(histSlice));
    const dist        = euclideanDistance(currentChanges, histChanges);
    const similarity  = distToSimilarity(dist);

    if (similarity < 50) continue; // Çok düşük benzerlik, atla

    // Bu pattern'den sonra ne olmuş?
    const afterClose = closes.slice(i + windowSize, i + windowSize + FORECAST_BARS);
    const basePrice  = closes[i + windowSize - 1];
    const maxUp      = basePrice ? (Math.max(...afterClose) - basePrice) / basePrice * 100 : 0;
    const maxDown    = basePrice ? (Math.min(...afterClose) - basePrice) / basePrice * 100 : 0;
    const endChange  = afterClose.length ? (afterClose[afterClose.length - 1] - basePrice) / basePrice * 100 : 0;
    const direction  = endChange >= 0.5 ? 'UP' : endChange <= -0.5 ? 'DOWN' : 'FLAT';

    matches.push({
      startIndex:  i,
      startTime:   candles[i]?.openTime,
      endTime:     candles[i + windowSize - 1]?.closeTime,
      similarity,
      dist:        parseFloat(dist.toFixed(4)),
      afterBars:   FORECAST_BARS,
      outcome: {
        direction,
        endChange:   parseFloat(endChange.toFixed(3)),
        maxUp:       parseFloat(maxUp.toFixed(3)),
        maxDown:     parseFloat(maxDown.toFixed(3)),
      },
    });
  }

  // En benzer TOP_MATCHES kadar döndür
  return matches
    .sort((a, b) => b.similarity - a.similarity)
    .slice(0, TOP_MATCHES);
}

// ─── TAHMİN HESAPLA ──────────────────────────────────────────────────────────
function computePrediction(matches) {
  if (!matches.length) return { direction: 'UNKNOWN', upProb: 50, avgExpected: 0, confidence: 0 };

  const ups    = matches.filter(m => m.outcome.direction === 'UP').length;
  const downs  = matches.filter(m => m.outcome.direction === 'DOWN').length;
  const upProb = Math.round(ups / matches.length * 100);

  const avgExpected  = matches.reduce((a, m) => a + m.outcome.endChange, 0) / matches.length;
  const avgSimilarity = matches.reduce((a, m) => a + m.similarity, 0) / matches.length;

  // Güven: ortalama benzerlik + oy çoğunluğu
  const majorityStrength = Math.abs(upProb - 50) / 50;
  const confidence = clamp(Math.round(avgSimilarity * 0.6 + majorityStrength * 40));

  const direction = upProb >= 60 ? 'UP' : upProb <= 40 ? 'DOWN' : 'SIDEWAYS';

  return {
    direction,
    upProb,
    downProb:    100 - upProb,
    avgExpected: parseFloat(avgExpected.toFixed(3)),
    confidence,
  };
}

// ─── HACIM PATTERN ANALİZİ ───────────────────────────────────────────────────
function volumePatternAnalysis(candles, windowSize = PATTERN_WINDOW) {
  const recent = candles.slice(-windowSize);
  const vols   = recent.map(c => c.volume);
  const avgVol = vols.reduce((a, b) => a + b, 0) / vols.length;

  // Hacim trendi: son 10 vs önceki 10
  const recentVol = vols.slice(-10).reduce((a, b) => a + b, 0) / 10;
  const prevVol   = vols.slice(-20, -10).reduce((a, b) => a + b, 0) / 10;
  const volTrend  = prevVol ? (recentVol - prevVol) / prevVol * 100 : 0;

  return {
    avgVolume:   parseFloat(avgVol.toFixed(0)),
    volTrend:    parseFloat(volTrend.toFixed(2)),
    volExpanding: volTrend > 10,
    volShrinking: volTrend < -10,
  };
}

// ─── ANA FONKSİYON ───────────────────────────────────────────────────────────
/**
 * runHistoricalPatternEngine
 *
 * @param {Array}  candles    — Normalize edilmiş mum dizisi { open,high,low,close,volume }
 * @param {number} windowSize — Kaç mum karşılaştırılacak (default: 50)
 */
export function runHistoricalPatternEngine(candles = [], windowSize = PATTERN_WINDOW) {
  if (!candles || candles.length < MIN_HISTORY) {
    return {
      score:      50,
      summary:    `Yetersiz veri (${candles.length} < ${MIN_HISTORY})`,
      matches:    [],
      prediction: { direction: 'UNKNOWN', upProb: 50, confidence: 0 },
      timestamp:  new Date().toISOString(),
    };
  }

  const matches    = findSimilarPatterns(candles, windowSize);
  const prediction = computePrediction(matches);
  const volPattern = volumePatternAnalysis(candles, windowSize);

  // Skor: tahmin güveni + yön
  let score = 50;
  if (prediction.direction === 'UP')   score += prediction.confidence * 0.4;
  if (prediction.direction === 'DOWN') score -= prediction.confidence * 0.4;
  if (volPattern.volExpanding)         score += 5;
  if (volPattern.volShrinking)         score -= 3;
  score = clamp(score);

  const topMatch = matches[0];
  const dirLabel = prediction.direction === 'UP' ? '📈 YUKARI' :
                   prediction.direction === 'DOWN' ? '📉 AŞAĞI' : '↔ YATAY';

  return {
    score:       parseFloat(score.toFixed(1)),
    matches,
    prediction,
    volPattern,
    topMatch:    topMatch || null,
    dirLabel,
    summary:     matches.length
      ? `${matches.length} benzer pattern bulundu | ${dirLabel} (%${prediction.upProb} olasılık, güven: ${prediction.confidence})`
      : 'Yeterince benzer geçmiş pattern bulunamadı',
    timestamp:   new Date().toISOString(),
  };
}

// ─── HIZLI PATTERN SKORU ─────────────────────────────────────────────────────
/**
 * getPatternScore — Sadece skor ve özet döner (hafif versiyon)
 */
export function getPatternScore(candles) {
  const r = runHistoricalPatternEngine(candles);
  return { score: r.score, summary: r.summary, timestamp: r.timestamp };
}

// ─── PATTERN GÖRSELLEŞTİRME VERİSİ ─────────────────────────────────────────
/**
 * getPatternChartData — Eşleşen pattern'lerin chart overlay verisi
 */
export function getPatternChartData(candles, matches) {
  return matches.map((m, idx) => {
    const slice = candles.slice(m.startIndex, m.startIndex + PATTERN_WINDOW);
    return {
      matchIndex:  idx + 1,
      similarity:  m.similarity,
      candles:     slice.map(c => c.close),
      direction:   m.outcome.direction,
      endChange:   m.outcome.endChange,
      startTime:   m.startTime,
    };
  });
}
