import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Clock, TrendingUp, TrendingDown, Minus, ChevronRight } from 'lucide-react';
import { fetchBinanceKlines, computeRSI, computeMACD, computeBollingerBands } from './exchangeAPI';

const TIMEFRAMES = [
  { label: '1m',  interval: '1m',  limit: 60,  weight: 0.05 },
  { label: '5m',  interval: '5m',  limit: 60,  weight: 0.10 },
  { label: '15m', interval: '15m', limit: 60,  weight: 0.15 },
  { label: '1H',  interval: '1h',  limit: 60,  weight: 0.25 },
  { label: '4H',  interval: '4h',  limit: 60,  weight: 0.25 },
  { label: '1D',  interval: '1d',  limit: 30,  weight: 0.20 },
];

function analyzeKlines(klines) {
  if (!klines || klines.length < 10) return null;
  const prices = klines.map(k => k.price);
  const closes = prices;
  const current = closes[closes.length - 1];
  const prev    = closes[closes.length - 2];

  const rsi  = computeRSI(klines);
  const macd = computeMACD(klines);
  const bb   = computeBollingerBands(klines);

  // EMA 9 / 21
  const ema = (data, p) => {
    const k = 2 / (p + 1);
    return data.reduce((acc, v, i) => {
      acc.push(i === 0 ? v : v * k + acc[i - 1] * (1 - k));
      return acc;
    }, []);
  };
  const ema9  = ema(closes, 9);
  const ema21 = ema(closes, 21);
  const lastEma9  = ema9[ema9.length - 1];
  const lastEma21 = ema21[ema21.length - 1];

  // Trend
  const emaTrend = lastEma9 > lastEma21 ? 'YUKARI' : 'AŞAĞI';

  // Momentum
  const change5 = ((current - closes[closes.length - 6]) / closes[closes.length - 6]) * 100;

  // Sinyal birleştir
  let bullPoints = 0, bearPoints = 0;
  if (rsi < 30) bullPoints += 2;
  else if (rsi > 70) bearPoints += 2;
  else if (rsi > 55) bullPoints += 1;
  else if (rsi < 45) bearPoints += 1;

  if (macd?.histogram > 0) bullPoints += 2;
  else if (macd?.histogram < 0) bearPoints += 2;

  if (emaTrend === 'YUKARI') bullPoints += 2;
  else bearPoints += 2;

  if (bb && bb.position < 0.2) bullPoints += 1;
  else if (bb && bb.position > 0.8) bearPoints += 1;

  const total = bullPoints + bearPoints;
  const bullPct = total > 0 ? (bullPoints / total) * 100 : 50;

  let signal = 'NÖTR';
  let signalColor = '#ffcc00';
  if (bullPct >= 70)      { signal = 'AL';    signalColor = '#00ff88'; }
  else if (bullPct >= 55) { signal = 'ZAYIF AL'; signalColor = '#00cc66'; }
  else if (bullPct <= 30) { signal = 'SAT';   signalColor = '#ff3366'; }
  else if (bullPct <= 45) { signal = 'ZAYIF SAT'; signalColor = '#cc2244'; }

  return { rsi, macd, bb, emaTrend, change5: parseFloat(change5.toFixed(2)), signal, signalColor, bullPct: parseFloat(bullPct.toFixed(1)), current };
}

function TrendArrow({ signal }) {
  if (signal === 'AL' || signal === 'ZAYIF AL')
    return <TrendingUp className="w-3 h-3" style={{ color: signal === 'AL' ? '#00ff88' : '#00cc66' }} />;
  if (signal === 'SAT' || signal === 'ZAYIF SAT')
    return <TrendingDown className="w-3 h-3" style={{ color: signal === 'SAT' ? '#ff3366' : '#cc2244' }} />;
  return <Minus className="w-3 h-3 text-[#ffcc00]" />;
}

function MiniBar({ value, max = 100, color }) {
  const pct = Math.min(100, Math.max(0, (value / max) * 100));
  return (
    <div className="relative h-1 rounded-full overflow-hidden bg-[#1a1a2e] w-full">
      <motion.div
        className="absolute left-0 top-0 h-full rounded-full"
        style={{ background: color }}
        initial={{ width: 0 }}
        animate={{ width: `${pct}%` }}
        transition={{ duration: 0.6 }}
      />
    </div>
  );
}

export default function MultiTimeframePanel({ symbol }) {
  const [tfData, setTfData] = useState({});
  const [loading, setLoading] = useState(true);
  const [lastUpdate, setLastUpdate] = useState(null);

  const fetchAll = async () => {
    if (!symbol) return;
    try {
      const results = await Promise.allSettled(
        TIMEFRAMES.map(tf => fetchBinanceKlines(symbol, tf.interval, tf.limit).then(k => ({ tf: tf.label, klines: k })))
      );
      const map = {};
      results.forEach(r => {
        if (r.status === 'fulfilled' && r.value) {
          const { tf, klines } = r.value;
          map[tf] = analyzeKlines(klines);
        }
      });
      setTfData(map);
      setLastUpdate(new Date());
    } catch (e) {
      console.error('MTF fetch error', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    setLoading(true);
    setTfData({});
    fetchAll();
    const interval = setInterval(fetchAll, 30000);
    return () => clearInterval(interval);
  }, [symbol]);

  // Ağırlıklı konsensüs
  const consensus = useMemo(() => {
    let weightedBull = 0, totalWeight = 0;
    TIMEFRAMES.forEach(({ label, weight }) => {
      const d = tfData[label];
      if (d) {
        weightedBull += d.bullPct * weight;
        totalWeight += weight;
      }
    });
    if (totalWeight === 0) return null;
    const score = weightedBull / totalWeight;
    const signal = score >= 65 ? 'GÜÇLÜ AL' : score >= 55 ? 'AL' : score <= 35 ? 'GÜÇLÜ SAT' : score <= 45 ? 'SAT' : 'NÖTR';
    const color  = score >= 55 ? '#00ff88' : score <= 45 ? '#ff3366' : '#ffcc00';
    return { score: parseFloat(score.toFixed(1)), signal, color };
  }, [tfData]);

  const hasData = Object.keys(tfData).length > 0;

  return (
    <div className="cyber-border rounded-lg p-4 space-y-3">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4 text-[#00aaff]" />
          <h3 className="text-xs font-bold tracking-widest uppercase text-[#00aaff]">
            Çoklu Zaman Dilimi
          </h3>
        </div>
        {lastUpdate && (
          <span className="text-[9px] font-mono text-gray-600">
            {lastUpdate.toLocaleTimeString('tr-TR')}
          </span>
        )}
      </div>

      {/* Consensus */}
      {consensus && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="rounded-xl p-3 flex items-center justify-between"
          style={{ background: `${consensus.color}08`, border: `1px solid ${consensus.color}25` }}
        >
          <div>
            <div className="text-[9px] font-mono text-gray-500 uppercase tracking-widest">MTF Konsensüs</div>
            <div className="text-lg font-black font-mono mt-0.5" style={{ color: consensus.color }}>
              {consensus.signal}
            </div>
          </div>
          <div className="text-right">
            <div className="text-[9px] font-mono text-gray-500">Boğa Skoru</div>
            <div className="text-2xl font-black font-mono" style={{ color: consensus.color }}>
              {consensus.score}<span className="text-sm">%</span>
            </div>
          </div>
        </motion.div>
      )}

      {/* Timeframe rows */}
      {loading && !hasData ? (
        <div className="flex items-center justify-center py-8">
          <div className="text-[10px] font-mono text-gray-500 animate-pulse">Zaman dilimleri yükleniyor...</div>
        </div>
      ) : (
        <div className="space-y-1.5">
          {TIMEFRAMES.map(({ label }) => {
            const d = tfData[label];
            return (
              <div
                key={label}
                className="flex items-center gap-2 bg-[#0a0a0f] rounded-lg px-3 py-2"
              >
                {/* TF Label */}
                <span className="text-[10px] font-mono font-bold text-gray-400 w-6">{label}</span>

                {/* Signal arrow + label */}
                <div className="flex items-center gap-1 w-20">
                  {d ? <TrendArrow signal={d.signal} /> : <Minus className="w-3 h-3 text-gray-600" />}
                  <span
                    className="text-[9px] font-mono font-bold"
                    style={{ color: d?.signalColor || '#4b5563' }}
                  >
                    {d?.signal || '—'}
                  </span>
                </div>

                {/* Bull bar */}
                <div className="flex-1">
                  {d ? (
                    <MiniBar
                      value={d.bullPct}
                      color={d.bullPct >= 55 ? '#00ff88' : d.bullPct <= 45 ? '#ff3366' : '#ffcc00'}
                    />
                  ) : (
                    <div className="h-1 bg-[#1a1a2e] rounded-full" />
                  )}
                </div>

                {/* RSI */}
                <span
                  className="text-[9px] font-mono w-8 text-right"
                  style={{
                    color: d ? (d.rsi > 70 ? '#ff3366' : d.rsi < 30 ? '#00ff88' : '#6b7280') : '#4b5563',
                  }}
                >
                  {d ? d.rsi : '—'}
                </span>

                {/* MACD indicator */}
                <span
                  className="text-[9px] font-mono w-3"
                  style={{ color: d?.macd?.histogram > 0 ? '#00ff88' : d?.macd?.histogram < 0 ? '#ff3366' : '#4b5563' }}
                >
                  {d?.macd ? (d.macd.histogram > 0 ? '▲' : '▼') : '—'}
                </span>

                {/* Change */}
                <span
                  className="text-[9px] font-mono w-12 text-right"
                  style={{ color: d && d.change5 >= 0 ? '#00ff88' : '#ff3366' }}
                >
                  {d ? `${d.change5 >= 0 ? '+' : ''}${d.change5}%` : '—'}
                </span>
              </div>
            );
          })}
        </div>
      )}

      {/* Legend */}
      <div className="flex items-center gap-3 pt-1 border-t border-[#1a1a2e]">
        <div className="flex items-center gap-1">
          <span className="text-[8px] font-mono text-gray-600">RSI</span>
          <span className="text-[8px] font-mono text-gray-700">· MACD ▲▼ · 5 mum değişim</span>
        </div>
      </div>
    </div>
  );
}
