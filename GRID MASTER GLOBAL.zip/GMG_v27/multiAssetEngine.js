/**
 * GRID MASTER GLOBAL — MULTI ASSET ENGINE v1
 * ============================================
 * Kripto dışı varlıkları takip eder: Forex, Emtia, Endeksler.
 *
 * VARLIKLAR:
 *   Forex:   EUR/USD, GBP/USD, USD/JPY, USD/CHF, AUD/USD
 *   Emtia:   Altın (XAU/USD), Gümüş (XAG/USD), Petrol (WTI, Brent)
 *   Endeks:  S&P500, Nasdaq, VIX, DXY (Dolar Endeksi)
 *
 * VERİ KAYNAĞI:
 *   - ExchangeRate-API (forex)
 *   - stooq.com (endeks ve emtia - ücretsiz)
 *   - Yahoo Finance (yedek)
 *
 * ÇIKTI:
 *   Kripto piyasasıyla korelasyon skoru + risk sinyali
 */

import { clamp } from './engineCore.js';

// ─── VARLIK TANIMLAMALARI ─────────────────────────────────────────────────────
export const ASSET_LIST = {
  // Forex
  forex: [
    { id: 'EURUSD', label: 'EUR/USD', category: 'forex',  cryptoCorr: -0.3 },
    { id: 'GBPUSD', label: 'GBP/USD', category: 'forex',  cryptoCorr: -0.2 },
    { id: 'USDJPY', label: 'USD/JPY', category: 'forex',  cryptoCorr: -0.4 },
    { id: 'USDCHF', label: 'USD/CHF', category: 'forex',  cryptoCorr: -0.35 },
    { id: 'AUDUSD', label: 'AUD/USD', category: 'forex',  cryptoCorr:  0.2 },
    { id: 'DXY',    label: 'DXY',     category: 'forex',  cryptoCorr: -0.6 }, // Güçlü DXY = kripto düşer
  ],
  // Emtia
  commodities: [
    { id: 'XAUUSD',  label: 'Altın',       category: 'commodity', cryptoCorr:  0.40 },
    { id: 'XAGUSD',  label: 'Gümüş',       category: 'commodity', cryptoCorr:  0.35 },
    { id: 'XPTUSD',  label: 'Platin',      category: 'commodity', cryptoCorr:  0.25 },
    { id: 'WTIUSD',  label: 'WTI Ham',     category: 'commodity', cryptoCorr:  0.10 },
    { id: 'BRTUSD',  label: 'Brent',       category: 'commodity', cryptoCorr:  0.10 },
    { id: 'GASUSD',  label: 'Doğalgaz',    category: 'commodity', cryptoCorr:  0.05 },
    { id: 'COPPUSD', label: 'Bakır',       category: 'commodity', cryptoCorr:  0.30 },
    { id: 'WHTUSD',  label: 'Buğday',      category: 'commodity', cryptoCorr: -0.05 },
  ],
  // Endeks
  indices: [
    { id: 'SPX',    label: 'S&P 500',  category: 'index', cryptoCorr:  0.65 },
    { id: 'NDX',    label: 'Nasdaq',   category: 'index', cryptoCorr:  0.70 },
    { id: 'DJIA',   label: 'Dow Jones', category: 'index', cryptoCorr:  0.55 },
    { id: 'DAX',    label: 'DAX',      category: 'index', cryptoCorr:  0.50 },
    { id: 'FTSE',   label: 'FTSE 100', category: 'index', cryptoCorr:  0.45 },
    { id: 'NKY',    label: 'Nikkei',   category: 'index', cryptoCorr:  0.40 },
    { id: 'VIX',    label: 'VIX',      category: 'index', cryptoCorr: -0.55 },
  ],
};

// ─── ÖNBELLEK ─────────────────────────────────────────────────────────────────
const _cache = new Map();
const CACHE_TTL = 5 * 60 * 1000; // 5 dakika

function cacheGet(key) {
  const e = _cache.get(key);
  return e && Date.now() - e.ts < CACHE_TTL ? e.val : null;
}
function cacheSet(key, val) { _cache.set(key, { val, ts: Date.now() }); }

// ─── VERİ ÇEKİCİLER ──────────────────────────────────────────────────────────

// Forex: ExchangeRate-API (ücretsiz, API key gerektirmez bazı çiftler için)
async function fetchForex(pair) {
  const cached = cacheGet(`forex_${pair}`);
  if (cached) return cached;

  try {
    // Örn: EURUSD → base=EUR, target=USD
    const base   = pair.slice(0, 3);
    const target = pair.slice(3);
    const url    = `https://api.exchangerate-api.com/v4/latest/${base}`;
    const res    = await fetch(url, { signal: AbortSignal.timeout(5000) });
    const data   = await res.json();
    const price  = data?.rates?.[target];
    if (!price) return null;

    const result = { id: pair, price, change24h: null, source: 'exchangerate-api' };
    cacheSet(`forex_${pair}`, result);
    return result;
  } catch (e) {
    console.error(`[MULTI ASSET] Forex fetch hatası (${pair}):`, e.message);
    return null;
  }
}

// Stooq: Endeks ve emtia fiyatları (ücretsiz CSV)
async function fetchStooq(symbol, id) {
  const cached = cacheGet(`stooq_${id}`);
  if (cached) return cached;

  // Stooq sembol map
  const stooqMap = {
    // Endeksler
    SPX:    '^spx',
    NDX:    '^ndx',
    DJIA:   '^dji',
    DAX:    '^dax',
    FTSE:   '^ftse',
    NKY:    '^nkx',
    VIX:    '^vix',
    // Emtia
    XAUUSD:  'xauusd',
    XAGUSD:  'xagusd',
    XPTUSD:  'xptusd',
    WTIUSD:  'cl.f',
    BRTUSD:  'lcousd',
    GASUSD:  'ng.f',
    COPPUSD: 'hg.f',
    WHTUSD:  'w.f',
    // Forex
    DXY:    '^dxy',
  };

  const stooqSym = stooqMap[id];
  if (!stooqSym) return null;

  try {
    const url = `https://stooq.com/q/l/?s=${stooqSym}&f=sd2t2ohlcv&h&e=csv`;
    const res = await fetch(url, { signal: AbortSignal.timeout(6000) });
    const csv = await res.text();

    const lines = csv.split('\n');
    if (lines.length < 2) return null;

    const headers = lines[0].split(',');
    const values  = lines[1].split(',');
    const row     = {};
    headers.forEach((h, i) => { row[h.trim()] = values[i]?.trim(); });

    const close = parseFloat(row['Close']);
    const open  = parseFloat(row['Open']);
    if (isNaN(close)) return null;

    const change24h = open ? ((close - open) / open * 100) : null;
    const result    = { id, price: close, open, change24h: parseFloat(change24h?.toFixed(3) ?? 0), source: 'stooq' };
    cacheSet(`stooq_${id}`, result);
    return result;
  } catch (e) {
    console.error(`[MULTI ASSET] Stooq fetch hatası (${id}):`, e.message);
    return null;
  }
}

// ─── TÜM VARLIK VERİSİ ───────────────────────────────────────────────────────
/**
 * fetchAllAssets — Tüm varlıkların fiyatlarını çek
 */
export async function fetchAllAssets() {
  const promises = [];

  // Forex
  for (const a of ASSET_LIST.forex) {
    if (a.id === 'DXY') promises.push(fetchStooq(a.id, a.id).then(d => ({ ...a, data: d })));
    else                promises.push(fetchForex(a.id).then(d => ({ ...a, data: d })));
  }

  // Emtia
  for (const a of ASSET_LIST.commodities) {
    promises.push(fetchStooq(a.label, a.id).then(d => ({ ...a, data: d })));
  }

  // Endeks
  for (const a of ASSET_LIST.indices) {
    promises.push(fetchStooq(a.label, a.id).then(d => ({ ...a, data: d })));
  }

  const results = await Promise.allSettled(promises);
  return results
    .filter(r => r.status === 'fulfilled' && r.value)
    .map(r => r.value)
    .filter(a => a.data);
}

// ─── KRİPTO KORELASYON SKORU ─────────────────────────────────────────────────
/**
 * computeCryptoCorrelationScore
 * Çekilen varlıkların kripto ile beklenen korelasyonuna bakarak
 * genel kripto-pozitif / negatif sinyal üretir.
 *
 * @param {Array} assets — fetchAllAssets() çıktısı
 */
export function computeCryptoCorrelationScore(assets) {
  if (!assets || assets.length === 0) return { score: 50, summary: 'Veri yok', details: [] };

  const details = [];
  let   weightedScore = 0;
  let   totalWeight   = 0;

  for (const asset of assets) {
    const { id, label, cryptoCorr, data } = asset;
    if (!data || data.change24h === null) continue;

    const corr   = cryptoCorr || 0;
    const chg    = data.change24h;

    // Beklenen etki: korelasyon * değişim → pozitif = kripto için iyi
    const impact = corr * chg;
    const weight = Math.abs(corr); // Yüksek korelasyon → daha fazla ağırlık

    weightedScore += impact * weight;
    totalWeight   += weight;

    details.push({
      id,
      label,
      price:    data.price,
      change24h: data.change24h,
      corr,
      impact:   parseFloat(impact.toFixed(3)),
    });
  }

  // Normalize: -10..+10 aralığını 0-100'e çevir
  const rawScore = totalWeight ? weightedScore / totalWeight : 0;
  const score    = clamp(50 + rawScore * 5);

  // VIX özel kuralı: VIX > 25 ise kripto riski yüksek
  const vix = assets.find(a => a.id === 'VIX');
  let   vixWarning = null;
  if (vix?.data?.price > 30) {
    vixWarning = `⚠️ VIX ${vix.data.price?.toFixed(1)} — Piyasa korku yüksek, kripto için risk var`;
  }

  // DXY özel kuralı: DXY güçleniyorsa kripto baskı altında
  const dxy = assets.find(a => a.id === 'DXY');
  let   dxyWarning = null;
  if (dxy?.data?.change24h > 0.3) {
    dxyWarning = `⚠️ DXY güçleniyor (+${dxy.data.change24h}%) — Kripto baskı altında`;
  }

  const verdict = score >= 65 ? 'KRİPTO DOSTU' : score <= 35 ? 'KRİPTO RİSKLİ' : 'NÖTR';

  return {
    score:      parseFloat(score.toFixed(1)),
    verdict,
    rawScore:   parseFloat(rawScore.toFixed(3)),
    details,
    vixWarning,
    dxyWarning,
    warnings:   [vixWarning, dxyWarning].filter(Boolean),
    summary:    `${verdict} (${score.toFixed(0)}/100) — ${details.length} varlık analiz edildi`,
    timestamp:  new Date().toISOString(),
  };
}

// ─── ANA FONKSİYON ───────────────────────────────────────────────────────────
/**
 * runMultiAssetEngine — Tüm varlıkları çek ve kripto korelasyon skoru üret
 */
export async function runMultiAssetEngine() {
  try {
    const assets = await fetchAllAssets();
    const result = computeCryptoCorrelationScore(assets);
    return {
      ...result,
      assetCount: assets.length,
      assets,
    };
  } catch (e) {
    console.error('[MULTI ASSET] Hata:', e.message);
    return { score: 50, summary: 'Hata: ' + e.message, error: e.message, timestamp: new Date().toISOString() };
  }
}

// ─── TEKİL VARLIK SORGULAMA ────────────────────────────────────────────────────
/**
 * getAsset — Tek bir varlığı getir
 */
export async function getAsset(id) {
  const allAssets = [...ASSET_LIST.forex, ...ASSET_LIST.commodities, ...ASSET_LIST.indices];
  const def = allAssets.find(a => a.id === id);
  if (!def) return null;

  if (def.category === 'forex' && id !== 'DXY') {
    const data = await fetchForex(id);
    return { ...def, data };
  }
  const data = await fetchStooq(def.label, id);
  return { ...def, data };
}

// ─── MAKRO RISK SEVİYESİ ─────────────────────────────────────────────────────
/**
 * getMacroRiskLevel — VIX + DXY bazlı genel risk seviyesi
 */
export async function getMacroRiskLevel() {
  const [vixData, dxyData] = await Promise.all([
    fetchStooq('VIX', 'VIX'),
    fetchStooq('DXY', 'DXY'),
  ]);

  const vix = vixData?.price || 20;
  const dxy = dxyData?.price || 103;

  let riskScore = 50;
  if (vix > 30)       riskScore += 25;
  else if (vix > 25)  riskScore += 15;
  else if (vix < 15)  riskScore -= 10;

  if (dxy > 106)      riskScore += 15;
  else if (dxy > 104) riskScore += 8;
  else if (dxy < 100) riskScore -= 10;

  riskScore = clamp(riskScore);

  return {
    riskScore,
    vix,
    dxy,
    level: riskScore >= 70 ? 'YÜKSEK' : riskScore >= 50 ? 'ORTA' : 'DÜŞÜK',
    summary: `Makro Risk: ${riskScore >= 70 ? 'YÜKSEK' : riskScore >= 50 ? 'ORTA' : 'DÜŞÜK'} (VIX:${vix?.toFixed(1)} DXY:${dxy?.toFixed(2)})`,
    timestamp: new Date().toISOString(),
  };
}
