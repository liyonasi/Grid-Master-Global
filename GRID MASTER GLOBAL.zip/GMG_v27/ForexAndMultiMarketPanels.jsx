/**
 * ForexAndMultiMarketPanels.jsx — GMG v13
 * Prop uyumu düzeltildi:
 *   ForexPanel     → { masterResult, scanResults, symbol, btcChange, dxyLevel, us10yYield }
 *   MultiMarketPanel → { masterResult, scanResults, heatmapData, btcChange, dxyLevel, us10yYield }
 */
import React, { useState, useEffect, useCallback } from 'react';
import { runForexEngine, runCommodityEngine, runBondEngine } from './multiAssetEngines';
import { testProxies, clearMacroCache } from './macroAPIEngine';

// ─── FOREX PANEL ──────────────────────────────────────────────────────────────
export function ForexPanel({
  masterResult  = null,
  scanResults   = [],
  symbol        = 'BTCUSDT',
  btcChange     = 0,
  dxyLevel      = 104.2,   // macroAPIEngine'den gerçek değer gelir
  us10yYield    = 4.3,
}) {
  const [data, setData]           = useState(null);
  const [proxyStatus, setProxyStatus] = useState(null);  // proxy test sonucu
  const [proxyTesting, setProxyTesting] = useState(false);

  useEffect(() => {
    // dxyLevel ve us10yYield artık Dashboard'dan gerçek değer geliyor
    const result = runForexEngine({
      dxyData:    { dxyLevel, dxyChange1d: 0.15 },
      carryData:  { usdJpyChange: 0.3, usdChfChange: 0.1, vixLevel: masterResult?.vixLevel || 18 },
      sessionHour: new Date().getUTCHours(),
    });
    setData(result);
  }, [dxyLevel, us10yYield, masterResult]);

  if (!data) return <div style={styles.loading}>Forex verisi yükleniyor...</div>;

  const scoreColor = data.score >= 60 ? '#00ff88' : data.score <= 40 ? '#ff3366' : '#ffcc00';

  const modules = [
    { label: 'DXY Baskısı',    val: data.dxy?.pressure,                          score: data.dxy?.score,                    col: '#00aaff' },
    { label: 'Döviz Gücü',     val: data.currencyStrength?.summary?.slice(0,30),  score: data.currencyStrength?.cryptoScore,  col: '#00ff88' },
    { label: 'Carry Trade',    val: data.carryTrade?.signal,                      score: data.carryTrade?.score,              col: '#ffcc00' },
    { label: 'Seans',          val: data.session?.summary?.slice(0,28),           score: clamp(50 + (data.session?.cryptoVolBoost || 0)), col: '#aa88ff' },
    { label: 'Merkez Bankası', val: data.centralBank?.cryptoImpact,               score: data.centralBank?.score,             col: '#00bcd4' },
  ];

  return (
    <div style={styles.panel}>
      <div style={styles.header}>
        <span style={{ ...styles.title, color: '#00aaff' }}>FOREX İSTİHBARAT</span>
        <span style={{ fontSize: 9, color: '#404070', fontFamily: 'monospace' }}>DXY {dxyLevel.toFixed(1)} · US10Y {us10yYield.toFixed(2)}%</span>
        {/* Proxy test butonu */}
        <button
          onClick={async () => {
            setProxyTesting(true);
            try {
              clearMacroCache();
              const results = await testProxies();
              setProxyStatus(results);
            } catch {}
            setProxyTesting(false);
          }}
          style={{ fontSize: 8, fontFamily: 'monospace', background: '#0a0a1c', border: '1px solid #1a1a2e', color: '#404070', padding: '1px 6px', borderRadius: 3, cursor: 'pointer' }}
        >
          {proxyTesting ? '⏳ Test...' : '🔌 Proxy Test'}
        </button>
        <span style={{ ...styles.badge, background: `${scoreColor}18`, color: scoreColor }}>{data.action}</span>
      </div>
      <ScoreGauge score={data.score} color={scoreColor} label="Forex → Kripto Etkisi" />
      <div style={{ marginTop: 8 }}>
        {modules.map((m, i) => (
          <ModuleRow key={i} label={m.label} val={m.val} score={m.score} color={m.col} />
        ))}
      </div>
      {/* masterResult varsa ek bağlam */}
      {masterResult?.multiAsset?.forex && (
        <div style={{ marginTop: 8, padding: '4px 8px', background: '#0a0a1c', borderRadius: 4 }}>
          <span style={{ fontSize: 9, color: '#6060a0', fontFamily: 'monospace' }}>
            Master Forex Adj: {masterResult.multiAsset.forex.score >= 50 ? '+' : ''}{(masterResult.multiAsset.forex.score - 50).toFixed(0)} puan
          </span>
        </div>
      )}
      <div style={styles.summary}>{data.summary}</div>
    </div>
  );
}

// ─── MULTI MARKET PANEL ───────────────────────────────────────────────────────
export function MultiMarketPanel({
  masterResult  = null,
  scanResults   = [],
  heatmapData   = [],
  btcChange     = 0,
  dxyLevel      = 104.2,
  us10yYield    = 4.3,
}) {
  const [markets, setMarkets] = useState(null);

  useEffect(() => {
    const forex = runForexEngine({
      dxyData:  { dxyLevel, dxyChange1d: 0.15 },
      carryData:{ vixLevel: masterResult?.vixLevel || 18 },
    });
    const commodity = runCommodityEngine({
      gold:      { change1d: 0.4 },
      oil:       { wtiPrice: 78, wtiChange1d: -0.5 },
      safeHaven: { goldChange: 0.4, vixLevel: masterResult?.vixLevel || 18 },
    });
    const bond = runBondEngine({
      yieldCurve: { us2y: 4.8, us10y: us10yYield },   // gerçek US10Y
      globalLiq:  { fedBalanceSheetChgBln: -20, globalM2Growth: 2 },
    });
    const crypto = {
      score: masterResult?.score || 50,
      label: masterResult?.label || 'BEKLE',
      color: masterResult?.color || '#ffcc00',
    };

    // heatmapData varsa sektör dağılımı
    const sectorInfo = heatmapData?.length
      ? `${heatmapData.filter(c => (c.change24h || 0) > 0).length}/${heatmapData.length} coin yeşil`
      : null;

    setMarkets({ forex, commodity, bond, crypto, sectorInfo });
  }, [masterResult, dxyLevel, us10yYield, heatmapData]);

  if (!markets) return <div style={styles.loading}>Piyasa verisi yükleniyor...</div>;

  const { forex, commodity, bond, crypto, sectorInfo } = markets;
  const riskScore = Math.round((forex.score + commodity.score + bond.score + crypto.score) / 4);
  const riskLabel = riskScore >= 60 ? 'RISK-ON 🟢' : riskScore <= 40 ? 'RISK-OFF 🔴' : 'KARMA 🟡';
  const riskColor = riskScore >= 60 ? '#00ff88' : riskScore <= 40 ? '#ff3366' : '#ffcc00';

  const assets = [
    { label: '₿ KRIPTO',  score: crypto.score,    action: crypto.label,     color: crypto.color  },
    { label: '$ FOREX',   score: forex.score,      action: forex.action,     color: '#00aaff'     },
    { label: '⚗ EMTIA',  score: commodity.score,  action: commodity.action, color: '#ffcc00'     },
    { label: '📊 TAHVİL', score: bond.score,       action: bond.action,      color: '#aa88ff'     },
  ];

  // scanResults'tan güçlü sinyal sayısı
  const strongSignals = scanResults?.filter(r => r.confidence >= 75).length || 0;

  return (
    <div style={styles.panel}>
      <div style={styles.header}>
        <span style={{ ...styles.title, color: '#aa88ff' }}>ÇOK VARLIKLI PANO</span>
        <span style={{ ...styles.badge, background: `${riskColor}18`, color: riskColor }}>{riskLabel}</span>
      </div>

      {/* Makro bilgi satırı */}
      <div style={{ display: 'flex', gap: 12, marginBottom: 8, flexWrap: 'wrap' }}>
        <span style={styles.chip}>DXY {dxyLevel.toFixed(1)}</span>
        <span style={styles.chip}>US10Y {us10yYield.toFixed(2)}%</span>
        {sectorInfo && <span style={styles.chip}>{sectorInfo}</span>}
        {strongSignals > 0 && <span style={{ ...styles.chip, color: '#00ff88' }}>{strongSignals} güçlü sinyal</span>}
      </div>

      <ScoreGauge score={riskScore} color={riskColor} label="Genel Risk İştahı" />

      <div style={{ marginTop: 10 }}>
        {assets.map((a, i) => (
          <div key={i} style={{ marginBottom: 6 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 2 }}>
              <span style={{ fontSize: 10, color: a.color, fontFamily: 'monospace' }}>{a.label}</span>
              <span style={{ fontSize: 10, color: a.color, fontFamily: 'monospace', fontWeight: 700 }}>{a.action}</span>
              <span style={{ fontSize: 10, color: '#6060a0', fontFamily: 'monospace' }}>{a.score}/100</span>
            </div>
            <div style={{ height: 5, background: '#0a0a1c', borderRadius: 3, overflow: 'hidden' }}>
              <div style={{ width: `${a.score}%`, height: '100%', background: a.color + '88', borderRadius: 3, transition: 'width .4s' }} />
            </div>
          </div>
        ))}
      </div>

      <div style={{ ...styles.summary, marginTop: 10 }}>
        {forex.summary?.slice(0, 80)}<br />
        {bond.summary?.slice(0, 80)}
      </div>
    </div>
  );
}

// ─── YARDIMCI BİLEŞENLER ──────────────────────────────────────────────────────
function ScoreGauge({ score, color, label }) {
  const s = clamp(score);
  return (
    <div style={{ marginBottom: 8 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 3 }}>
        <span style={{ fontSize: 9, color: '#6060a0', fontFamily: 'monospace' }}>{label}</span>
        <span style={{ fontSize: 11, fontWeight: 700, color, fontFamily: 'monospace' }}>{s}</span>
      </div>
      <div style={{ height: 6, background: '#0a0a1c', borderRadius: 3, overflow: 'hidden' }}>
        <div style={{ width: `${s}%`, height: '100%', background: color, borderRadius: 3, transition: 'width .4s' }} />
      </div>
    </div>
  );
}

function ModuleRow({ label, val, score, color }) {
  const s = clamp(score);
  const c = s >= 60 ? '#00ff88' : s <= 40 ? '#ff3366' : '#ffcc00';
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4, padding: '3px 0' }}>
      <div style={{ width: 5, height: 5, borderRadius: '50%', background: c, flexShrink: 0 }} />
      <span style={{ fontSize: 9, color: '#9090c0', fontFamily: 'monospace', width: 90, flexShrink: 0 }}>{label}</span>
      <span style={{ fontSize: 9, color: '#6060a0', fontFamily: 'monospace', flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{val || '—'}</span>
      <span style={{ fontSize: 9, color: c, fontFamily: 'monospace', minWidth: 24, textAlign: 'right' }}>{s}</span>
    </div>
  );
}

function clamp(v) { return Math.max(0, Math.min(100, v || 50)); }

const styles = {
  panel:   { fontFamily: 'monospace', fontSize: 10 },
  header:  { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10, flexWrap: 'wrap', gap: 4 },
  title:   { fontSize: 11, fontWeight: 700, letterSpacing: 2 },
  badge:   { fontSize: 9, fontWeight: 700, padding: '2px 8px', borderRadius: 3 },
  chip:    { fontSize: 9, color: '#6060a0', fontFamily: 'monospace', background: '#0a0a1c', padding: '2px 6px', borderRadius: 3 },
  summary: { fontSize: 9, color: '#404070', lineHeight: 1.5, marginTop: 6, borderTop: '1px solid #1a1a2e', paddingTop: 6 },
  loading: { padding: 16, textAlign: 'center', color: '#404070', fontSize: 10, fontFamily: 'monospace' },
};
