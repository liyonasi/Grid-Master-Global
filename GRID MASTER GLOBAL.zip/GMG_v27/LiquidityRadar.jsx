import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Radar, AlertTriangle, Shield, TrendingUp, TrendingDown, Activity, Eye, Zap } from 'lucide-react';

// ─── HELPERS ──────────────────────────────────────────────────────────────────

function classifyWalls(orderbook) {
  if (!orderbook?.bids?.length || !orderbook?.asks?.length) return null;
  const bids = orderbook.bids.slice(0, 20);
  const asks = orderbook.asks.slice(0, 20);

  // Find dominant walls (orders > 2x median)
  const bidAmounts = bids.map(b => b.amount);
  const askAmounts = asks.map(a => a.amount);
  const medBid = [...bidAmounts].sort((a, b) => a - b)[Math.floor(bidAmounts.length / 2)];
  const medAsk = [...askAmounts].sort((a, b) => a - b)[Math.floor(askAmounts.length / 2)];

  const bigBidWalls = bids.filter(b => b.amount > medBid * 3);
  const bigAskWalls = asks.filter(a => a.amount > medAsk * 3);

  const totalBid = bids.reduce((s, b) => s + b.amount * b.price, 0);
  const totalAsk = asks.reduce((s, a) => s + a.amount * a.price, 0);
  const imbalance = totalBid / (totalBid + totalAsk);

  // Liquidity void: big gap between consecutive levels
  const bidGaps = bids.slice(1).map((b, i) => ({
    gap: Math.abs(b.price - bids[i].price),
    price: b.price,
  }));
  const askGaps = asks.slice(1).map((a, i) => ({
    gap: Math.abs(a.price - asks[i].price),
    price: a.price,
  }));
  const avgBidGap = bidGaps.reduce((s, g) => s + g.gap, 0) / bidGaps.length;
  const avgAskGap = askGaps.reduce((s, g) => s + g.gap, 0) / askGaps.length;
  const voidBid = bidGaps.find(g => g.gap > avgBidGap * 3);
  const voidAsk = askGaps.find(g => g.gap > avgAskGap * 3);

  return {
    hasBuyWall: bigBidWalls.length > 0,
    hasSellWall: bigAskWalls.length > 0,
    bigBidWalls,
    bigAskWalls,
    imbalance,
    totalBid,
    totalAsk,
    hasLiqVoid: !!(voidBid || voidAsk),
    voidSide: voidBid ? 'BID' : voidAsk ? 'ASK' : null,
  };
}

function computeStopHuntRisk(orderbook, priceHistory) {
  if (!orderbook || !priceHistory?.length) return 'DÜŞÜK';
  const recent = priceHistory.slice(-20);
  if (recent.length < 5) return 'DÜŞÜK';

  const prices = recent.map(p => p.price);
  const high = Math.max(...prices);
  const low = Math.min(...prices);
  const range = high - low;
  const current = prices[prices.length - 1];

  // Wick analysis — large wicks at extremes signal stop hunt
  const avgVolume = recent.reduce((s, p) => s + (p.volume || 0), 0) / recent.length;
  const lastVol = recent[recent.length - 1]?.volume || 0;
  const volSpike = lastVol > avgVolume * 2;

  // Price near extreme + volume spike = stop hunt risk
  const nearHigh = current > high - range * 0.05;
  const nearLow = current < low + range * 0.05;
  if (volSpike && (nearHigh || nearLow)) return 'YÜKSEK';
  if (nearHigh || nearLow) return 'ORTA';
  return 'DÜŞÜK';
}

function computeFakeBreakoutRisk(orderbook, priceHistory) {
  if (!orderbook || !priceHistory?.length) return 'DÜŞÜK';
  const recent = priceHistory.slice(-30);
  if (recent.length < 10) return 'DÜŞÜK';

  const prices = recent.map(p => p.price);
  const current = prices[prices.length - 1];
  const prev10Avg = prices.slice(-10, -1).reduce((a, b) => a + b, 0) / 9;
  const breakoutMag = Math.abs((current - prev10Avg) / prev10Avg * 100);

  const imbalance = orderbook.bids.slice(0, 5).reduce((s, b) => s + b.amount, 0) /
    (orderbook.asks.slice(0, 5).reduce((s, a) => s + a.amount, 0) || 1);

  // Breakout against orderbook pressure = fake breakout risk
  const bullishBreak = current > prev10Avg && imbalance < 0.7;
  const bearishBreak = current < prev10Avg && imbalance > 1.4;

  if (breakoutMag > 1.5 && (bullishBreak || bearishBreak)) return 'YÜKSEK';
  if (breakoutMag > 0.8 || bullishBreak || bearishBreak) return 'ORTA';
  return 'DÜŞÜK';
}

function computeLiqSweepRisk(orderbook, priceHistory) {
  if (!orderbook || !priceHistory?.length) return { risk: 'DÜŞÜK', direction: null };
  const recent = priceHistory.slice(-10);
  if (recent.length < 3) return { risk: 'DÜŞÜK', direction: null };

  const prices = recent.map(p => p.price);
  const current = prices[prices.length - 1];
  const prev = prices[prices.length - 2];
  const change = (current - prev) / prev * 100;

  const bigBidTotal = orderbook.bids.slice(0, 5).reduce((s, b) => s + b.amount * b.price, 0);
  const bigAskTotal = orderbook.asks.slice(0, 5).reduce((s, a) => s + a.amount * a.price, 0);

  // Rapid move + thin book on opposite side = sweep risk
  if (Math.abs(change) > 0.5) {
    if (change > 0 && bigAskTotal < bigBidTotal * 0.5) return { risk: 'YÜKSEK', direction: 'YUKARI' };
    if (change < 0 && bigBidTotal < bigAskTotal * 0.5) return { risk: 'YÜKSEK', direction: 'AŞAĞI' };
    return { risk: 'ORTA', direction: change > 0 ? 'YUKARI' : 'AŞAĞI' };
  }
  return { risk: 'DÜŞÜK', direction: null };
}

// ─── SUB-COMPONENTS ───────────────────────────────────────────────────────────

function RiskBadge({ level }) {
  const cfg = {
    YÜKSEK: { color: '#ff3366', bg: '#ff336618', glow: true },
    ORTA:   { color: '#ffcc00', bg: '#ffcc0018', glow: false },
    DÜŞÜK:  { color: '#00ff88', bg: '#00ff8818', glow: false },
  }[level] || { color: '#6b7280', bg: '#6b728018', glow: false };

  return (
    <motion.span
      key={level}
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-mono font-bold ${cfg.glow ? 'glow-red' : ''}`}
      style={{ color: cfg.color, background: cfg.bg, border: `1px solid ${cfg.color}30` }}
    >
      {level}
    </motion.span>
  );
}

function WallMeter({ label, present, walls = [], totalValue = 0, color }) {
  return (
    <div className="flex items-center justify-between py-1.5 border-b border-[#1a1a2e]/50 last:border-0">
      <span className="text-[10px] font-mono text-gray-500 uppercase tracking-wider">{label}</span>
      <div className="flex items-center gap-2">
        {present && walls.length > 0 && (
          <span className="text-[9px] font-mono text-gray-600">
            {walls.length} duvar · ${(totalValue / 1e6).toFixed(2)}M
          </span>
        )}
        <span
          className="text-[10px] font-mono font-bold px-2 py-0.5 rounded"
          style={{
            color: present ? color : '#4b5563',
            background: present ? `${color}15` : '#1a1a2e',
            border: `1px solid ${present ? color + '30' : '#2a2a3e'}`,
          }}
        >
          {present ? 'VAR' : 'YOK'}
        </span>
      </div>
    </div>
  );
}

function ImbalanceBar({ imbalance }) {
  const pct = Math.round((imbalance || 0.5) * 100);
  const isBuyDom = pct > 55;
  const isSellDom = pct < 45;

  return (
    <div className="space-y-1">
      <div className="flex justify-between text-[9px] font-mono text-gray-600">
        <span>ALIŞ</span>
        <span>SATIŞ</span>
      </div>
      <div className="relative h-3 rounded-full overflow-hidden bg-[#1a1a2e]">
        <motion.div
          className="absolute left-0 top-0 h-full rounded-full"
          style={{ background: isBuyDom ? '#00ff88' : isSellDom ? '#ff3366' : '#00aaff' }}
          initial={{ width: '50%' }}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 0.6, ease: 'easeOut' }}
        />
      </div>
      <div className="flex justify-between text-[9px] font-mono">
        <span style={{ color: isBuyDom ? '#00ff88' : '#6b7280' }}>{pct}%</span>
        <span style={{ color: isSellDom ? '#ff3366' : '#6b7280' }}>{100 - pct}%</span>
      </div>
    </div>
  );
}

function RadarPulse({ active, color = '#00aaff' }) {
  if (!active) return null;
  return (
    <motion.div
      className="absolute inset-0 rounded-full pointer-events-none"
      animate={{ scale: [1, 1.4, 1], opacity: [0.4, 0, 0.4] }}
      transition={{ duration: 2, repeat: Infinity, ease: 'easeOut' }}
      style={{ border: `1px solid ${color}`, borderRadius: '50%' }}
    />
  );
}

// ─── MAIN COMPONENT ───────────────────────────────────────────────────────────

export default function LiquidityRadar({ orderbook, priceHistory, symbol }) {
  const [scanActive, setScanActive] = useState(true);
  const [lastScan, setLastScan] = useState(new Date());
  const [scanCount, setScanCount] = useState(0);

  const analysis = useMemo(() => {
    const walls = classifyWalls(orderbook);
    const stopHunt = computeStopHuntRisk(orderbook, priceHistory);
    const fakeBreak = computeFakeBreakoutRisk(orderbook, priceHistory);
    const liqSweep = computeLiqSweepRisk(orderbook, priceHistory);

    const riskScore = [stopHunt, fakeBreak, liqSweep.risk]
      .filter(r => r === 'YÜKSEK').length * 33 +
      [stopHunt, fakeBreak, liqSweep.risk]
        .filter(r => r === 'ORTA').length * 11;

    const overallRisk = riskScore >= 60 ? 'YÜKSEK' : riskScore >= 25 ? 'ORTA' : 'DÜŞÜK';

    return { walls, stopHunt, fakeBreak, liqSweep, overallRisk, riskScore };
  }, [orderbook, priceHistory]);

  useEffect(() => {
    const interval = setInterval(() => {
      setLastScan(new Date());
      setScanCount(prev => prev + 1);
    }, 8000);
    return () => clearInterval(interval);
  }, []);

  const { walls, stopHunt, fakeBreak, liqSweep, overallRisk, riskScore } = analysis;

  const overallColor = overallRisk === 'YÜKSEK' ? '#ff3366' : overallRisk === 'ORTA' ? '#ffcc00' : '#00ff88';

  return (
    <div className="cyber-border rounded-lg p-4 space-y-3">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="relative w-5 h-5">
            <Radar className="w-4 h-4 text-[#00aaff] relative z-10" />
            <RadarPulse active={scanActive} color="#00aaff" />
          </div>
          <h3 className="text-xs font-bold tracking-widest uppercase text-[#00aaff]">
            Liquidity Radar
          </h3>
          <span className="text-[9px] font-mono text-gray-600 bg-[#0a0a0f] px-1.5 py-0.5 rounded">
            {symbol?.replace('/USDT', '') || 'BTC'}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <motion.div
            className="w-1.5 h-1.5 rounded-full"
            style={{ background: '#00ff88' }}
            animate={{ opacity: [1, 0.2, 1] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          />
          <span className="text-[9px] font-mono text-gray-600">AKTİF</span>
        </div>
      </div>

      {/* Overall Risk Score */}
      <motion.div
        key={overallRisk}
        initial={{ opacity: 0, y: -4 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative rounded-xl p-3 overflow-hidden"
        style={{ background: `${overallColor}08`, border: `1px solid ${overallColor}25` }}
      >
        <div className="flex items-center justify-between">
          <div>
            <div className="text-[9px] font-mono text-gray-500 uppercase tracking-widest mb-1">
              Genel Likidite Riski
            </div>
            <div
              className="text-2xl font-black font-mono"
              style={{ color: overallColor, textShadow: `0 0 20px ${overallColor}40` }}
            >
              {overallRisk}
            </div>
          </div>
          {/* Gauge */}
          <div className="relative w-16 h-16">
            <svg viewBox="0 0 64 64" className="w-full h-full -rotate-90">
              <circle cx="32" cy="32" r="26" fill="none" stroke="#1a1a2e" strokeWidth="6" />
              <motion.circle
                cx="32" cy="32" r="26" fill="none"
                stroke={overallColor} strokeWidth="6"
                strokeDasharray={`${2 * Math.PI * 26}`}
                initial={{ strokeDashoffset: 2 * Math.PI * 26 }}
                animate={{ strokeDashoffset: 2 * Math.PI * 26 * (1 - riskScore / 100) }}
                transition={{ duration: 1, ease: 'easeOut' }}
                strokeLinecap="round"
              />
            </svg>
            <div
              className="absolute inset-0 flex items-center justify-center text-xs font-black font-mono"
              style={{ color: overallColor }}
            >
              {Math.round(riskScore)}
            </div>
          </div>
        </div>
      </motion.div>

      {/* Wall Analysis */}
      <div className="bg-[#0a0a0f] rounded-lg p-3">
        <div className="text-[9px] font-mono text-gray-600 uppercase tracking-widest mb-2">
          Orderbook Duvarları
        </div>
        <WallMeter
          label="Buy Wall"
          present={walls?.hasBuyWall}
          walls={walls?.bigBidWalls || []}
          totalValue={walls?.bigBidWalls?.reduce((s, b) => s + b.amount * b.price, 0) || 0}
          color="#00ff88"
        />
        <WallMeter
          label="Sell Wall"
          present={walls?.hasSellWall}
          walls={walls?.bigAskWalls || []}
          totalValue={walls?.bigAskWalls?.reduce((s, a) => s + a.amount * a.price, 0) || 0}
          color="#ff3366"
        />
      </div>

      {/* Bid/Ask Imbalance */}
      <div className="bg-[#0a0a0f] rounded-lg p-3">
        <div className="text-[9px] font-mono text-gray-600 uppercase tracking-widest mb-2">
          Bid/Ask Dengesizlik
        </div>
        <ImbalanceBar imbalance={walls?.imbalance} />
      </div>

      {/* Risk Grid */}
      <div className="grid grid-cols-2 gap-2">
        {/* Stop Hunt */}
        <div className="bg-[#0a0a0f] rounded-lg p-2.5">
          <div className="flex items-center gap-1 mb-1.5">
            <Eye className="w-3 h-3 text-gray-500" />
            <span className="text-[9px] font-mono text-gray-500 uppercase">Stop Hunt</span>
          </div>
          <RiskBadge level={stopHunt} />
        </div>

        {/* Liq Sweep */}
        <div className="bg-[#0a0a0f] rounded-lg p-2.5">
          <div className="flex items-center gap-1 mb-1.5">
            <Zap className="w-3 h-3 text-gray-500" />
            <span className="text-[9px] font-mono text-gray-500 uppercase">Liq Sweep</span>
          </div>
          <div className="flex items-center gap-1">
            <RiskBadge level={liqSweep.risk} />
            {liqSweep.direction && (
              <span className="text-[9px] font-mono text-gray-600">{liqSweep.direction}</span>
            )}
          </div>
        </div>

        {/* Fake Breakout */}
        <div className="bg-[#0a0a0f] rounded-lg p-2.5">
          <div className="flex items-center gap-1 mb-1.5">
            <AlertTriangle className="w-3 h-3 text-gray-500" />
            <span className="text-[9px] font-mono text-gray-500 uppercase">Fake Breakout</span>
          </div>
          <RiskBadge level={fakeBreak} />
        </div>

        {/* Liq Void */}
        <div className="bg-[#0a0a0f] rounded-lg p-2.5">
          <div className="flex items-center gap-1 mb-1.5">
            <Activity className="w-3 h-3 text-gray-500" />
            <span className="text-[9px] font-mono text-gray-500 uppercase">Liq Void</span>
          </div>
          <span
            className="text-[10px] font-mono font-bold px-2 py-0.5 rounded inline-block"
            style={{
              color: walls?.hasLiqVoid ? '#ff8800' : '#00ff88',
              background: walls?.hasLiqVoid ? '#ff880015' : '#00ff8815',
              border: `1px solid ${walls?.hasLiqVoid ? '#ff880030' : '#00ff8830'}`,
            }}
          >
            {walls?.hasLiqVoid ? `VAR · ${walls.voidSide}` : 'YOK'}
          </span>
        </div>
      </div>

      {/* Scan Footer */}
      <div className="flex items-center justify-between text-[9px] font-mono text-gray-600">
        <span>Tarama #{scanCount}</span>
        <span>{lastScan.toLocaleTimeString('tr-TR')}</span>
      </div>
    </div>
  );
}
