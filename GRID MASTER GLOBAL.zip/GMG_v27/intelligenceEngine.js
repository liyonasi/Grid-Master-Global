/**
 * GRID MASTER GLOBAL — INTELLIGENCE ENGINE
 * ==========================================
 * Tüm tarama modüllerinin ham sinyal üretim motoru.
 * Bu dosya sadece veri üretir, karar vermez.
 * Kararlar councilEngine.js'te alınır.
 */

// ─── ZAMAN DİLİMİ TANIMLAR ────────────────────────────────────────────────────
export const SESSIONS = {
  ASIA:   { start: 0,  end: 8,  label: 'ASYA',   color: '#00aaff', coins: ['BTC','ETH','XRP','SOL','BNB','TRX','NEO'] },
  EUROPE: { start: 7,  end: 16, label: 'AVRUPA', color: '#ffcc00', coins: ['BTC','ETH','LTC','LINK','DOT','ADA','XMR'] },
  USA:    { start: 13, end: 22, label: 'ABD',    color: '#ff8800', coins: ['BTC','ETH','SOL','DOGE','AVAX','ARB','OP'] },
};

export function getActiveSession() {
  const h = new Date().getUTCHours();
  const active = [];
  if (h >= 0  && h < 8)  active.push('ASIA');
  if (h >= 7  && h < 16) active.push('EUROPE');
  if (h >= 13 && h < 22) active.push('USA');
  return active;
}

// ─── YARDIMCI FONKSİYONLAR ────────────────────────────────────────────────────

function ema(closes, period) {
  if (!closes || closes.length < period) return null;
  const k = 2 / (period + 1);
  let val = closes.slice(0, period).reduce((a, b) => a + b, 0) / period;
  for (let i = period; i < closes.length; i++) val = closes[i] * k + val * (1 - k);
  return val;
}

function rsi(closes, period = 14) {
  if (!closes || closes.length < period + 1) return 50;
  let gains = 0, losses = 0;
  for (let i = 1; i <= period; i++) {
    const d = closes[i] - closes[i - 1];
    d > 0 ? gains += d : losses += Math.abs(d);
  }
  let ag = gains / period, al = losses / period;
  for (let i = period + 1; i < closes.length; i++) {
    const d = closes[i] - closes[i - 1];
    ag = (ag * (period - 1) + (d > 0 ? d : 0)) / period;
    al = (al * (period - 1) + (d < 0 ? Math.abs(d) : 0)) / period;
  }
  return al === 0 ? 100 : parseFloat((100 - 100 / (1 + ag / al)).toFixed(1));
}

function atr(klines, period = 14) {
  if (!klines || klines.length < period + 1) return 0;
  const trs = klines.slice(1).map((k, i) => {
    const prev = klines[i];
    return Math.max(
      (k.high || k.price) - (k.low || k.price),
      Math.abs((k.high || k.price) - prev.price),
      Math.abs((k.low  || k.price) - prev.price)
    );
  });
  return trs.slice(-period).reduce((a, b) => a + b, 0) / period;
}

function bollingerPosition(closes, period = 20) {
  if (!closes || closes.length < period) return 0.5;
  const recent = closes.slice(-period);
  const mean = recent.reduce((a, b) => a + b, 0) / period;
  const std  = Math.sqrt(recent.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / period);
  const last = closes[closes.length - 1];
  const upper = mean + 2 * std, lower = mean - 2 * std;
  return upper !== lower ? Math.max(0, Math.min(1, (last - lower) / (upper - lower))) : 0.5;
}

function volumeZScore(volumes) {
  if (!volumes || volumes.length < 5) return 0;
  const mean = volumes.reduce((a, b) => a + b, 0) / volumes.length;
  const std  = Math.sqrt(volumes.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / volumes.length);
  return std > 0 ? (volumes[volumes.length - 1] - mean) / std : 0;
}

// ─── 1. SCALP TUZAK TARAYICI ─────────────────────────────────────────────────
/**
 * Scalp girmek için tehlikeli coinleri tespit eder.
 * Kriter: Hızlı yükseliş + ince book + yüksek RSI + yakın direnç
 */
export function scalpTrapScanner(coins, orderbookMap = {}) {
  return coins
    .filter(c => {
      if (!c.change_24h) return false;
      const ob = orderbookMap[c.symbol];
      const thinBook = ob
        ? ob.asks.slice(0, 5).reduce((s, a) => s + a.amount, 0) < 10
        : false;
      const rapidMove = Math.abs(c.change_24h) > 3;
      const overExtended = c.rsi ? c.rsi > 72 || c.rsi < 28 : false;
      return (rapidMove && thinBook) || overExtended;
    })
    .map(c => ({
      symbol: c.symbol?.replace('/USDT', '') || c.name,
      reason: c.rsi > 72 ? 'Aşırı alım' : c.rsi < 28 ? 'Aşırı satım' : 'İnce book + hızlı hareket',
      change: c.change_24h,
      rsi: c.rsi || 50,
      riskLevel: 'YÜKSEK',
    }))
    .slice(0, 10);
}

// ─── 2. SCALP LONG ADAYLARI ───────────────────────────────────────────────────
export function scalpLongScanner(coins, btcChange = 0) {
  return coins
    .filter(c => {
      if (!c.change_24h) return false;
      const rsiOk  = !c.rsi || (c.rsi > 45 && c.rsi < 65);
      const momentumOk = c.change_24h > 0.5 && c.change_24h < 8;
      const btcStrong  = btcChange > -1;
      return rsiOk && momentumOk && btcStrong;
    })
    .sort((a, b) => b.change_24h - a.change_24h)
    .slice(0, 8)
    .map(c => ({
      symbol: c.symbol?.replace('/USDT', '') || c.name,
      change: c.change_24h,
      rsi: c.rsi || 50,
      volume: c.volume_24h || 0,
      confidence: Math.min(95, 50 + Math.abs(c.change_24h) * 5 + (c.rsi ? (60 - Math.abs(c.rsi - 55)) : 0)),
      entry: c.price,
      tp: c.price ? parseFloat((c.price * 1.015).toFixed(6)) : null,
      sl: c.price ? parseFloat((c.price * 0.990).toFixed(6)) : null,
    }));
}

// ─── 3. SCALP SHORT ADAYLARI ──────────────────────────────────────────────────
export function scalpShortScanner(coins, btcChange = 0) {
  return coins
    .filter(c => {
      if (!c.change_24h) return false;
      const rsiOk      = !c.rsi || (c.rsi > 55 && c.rsi < 75);
      const momentumOk = c.change_24h < -0.5 && c.change_24h > -8;
      const btcWeak    = btcChange < 1;
      return rsiOk && momentumOk && btcWeak;
    })
    .sort((a, b) => a.change_24h - b.change_24h)
    .slice(0, 8)
    .map(c => ({
      symbol: c.symbol?.replace('/USDT', '') || c.name,
      change: c.change_24h,
      rsi: c.rsi || 50,
      volume: c.volume_24h || 0,
      confidence: Math.min(95, 50 + Math.abs(c.change_24h) * 5),
      entry: c.price,
      tp: c.price ? parseFloat((c.price * 0.985).toFixed(6)) : null,
      sl: c.price ? parseFloat((c.price * 1.010).toFixed(6)) : null,
    }));
}

// ─── 4. LONG GİRMEYE HAZIR COİNLER ───────────────────────────────────────────
/**
 * Birikim tamamlanmış, long için hazır.
 * Kriter: Düzeltmeden dönen + BB alt + RSI 35-50 + hacim artışı
 */
export function longReadyScanner(coins) {
  return coins
    .filter(c => {
      const rsiReady   = c.rsi ? c.rsi >= 35 && c.rsi <= 55 : true;
      const bbReady    = c.bbPosition ? c.bbPosition < 0.4 : false;
      const volSpike   = c.volumeZScore ? c.volumeZScore > 0.5 : false;
      const smallDip   = c.change_24h >= -3 && c.change_24h <= 2;
      return rsiReady && smallDip && (bbReady || volSpike);
    })
    .sort((a, b) => (b.volumeZScore || 0) - (a.volumeZScore || 0))
    .slice(0, 10)
    .map(c => ({
      symbol: c.symbol?.replace('/USDT', '') || c.name,
      change: c.change_24h,
      rsi: c.rsi || 50,
      bbPosition: c.bbPosition || 0.5,
      readyScore: Math.min(100, 60 +
        (c.rsi ? (50 - Math.abs(c.rsi - 42)) : 0) +
        (c.bbPosition ? (0.4 - c.bbPosition) * 50 : 0) +
        (c.volumeZScore ? c.volumeZScore * 5 : 0)
      ),
    }));
}

// ─── 5. SHORT YAPILMAYA HAZIR COİNLER ────────────────────────────────────────
export function shortReadyScanner(coins) {
  return coins
    .filter(c => {
      const rsiHigh  = c.rsi ? c.rsi >= 65 && c.rsi <= 78 : false;
      const bbTop    = c.bbPosition ? c.bbPosition > 0.75 : false;
      const overExt  = c.change_24h >= 4;
      return rsiHigh || (bbTop && overExt);
    })
    .sort((a, b) => (b.rsi || 50) - (a.rsi || 50))
    .slice(0, 10)
    .map(c => ({
      symbol: c.symbol?.replace('/USDT', '') || c.name,
      change: c.change_24h,
      rsi: c.rsi || 50,
      bbPosition: c.bbPosition || 0.5,
      readyScore: Math.min(100, 50 +
        (c.rsi ? c.rsi - 60 : 0) +
        (c.bbPosition ? (c.bbPosition - 0.6) * 80 : 0)
      ),
    }));
}

// ─── 6. PATLAMAYA HAZIR (AKÜMÜLASYON BİTMİŞ) ─────────────────────────────────
/**
 * Uzun süreli sıkışma + düşük volatilite + hacim birikmesi = PATLAMA HAZIR
 */
export function explosionReadyScanner(coins) {
  return coins
    .filter(c => {
      const smallRange = Math.abs(c.change_24h) < 2;
      const bbSqueeze  = c.bbPosition ? c.bbPosition > 0.35 && c.bbPosition < 0.65 : false;
      const volBuild   = c.volumeZScore ? c.volumeZScore > 0.3 : false;
      const rsiMid     = c.rsi ? c.rsi > 45 && c.rsi < 60 : true;
      return smallRange && (bbSqueeze || volBuild) && rsiMid;
    })
    .sort((a, b) => (b.volumeZScore || 0) - (a.volumeZScore || 0))
    .slice(0, 8)
    .map(c => ({
      symbol: c.symbol?.replace('/USDT', '') || c.name,
      change: c.change_24h,
      rsi: c.rsi || 50,
      bbPosition: c.bbPosition || 0.5,
      volumeZScore: c.volumeZScore || 0,
      explosionScore: Math.min(100, 50 +
        (c.volumeZScore ? c.volumeZScore * 15 : 0) +
        (c.bbPosition ? (1 - Math.abs(c.bbPosition - 0.5) * 4) * 20 : 0)
      ),
    }));
}

// ─── 7. ANİ DUMP YAŞAYAN COİNLER ─────────────────────────────────────────────
export function suddenDumpScanner(coins) {
  return coins
    .filter(c => c.change_24h <= -4)
    .sort((a, b) => a.change_24h - b.change_24h)
    .slice(0, 12)
    .map(c => ({
      symbol: c.symbol?.replace('/USDT', '') || c.name,
      change: c.change_24h,
      severity: c.change_24h <= -10 ? 'KRİTİK' : c.change_24h <= -7 ? 'YÜKSEK' : 'ORTA',
      volume: c.volume_24h || 0,
      price: c.price || 0,
    }));
}

// ─── 8. ANİ PUMP YAŞAYAN COİNLER ─────────────────────────────────────────────
export function suddenPumpScanner(coins) {
  return coins
    .filter(c => c.change_24h >= 5)
    .sort((a, b) => b.change_24h - a.change_24h)
    .slice(0, 12)
    .map(c => ({
      symbol: c.symbol?.replace('/USDT', '') || c.name,
      change: c.change_24h,
      severity: c.change_24h >= 20 ? 'FOMO' : c.change_24h >= 10 ? 'GÜÇLÜ' : 'NORMAL',
      volume: c.volume_24h || 0,
      price: c.price || 0,
      pumpRisk: c.change_24h >= 15 ? 'YÜKSEK' : 'ORTA',
    }));
}

// ─── 9. SESSIZ YÜKSELENler ────────────────────────────────────────────────────
/**
 * BTC ile birlikte değil, sessizce güçlenen coinler
 * Kriter: Pozitif değişim + düşük sosyal/hacim = stealth move
 */
export function stealthRisingScanner(coins, btcChange = 0) {
  return coins
    .filter(c => {
      const positive   = c.change_24h > 0.3;
      const belowRadar = c.change_24h < 4;
      const volNormal  = !c.volumeZScore || c.volumeZScore < 1.5;
      const rsiNormal  = !c.rsi || (c.rsi > 45 && c.rsi < 65);
      return positive && belowRadar && volNormal && rsiNormal;
    })
    .sort((a, b) => b.change_24h - a.change_24h)
    .slice(0, 10)
    .map(c => ({
      symbol: c.symbol?.replace('/USDT', '') || c.name,
      change: c.change_24h,
      rsi: c.rsi || 50,
      stealthScore: Math.min(100, 40 + c.change_24h * 15 - (c.volumeZScore || 0) * 5),
    }));
}

// ─── 10. SESSIZ DÜŞENler ─────────────────────────────────────────────────────
export function stealthFallingScanner(coins) {
  return coins
    .filter(c => {
      const negative   = c.change_24h < -0.3;
      const belowRadar = c.change_24h > -4;
      const volNormal  = !c.volumeZScore || c.volumeZScore < 1.5;
      return negative && belowRadar && volNormal;
    })
    .sort((a, b) => a.change_24h - b.change_24h)
    .slice(0, 10)
    .map(c => ({
      symbol: c.symbol?.replace('/USDT', '') || c.name,
      change: c.change_24h,
      rsi: c.rsi || 50,
      dangerScore: Math.min(100, 40 + Math.abs(c.change_24h) * 10),
    }));
}

// ─── 11. ZAMAN DİLİMİNE GÖRE RİSKLİ COİNLER ─────────────────────────────────
/**
 * Aktif seansa göre hangi coinler daha riskli/fırsatlı
 */
export function sessionRiskScanner(coins) {
  const activeSessions = getActiveSession();
  const now = new Date().getUTCHours();

  return coins
    .filter(c => {
      const sym = c.symbol?.replace('/USDT', '') || c.name || '';
      // Asia session high-risk: thin markets, manipulation prone
      const inAsiaRisk = activeSessions.includes('ASIA') && (now < 3 || now > 6);
      // USA session high-vol: big moves
      const inUSAHigh  = activeSessions.includes('USA') && (now >= 13 && now <= 16);

      const highVol    = c.volumeZScore ? Math.abs(c.volumeZScore) > 1.5 : false;
      const bigMove    = Math.abs(c.change_24h) > 5;

      return (inAsiaRisk || inUSAHigh) && (highVol || bigMove);
    })
    .slice(0, 8)
    .map(c => ({
      symbol: c.symbol?.replace('/USDT', '') || c.name,
      change: c.change_24h,
      session: activeSessions[0] || 'KARMA',
      riskType: Math.abs(c.change_24h) > 8 ? 'Aşırı hareket' : 'Hacim anomalisi',
      riskLevel: Math.abs(c.change_24h) > 10 ? 'KRİTİK' : 'YÜKSEK',
    }));
}

// ─── 12. LİKİDİTE DUYARLILIĞI (Orderbook baskısı) ────────────────────────────
export function liquiditySensitivityScanner(coins, orderbookMap = {}) {
  return coins
    .filter(c => orderbookMap[c.symbol])
    .map(c => {
      const ob = orderbookMap[c.symbol];
      const topBidVol = ob.bids.slice(0, 10).reduce((s, b) => s + b.amount * b.price, 0);
      const topAskVol = ob.asks.slice(0, 10).reduce((s, a) => s + a.amount * a.price, 0);
      const imbalance = topBidVol / (topBidVol + topAskVol + 0.001);
      const sensitivity = Math.abs(imbalance - 0.5) * 2; // 0-1, yüksek = hassas

      // Büyük duvar var mı?
      const medBid = ob.bids[ob.bids.length >> 1]?.amount || 1;
      const walls  = ob.bids.filter(b => b.amount > medBid * 5).length +
                     ob.asks.filter(a => a.amount > medBid * 5).length;

      return {
        symbol: c.symbol?.replace('/USDT', '') || c.name,
        change: c.change_24h,
        imbalance: parseFloat(imbalance.toFixed(3)),
        sensitivity: parseFloat(sensitivity.toFixed(3)),
        wallCount: walls,
        bias: imbalance > 0.6 ? 'ALIŞ' : imbalance < 0.4 ? 'SATIŞ' : 'NÖTR',
        riskLevel: sensitivity > 0.4 ? 'YÜKSEK' : sensitivity > 0.2 ? 'ORTA' : 'DÜŞÜK',
      };
    })
    .sort((a, b) => b.sensitivity - a.sensitivity)
    .slice(0, 10);
}

// ─── 13. STOP HUNT TARAYICI ───────────────────────────────────────────────────
export function stopHuntScanner(coins, klineMap = {}) {
  return coins
    .map(c => {
      const klines = klineMap[c.symbol] || [];
      if (klines.length < 5) return null;
      const prices  = klines.map(k => k.price);
      const highs   = klines.map(k => k.high  || k.price);
      const lows    = klines.map(k => k.low   || k.price);
      const volumes = klines.map(k => k.volume || 0);

      const recentHigh = Math.max(...highs.slice(-5));
      const recentLow  = Math.min(...lows.slice(-5));
      const current    = prices[prices.length - 1];
      const range      = recentHigh - recentLow;
      const volSpike   = volumeZScore(volumes) > 1.5;

      // Wick past key level then reversal
      const spikedAbove = recentHigh > prices.slice(-6, -1).reduce((a, b) => Math.max(a, b), 0) * 1.005;
      const spikedBelow = recentLow  < prices.slice(-6, -1).reduce((a, b) => Math.min(a, b), Infinity) * 0.995;
      const reversed    = (spikedAbove && current < recentHigh - range * 0.3) ||
                          (spikedBelow && current > recentLow  + range * 0.3);

      if (!reversed && !volSpike) return null;

      return {
        symbol: c.symbol?.replace('/USDT', '') || c.name,
        change: c.change_24h,
        direction: spikedAbove ? 'YUKARI SWEEP' : 'AŞAĞI SWEEP',
        riskLevel: volSpike && reversed ? 'YÜKSEK' : 'ORTA',
        huntPrice: spikedAbove ? recentHigh : recentLow,
      };
    })
    .filter(Boolean)
    .slice(0, 8);
}

// ─── 14. BTC'YE RAĞMEN GÜÇLÜ ─────────────────────────────────────────────────
export function btcRelativeStrong(coins, btcChange = 0) {
  return coins
    .filter(c => {
      const relStrength = (c.change_24h || 0) - btcChange;
      return relStrength > 1.5 && c.change_24h > 0;
    })
    .sort((a, b) => ((b.change_24h - btcChange) - (a.change_24h - btcChange)))
    .slice(0, 15)
    .map(c => ({
      symbol: c.symbol?.replace('/USDT', '') || c.name,
      change: c.change_24h,
      relStrength: parseFloat((c.change_24h - btcChange).toFixed(2)),
    }));
}

// ─── 15. BTC'YE RAĞMEN ZAYIF ─────────────────────────────────────────────────
export function btcRelativeWeak(coins, btcChange = 0) {
  return coins
    .filter(c => {
      const relStrength = (c.change_24h || 0) - btcChange;
      return relStrength < -1.5;
    })
    .sort((a, b) => ((a.change_24h - btcChange) - (b.change_24h - btcChange)))
    .slice(0, 15)
    .map(c => ({
      symbol: c.symbol?.replace('/USDT', '') || c.name,
      change: c.change_24h,
      relStrength: parseFloat((c.change_24h - btcChange).toFixed(2)),
    }));
}

// ─── 16. TÜM BORSALAR PUMP/DUMP HUNTER ───────────────────────────────────────
export function multiExchangePumpDump(binanceCoins, mexcCoins = []) {
  const allCoins = [...binanceCoins, ...mexcCoins.map(c => ({ ...c, exchange: 'MEXC' }))];

  const pumps = allCoins
    .filter(c => (c.change_24h || 0) >= 8)
    .sort((a, b) => b.change_24h - a.change_24h)
    .slice(0, 12)
    .map(c => ({
      symbol: c.symbol?.replace('/USDT', '') || c.name,
      change: c.change_24h,
      exchange: c.exchange || 'BINANCE',
      pumpType: c.change_24h >= 20 ? 'FOMO PUMP' : c.change_24h >= 12 ? 'GÜÇLÜ PUMP' : 'NORMAL PUMP',
      riskLevel: c.change_24h >= 20 ? 'KRİTİK' : 'YÜKSEK',
    }));

  const dumps = allCoins
    .filter(c => (c.change_24h || 0) <= -6)
    .sort((a, b) => a.change_24h - b.change_24h)
    .slice(0, 12)
    .map(c => ({
      symbol: c.symbol?.replace('/USDT', '') || c.name,
      change: c.change_24h,
      exchange: c.exchange || 'BINANCE',
      dumpType: c.change_24h <= -15 ? 'SERT DUMP' : c.change_24h <= -10 ? 'GÜÇLÜ DUMP' : 'NORMAL DUMP',
      riskLevel: c.change_24h <= -15 ? 'KRİTİK' : 'YÜKSEK',
    }));

  return { pumps, dumps };
}

// ─── ANA TARAMA FONKSİYONU ────────────────────────────────────────────────────
/**
 * Tüm modülleri çalıştırır ve ham sinyal paketini döner.
 * councilEngine bu paketi alır ve oylama yapar.
 */
export function runAllScanners({
  coins = [],
  btcChange = 0,
  orderbookMap = {},
  klineMap = {},
  mexcCoins = [],
}) {
  // Coins'e ek hesaplamalı alanlar ekle
  const enrichedCoins = coins.map(c => {
    const klines  = klineMap[c.symbol] || [];
    const closes  = klines.map(k => k.price);
    const volumes = klines.map(k => k.volume || 0);
    return {
      ...c,
      rsi:         closes.length > 15 ? rsi(closes) : null,
      bbPosition:  closes.length >= 20 ? bollingerPosition(closes) : null,
      volumeZScore: volumes.length > 5  ? volumeZScore(volumes) : null,
      ema9:        closes.length > 9   ? ema(closes, 9)  : null,
      ema21:       closes.length > 21  ? ema(closes, 21) : null,
    };
  });

  return {
    scalpTraps:       scalpTrapScanner(enrichedCoins, orderbookMap),
    scalpLongs:       scalpLongScanner(enrichedCoins, btcChange),
    scalpShorts:      scalpShortScanner(enrichedCoins, btcChange),
    longReady:        longReadyScanner(enrichedCoins),
    shortReady:       shortReadyScanner(enrichedCoins),
    explosionReady:   explosionReadyScanner(enrichedCoins),
    suddenDumps:      suddenDumpScanner(enrichedCoins),
    suddenPumps:      suddenPumpScanner(enrichedCoins),
    stealthRising:    stealthRisingScanner(enrichedCoins, btcChange),
    stealthFalling:   stealthFallingScanner(enrichedCoins),
    sessionRisks:     sessionRiskScanner(enrichedCoins),
    liquiditySens:    liquiditySensitivityScanner(enrichedCoins, orderbookMap),
    stopHunts:        stopHuntScanner(enrichedCoins, klineMap),
    btcStrong:        btcRelativeStrong(enrichedCoins, btcChange),
    btcWeak:          btcRelativeWeak(enrichedCoins, btcChange),
    multiExchange:    multiExchangePumpDump(enrichedCoins, mexcCoins),
    activeSession:    getActiveSession(),
    enrichedCoins,
    btcChange,
    timestamp: Date.now(),
  };
}
