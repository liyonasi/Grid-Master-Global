/**
 * ScannerPage.jsx — GMG v20
 * ===========================
 * Tüm tarayıcı panelleri aynı anda görünür — tab değil grid.
 * Dashboard Sayfa 2 olarak kullanılır.
 *
 * Props:
 *   scanResults   — runAllScanners() çıktısı
 *   masterResult  — runMasterCouncil() çıktısı
 *   scalpResult   — runScalpEngine() çıktısı
 *   loading       — boolean
 *   onRefresh     — callback
 */

import React, { useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  TrendingUp, TrendingDown, Zap, Eye, AlertTriangle,
  Flame, Target, Shield, Activity, BarChart2, Clock,
} from 'lucide-react';

// ─── YARDIMCI BİLEŞENLER ──────────────────────────────────────────────────────

function PanelBox({ title, count, color, icon: Icon, children, span = 1 }) {
  return (
    <div style={{
      background: '#0b0b18',
      border: `1px solid ${color}22`,
      borderTop: `2px solid ${color}55`,
      borderRadius: 10,
      overflow: 'hidden',
      gridColumn: span > 1 ? `span ${span}` : undefined,
    }}>
      {/* Header */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '8px 12px',
        borderBottom: '1px solid #0f0f22',
        background: `${color}08`,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          {Icon && <Icon style={{ width: 10, height: 10, color }} />}
          <span style={{ fontSize: 9, fontFamily: 'monospace', fontWeight: 700, letterSpacing: 2, textTransform: 'uppercase', color }}>
            {title}
          </span>
        </div>
        {count != null && (
          <span style={{
            fontSize: 9, fontFamily: 'monospace', fontWeight: 700,
            padding: '1px 6px', borderRadius: 3,
            background: count > 0 ? `${color}18` : '#0f0f1a',
            color: count > 0 ? color : '#2a2a50',
            border: `1px solid ${count > 0 ? color + '30' : '#0f0f1a'}`,
          }}>
            {count}
          </span>
        )}
      </div>
      {/* Content */}
      <div style={{ padding: '8px 10px' }}>
        {children}
      </div>
    </div>
  );
}

function CoinRow({ coin, index, color = '#00e87a', rightLabel, rightLabel2 }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 6,
      padding: '4px 4px',
      borderBottom: '1px solid #0d0d1e',
    }}>
      <span style={{ fontSize: 8, fontFamily: 'monospace', color: '#252545', width: 14 }}>{index + 1}</span>
      <span style={{ fontSize: 10, fontFamily: 'monospace', fontWeight: 700, color: '#c0c0e0', flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
        {coin.symbol}
      </span>
      {rightLabel && (
        <span style={{ fontSize: 9, fontFamily: 'monospace', fontWeight: 700, color }}>
          {rightLabel}
        </span>
      )}
      {rightLabel2 && (
        <span style={{ fontSize: 8, fontFamily: 'monospace', color: '#3a3a68' }}>
          {rightLabel2}
        </span>
      )}
    </div>
  );
}

function ChangeBar({ value, max = 20 }) {
  const pct = Math.min(100, Math.abs(value) / max * 100);
  const color = value >= 0 ? '#00e87a' : '#ff335c';
  return (
    <div style={{ flex: 1, height: 3, background: '#0f0f22', borderRadius: 2, margin: '0 6px' }}>
      <div style={{ width: `${pct}%`, height: '100%', background: color, borderRadius: 2 }} />
    </div>
  );
}

function Empty({ text }) {
  return (
    <div style={{ padding: '8px 0', textAlign: 'center', fontSize: 9, fontFamily: 'monospace', color: '#1e1e38' }}>
      {text}
    </div>
  );
}

// ─── PANEL BİLEŞENLERİ ────────────────────────────────────────────────────────

function BTCStrongPanel({ data }) {
  const coins = data?.btcStrong || [];
  return (
    <PanelBox title="BTC'ye Rağmen GÜÇLÜ" count={coins.length} color="#00e87a" icon={TrendingUp}>
      {coins.length
        ? coins.slice(0, 8).map((c, i) => (
            <div key={c.symbol} style={{ display: 'flex', alignItems: 'center', padding: '4px 4px', borderBottom: '1px solid #0d0d1e' }}>
              <span style={{ fontSize: 8, color: '#252545', width: 14, fontFamily: 'monospace' }}>{i + 1}</span>
              <span style={{ fontSize: 10, fontFamily: 'monospace', fontWeight: 700, color: '#c0c0e0', width: 56 }}>{c.symbol}</span>
              <ChangeBar value={c.relStrength || 0} max={10} />
              <span style={{ fontSize: 9, fontFamily: 'monospace', fontWeight: 700, color: '#00aaff', width: 38, textAlign: 'right' }}>
                +{(c.relStrength || 0).toFixed(1)}%
              </span>
              <span style={{ fontSize: 10, fontFamily: 'monospace', fontWeight: 700, color: '#00e87a', width: 46, textAlign: 'right' }}>
                {(c.change || 0) >= 0 ? '+' : ''}{(c.change || 0).toFixed(2)}%
              </span>
            </div>
          ))
        : <Empty text="BTC'ye rağmen güçlü coin tespit edilmedi" />}
    </PanelBox>
  );
}

function BTCWeakPanel({ data }) {
  const coins = data?.btcWeak || [];
  return (
    <PanelBox title="BTC'ye Rağmen ZAYIF" count={coins.length} color="#ff335c" icon={TrendingDown}>
      {coins.length
        ? coins.slice(0, 8).map((c, i) => (
            <div key={c.symbol} style={{ display: 'flex', alignItems: 'center', padding: '4px 4px', borderBottom: '1px solid #0d0d1e' }}>
              <span style={{ fontSize: 8, color: '#252545', width: 14, fontFamily: 'monospace' }}>{i + 1}</span>
              <span style={{ fontSize: 10, fontFamily: 'monospace', fontWeight: 700, color: '#c0c0e0', width: 56 }}>{c.symbol}</span>
              <ChangeBar value={-(c.relStrength || 0)} max={10} />
              <span style={{ fontSize: 9, fontFamily: 'monospace', fontWeight: 700, color: '#ff8844', width: 38, textAlign: 'right' }}>
                {(c.relStrength || 0).toFixed(1)}%
              </span>
              <span style={{ fontSize: 10, fontFamily: 'monospace', fontWeight: 700, color: '#ff335c', width: 46, textAlign: 'right' }}>
                {(c.change || 0).toFixed(2)}%
              </span>
            </div>
          ))
        : <Empty text="BTC'ye rağmen zayıf coin tespit edilmedi" />}
    </PanelBox>
  );
}

function ScalpLongPanel({ data }) {
  const coins = data?.scalpLongs || [];
  return (
    <PanelBox title="Scalp LONG" count={coins.length} color="#00e87a" icon={Zap}>
      {coins.length
        ? coins.slice(0, 7).map((c, i) => (
            <CoinRow key={c.symbol} coin={c} index={i} color="#00e87a"
              rightLabel={`${(c.change || 0) >= 0 ? '+' : ''}${(c.change || 0).toFixed(2)}%`}
              rightLabel2={c.signal || ''}
            />
          ))
        : <Empty text="Scalp long sinyali yok" />}
    </PanelBox>
  );
}

function ScalpShortPanel({ data }) {
  const coins = data?.scalpShorts || [];
  return (
    <PanelBox title="Scalp SHORT" count={coins.length} color="#ff335c" icon={Zap}>
      {coins.length
        ? coins.slice(0, 7).map((c, i) => (
            <CoinRow key={c.symbol} coin={c} index={i} color="#ff335c"
              rightLabel={`${(c.change || 0).toFixed(2)}%`}
              rightLabel2={c.signal || ''}
            />
          ))
        : <Empty text="Scalp short sinyali yok" />}
    </PanelBox>
  );
}

function ScalpTrapPanel({ data }) {
  const coins = data?.scalpTraps || [];
  return (
    <PanelBox title="Scalp TUZAK" count={coins.length} color="#ff8844" icon={AlertTriangle}>
      {coins.length
        ? coins.slice(0, 7).map((c, i) => (
            <div key={c.symbol} style={{ display: 'flex', alignItems: 'center', padding: '4px 4px', borderBottom: '1px solid #0d0d1e' }}>
              <span style={{ fontSize: 8, color: '#252545', width: 14, fontFamily: 'monospace' }}>{i + 1}</span>
              <span style={{ fontSize: 10, fontFamily: 'monospace', fontWeight: 700, color: '#c0c0e0', width: 52 }}>{c.symbol}</span>
              <span style={{ fontSize: 8, fontFamily: 'monospace', color: '#ff8844', flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {c.reason || 'Tuzak riski'}
              </span>
              <span style={{ fontSize: 9, fontFamily: 'monospace', fontWeight: 700, color: (c.change || 0) >= 0 ? '#00e87a' : '#ff335c' }}>
                {(c.change || 0) >= 0 ? '+' : ''}{(c.change || 0).toFixed(2)}%
              </span>
            </div>
          ))
        : <Empty text="Scalp tuzak tespit edilmedi" />}
    </PanelBox>
  );
}

function ExplosionPanel({ data }) {
  const coins = data?.explosionReady || [];
  return (
    <PanelBox title="Patlamaya HAZIR" count={coins.length} color="#9966ff" icon={Flame}>
      {coins.length
        ? coins.slice(0, 7).map((c, i) => (
            <div key={c.symbol} style={{ display: 'flex', alignItems: 'center', padding: '4px 4px', borderBottom: '1px solid #0d0d1e' }}>
              <span style={{ fontSize: 8, color: '#252545', width: 14, fontFamily: 'monospace' }}>{i + 1}</span>
              <span style={{ fontSize: 10, fontFamily: 'monospace', fontWeight: 700, color: '#c0c0e0', width: 52 }}>{c.symbol}</span>
              <div style={{ flex: 1, height: 3, background: '#0f0f22', borderRadius: 2, margin: '0 6px' }}>
                <div style={{ width: `${Math.min(100, c.explosionScore || 0)}%`, height: '100%', background: '#9966ff', borderRadius: 2 }} />
              </div>
              <span style={{ fontSize: 9, fontFamily: 'monospace', fontWeight: 700, color: '#9966ff', width: 24 }}>
                {Math.round(c.explosionScore || 0)}
              </span>
            </div>
          ))
        : <Empty text="Patlama sinyali yok" />}
    </PanelBox>
  );
}

function LongReadyPanel({ data }) {
  const coins = data?.longReady || [];
  return (
    <PanelBox title="Long ADAYLARI" count={coins.length} color="#00aaff" icon={Target}>
      {coins.length
        ? coins.slice(0, 7).map((c, i) => (
            <CoinRow key={c.symbol} coin={c} index={i} color="#00aaff"
              rightLabel={`${(c.change || 0) >= 0 ? '+' : ''}${(c.change || 0).toFixed(2)}%`}
            />
          ))
        : <Empty text="Long aday yok" />}
    </PanelBox>
  );
}

function ShortReadyPanel({ data }) {
  const coins = data?.shortReady || [];
  return (
    <PanelBox title="Short ADAYLARI" count={coins.length} color="#ff6688" icon={Target}>
      {coins.length
        ? coins.slice(0, 7).map((c, i) => (
            <CoinRow key={c.symbol} coin={c} index={i} color="#ff6688"
              rightLabel={`${(c.change || 0).toFixed(2)}%`}
            />
          ))
        : <Empty text="Short aday yok" />}
    </PanelBox>
  );
}

function StealthRisingPanel({ data }) {
  const coins = data?.stealthRising || [];
  return (
    <PanelBox title="GİZLİ YÜKSELİŞ" count={coins.length} color="#aa66ff" icon={Eye}>
      {coins.length
        ? coins.slice(0, 8).map((c, i) => (
            <CoinRow key={c.symbol} coin={c} index={i} color="#aa66ff"
              rightLabel={`${(c.change || 0) >= 0 ? '+' : ''}${(c.change || 0).toFixed(2)}%`}
              rightLabel2={c.volumeZ ? `V×${c.volumeZ.toFixed(1)}` : ''}
            />
          ))
        : <Empty text="Gizli yükseliş yok" />}
    </PanelBox>
  );
}

function StealthFallingPanel({ data }) {
  const coins = data?.stealthFalling || [];
  return (
    <PanelBox title="GİZLİ DÜŞÜŞ" count={coins.length} color="#ff8844" icon={Eye}>
      {coins.length
        ? coins.slice(0, 8).map((c, i) => (
            <CoinRow key={c.symbol} coin={c} index={i} color="#ff8844"
              rightLabel={`${(c.change || 0).toFixed(2)}%`}
            />
          ))
        : <Empty text="Gizli düşüş yok" />}
    </PanelBox>
  );
}

function StopHuntPanel({ data }) {
  const coins = data?.stopHunts || [];
  return (
    <PanelBox title="Stop HUNT" count={coins.length} color="#ff335c" icon={Shield}>
      {coins.length
        ? coins.slice(0, 8).map((c, i) => (
            <div key={c.symbol} style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '4px 4px', borderBottom: '1px solid #0d0d1e' }}>
              <span style={{ fontSize: 8, color: '#252545', width: 14, fontFamily: 'monospace' }}>{i + 1}</span>
              <span style={{ fontSize: 10, fontFamily: 'monospace', fontWeight: 700, color: '#c0c0e0', width: 52 }}>{c.symbol}</span>
              <span style={{ fontSize: 8, fontFamily: 'monospace', color: '#ff8844' }}>{c.direction || '—'}</span>
              <span style={{ marginLeft: 'auto', fontSize: 8, fontFamily: 'monospace', padding: '1px 5px', borderRadius: 2,
                background: (c.riskLevel === 'YÜKSEK' ? '#ff335c18' : '#ff884418'),
                color: (c.riskLevel === 'YÜKSEK' ? '#ff335c' : '#ff8844'),
              }}>
                {c.riskLevel || 'ORTA'}
              </span>
            </div>
          ))
        : <Empty text="Stop hunt tespit edilmedi" />}
    </PanelBox>
  );
}

function FakeMovePanel({ data }) {
  // Fake move = ani pump + dump kombinasyonu — MEX/BNC farkı
  const multiEx = data?.multiExchange || {};
  const fakePumps = (multiEx.pumps || []).filter(c => c.pumpType === 'FAKE' || c.exchange === 'MEXC');
  const pumpDumps = [...(data?.suddenPumps || []).slice(0, 4), ...(data?.suddenDumps || []).slice(0, 4)];
  const coins = fakePumps.length ? fakePumps : pumpDumps;
  return (
    <PanelBox title="FAKE MOVE / MEXC Pump" count={coins.length} color="#ffc800" icon={AlertTriangle}>
      {coins.length
        ? coins.slice(0, 8).map((c, i) => (
            <div key={c.symbol + i} style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '4px 4px', borderBottom: '1px solid #0d0d1e' }}>
              <span style={{ fontSize: 8, color: '#252545', width: 14, fontFamily: 'monospace' }}>{i + 1}</span>
              <span style={{ fontSize: 10, fontFamily: 'monospace', fontWeight: 700, color: '#c0c0e0', width: 52 }}>{c.symbol}</span>
              <span style={{ fontSize: 8, fontFamily: 'monospace', padding: '1px 5px', borderRadius: 2, background: '#1a1428', color: '#9966ff' }}>
                {c.exchange || 'BNC'}
              </span>
              <ChangeBar value={c.change || 0} max={15} />
              <span style={{ fontSize: 9, fontFamily: 'monospace', fontWeight: 700, color: (c.change || 0) >= 0 ? '#00e87a' : '#ff335c', width: 44, textAlign: 'right' }}>
                {(c.change || 0) >= 0 ? '+' : ''}{(c.change || 0).toFixed(2)}%
              </span>
            </div>
          ))
        : <Empty text="Fake move / MEXC pump tespit edilmedi" />}
    </PanelBox>
  );
}

function MEXCRiskyPanel({ data }) {
  const multiEx = data?.multiExchange || {};
  const risky = [...(multiEx.dumps || []), ...(multiEx.pumps || [])].filter(c => c.exchange === 'MEXC');
  return (
    <PanelBox title="MEXC RİSKLİ" count={risky.length} color="#ff6644" icon={AlertTriangle}>
      {risky.length
        ? risky.slice(0, 7).map((c, i) => (
            <CoinRow key={c.symbol + i} coin={c} index={i} color="#ff6644"
              rightLabel={`${(c.change || 0) >= 0 ? '+' : ''}${(c.change || 0).toFixed(2)}%`}
              rightLabel2="MEXC"
            />
          ))
        : <Empty text="MEXC riskli coin yok" />}
    </PanelBox>
  );
}

function LiqWallPanel({ data }) {
  const coins = data?.liquiditySens || [];
  return (
    <PanelBox title="LİKİDİTE DUVARLARI" count={coins.length} color="#00aaff" icon={Activity}>
      {coins.length
        ? coins.slice(0, 7).map((c, i) => (
            <div key={c.symbol} style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '4px 4px', borderBottom: '1px solid #0d0d1e' }}>
              <span style={{ fontSize: 8, color: '#252545', width: 14, fontFamily: 'monospace' }}>{i + 1}</span>
              <span style={{ fontSize: 10, fontFamily: 'monospace', fontWeight: 700, color: '#c0c0e0', width: 52 }}>{c.symbol}</span>
              <span style={{ fontSize: 9, fontFamily: 'monospace', color: c.bias === 'ALIŞ' ? '#00e87a' : c.bias === 'SATIŞ' ? '#ff335c' : '#ffc800' }}>
                {c.bias || 'NÖTR'}
              </span>
              <ChangeBar value={(c.sensitivity || 0.5) * 10 - 5} max={5} />
              <span style={{ fontSize: 8, fontFamily: 'monospace', padding: '1px 5px', borderRadius: 2,
                background: c.riskLevel === 'YÜKSEK' ? '#ff335c18' : '#ffc80018',
                color: c.riskLevel === 'YÜKSEK' ? '#ff335c' : '#ffc800',
              }}>
                {c.riskLevel || 'ORTA'}
              </span>
            </div>
          ))
        : <Empty text="Likidite duvarı verisi yok" />}
    </PanelBox>
  );
}

function SessionPanel({ data }) {
  const activeSession = data?.activeSession || [];
  const sessionRisks = data?.sessionRisks || [];
  const sessionColors = { ASIA: '#00aaff', EUROPE: '#ffc800', USA: '#ff8844' };
  const sessionLabels = { ASIA: 'ASYA', EUROPE: 'AVRUPA', USA: 'ABD' };

  return (
    <PanelBox title="SEANS & SAAT" count={null} color="#00ccaa" icon={Clock}>
      {/* Aktif seanslar */}
      <div style={{ display: 'flex', gap: 5, marginBottom: 8 }}>
        {['ASIA', 'EUROPE', 'USA'].map(s => {
          const on = activeSession.includes(s);
          return (
            <div key={s} style={{
              flex: 1, textAlign: 'center', padding: '5px 4px', borderRadius: 5,
              background: on ? `${sessionColors[s]}12` : '#0a0a15',
              border: `1px solid ${on ? sessionColors[s] + '40' : '#0f0f22'}`,
            }}>
              <div style={{ fontSize: 9, fontFamily: 'monospace', fontWeight: 700, color: on ? sessionColors[s] : '#1e1e38' }}>
                {sessionLabels[s]}
              </div>
              <div style={{ fontSize: 8, color: on ? sessionColors[s] + '99' : '#141428', fontFamily: 'monospace', marginTop: 1 }}>
                {on ? '● AKTİF' : 'KAPALI'}
              </div>
            </div>
          );
        })}
      </div>
      {sessionRisks.slice(0, 5).map((c, i) => (
        <CoinRow key={c.symbol} coin={c} index={i} color="#00ccaa"
          rightLabel={`${(c.change || 0) >= 0 ? '+' : ''}${(c.change || 0).toFixed(2)}%`}
          rightLabel2={c.session || ''}
        />
      ))}
      {!sessionRisks.length && <Empty text="Seans riski yok" />}
    </PanelBox>
  );
}

// ─── ANA SAYFA ────────────────────────────────────────────────────────────────

export default function ScannerPage({ scanResults, masterResult, scalpResult, missingBundle, jsonOutputs, loading, onRefresh }) {

  const data = useMemo(() => {
    if (!scanResults) return {};
    return {
      // BTC relatif
      btcStrong:      scanResults.btcStrong       || [],
      btcWeak:        scanResults.btcWeak          || [],
      btcChange:      scanResults.btcChange        || 0,
      // Scalp
      scalpLongs:     scanResults.scalpLongs       || scalpResult?.longs  || [],
      scalpShorts:    scanResults.scalpShorts      || scalpResult?.shorts || [],
      scalpTraps:     scanResults.scalpTraps       || [],
      // Hazır
      longReady:      scanResults.longReady        || [],
      shortReady:     scanResults.shortReady       || [],
      explosionReady: scanResults.explosionReady   || [],
      // Gizli
      stealthRising:  scanResults.stealthRising    || [],
      stealthFalling: scanResults.stealthFalling   || [],
      // Risk
      stopHunts:      scanResults.stopHunts        || [],
      liquiditySens:  scanResults.liquiditySens    || [],
      // Pump/Dump
      suddenPumps:    scanResults.suddenPumps      || [],
      suddenDumps:    scanResults.suddenDumps      || [],
      multiExchange:  scanResults.multiExchange    || {},
      // Seans
      activeSession:  scanResults.activeSession    || [],
      sessionRisks:   scanResults.sessionRisks     || [],
    };
  }, [scanResults, scalpResult]);

  // Toplam sinyal sayısı
  const totalSignals = data.btcStrong?.length + data.btcWeak?.length +
    data.scalpLongs?.length + data.scalpShorts?.length +
    data.longReady?.length + data.shortReady?.length +
    data.explosionReady?.length + data.stopHunts?.length;

  return (
    <div style={{ padding: '12px 14px' }}>

      {/* Üst şerit */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        marginBottom: 14, paddingBottom: 10,
        borderBottom: '1px solid #0f0f22',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ fontSize: 9, fontFamily: 'monospace', fontWeight: 700, letterSpacing: 3, color: '#2a2a50', textTransform: 'uppercase' }}>
            Tarayıcı Sayfası
          </span>
          <span style={{
            fontSize: 9, fontFamily: 'monospace', fontWeight: 700,
            padding: '2px 8px', borderRadius: 3,
            background: 'rgba(0,232,122,0.1)', border: '1px solid rgba(0,232,122,0.25)', color: '#00e87a',
          }}>
            {totalSignals || 0} aktif sinyal
          </span>
          {data.btcChange !== 0 && (
            <span style={{
              fontSize: 9, fontFamily: 'monospace', fontWeight: 700,
              padding: '2px 8px', borderRadius: 3,
              background: data.btcChange >= 0 ? 'rgba(0,232,122,0.08)' : 'rgba(255,51,92,0.08)',
              border: `1px solid ${data.btcChange >= 0 ? 'rgba(0,232,122,0.2)' : 'rgba(255,51,92,0.2)'}`,
              color: data.btcChange >= 0 ? '#00e87a' : '#ff335c',
            }}>
              BTC {data.btcChange >= 0 ? '+' : ''}{data.btcChange?.toFixed(2)}%
            </span>
          )}
        </div>
        <button
          onClick={onRefresh}
          disabled={loading}
          style={{
            fontSize: 9, fontFamily: 'monospace', fontWeight: 700,
            padding: '4px 12px', borderRadius: 5, cursor: 'pointer',
            background: loading ? '#0f0f22' : 'rgba(0,170,255,0.1)',
            border: `1px solid ${loading ? '#0f0f22' : 'rgba(0,170,255,0.3)'}`,
            color: loading ? '#1e1e38' : '#00aaff',
            transition: 'all 0.15s',
          }}
        >
          {loading ? '◈ TARANIYYOR...' : '◎ YENİLE'}
        </button>
      </div>

      {loading && !scanResults && (
        <div style={{ textAlign: 'center', padding: '40px 0' }}>
          <div style={{ fontSize: 10, fontFamily: 'monospace', color: '#2a2a50', letterSpacing: 2, animation: 'gmgPulse 1.4s ease-in-out infinite' }}>
            ◈ TARAYICILAR ÇALIŞIYOR...
          </div>
        </div>
      )}

      {scanResults && (
        <>
          {/* Satır 1: BTC Relatif + Scalp */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, minmax(0,1fr))', gap: 10, marginBottom: 10 }}>
            <BTCStrongPanel data={data} />
            <BTCWeakPanel data={data} />
            <ScalpLongPanel data={data} />
            <ScalpShortPanel data={data} />
          </div>

          {/* Satır 2: Hazır + Gizli */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, minmax(0,1fr))', gap: 10, marginBottom: 10 }}>
            <LongReadyPanel data={data} />
            <ShortReadyPanel data={data} />
            <StealthRisingPanel data={data} />
            <StealthFallingPanel data={data} />
          </div>

          {/* Satır 3: Risk + Pump/Fake/Seans */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, minmax(0,1fr))', gap: 10, marginBottom: 10 }}>
            <ExplosionPanel data={data} />
            <StopHuntPanel data={data} />
            <FakeMovePanel data={data} />
            <MEXCRiskyPanel data={data} />
          </div>

          {/* Satır 4: Likidite + Seans + Scalp Trap + Özet */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, minmax(0,1fr))', gap: 10 }}>
            <ScalpTrapPanel data={data} />
            <LiqWallPanel data={data} />
            <SessionPanel data={data} />
            {/* Özet kart */}
            <div style={{
              background: '#0b0b18', border: '1px solid #13132a', borderTop: '2px solid #2a2a50',
              borderRadius: 10, padding: '12px 14px',
            }}>
              <div style={{ fontSize: 9, fontFamily: 'monospace', fontWeight: 700, letterSpacing: 2, color: '#2a2a50', marginBottom: 10, textTransform: 'uppercase' }}>
                Özet
              </div>
              {[
                { label: 'Scalp Long', val: data.scalpLongs?.length, color: '#00e87a' },
                { label: 'Scalp Short', val: data.scalpShorts?.length, color: '#ff335c' },
                { label: 'Patlamaya Hazır', val: data.explosionReady?.length, color: '#9966ff' },
                { label: 'Stop Hunt', val: data.stopHunts?.length, color: '#ff335c' },
                { label: 'BTC\'ye Rağmen Güçlü', val: data.btcStrong?.length, color: '#00e87a' },
                { label: 'BTC\'ye Rağmen Zayıf', val: data.btcWeak?.length, color: '#ff335c' },
                { label: 'Gizli Yükseliş', val: data.stealthRising?.length, color: '#aa66ff' },
                { label: 'MEXC Riskli', val: (data.multiExchange?.dumps?.length || 0) + (data.multiExchange?.pumps?.filter(c => c.exchange === 'MEXC')?.length || 0), color: '#ff6644' },
              ].map(row => (
                <div key={row.label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '3px 0', borderBottom: '1px solid #0d0d1e' }}>
                  <span style={{ fontSize: 9, fontFamily: 'monospace', color: '#3a3a68' }}>{row.label}</span>
                  <span style={{ fontSize: 10, fontFamily: 'monospace', fontWeight: 700, color: (row.val || 0) > 0 ? row.color : '#1e1e38' }}>
                    {row.val || 0}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Satır 5: 18 Eksik Modül Paketi */}
          {missingBundle && (
            <div style={{
              background: '#0b0b18', border: '1px solid #13132a',
              borderTop: '2px solid #1a1a3e', borderRadius: 10,
              padding: '12px 14px', marginTop: 10,
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                <span style={{ fontSize: 9, fontFamily: 'monospace', fontWeight: 700, letterSpacing: 2, color: '#404080', textTransform: 'uppercase' }}>
                  18 MODÜL PAKETI
                </span>
                <span style={{
                  fontSize: 9, fontFamily: 'monospace', fontWeight: 700,
                  color: (missingBundle.bonusScore || 0) >= 0 ? '#00e87a' : '#ff335c',
                }}>
                  Final Katkı: {(missingBundle.bonusScore || 0) >= 0 ? '+' : ''}{(missingBundle.bonusScore || 0).toFixed(2)}
                </span>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 6 }}>
                {[
                  { label: 'Supertrend', d: missingBundle.supertrend, val: missingBundle.supertrend?.trend === 'UP' ? '▲ YUKARI' : '▼ AŞAĞI', col: missingBundle.supertrend?.trend === 'UP' ? '#00e676' : '#ff1744' },
                  { label: 'Keltner',    d: missingBundle.keltner,    val: missingBundle.keltner?.position || '—',       col: (missingBundle.keltner?.score || 50) >= 55 ? '#00e676' : '#ff3366' },
                  { label: 'Bulut',      d: missingBundle.trendCloud,  val: missingBundle.trendCloud?.signal || '—',      col: (missingBundle.trendCloud?.score || 50) >= 55 ? '#00e676' : '#ff3366' },
                  { label: 'Panik',      d: missingBundle.panic,       val: missingBundle.panic?.isPanic ? missingBundle.panic.level : 'YOK', col: missingBundle.panic?.isPanic ? '#ff0055' : '#00e67666' },
                  { label: 'Bulaşma',   d: missingBundle.contagion,   val: missingBundle.contagion?.contagion ? `%${missingBundle.contagion?.spreadScore || 0}` : 'YOK', col: missingBundle.contagion?.contagion ? '#ff6400' : '#00e67666' },
                  { label: 'Endeks',    d: missingBundle.indexStress, val: missingBundle.indexStress?.level || '—',       col: (missingBundle.indexStress?.score || 50) >= 60 ? '#ff3366' : '#00ff88' },
                  { label: 'Fed',       d: missingBundle.rateExpect,  val: missingBundle.rateExpect?.expectation || '—', col: '#ffcc00' },
                  { label: 'Metaller',  d: missingBundle.precious,    val: missingBundle.precious?.signal || '—',         col: '#ffd700' },
                  { label: 'Enerji',    d: missingBundle.energyVol,   val: missingBundle.energyVol?.level || '—',         col: '#ff8800' },
                  { label: 'Seans',     d: missingBundle.sessionVol,  val: missingBundle.sessionVol?.session || '—',     col: '#aa88ff' },
                ].map(({ label, d, val, col }, i) => {
                  if (!d) return null;
                  const score = Math.max(0, Math.min(100, d?.score || 50));
                  return (
                    <div key={i} style={{ background: '#06060f', border: `1px solid ${col}22`, borderRadius: 5, padding: '5px 7px' }}>
                      <div style={{ fontSize: 8, color: '#404070', fontFamily: 'monospace', marginBottom: 2 }}>{label}</div>
                      <div style={{ fontSize: 10, color: col, fontFamily: 'monospace', fontWeight: 700, marginBottom: 2 }}>{val}</div>
                      <div style={{ height: 2, background: '#0a0a1c', borderRadius: 1, overflow: 'hidden' }}>
                        <div style={{ width: `${score}%`, height: '100%', background: col + '88', borderRadius: 1 }} />
                      </div>
                    </div>
                  );
                }).filter(Boolean)}
              </div>
              {missingBundle.alerts?.length > 0 && (
                <div style={{ marginTop: 6, display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                  {missingBundle.alerts.map((a, i) => (
                    <span key={i} style={{ fontSize: 9, color: '#ff6d00', fontFamily: 'monospace', padding: '2px 6px', background: 'rgba(255,109,0,.1)', borderRadius: 3, border: '1px solid rgba(255,109,0,.2)' }}>{a}</span>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Satır 6: Likidite Özel (FlashCrash + DarkPool + OTC + Glassnode/CryptoQuant) */}
          {masterResult?.liquiditySpecial && (() => {
            const ls = masterResult.liquiditySpecial;
            const jls = jsonOutputs?.liquidity_special_output;
            if (!ls.flashCrash?.detected && !ls.darkPool?.detected && !ls.otcFlow) return null;
            return (
              <div style={{
                background: '#0b0b18', border: `1px solid ${ls.critical ? '#ff003344' : '#13132a'}`,
                borderTop: `2px solid ${ls.critical ? '#ff0033' : '#1a1a3e'}`,
                borderRadius: 10, padding: '12px 14px', marginTop: 10,
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                  <span style={{ fontSize: 9, fontFamily: 'monospace', fontWeight: 700, letterSpacing: 2, color: ls.critical ? '#ff3366' : '#404080', textTransform: 'uppercase' }}>
                    LİKİDİTE ÖZEL
                  </span>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                    {ls.darkPool?.glassnode && (
                      <span style={{ fontSize: 8, color: '#00e87a', fontFamily: 'monospace', background: 'rgba(0,232,122,.08)', padding: '1px 5px', borderRadius: 3, border: '1px solid rgba(0,232,122,.2)' }}>
                        ◈ Glassnode
                      </span>
                    )}
                    {ls.otcFlow?.cryptoquant && (
                      <span style={{ fontSize: 8, color: '#00aaff', fontFamily: 'monospace', background: 'rgba(0,170,255,.08)', padding: '1px 5px', borderRadius: 3, border: '1px solid rgba(0,170,255,.2)' }}>
                        ◈ CryptoQuant
                      </span>
                    )}
                    <span style={{ fontSize: 9, fontFamily: 'monospace', color: '#404070' }}>Skor: {ls.score}</span>
                  </div>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 6 }}>
                  {[
                    { label: '🕵 Dark Pool', detected: ls.darkPool?.detected, val: ls.darkPool?.type?.replace('_',' ') || '—', col: ls.darkPool?.detected ? '#00bcd4' : '#2a2a50', score: ls.darkPool?.score,
                      extra: ls.darkPool?.glassnode ? `Net: ${ls.darkPool.glassnode.netFlow > 0 ? '+' : ''}${(ls.darkPool.glassnode.netFlow/1e6).toFixed(1)}M` : null },
                    { label: '⚡ Flash Crash', detected: ls.flashCrash?.detected, val: ls.flashCrash?.severity || 'NONE', col: ls.flashCrash?.detected ? '#ff0055' : '#2a2a50', score: ls.flashCrash?.score, extra: null },
                    { label: '🏛 OTC Akışı', detected: ls.otcFlow?.isAccumulating || ls.otcFlow?.isDistributing, val: ls.otcFlow?.isAccumulating ? 'BİRİKİM' : ls.otcFlow?.isDistributing ? 'DAĞITIM' : 'NÖTR', col: ls.otcFlow?.isAccumulating ? '#00e676' : ls.otcFlow?.isDistributing ? '#ff3366' : '#404070', score: ls.otcFlow?.score,
                      extra: ls.otcFlow?.cryptoquant ? `Net: ${ls.otcFlow.cryptoquant.netFlow > 0 ? '+' : ''}${(ls.otcFlow.cryptoquant.netFlow/1e6).toFixed(1)}M` : null },
                  ].map(({ label, detected, val, col, score: s, extra }, i) => (
                    <div key={i} style={{ background: detected ? `${col}10` : '#06060f', border: `1px solid ${col}${detected ? '44' : '18'}`, borderRadius: 5, padding: '7px 8px' }}>
                      <div style={{ fontSize: 8, color: '#404070', fontFamily: 'monospace', marginBottom: 3 }}>{label}</div>
                      <div style={{ fontSize: 10, color: col, fontFamily: 'monospace', fontWeight: 700 }}>{val}</div>
                      {extra && <div style={{ fontSize: 8, color: col + 'bb', fontFamily: 'monospace', marginTop: 2 }}>{extra}</div>}
                      <div style={{ height: 2, background: '#0a0a1c', borderRadius: 1, marginTop: 3 }}>
                        <div style={{ width: `${Math.max(0,Math.min(100,s||50))}%`, height: '100%', background: col + '88', borderRadius: 1 }} />
                      </div>
                    </div>
                  ))}
                </div>
                {ls.alerts?.length > 0 && (
                  <div style={{ marginTop: 6, display: 'flex', gap: 5, flexWrap: 'wrap' }}>
                    {ls.alerts.map((a, i) => (
                      <span key={i} style={{ fontSize: 9, color: '#ff6d00', fontFamily: 'monospace', padding: '2px 6px', background: 'rgba(255,109,0,.1)', borderRadius: 3 }}>{a}</span>
                    ))}
                  </div>
                )}
              </div>
            );
          })()}

          {/* CrossFeed uyarısı */}
          {masterResult?.health?.crossFeed && !masterResult.health.crossFeed.isValid && (
            <div style={{
              background: 'rgba(255,136,0,.08)', border: '1px solid rgba(255,136,0,.25)',
              borderRadius: 8, padding: '8px 12px', marginTop: 8,
              display: 'flex', alignItems: 'center', gap: 8,
            }}>
              <span style={{ fontSize: 10 }}>⚠</span>
              <span style={{ fontSize: 9, color: '#ff8800', fontFamily: 'monospace' }}>
                Borsa fiyatları tutarsız — Maks. sapma: %{(masterResult.health.crossFeed.maxDeviation || 0).toFixed(3)}
              </span>
            </div>
          )}
        </>
      )}
    </div>
  );
}
