/**
 * GRID MASTER GLOBAL — BOND & GLOBAL MACRO ENGINE v1
 * ====================================================
 * BOND MODULES:
 *   YIELD CURVE ENGINE (tam)
 *   BOND FLOW ENGINE
 *   RATE EXPECTATION ENGINE
 *   INFLATION PREMIUM ENGINE
 *   DURATION PRESSURE ENGINE
 *
 * GLOBAL MACRO MODULES:
 *   GLOBAL LIQUIDITY ENGINE
 *   GLOBAL RISK APPETITE ENGINE
 *   GEOPOLITICAL RISK ENGINE
 *   GLOBAL MONEY FLOW ENGINE
 */

import { clamp } from './engineCore.js';

// ════════════════════════════════════════════════════════════════════════════════
// BOND ENGINE — TAM VERSİYON
// ════════════════════════════════════════════════════════════════════════════════

// ─── 1. YIELD CURVE ENGINE ────────────────────────────────────────────────────
/**
 * Getiri eğrisini tam olarak analiz eder.
 * 2Y-10Y spread, 3M-10Y spread, eğri şekli
 */
export function runYieldCurveEngine({
  us3m  = 5.3,
  us2y  = 4.8,
  us5y  = 4.5,
  us10y = 4.3,
  us30y = 4.5,
  de10y = 2.5,  // Almanya
  jp10y = 0.9,  // Japonya
} = {}) {

  // Kritik spreadler
  const spread_2y10y  = parseFloat((us10y - us2y).toFixed(3));
  const spread_3m10y  = parseFloat((us10y - us3m).toFixed(3));
  const spread_5y30y  = parseFloat((us30y - us5y).toFixed(3));

  const inverted_2y10y  = spread_2y10y  < 0;
  const inverted_3m10y  = spread_3m10y  < 0;

  let   score   = 50;
  const signals = [];

  // En kritik: 3M-10Y tersine dönme
  if (inverted_3m10y && spread_3m10y < -1.0) { score -= 25; signals.push(`🔴 3M-10Y tersine döndü (${spread_3m10y}%) — Resesyon sinyali`); }
  else if (inverted_3m10y)                   { score -= 15; signals.push(`Ters getiri eğrisi: ${spread_3m10y}%`); }

  if (inverted_2y10y && spread_2y10y < -0.5) { score -= 15; signals.push(`2Y-10Y spread negatif (${spread_2y10y}%)`); }
  else if (!inverted_2y10y && spread_2y10y >= 0.5) { score += 12; signals.push(`Normal eğri: ${spread_2y10y}% — Ekonomi sağlıklı`); }

  // Yüksek mutlak getiri seviyesi
  if (us10y >= 5.0)  { score -= 12; signals.push(`10Y %${us10y} — Yüksek, risk varlıkları baskı altında`); }
  else if (us10y <= 3.5) { score += 10; signals.push(`10Y %${us10y} — Düşük, likidite bol`); }

  // Şekil analizi
  const shape = inverted_3m10y ? 'TERS' :
                spread_3m10y >= 0.5 ? 'NORMAL' : 'DÜZLEŞME';

  score = clamp(score);

  return {
    score,
    yields:    { us3m, us2y, us5y, us10y, us30y, de10y, jp10y },
    spreads:   { spread_2y10y, spread_3m10y, spread_5y30y },
    inverted:  inverted_3m10y,
    shape,
    recessionRisk: inverted_3m10y && spread_3m10y < -0.5,
    signals,
    cryptoImpact: score >= 60 ? 'POZİTİF' : score <= 40 ? 'NEGATİF' : 'NÖTR',
    summary:   signals[0] || `Getiri eğrisi: ${shape} (10Y: %${us10y}, Spread: ${spread_2y10y}%)`,
    timestamp: new Date().toISOString(),
  };
}

// ─── 2. BOND FLOW ENGINE ──────────────────────────────────────────────────────
/**
 * Tahvil piyasasına para girişi/çıkışı.
 * Tahvile para kaçıyorsa = risk-off = kripto düşer
 */
export function runBondFlowEngine({
  treasuryFundFlowBln = 0,   // ABD tahvil fonlarına giriş/çıkış ($mlr)
  corpBondFlowBln     = 0,   // Kurumsal tahvil akışı
  highYieldFlowBln    = 0,   // Yüksek getiri (junk) tahvil akışı
  foreignBuying       = 0,   // Yabancı alıcılar net ($mlr)
} = {}) {

  let   score   = 50;
  const signals = [];

  // Güvenli tahvile akış = risk-off
  if (treasuryFundFlowBln >= 5)     { score -= 15; signals.push(`Hazine tahviline $${treasuryFundFlowBln}B giriş — Risk-off`); }
  else if (treasuryFundFlowBln <= -5){ score += 12; signals.push(`Hazine tahvilinden $${Math.abs(treasuryFundFlowBln)}B çıkış — Risk-on`); }

  // Junk bond akışı risk iştahını gösterir
  if (highYieldFlowBln >= 3)        { score += 15; signals.push(`Junk tahvile $${highYieldFlowBln}B giriş — Risk iştahı var`); }
  else if (highYieldFlowBln <= -3)  { score -= 12; signals.push(`Junk tahvilden çıkış — Risk kaçınımı`); }

  // Yabancı alım
  if (foreignBuying >= 10)          { score += 8; signals.push(`Yabancı $${foreignBuying}B hazine alımı — Dolar güçlü`); }
  else if (foreignBuying <= -10)    { score -= 8; }

  return {
    score:            clamp(score),
    treasuryFundFlowBln, corpBondFlowBln, highYieldFlowBln, foreignBuying,
    riskOff:          treasuryFundFlowBln >= 5 && highYieldFlowBln < 0,
    signals,
    summary:          signals[0] || `Tahvil akışı: Hazine $${treasuryFundFlowBln}B, HY $${highYieldFlowBln}B`,
    timestamp:        new Date().toISOString(),
  };
}

// ─── 3. RATE EXPECTATION ENGINE ───────────────────────────────────────────────
/**
 * Piyasanın faiz beklentisini ölçer (Fed Funds Futures bazlı)
 */
export function runRateExpectationEngine({
  currentFedRate     = 5.25,
  marketExpectedRate = 5.00,  // 12 ay sonra beklenen oran
  nextMeetingCutProb = 30,    // Bir sonraki toplantıda indirim olasılığı %
  pivotsExpected     = 0,     // Beklenen indirim sayısı (12 ay)
} = {}) {

  const rateChangeBps = (marketExpectedRate - currentFedRate) * 100;
  let   score         = 50;
  const signals       = [];

  // Faiz indirimi beklentisi = likidite genişleyecek = kripto bullish
  if (rateChangeBps <= -100)      { score += 30; signals.push(`Piyasa ${pivotsExpected}x faiz indirimi bekliyor — Kripto boğa`); }
  else if (rateChangeBps <= -50)  { score += 18; signals.push(`${pivotsExpected} faiz indirimi beklentisi`); }
  else if (rateChangeBps <= -25)  { score += 10; }
  else if (rateChangeBps >= 25)   { score -= 15; signals.push(`Faiz artırımı beklentisi — Likidite sıkışıyor`); }

  if (nextMeetingCutProb >= 70)   { score += 12; signals.push(`Sonraki toplantıda %${nextMeetingCutProb} indirim olasılığı`); }
  else if (nextMeetingCutProb <= 20 && pivotsExpected === 0) { score -= 8; }

  return {
    score:            clamp(score),
    currentFedRate, marketExpectedRate, rateChangeBps,
    nextMeetingCutProb, pivotsExpected,
    dovishExpectation: rateChangeBps < -50,
    hawkishExpectation: rateChangeBps > 25,
    signals,
    summary:          signals[0] || `Faiz beklentisi: ${rateChangeBps >= 0 ? '+' : ''}${rateChangeBps}bps (${pivotsExpected} indirim)`,
    timestamp:        new Date().toISOString(),
  };
}

// ─── 4. INFLATION PREMIUM ENGINE ──────────────────────────────────────────────
export function runInflationPremiumEngine({
  nominalYield10y   = 4.3,
  realYield10y      = 2.0,    // TIPS getirisi
  breakeven10y      = 2.3,    // breakeven = nominal - real
  cpiExpectation    = 2.5,    // 12 aylık beklenti
} = {}) {

  const impliedBreakeven = parseFloat((nominalYield10y - realYield10y).toFixed(3));
  let   score = 50;
  const signals = [];

  // Yüksek enflasyon beklentisi = altın/kripto hedge talebi
  if (impliedBreakeven >= 2.8)   { score += 15; signals.push(`Enflasyon break-even %${impliedBreakeven} — Hedge talebi yüksek`); }
  else if (impliedBreakeven <= 1.8) { score -= 10; signals.push(`Düşük enflasyon beklentisi — Hedge talebi zayıf`); }

  // Yüksek reel getiri = risk varlıkları için baskı
  if (realYield10y >= 2.5)      { score -= 15; signals.push(`Reel getiri %${realYield10y} — Yüksek, kripto baskı altında`); }
  else if (realYield10y < 0)    { score += 20; signals.push(`Negatif reel getiri %${realYield10y} — Kripto/Altın için ideal`); }
  else if (realYield10y < 1)    { score += 10; }

  return {
    score:           clamp(score),
    nominalYield10y, realYield10y, impliedBreakeven, cpiExpectation,
    highInflPremium: impliedBreakeven >= 2.5,
    negativeReal:    realYield10y < 0,
    signals,
    summary:         signals[0] || `Reel getiri: %${realYield10y} | Break-even: %${impliedBreakeven}`,
    timestamp:       new Date().toISOString(),
  };
}

// ─── 5. DURATION PRESSURE ENGINE ─────────────────────────────────────────────
export function runDurationPressureEngine({
  longBondChange = 0,   // 30Y tahvil fiyat % değişim
  durationRisk   = 7.0, // Portföy ortalama süresi (yıl)
  yieldVolatility = 5,  // Getiri volatilitesi (bps)
} = {}) {

  let score = 50;
  // Uzun vadeli tahvil düşüyorsa = getiri yükseliyor = duration baskısı
  if (longBondChange <= -2)     { score -= 18; }
  else if (longBondChange >= 2) { score += 12; }
  if (yieldVolatility >= 10)    { score -= 12; }
  if (durationRisk >= 10)       { score -= 8; }

  return {
    score:      clamp(score),
    longBondChange, durationRisk, yieldVolatility,
    highPressure: longBondChange <= -1.5,
    summary:    `Duration baskısı: ${longBondChange <= -1 ? 'Yüksek' : 'Normal'} (30Y: ${longBondChange >= 0 ? '+' : ''}${longBondChange}%)`,
    timestamp:  new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// GLOBAL MACRO ENGINE
// ════════════════════════════════════════════════════════════════════════════════

// ─── 1. GLOBAL LIQUIDITY ENGINE ───────────────────────────────────────────────
/**
 * Küresel likidite koşullarını ölçer.
 * M2 büyümesi, merkez bankası bilanço değişimi, repo piyasası
 */
export function runGlobalLiquidityEngine({
  fedBalanceSheetChgBln = 0,   // FED bilançosu değişimi ($mlr)
  ecbBalanceSheetChg    = 0,
  boj_balance_chg       = 0,
  m2GrowthUSD           = 0,   // ABD M2 büyümesi %
  globalM2Growth        = 0,   // Küresel M2 büyümesi %
  repoStress            = false, // Repo piyasası stres var mı?
} = {}) {

  let   score   = 50;
  const signals = [];

  // Merkez bankası bilanço genişleme = likidite artışı = kripto bullish
  const totalCBExpansion = fedBalanceSheetChgBln + ecbBalanceSheetChg + boj_balance_chg;
  if (totalCBExpansion >= 50)       { score += 25; signals.push(`MB bilançosu +$${totalCBExpansion}B — Likidite genişliyor 🟢`); }
  else if (totalCBExpansion >= 20)  { score += 12; }
  else if (totalCBExpansion <= -50) { score -= 20; signals.push(`MB bilançosu -$${Math.abs(totalCBExpansion)}B — Likidite daralıyor`); }
  else if (totalCBExpansion <= -20) { score -= 10; }

  // M2 büyümesi
  if (globalM2Growth >= 5)          { score += 15; signals.push(`Küresel M2 +%${globalM2Growth} — Bol para`); }
  else if (globalM2Growth <= -2)    { score -= 15; signals.push(`Küresel M2 daralıyor (%${globalM2Growth})`); }

  // Repo stres
  if (repoStress)                   { score -= 15; signals.push('⚠️ Repo piyasası stresi — Likidite sıkışıyor'); }

  score = clamp(score);

  return {
    score,
    totalCBExpansion, globalM2Growth, m2GrowthUSD, repoStress,
    liquidityExpanding: score >= 60,
    liquidityContracting: score <= 40,
    signals,
    summary:   signals[0] || `Global likidite: ${score >= 60 ? 'Genişliyor' : score <= 40 ? 'Daralıyor' : 'Nötr'}`,
    timestamp: new Date().toISOString(),
  };
}

// ─── 2. GLOBAL RISK APPETITE ENGINE ──────────────────────────────────────────
export function runGlobalRiskAppetiteEngine({
  vixLevel        = 20,
  embiSpread      = 300,   // Gelişmekte olan ülke tahvil spreadi (bps)
  highYieldSpread = 400,   // HY kredi spreadi (bps)
  copperGoldRatio = 0.20,  // Bakır/Altın oranı (yüksek = risk iştahı)
  dxy             = 103,
} = {}) {

  let   score   = 50;
  const signals = [];

  // VIX
  if (vixLevel <= 15)   { score += 15; signals.push('VIX düşük — Küresel risk iştahı açık'); }
  else if (vixLevel >= 25) { score -= 15; signals.push('VIX yüksek — Risk kaçınımı'); }

  // Kredi spreadi (daraldıkça risk iştahı artar)
  if (highYieldSpread <= 300)  { score += 12; signals.push('HY spread düşük — Risk iştahı güçlü'); }
  else if (highYieldSpread >= 600) { score -= 15; signals.push(`HY spread ${highYieldSpread}bps — Risk kaçınımı`); }

  // Bakır/Altın: Yüksek = ekonomi büyüyor = risk-on
  if (copperGoldRatio >= 0.25) { score += 10; signals.push('Bakır/Altın yüksek — Büyüme beklentisi güçlü'); }
  else if (copperGoldRatio <= 0.15) { score -= 10; }

  // DXY güçlüyse küresel risk iştahı baskı altında
  if (dxy >= 106) { score -= 10; }
  else if (dxy <= 100) { score += 8; }

  score = clamp(score);

  return {
    score, vixLevel, embiSpread, highYieldSpread, copperGoldRatio,
    riskOn: score >= 60, riskOff: score <= 40,
    signals,
    summary: signals[0] || `Küresel risk iştahı: ${score >= 60 ? 'Açık' : score <= 40 ? 'Kapalı' : 'Nötr'} (${score}/100)`,
    timestamp: new Date().toISOString(),
  };
}

// ─── 3. GEOPOLITICAL RISK ENGINE ─────────────────────────────────────────────
export function runGeopoliticalRiskEngine({
  activeConflicts   = 0,   // Aktif çatışma sayısı
  sanctionsActive   = false,
  energyRouteRisk   = false,
  nuclearTension    = false,
  tradeWarEscalation = false,
  gprIndex          = 100,  // Jeopolitik Risk İndeksi (100=normal)
} = {}) {

  let   score   = 50;
  const signals = [];

  // GPR Index
  if (gprIndex >= 200)       { score -= 25; signals.push(`GPR ${gprIndex} — Yüksek jeopolitik risk`); }
  else if (gprIndex >= 150)  { score -= 15; signals.push(`GPR ${gprIndex} — Artan jeopolitik gerilim`); }
  else if (gprIndex <= 80)   { score += 10; signals.push('Jeopolitik risk düşük — Stabil ortam'); }

  if (nuclearTension)        { score -= 20; signals.push('⚠️ Nükleer gerilim — Aşırı belirsizlik'); }
  if (energyRouteRisk)       { score -= 15; signals.push('Enerji tedarik yolu riski — Petrol/gaz volatil'); }
  if (sanctionsActive)       { score -= 10; signals.push('Yaptırımlar aktif — Küresel ticaret baskısı'); }
  if (tradeWarEscalation)    { score -= 12; signals.push('Ticaret savaşı tırmanıyor'); }
  if (activeConflicts >= 3)  { score -= 10; }

  score = clamp(score);

  // Kripto için jeopolitik risk bazen hedge talebi yaratır
  const cryptoHedgeDemand = score <= 35;

  return {
    score, gprIndex, activeConflicts,
    highRisk:      score <= 40,
    cryptoHedgeDemand,
    signals,
    summary:       signals[0] || `Jeopolitik risk: ${score <= 40 ? 'Yüksek' : score >= 60 ? 'Düşük' : 'Orta'} (GPR:${gprIndex})`,
    timestamp:     new Date().toISOString(),
  };
}

// ─── 4. GLOBAL MONEY FLOW ENGINE ─────────────────────────────────────────────
export function runGlobalMoneyFlowEngine({
  emergingMarketFlowBln = 0,  // Gelişmekte olan piyasalara akış
  developedMarketFlow   = 0,  // Gelişmiş piyasalar
  cryptoTotalFlowBln    = 0,  // Kripto'ya toplam akış
  stablecoinMcapChange  = 0,  // Stablecoin mcap değişimi %
} = {}) {

  let   score   = 50;
  const signals = [];

  // Kripto'ya direkt akış
  if (cryptoTotalFlowBln >= 2)    { score += 25; signals.push(`Kripto piyasasına $${cryptoTotalFlowBln}B giriş`); }
  else if (cryptoTotalFlowBln <= -2) { score -= 20; signals.push(`Kripto'dan $${Math.abs(cryptoTotalFlowBln)}B çıkış`); }

  // Stablecoin mcap büyümesi = yeni para kripto'ya giriyor
  if (stablecoinMcapChange >= 3)  { score += 15; signals.push(`Stablecoin mcap +%${stablecoinMcapChange} — Yeni para geliyor`); }
  else if (stablecoinMcapChange <= -3) { score -= 12; signals.push('Stablecoin mcap azalıyor — Para çıkışı'); }

  // Gelişmekte olan piyasalara akış = risk-on
  if (emergingMarketFlowBln >= 5) { score += 10; }
  else if (emergingMarketFlowBln <= -5) { score -= 8; }

  return {
    score:         clamp(score),
    emergingMarketFlowBln, cryptoTotalFlowBln, stablecoinMcapChange,
    moneyInCrypto: cryptoTotalFlowBln >= 1,
    signals,
    summary:       signals[0] || `Küresel para akışı: Kripto $${cryptoTotalFlowBln}B`,
    timestamp:     new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// ANA MOTORLAR
// ════════════════════════════════════════════════════════════════════════════════
export function runBondEngine(params = {}) {
  const { yieldCurve = {}, bondFlow = {}, rateExp = {}, inflPremium = {}, duration = {} } = params;

  const yieldR    = runYieldCurveEngine(yieldCurve);
  const flowR     = runBondFlowEngine(bondFlow);
  const rateExpR  = runRateExpectationEngine(rateExp);
  const inflR     = runInflationPremiumEngine(inflPremium);
  const durR      = runDurationPressureEngine(duration);

  const score = clamp(
    yieldR.score  * 0.30 +
    flowR.score   * 0.15 +
    rateExpR.score * 0.25 +
    inflR.score   * 0.20 +
    durR.score    * 0.10
  );

  return {
    score:    parseFloat(score.toFixed(1)),
    modules:  { yieldCurve: yieldR, bondFlow: flowR, rateExpectation: rateExpR, inflationPremium: inflR, duration: durR },
    recessionSignal: yieldR.recessionRisk,
    dovishSignal:    rateExpR.dovishExpectation,
    topSignal:       yieldR.signals[0] || rateExpR.signals[0] || inflR.signals[0],
    summary:  `Tahvil: ${score >= 60 ? 'POZİTİF' : score <= 40 ? 'NEGATİF' : 'NÖTR'} (${score.toFixed(0)}/100)`,
    timestamp: new Date().toISOString(),
  };
}

export function runGlobalMacroEngine(params = {}) {
  const { liquidity = {}, riskAppetite = {}, geopolitical = {}, moneyFlow = {} } = params;

  const liqR   = runGlobalLiquidityEngine(liquidity);
  const riskR  = runGlobalRiskAppetiteEngine(riskAppetite);
  const geoR   = runGeopoliticalRiskEngine(geopolitical);
  const flowR  = runGlobalMoneyFlowEngine(moneyFlow);

  const score = clamp(
    liqR.score  * 0.30 +
    riskR.score * 0.30 +
    geoR.score  * 0.20 +
    flowR.score * 0.20
  );

  const topSignal = liqR.signals[0] || riskR.signals[0] || geoR.signals[0] || flowR.signals[0];

  return {
    score:     parseFloat(score.toFixed(1)),
    modules:   { liquidity: liqR, riskAppetite: riskR, geopolitical: geoR, moneyFlow: flowR },
    topSignal: topSignal || 'Küresel makro: Normal',
    verdict:   score >= 65 ? 'MAKRO POZİTİF' : score <= 35 ? 'MAKRO NEGATİF' : 'NÖTR',
    summary:   `${score >= 65 ? 'MAKRO POZİTİF' : score <= 35 ? 'MAKRO NEGATİF' : 'NÖTR'} (${score.toFixed(0)}/100) — ${topSignal || 'Normal'}`,
    timestamp: new Date().toISOString(),
  };
}
