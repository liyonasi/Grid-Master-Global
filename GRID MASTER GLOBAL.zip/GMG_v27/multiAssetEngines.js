/**
 * GMG — MULTI ASSET ENGINES
 * ===========================
 * forexEngine.js + commodityEngine.js + bondMacroEngine.js + technicalExtEngine.js
 */

const clamp = (v, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, v));

// ═══════════════════════════════════════════════════════════════════════════════
// 1. FOREX ENGINE
// ═══════════════════════════════════════════════════════════════════════════════
export function runDXYPressureEngine({ dxyLevel = 104, dxyChange1d = 0 }) {
  // DXY yüksek + artıyor = kripto için olumsuz
  let score = 50;
  if (dxyLevel > 107)      score -= 20;
  else if (dxyLevel > 104) score -= 10;
  else if (dxyLevel < 100) score += 15;
  else if (dxyLevel < 102) score += 7;
  if (dxyChange1d > 0.5)   score -= 10;
  else if (dxyChange1d < -0.5) score += 10;
  return {
    score: Math.round(clamp(score)),
    dxyLevel, dxyChange1d,
    pressure: dxyLevel > 104 ? 'GÜÇLÜ DOLAR — Kripto Baskılı' : dxyLevel < 100 ? 'ZAYIF DOLAR — Kripto Destekli' : 'NÖTR',
    cryptoImpact: score >= 55 ? 'OLUMLU' : score <= 45 ? 'OLUMSUZ' : 'NÖTR',
  };
}

export function runCurrencyStrengthEngine(pairChanges = {}) {
  // pairChanges: { EURUSD: 0.3, GBPUSD: -0.2, USDJPY: 0.5, ... }
  const usdPairs  = ['USDJPY', 'USDCHF', 'USDCAD'];
  const nonUsdP   = ['EURUSD', 'GBPUSD', 'AUDUSD', 'NZDUSD'];
  let usdStr = 0, cnt = 0;
  for (const p of usdPairs)  { if (pairChanges[p] != null) { usdStr += pairChanges[p]; cnt++; } }
  for (const p of nonUsdP)   { if (pairChanges[p] != null) { usdStr -= pairChanges[p]; cnt++; } }
  const usdIndex = cnt ? usdStr / cnt : 0;
  return {
    usdStrength:  parseFloat(usdIndex.toFixed(3)),
    isUSDStrong:  usdIndex > 0.1,
    isUSDWeak:    usdIndex < -0.1,
    cryptoScore:  Math.round(clamp(50 - usdIndex * 30)),
    summary: `USD gücü: ${usdIndex >= 0 ? '+' : ''}${usdIndex.toFixed(3)} → Kripto ${usdIndex > 0.1 ? 'baskılı' : usdIndex < -0.1 ? 'destekli' : 'nötr'}`,
  };
}

export function runCarryTradeAnalyzer({ usdJpyChange = 0, usdChfChange = 0, vixLevel = 20 }) {
  // Carry trade çözülmesi = risk-off = kripto satış
  const carryUnwind = (usdJpyChange < -1.5 || usdChfChange < -1.0) && vixLevel > 25;
  const riskOff     = vixLevel > 30;
  let score = 50;
  if (carryUnwind) score -= 25;
  if (riskOff)     score -= 15;
  if (vixLevel < 15) score += 10;
  return {
    score: Math.round(clamp(score)),
    carryUnwind,
    riskOff,
    vixLevel,
    signal: carryUnwind ? '⚠ CARRY TRADE ÇÖZÜLÜYOR — Kripto satış riski' : riskOff ? 'Risk-Off ortam' : 'Normal',
  };
}

export function runSessionFlowEngine(utcHour = new Date().getUTCHours()) {
  const sessions = {
    ASYA:    { start: 0,  end: 8,  vol: 'DÜŞÜK',  pairs: ['USDJPY','AUDUSD'] },
    LONDON:  { start: 7,  end: 16, vol: 'YÜKSEK', pairs: ['EURUSD','GBPUSD'] },
    NEW_YORK:{ start: 13, end: 22, vol: 'YÜKSEK', pairs: ['EURUSD','USDCAD'] },
    OVERLAP: { start: 13, end: 16, vol: 'EN YÜKSEK', pairs: ['EURUSD','GBPUSD','USDJPY'] },
  };
  const active = [];
  for (const [name, s] of Object.entries(sessions)) {
    if (utcHour >= s.start && utcHour < s.end) active.push(name);
  }
  const isHighVol = active.includes('OVERLAP') || (active.includes('LONDON') && active.includes('NEW_YORK'));
  return {
    utcHour, activeSessions: active,
    isHighVolume: isHighVol,
    cryptoVolBoost: isHighVol ? 15 : active.includes('NEW_YORK') ? 8 : 0,
    summary: `Aktif seans: ${active.join(' + ') || 'KAPALI'} | ${isHighVol ? 'Yüksek hacim' : 'Normal'}`,
  };
}

export function runCentralBankSignalEngine(overrides = {}) {
  const defaults = { fedTone: 'neutral', ecbTone: 'neutral', bojTone: 'neutral', rateExpectation: 'hold' };
  const cfg = { ...defaults, ...overrides };
  const toneScore = { hawkish: -15, neutral: 0, dovish: 15 };
  let score = 50;
  score += (toneScore[cfg.fedTone] || 0) * 1.5;
  score += (toneScore[cfg.ecbTone] || 0) * 0.8;
  score += (toneScore[cfg.bojTone] || 0) * 0.5;
  if (cfg.rateExpectation === 'cut')  score += 12;
  if (cfg.rateExpectation === 'hike') score -= 12;
  return {
    score: Math.round(clamp(score)),
    ...cfg,
    cryptoImpact: score >= 60 ? 'OLUMLU — Gevşek para politikası' : score <= 40 ? 'OLUMSUZ — Sıkı para politikası' : 'NÖTR',
  };
}

export function runForexEngine({ pairChanges = {}, dxyData = {}, carryData = {}, sessionHour = null } = {}) {
  const dxy     = runDXYPressureEngine(dxyData);
  const cStr    = runCurrencyStrengthEngine(pairChanges);
  const carry   = runCarryTradeAnalyzer(carryData);
  const session = runSessionFlowEngine(sessionHour ?? new Date().getUTCHours());
  const cbk     = runCentralBankSignalEngine();

  const score = Math.round(clamp(
    dxy.score   * 0.30 +
    cStr.cryptoScore * 0.25 +
    carry.score * 0.25 +
    clamp(50 + session.cryptoVolBoost) * 0.10 +
    cbk.score   * 0.10
  ));

  return {
    score,
    dxy, currencyStrength: cStr, carryTrade: carry, session, centralBank: cbk,
    action: score >= 65 ? 'FOREX DESTEKLI' : score <= 35 ? 'FOREX BASKILI' : 'NÖTR',
    summary: `DXY: ${dxy.pressure} | Seans: ${session.activeSessions.join('+')} | ${carry.signal}`,
    timestamp: Date.now(),
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// 2. COMMODITY ENGINE
// ═══════════════════════════════════════════════════════════════════════════════
export function runSafeHavenFlowEngine({ goldChange = 0, jpyChange = 0, vixLevel = 20 } = {}) {
  // Altın + JPY yükseliyorsa = risk-off = kripto için kötü
  const safeHavenBid = (goldChange > 1 || jpyChange > 0.5) && vixLevel > 22;
  let score = 50;
  if (safeHavenBid)    score -= 20;
  if (goldChange > 2)  score -= 10;
  if (goldChange < -1) score += 8;   // altın düşüyor = risk-on
  if (vixLevel < 15)   score += 10;
  return {
    score: Math.round(clamp(score)),
    safeHavenBid, goldChange, jpyChange, vixLevel,
    signal: safeHavenBid ? '⚠ Güvenli liman talebi — Risk-Off' : goldChange > 1 ? 'Altın güçlü' : 'Normal',
  };
}

export function runOilSupplyShockEngine({ wtiPrice = 80, wtiChange1d = 0, opecCutAnnounced = false } = {}) {
  let score = 50;
  // Petrol çok yükselirse enflasyon + fed sıkılaşma → kripto kötü
  if (wtiPrice > 100)      score -= 15;
  else if (wtiPrice > 90)  score -= 8;
  else if (wtiPrice < 60)  score += 5;
  if (wtiChange1d > 3)     score -= 10;
  if (opecCutAnnounced)    score -= 8;
  return {
    score: Math.round(clamp(score)),
    wtiPrice, wtiChange1d, opecCutAnnounced,
    signal: wtiPrice > 100 ? '⚠ Yüksek petrol — Enflasyon riski' : wtiChange1d > 3 ? 'Petrol ani artış' : 'Normal',
  };
}

export function runCommodityEngine({ gold = {}, oil = {}, safeHaven = {} } = {}) {
  const sh  = runSafeHavenFlowEngine(safeHaven);
  const oil2 = runOilSupplyShockEngine(oil);
  const goldScore = clamp(50 - (gold.change1d || 0) * 5); // altın artarsa kripto düşer (risk-off)

  const score = Math.round(clamp(
    sh.score    * 0.45 +
    oil2.score  * 0.30 +
    goldScore   * 0.25
  ));

  return {
    score,
    safeHaven: sh, oilShock: oil2,
    goldChange: gold.change1d || 0,
    action: score >= 60 ? 'EMTIA DESTEKLI' : score <= 40 ? 'EMTIA BASKILI' : 'NÖTR',
    summary: `${sh.signal} | Petrol: $${oil.wtiPrice || 80} (${oil.wtiChange1d >= 0 ? '+' : ''}${oil.wtiChange1d || 0}%)`,
    timestamp: Date.now(),
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// 3. BOND MACRO ENGINE
// ═══════════════════════════════════════════════════════════════════════════════
export function runYieldCurveEngine({ us3m = 5.2, us2y = 4.8, us10y = 4.5, us30y = 4.6 } = {}) {
  const spread2y10y  = us10y - us2y;
  const spread3m10y  = us10y - us3m;
  const inverted2y   = spread2y10y < 0;
  const inverted3m   = spread3m10y < 0;
  const deepInverted = spread2y10y < -0.5;

  let score = 50;
  if (deepInverted) score -= 20;
  else if (inverted2y) score -= 10;
  if (inverted3m)   score -= 8;
  if (us10y > 5)    score -= 12; // yüksek faiz = kripto kötü
  if (us10y < 3.5)  score += 10;

  return {
    score: Math.round(clamp(score)),
    us3m, us2y, us10y, us30y,
    spread2y10y: parseFloat(spread2y10y.toFixed(3)),
    spread3m10y: parseFloat(spread3m10y.toFixed(3)),
    inverted: inverted2y || inverted3m,
    signal: deepInverted ? '🚨 Derin ters eğri — Resesyon riski' : inverted2y ? '⚠ Ters eğri' : us10y > 5 ? 'Yüksek faiz baskısı' : 'Normal',
    cryptoImpact: score >= 55 ? 'OLUMLU' : score <= 45 ? 'OLUMSUZ' : 'NÖTR',
  };
}

export function runGlobalLiquidityEngine({ fedBalanceSheetChgBln = 0, globalM2Growth = 0 } = {}) {
  // Fed balance sheet genişliyor + M2 artıyor = kripto için çok olumlu
  let score = 50;
  if (fedBalanceSheetChgBln > 50)  score += 20;
  else if (fedBalanceSheetChgBln > 0)  score += 8;
  else if (fedBalanceSheetChgBln < -50) score -= 15;
  if (globalM2Growth > 5)  score += 10;
  else if (globalM2Growth < 0) score -= 10;
  return {
    score: Math.round(clamp(score)),
    fedBalanceSheetChgBln, globalM2Growth,
    isExpanding: fedBalanceSheetChgBln > 0 || globalM2Growth > 3,
    signal: fedBalanceSheetChgBln > 50 ? '🟢 Fed genişliyor — Likidite artıyor'
      : fedBalanceSheetChgBln < -50 ? '🔴 Fed daralıyor — Likidite azalıyor' : 'Nötr likidite',
  };
}

export function runBondEngine({ yieldCurve = {}, globalLiq = {} } = {}) {
  const yc  = runYieldCurveEngine(yieldCurve);
  const gl  = runGlobalLiquidityEngine(globalLiq);
  const score = Math.round(clamp(yc.score * 0.50 + gl.score * 0.50));
  return {
    score,
    yieldCurve: yc, globalLiquidity: gl,
    action: score >= 60 ? 'TAHVİL DESTEKLI' : score <= 40 ? 'TAHVİL BASKILI' : 'NÖTR',
    summary: `${yc.signal} | ${gl.signal}`,
    timestamp: Date.now(),
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// 4. TECHNICAL EXT ENGINE — BOS / CHoCH / Wall / Squeeze
// ═══════════════════════════════════════════════════════════════════════════════
export function runBOSDetector(candles, lookback = 20) {
  if (!candles || candles.length < lookback + 2) return { bos: null, direction: null };
  const n      = candles.length - 1;
  const recent = candles.slice(-lookback);
  const prevH  = Math.max(...recent.slice(0,-1).map(c => c.h || c.c));
  const prevL  = Math.min(...recent.slice(0,-1).map(c => c.l || c.c));
  const cur    = candles[n].c;
  if (cur > prevH) return { bos: 'YUKARI', level: prevH, current: cur, breakPct: ((cur-prevH)/prevH*100).toFixed(2) };
  if (cur < prevL) return { bos: 'ASAGI',  level: prevL, current: cur, breakPct: ((prevL-cur)/prevL*100).toFixed(2) };
  return { bos: null, direction: null };
}

export function runCHoCHDetector(candles, lookback = 30) {
  if (!candles || candles.length < lookback + 2) return { choch: null };
  const n = candles.length - 1;
  const slice = candles.slice(-lookback);
  const highs = slice.map(c => c.h || c.c);
  const lows  = slice.map(c => c.l || c.c);
  // Yükselen yapıda LL = CHoCH bearish
  const hh = highs[highs.length-1] > Math.max(...highs.slice(0,-3));
  const ll = lows[lows.length-1]   < Math.min(...lows.slice(0,-3));
  const hl = lows[lows.length-1]   > Math.min(...lows.slice(0,-3));
  const lh = highs[highs.length-1] < Math.max(...highs.slice(0,-3));
  let choch = null;
  if (hh && ll) choch = { type:'CHoCH_BEARISH', msg:'Yükselen yapıda LL kırıldı — dönüş ihtimali', strength:72 };
  if (ll && hh) choch = { type:'CHoCH_BULLISH', msg:'Düşen yapıda HH kırıldı — dönüş ihtimali', strength:72 };
  return { choch, hh, hl, lh, ll };
}

export function runBuyWallDetector(orderbook, currentPrice) {
  if (!orderbook?.bids?.length || !currentPrice) return { walls: [], strongestWall: null };
  const walls = orderbook.bids
    .filter(b => b.amount * b.price > 200000)
    .map(b => ({
      price: b.price, value: b.amount * b.price,
      distPct: ((currentPrice - b.price) / currentPrice * 100).toFixed(2),
      strength: b.amount * b.price > 1000000 ? 'GÜÇLÜ' : 'ORTA',
    }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 5);
  return { walls, strongestWall: walls[0] || null, wallCount: walls.length };
}

export function runSellWallDetector(orderbook, currentPrice) {
  if (!orderbook?.asks?.length || !currentPrice) return { walls: [], strongestWall: null };
  const walls = orderbook.asks
    .filter(a => a.amount * a.price > 200000)
    .map(a => ({
      price: a.price, value: a.amount * a.price,
      distPct: ((a.price - currentPrice) / currentPrice * 100).toFixed(2),
      strength: a.amount * a.price > 1000000 ? 'GÜÇLÜ' : 'ORTA',
    }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 5);
  return { walls, strongestWall: walls[0] || null, wallCount: walls.length };
}

export function runSqueezeDetector(candles, period = 20) {
  if (!candles || candles.length < period) return { squeeze: false };
  const closes = candles.slice(-period).map(c => c.c);
  const mean   = closes.reduce((a,b) => a+b,0) / period;
  const std    = Math.sqrt(closes.reduce((a,b) => a+(b-mean)**2,0) / period);
  const bbWidth = (std * 4) / mean; // 2*std her yönde
  const squeeze = bbWidth < 0.03;
  const recentRanges = candles.slice(-5).map(c => ((c.h||c.c)-(c.l||c.c))/(c.c||1));
  const avgRange = recentRanges.reduce((a,b)=>a+b,0)/recentRanges.length;
  const tightening = avgRange < 0.008;
  return {
    squeeze: squeeze || tightening,
    bbWidth:    parseFloat(bbWidth.toFixed(4)),
    avgRange:   parseFloat(avgRange.toFixed(4)),
    strength:   squeeze && tightening ? 'GÜÇLÜ SIKIŞ' : squeeze || tightening ? 'ORTA SIKIŞ' : 'NORMAL',
    potentialBreakout: (squeeze || tightening),
    signal: (squeeze || tightening) ? '⚡ SIKIŞ TESPİT EDİLDİ — Patlama yakın' : null,
  };
}

export function runLongShortRatioEngine({ longRatio = 50, shortRatio = 50 } = {}) {
  const lsRatio  = longRatio / Math.max(shortRatio, 0.1);
  const overcrowdedLong  = longRatio > 65;
  const overcrowdedShort = shortRatio > 65;
  let score = 50;
  if (overcrowdedLong)  score -= 15; // çok fazla long = düşüş riski
  if (overcrowdedShort) score += 15; // çok fazla short = yükseliş
  return {
    score: Math.round(clamp(score)),
    longRatio, shortRatio, lsRatio: parseFloat(lsRatio.toFixed(2)),
    overcrowdedLong, overcrowdedShort,
    signal: overcrowdedLong ? '⚠ Long kalabalık — Short squeeze riski'
      : overcrowdedShort ? '⚡ Short kalabalık — Long squeeze potansiyeli' : 'Dengeli',
  };
}

export function runStealthTrendEngine(candles) {
  if (!candles || candles.length < 20) return { stealth: false };
  const n      = candles.length - 1;
  const closes = candles.map(c => c.c);
  const vols   = candles.map(c => c.v || 0);
  // Son 10 mumun fiyat değişimi vs hacim değişimi
  const priceChange = (closes[n] - closes[n-10]) / closes[n-10] * 100;
  const avgVol10    = vols.slice(-10).reduce((a,b) => a+b,0) / 10;
  const avgVol20    = vols.slice(-20,-10).reduce((a,b) => a+b,0) / 10;
  const volRatio    = avgVol20 > 0 ? avgVol10 / avgVol20 : 1;
  // Sessiz yükseliş: fiyat artıyor ama hacim düşük
  const stealthRising  = priceChange > 1.5 && volRatio < 0.7;
  const stealthFalling = priceChange < -1.5 && volRatio < 0.7;
  return {
    stealthRising, stealthFalling,
    stealth: stealthRising || stealthFalling,
    priceChange: parseFloat(priceChange.toFixed(2)),
    volRatio:    parseFloat(volRatio.toFixed(2)),
    signal: stealthRising ? '🥷 GİZLİ YÜKSELİŞ — Birikim sinyali'
      : stealthFalling ? '🥷 GİZLİ DÜŞÜŞ — Dağıtım sinyali' : null,
  };
}

// ─── TOPLU ÇALIŞTIRICI ────────────────────────────────────────────────────────
export function runTechnicalExtEngine({ candles = [], orderbook = null, currentPrice = 0, longShortData = {} } = {}) {
  const bos   = runBOSDetector(candles);
  const choch = runCHoCHDetector(candles);
  const buyW  = runBuyWallDetector(orderbook, currentPrice);
  const sellW = runSellWallDetector(orderbook, currentPrice);
  const sq    = runSqueezeDetector(candles);
  const ls    = runLongShortRatioEngine(longShortData);
  const st    = runStealthTrendEngine(candles);

  let score = 50;
  if (bos.bos === 'YUKARI')  score += 15;
  if (bos.bos === 'ASAGI')   score -= 15;
  if (choch.choch?.type === 'CHoCH_BULLISH') score += 10;
  if (choch.choch?.type === 'CHoCH_BEARISH') score -= 10;
  if (buyW.wallCount > 2)    score += 8;
  if (sellW.wallCount > 2)   score -= 8;
  if (sq.potentialBreakout)  score += 5;
  score += ls.score - 50;
  if (st.stealthRising)      score += 10;
  if (st.stealthFalling)     score -= 10;

  return {
    score: Math.round(clamp(score)),
    bos, choch, buyWalls: buyW, sellWalls: sellW,
    squeeze: sq, longShort: ls, stealthTrend: st,
    signals: [bos.bos && `BOS ${bos.bos}`, choch.choch?.msg, sq.signal, ls.signal, st.signal].filter(Boolean),
    timestamp: Date.now(),
  };
}
