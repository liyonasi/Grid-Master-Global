/**
 * GMG — PINE INDICATOR ENGINE v6 (JS Port)
 * ==========================================
 * Pine Script v6 tam karşılığı:
 * LeventTaze | Grid Master Global — KLASİK ALSAT + GMG Indicator Council
 *
 * BÖLÜMLER:
 * 1. Range Filter (smoothrng + rngfilt + condIni)
 * 2. S/R Pivot Cluster (getSrVals + swapChannel)
 * 3. Filtrelenmiş Mod (longSignal/shortSignal = KLASİK veya FİLTRELİ)
 * 4. PB-AL / PB-SAT (trendUp = upward>0 AND filt>=filt[1])
 * 5. GMG Indicator Council (score + confidence + action + reason)
 * 6. TP1 / TP2 / SL hesabı
 * 7. Mum renklendirme (barColor)
 * 8. Alarm mesajları
 */

// ─── YARDIMCI ─────────────────────────────────────────────────────────────────
function emaArr(data, period) {
  if (!data || !data.length || period < 1) return Array(data?.length || 0).fill(null);
  const k = 2 / (period + 1);
  const r = Array(data.length).fill(null);
  let s = 0, cnt = 0;
  for (let i = 0; i < Math.min(period, data.length); i++) {
    if (data[i] != null) { s += data[i]; cnt++; }
  }
  if (!cnt) return r;
  r[Math.min(period, data.length) - 1] = s / cnt;
  for (let i = period; i < data.length; i++) {
    const prev = r[i-1];
    r[i] = data[i] != null && prev != null ? data[i] * k + prev * (1 - k) : prev;
  }
  return r;
}

// ─── 1. RANGE FILTER ─────────────────────────────────────────────────────────
function smoothrng(closes, t, m) {
  const absChanges = closes.map((v, i) => i === 0 ? 0 : Math.abs(v - closes[i-1]));
  const wper  = t * 2 - 1;
  const avrng = emaArr(absChanges, t);
  const smoothed = emaArr(avrng, wper);
  return smoothed.map(v => v != null ? v * m : null);
}

function rngfilt(closes, smrng) {
  const f = new Array(closes.length).fill(null);
  for (let i = 0; i < closes.length; i++) {
    const x = closes[i], r = smrng[i];
    if (r == null) { f[i] = x; continue; }
    if (i === 0)   { f[i] = x; continue; }
    const prev = f[i-1] ?? x;
    if (x > prev) f[i] = (x - r) < prev ? prev : (x - r);
    else          f[i] = (x + r) > prev ? prev : (x + r);
  }
  return f;
}

function computeRangeFilter(candles, per = 100, mult = 3.0) {
  if (!candles || candles.length < per + 1) return null;
  const closes = candles.map(c => c.c);
  const smrng  = smoothrng(closes, per, mult);
  const filt   = rngfilt(closes, smrng);

  // upward / downward sayaçları
  const upward   = new Array(closes.length).fill(0);
  const downward = new Array(closes.length).fill(0);
  for (let i = 1; i < filt.length; i++) {
    if      (filt[i] > filt[i-1]) { upward[i]   = (upward[i-1]   || 0) + 1; downward[i] = 0; }
    else if (filt[i] < filt[i-1]) { downward[i] = (downward[i-1] || 0) + 1; upward[i]   = 0; }
    else { upward[i] = upward[i-1] || 0; downward[i] = downward[i-1] || 0; }
  }

  const hband = filt.map((f, i) => f + (smrng[i] || 0));
  const lband = filt.map((f, i) => f - (smrng[i] || 0));

  // longCond / shortCond
  const longCond  = closes.map((c, i) => i === 0 ? false :
    (c > filt[i] && c > closes[i-1] && upward[i] > 0) ||
    (c > filt[i] && c < closes[i-1] && upward[i] > 0));
  const shortCond = closes.map((c, i) => i === 0 ? false :
    (c < filt[i] && c < closes[i-1] && downward[i] > 0) ||
    (c < filt[i] && c > closes[i-1] && downward[i] > 0));

  // CondIni flip — Pine mantığı
  const condIni = new Array(closes.length).fill(0);
  for (let i = 1; i < closes.length; i++) {
    if      (longCond[i])  condIni[i] = 1;
    else if (shortCond[i]) condIni[i] = -1;
    else                   condIni[i] = condIni[i-1] || 0;
  }

  const n = closes.length - 1;
  const buySignal  = longCond[n]  && condIni[n-1] === -1;
  const sellSignal = shortCond[n] && condIni[n-1] === 1;

  // Pine'daki barColor mantığı
  const barColors = closes.map((c, i) => {
    if (i === 0) return 'neutral';
    if (c > filt[i] && c > closes[i-1] && upward[i] > 0)   return 'lime';   // güçlü yükseliş
    if (c > filt[i] && c < closes[i-1] && upward[i] > 0)   return 'green';  // zayıf yükseliş
    if (c < filt[i] && c < closes[i-1] && downward[i] > 0) return 'red';    // güçlü düşüş
    if (c < filt[i] && c > closes[i-1] && downward[i] > 0) return 'maroon'; // zayıf düşüş
    return 'orange'; // belirsiz
  });

  // Pine v6: trendUp = upward > 0 AND filt >= filt[1]  ← KRİTİK DÜZELTME
  const trendUp   = upward[n] > 0   && filt[n] >= filt[n-1];
  const trendDown = downward[n] > 0  && filt[n] <= filt[n-1];

  const trendDir = trendUp ? 'YUKARI' : trendDown ? 'ASAGI' : 'BELIRSIZ';

  return {
    filt, smrng, hband, lband,
    upward, downward, condIni,
    longCond, shortCond,
    buySignal, sellSignal,
    barColors,
    trendDir, trendUp, trendDown,
    filtLast:     filt[n],
    hbandLast:    hband[n],
    lbandLast:    lband[n],
    upwardLast:   upward[n],
    downwardLast: downward[n],
    filtPrev:     filt[n-1] || filt[n],
  };
}

// ─── 2. S/R PIVOT CLUSTER ────────────────────────────────────────────────────
function computeATR(candles, period = 14) {
  if (!candles || candles.length < period + 1) return 0;
  const tr = candles.map((c, i) => {
    if (!i) return (c.h || c.c) - (c.l || c.c);
    const pc = candles[i-1].c;
    return Math.max((c.h||c.c)-(c.l||c.c), Math.abs((c.h||c.c)-pc), Math.abs((c.l||c.c)-pc));
  });
  const atrArr2 = emaArr(tr, period);
  return atrArr2[atrArr2.length-1] || 0;
}

function computePivotSR(candles, {
  prd      = 10,
  channelW = 5,
  minStr   = 1,
  maxNum   = 6,
  loopback = 290,
  src      = 'hl',
} = {}) {
  if (!candles || candles.length < prd * 2 + 1) return { res: [], sup: [], inside: [], all: [], inAnyChannel: false };

  const n    = candles.length;
  const src1 = candles.map(c => src === 'hl' ? (c.h || c.c) : Math.max(c.c, c.o || c.c));
  const src2 = candles.map(c => src === 'hl' ? (c.l || c.c) : Math.min(c.c, c.o || c.c));

  // Pivot tespiti
  const pivotVals = [], pivotIdxs = [];
  for (let i = prd; i < n - prd; i++) {
    let isHigh = true, isLow = true;
    for (let j = i - prd; j <= i + prd; j++) {
      if (j !== i && src1[j] >= src1[i]) isHigh = false;
      if (j !== i && src2[j] <= src2[i]) isLow  = false;
    }
    if (isHigh) { pivotVals.push(src1[i]); pivotIdxs.push(i); }
    if (isLow)  { pivotVals.push(src2[i]); pivotIdxs.push(i); }
  }

  // Loopback filtresi
  const recent = pivotVals
    .map((v, i) => ({ v, idx: pivotIdxs[i] }))
    .filter(p => n - p.idx <= loopback);

  if (!recent.length) return { res: [], sup: [], inside: [], all: [], inAnyChannel: false };

  // Kanal genişliği hesabı
  const allH = candles.slice(-300).map(c => c.h || c.c);
  const allL = candles.slice(-300).map(c => c.l || c.c);
  const cwidth = (Math.max(...allH) - Math.min(...allL)) * channelW / 100;

  // getSrVals — Pine'daki gibi kanal+dokunuş
  function getSrVals(pivotPrice) {
    let lo = pivotPrice, hi = pivotPrice, numpp = 0;
    for (const p of recent) {
      const wdth = p.v <= hi ? (hi - p.v) : (p.v - lo);
      if (wdth <= cwidth) {
        if (p.v <= hi) lo = Math.min(lo, p.v);
        else           hi = Math.max(hi, p.v);
        numpp += 20;
      }
    }
    let touchCount = 0;
    for (let i = 0; i < Math.min(loopback, n); i++) {
      const h = candles[n-1-i]?.h || candles[n-1-i]?.c || 0;
      const l = candles[n-1-i]?.l || candles[n-1-i]?.c || 0;
      if ((h <= hi && h >= lo) || (l <= hi && l >= lo)) touchCount++;
    }
    return { hi, lo, score: numpp + touchCount };
  }

  // Kanalları hesapla, sırala, örtüşenleri ele
  const channels = recent.map(p => {
    const { hi, lo, score } = getSrVals(p.v);
    return { hi, lo, score, pivot: p.v, idx: p.idx, touches: Math.floor(score / 20) };
  });

  const selected = [];
  const sorted   = [...channels].sort((a, b) => b.score - a.score);
  for (const ch of sorted) {
    if (selected.length >= 10) break;
    if (ch.score < minStr * 20) continue;
    let overlap = false;
    for (const s of selected) {
      if ((ch.hi <= s.hi && ch.hi >= s.lo) || (ch.lo <= s.hi && ch.lo >= s.lo)) {
        overlap = true; break;
      }
    }
    if (!overlap) selected.push(ch);
  }

  selected.sort((a, b) => b.score - a.score);
  const top = selected.slice(0, maxNum);

  const cur    = candles[n-1].c;
  const res    = top.filter(z => z.lo > cur).sort((a, b) => a.lo - b.lo);
  const sup    = top.filter(z => z.hi < cur).sort((a, b) => b.hi - a.hi);
  const inside = top.filter(z => z.hi >= cur && z.lo <= cur);

  return { res, sup, inside, all: top, inAnyChannel: inside.length > 0 };
}

// ─── 3. FİLTRELİ MOD ─────────────────────────────────────────────────────────
function computeSignals(rf, srData, pb, signalMode = 'KLASİK') {
  const longClassic  = rf.buySignal;
  const shortClassic = rf.sellSignal;

  // FİLTRELİ: classic + (nearSupport OR inAnyChannel)
  const longFiltered  = longClassic  && (pb.nearSupport || srData.inAnyChannel);
  const shortFiltered = shortClassic && (pb.nearRes     || srData.inAnyChannel);

  const useFiltered = signalMode === 'FİLTRELİ';
  const longSignal  = useFiltered ? longFiltered  : longClassic;
  const shortSignal = useFiltered ? shortFiltered : shortClassic;

  return { longClassic, shortClassic, longFiltered, shortFiltered, longSignal, shortSignal, useFiltered };
}

// ─── 4. PB-AL / PB-SAT ───────────────────────────────────────────────────────
function computePullbacks(candles, rf, srData, atrVal, {
  proxMode    = 'ATR',
  proxATRmult = 0.6,
  proxPct     = 0.35,
  pbsStrict   = true,
  pbaStrict   = true,
  signals     = null,  // longSignal/shortSignal — PB bunlarla çakışmamalı
} = {}) {
  if (!candles || !rf || !srData) return { pbSell: false, pbBuy: false, nearSupport: false, nearRes: false };

  const n   = candles.length - 1;
  const cur = candles[n].c;
  const prox = proxMode === 'ATR' ? atrVal * proxATRmult : cur * (proxPct / 100);

  // nearSupport / nearRes — Pine mantığıyla aynı
  let nearSupport = false, nearRes = false;
  for (const s of srData.sup) {
    if (cur - s.hi <= prox) { nearSupport = true; break; }
  }
  for (const r of srData.res) {
    if (r.lo - cur <= prox) { nearRes = true; break; }
  }

  // Pine v6: trendUp = upward>0 AND filt>=filt[1]  ← DÜZELTME
  const trendUp   = rf.trendUp;
  const trendDown = rf.trendDown;

  // Mum gücü
  const c = candles[n], p = candles[n-1] || c;
  const weakNow      = c.c < p.c || c.c < (c.o || c.c);
  const weakStrict   = c.c < p.c && c.c < (c.o || c.c);
  const strongNow    = c.c > p.c || c.c > (c.o || c.c);
  const strongStrict = c.c > p.c && c.c > (c.o || c.c);

  const pbWeak   = pbsStrict ? weakStrict   : weakNow;
  const pbStrong = pbaStrict ? strongStrict : strongNow;

  // Sinyal varsa PB gösterme — Pine: not shortSignal and not longSignal
  const ls = signals?.longSignal  || false;
  const ss = signals?.shortSignal || false;

  const pbSell = trendUp   && nearRes     && pbWeak   && !ss && !ls;
  const pbBuy  = trendDown && nearSupport && pbStrong  && !ss && !ls;

  return { pbSell, pbBuy, nearSupport, nearRes, inAnyChannel: srData.inAnyChannel };
}

// ─── 5. GMG INDICATOR COUNCIL ────────────────────────────────────────────────
/**
 * Pine Script Bölüm 6'nın tam karşılığı.
 * councilScore, councilConfidence, councilAction, councilReason
 */
function computeIndicatorCouncil({
  rf, pb, signals, signalMode,
  tp1Mult = 1.0, tp2Mult = 2.0, slMult = 1.0,
}) {
  let councilScore = 50.0;

  if (rf.trendUp)                     councilScore += 10;
  if (rf.trendDown)                   councilScore -= 10;

  if (signals.longClassic)            councilScore += 12;
  if (signals.shortClassic)           councilScore -= 12;

  if (signals.longFiltered)           councilScore += 18;
  if (signals.shortFiltered)          councilScore -= 18;

  if (pb.nearSupport && rf.trendUp)   councilScore += 8;
  if (pb.nearRes     && rf.trendDown) councilScore -= 8;

  if (pb.inAnyChannel)                councilScore -= 4;

  if (pb.pbBuy)                       councilScore += 6;
  if (pb.pbSell)                      councilScore -= 6;

  // Risk/Ödül bonusu
  const riskReward = slMult > 0 ? tp2Mult / slMult : 0;
  if (signals.longSignal  && riskReward >= 1.5) councilScore += 5;
  if (signals.shortSignal && riskReward >= 1.5) councilScore -= 5;

  councilScore = Math.max(0, Math.min(100, councilScore));

  // Güven hesabı
  let councilConfidence = Math.min(100, Math.abs(councilScore - 50) * 2);
  if (signals.useFiltered)         councilConfidence = Math.min(100, councilConfidence + 8);
  if (pb.pbBuy || pb.pbSell)       councilConfidence = Math.min(100, councilConfidence + 4);

  // Karar
  let councilAction, councilReason;
  if      (councilScore >= 75) { councilAction = 'STRONG BUY';  councilReason = 'Trend yukarı + güçlü sinyal'; }
  else if (councilScore >= 60) { councilAction = 'BUY';          councilReason = 'Olumlu yapı'; }
  else if (councilScore <= 25) { councilAction = 'STRONG SELL'; councilReason = 'Trend aşağı + güçlü satış baskısı'; }
  else if (councilScore <= 40) { councilAction = 'SELL';         councilReason = 'Zayıf yapı'; }
  else                          { councilAction = 'WAIT';         councilReason = 'Karışık / teyit bekleniyor'; }

  return {
    councilScore:      Math.round(councilScore),
    councilConfidence: Math.round(councilConfidence),
    councilAction,
    councilReason,
    riskReward:        parseFloat(riskReward.toFixed(2)),
  };
}

// ─── 6. TP1 / TP2 / SL ───────────────────────────────────────────────────────
function computeTPSL(candles, atrVal, signals, {
  tp1Mult = 1.0,
  tp2Mult = 2.0,
  slMult  = 1.0,
} = {}) {
  const n     = candles.length - 1;
  const entry = candles[n].c;
  if (!signals.longSignal && !signals.shortSignal) return null;

  const isLong = signals.longSignal;
  return {
    entry,
    tp1:   isLong ? entry + atrVal * tp1Mult  : entry - atrVal * tp1Mult,
    tp2:   isLong ? entry + atrVal * tp2Mult  : entry - atrVal * tp2Mult,
    sl:    isLong ? entry - atrVal * slMult   : entry + atrVal * slMult,
    isLong,
    atr:   atrVal,
  };
}

// ─── 7. ALARM MESAJLARI ───────────────────────────────────────────────────────
function buildAlertMessages(symbol, tf, price, rf, signals, pb, council) {
  const brand    = 'LeventTaze | Grid Master Global';
  const trendTxt = rf.trendUp ? 'YUKARI' : rf.trendDown ? 'AŞAĞI' : 'BELİRSİZ';
  const px       = price.toFixed(2);

  const base = `${brand}\nCoin: ${symbol}\nTF: ${tf}\nFiyat: ${px}\nTrend: ${trendTxt}\nCouncil: ${council.councilAction}`;

  return {
    buy:   signals.longSignal  ? `${brand} | BUY\n${base}`    : null,
    sell:  signals.shortSignal ? `${brand} | SELL\n${base}`   : null,
    pbAl:  pb.pbBuy            ? `${brand} | PB-AL\n${base}`  : null,
    pbSat: pb.pbSell           ? `${brand} | PB-SAT\n${base}` : null,
  };
}

// ─── ANA ÇALIŞTIRICI ─────────────────────────────────────────────────────────
export function runPineEngine(candles, {
  rfPer       = 100,
  rfMult      = 3.0,
  srPrd       = 10,
  srChannelW  = 5,
  srMaxNum    = 6,
  srMinStr    = 1,
  srLoopback  = 290,
  srSrc       = 'hl',
  atrLen      = 14,
  proxMode    = 'ATR',
  proxATRmult = 0.6,
  proxPct     = 0.35,
  pbsStrict   = true,
  pbaStrict   = true,
  signalMode  = 'KLASİK',  // 'KLASİK' veya 'FİLTRELİ'  ← YENİ
  tp1Mult     = 1.0,
  tp2Mult     = 2.0,
  slMult      = 1.0,
  symbol      = '',
  tf          = '1m',
} = {}) {
  if (!candles || candles.length < 30) return null;

  // Hesaplamalar
  const rf   = computeRangeFilter(candles, rfPer, rfMult);
  if (!rf) return null;

  const sr   = computePivotSR(candles, {
    prd: srPrd, channelW: srChannelW, maxNum: srMaxNum,
    minStr: srMinStr, loopback: srLoopback, src: srSrc,
  });
  const atrV = computeATR(candles, atrLen);

  // Önce signals hesapla (pb buna bakacak)
  const signalsRaw = computeSignals(rf, sr, { nearSupport: false, nearRes: false, inAnyChannel: sr.inAnyChannel }, signalMode);
  const pb         = computePullbacks(candles, rf, sr, atrV, {
    proxMode, proxATRmult, proxPct, pbsStrict, pbaStrict,
    signals: signalsRaw,
  });

  // Signals'ı pb ile birlikte yeniden hesapla (pb.nearSupport güncellendi)
  const signals = computeSignals(rf, sr, pb, signalMode);
  // pb'yi de signals ile yeniden hesapla
  const pbFinal = computePullbacks(candles, rf, sr, atrV, {
    proxMode, proxATRmult, proxPct, pbsStrict, pbaStrict,
    signals,
  });

  const council = computeIndicatorCouncil({
    rf, pb: pbFinal, signals, signalMode, tp1Mult, tp2Mult, slMult,
  });

  const tpsl    = computeTPSL(candles, atrV, signals, { tp1Mult, tp2Mult, slMult });
  const n       = candles.length - 1;
  const price   = candles[n].c;
  const alerts  = buildAlertMessages(symbol, tf, price, rf, signals, pbFinal, council);

  // Technical Council'a gidecek sinyal paketi
  const technicalSignal = {
    rfTrendDir:   rf.trendDir,
    rfTrendUp:    rf.trendUp,
    rfTrendDown:  rf.trendDown,
    rfBuySignal:  signals.longSignal,
    rfSellSignal: signals.shortSignal,
    rfFiltLast:   rf.filtLast,
    rfUpward:     rf.upwardLast,
    rfDownward:   rf.downwardLast,
    inAnyChannel: pbFinal.inAnyChannel,
    nearSupport:  pbFinal.nearSupport,
    nearRes:      pbFinal.nearRes,
    srResCount:   sr.res.length,
    srSupCount:   sr.sup.length,
    srResNearest: sr.res[0]?.lo   || null,
    srSupNearest: sr.sup[0]?.hi   || null,
    pbBuy:        pbFinal.pbBuy,
    pbSell:       pbFinal.pbSell,
    councilScore:      council.councilScore,
    councilAction:     council.councilAction,
    councilConfidence: council.councilConfidence,
  };

  // Council skoru (masterCouncil'e girdi)
  const score = council.councilScore;

  return {
    // Ham hesaplamalar
    rf,
    sr,
    pb: pbFinal,
    atrV,
    signals,
    council,
    tpsl,
    alerts,
    // Özet
    technicalSignal,
    score,
    // Grafik çizim dizileri
    filtLine:  rf.filt   || [],
    hbandLine: rf.hband  || [],
    lbandLine: rf.lband  || [],
    srZones:   sr.all    || [],
    barColors: rf.barColors || [],
  };
}

// ─── PINE PARAMETRESİ OPTİMİZATÖRÜ ──────────────────────────────────────────
// rfPer × rfMult grid search → en yüksek win rate + ROI kombinasyonunu bulur.
// Hafif backtest: her parametre seti için sinyal üretip PnL hesaplar.
// Kullanım: await runPineOptimizer(candles) → { bestParams, results, topN }

export async function runPineOptimizer(candles, {
  rfPerRange  = [50, 75, 100, 150, 200],
  rfMultRange = [2.0, 2.5, 3.0, 3.5, 4.0],
  signalModes = ['KLASİK', 'FİLTRELİ'],
  minBars     = 50,
  tpAtrMult   = 1.5,
  slAtrMult   = 1.0,
  onProgress  = null, // (pct) => {} callback
} = {}) {
  if (!candles || candles.length < minBars + 30) {
    return { error: 'Yeterli veri yok', results: [] };
  }

  const results = [];
  const total   = rfPerRange.length * rfMultRange.length * signalModes.length;
  let done = 0;

  for (const rfPer of rfPerRange) {
    for (const rfMult of rfMultRange) {
      for (const signalMode of signalModes) {
        // Her 5 adımda UI'nın nefes almasına izin ver
        if (done % 5 === 0) {
          await new Promise(r => setTimeout(r, 0));
          if (onProgress) onProgress(Math.round(done / total * 100));
        }

        let wins = 0, losses = 0, totalPnlPct = 0, trades = 0;
        let inTrade = false, entry = null, direction = null, tp = 0, sl = 0;

        for (let i = 30; i < candles.length - 1; i++) {
          const slice = candles.slice(0, i + 1);
          let pd;
          try { pd = runPineEngine(slice, { rfPer, rfMult, signalMode }); } catch { continue; }
          if (!pd) continue;

          const cur = candles[i].c;
          const atr = pd.atrV || cur * 0.02;

          if (inTrade && entry) {
            const hi = candles[i].h || cur;
            const lo = candles[i].l || cur;
            let exited = false;
            if (direction === 'LONG') {
              if (lo <= sl)  { const pct = (sl - entry) / entry * 100; totalPnlPct += pct; losses++; exited = true; }
              else if (hi >= tp) { const pct = (tp - entry) / entry * 100; totalPnlPct += pct; wins++;  exited = true; }
            } else {
              if (hi >= sl)  { const pct = (entry - sl) / entry * 100; totalPnlPct += pct; losses++; exited = true; }
              else if (lo <= tp) { const pct = (entry - tp) / entry * 100; totalPnlPct += pct; wins++;  exited = true; }
            }
            if (exited) { inTrade = false; entry = null; trades++; }
          }

          if (!inTrade) {
            if (pd.signals?.longSignal) {
              inTrade = true; direction = 'LONG'; entry = cur;
              tp = cur + atr * tpAtrMult; sl = cur - atr * slAtrMult;
            } else if (pd.signals?.shortSignal) {
              inTrade = true; direction = 'SHORT'; entry = cur;
              tp = cur - atr * tpAtrMult; sl = cur + atr * slAtrMult;
            }
          }
        }

        if (trades < 3) { done++; continue; } // Çok az işlem — geç

        const winRate     = Math.round(wins / trades * 100);
        const avgPnl      = parseFloat((totalPnlPct / trades).toFixed(3));
        const compositeScore = winRate * 0.6 + avgPnl * 0.4; // Optimizasyon hedefi

        results.push({ rfPer, rfMult, signalMode, winRate, avgPnl, trades, compositeScore });
        done++;
      }
    }
  }

  if (results.length === 0) return { error: 'Sonuç üretilmedi', results: [] };

  // Sırala — compositeScore'a göre
  results.sort((a, b) => b.compositeScore - a.compositeScore);

  const best = results[0];
  return {
    bestParams: {
      rfPer:      best.rfPer,
      rfMult:     best.rfMult,
      signalMode: best.signalMode,
    },
    bestScore:  best.compositeScore,
    bestWinRate: best.winRate,
    bestAvgPnl:  best.avgPnl,
    totalCombos: total,
    testedCombos: results.length,
    topN:       results.slice(0, 5),
    results,
    timestamp:  Date.now(),
  };
}
