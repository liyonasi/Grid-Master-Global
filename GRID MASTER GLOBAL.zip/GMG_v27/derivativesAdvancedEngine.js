/**
 * derivativesAdvancedEngine.js — GMG v16
 * Gelişmiş Türev Motorları:
 *   74. Leverage Buildup Engine
 *   75. Unwind Detector
 *   77. Funding Extreme Engine
 *   78. OI Divergence Engine
 *   79. Cascade Risk Engine
 *   80. Derivative Trap Engine
 */

const clamp = (v, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, v));

// ─── LEVERAGE BUILDUP ENGINE ──────────────────────────────────────────────────
export function runLeverageBuildupEngine({
  openInterestHistory = [],  // [{oi, price, time}]
  fundingRate = 0,
  longShortRatio = 1,
}) {
  if (openInterestHistory.length < 3) return { score: 0, riskLevel: 'BILINMIYOR', buildup: false };

  const recent = openInterestHistory.slice(-10);
  const oldest = recent[0];
  const latest = recent[recent.length - 1];

  // OI artış hızı
  const oiGrowth = oldest.oi > 0 ? (latest.oi - oldest.oi) / oldest.oi * 100 : 0;

  // Fiyat ile OI ilişkisi
  const priceChange = oldest.price > 0 ? (latest.price - oldest.price) / oldest.price * 100 : 0;

  // Kaldıraç birikimi kriterleri:
  // 1. OI hızla artıyor (özellikle fiyat artarken)
  const rapidOIGrowth = oiGrowth > 10;

  // 2. Funding aşırı pozitif (longa doğru aşırı kaldıraç)
  const excessiveLongLeverage = fundingRate > 0.05;
  const excessiveShortLeverage = fundingRate < -0.05;

  // 3. Long/Short oranı dengesiz
  const lsImbalance = Math.abs(longShortRatio - 1) > 0.3;

  // 4. OI artışı fiyat artışını çok geçiyor (aşırı kaldıraç)
  const leverageAcceleration = oiGrowth > priceChange * 3 && oiGrowth > 5;

  let score = 0;
  if (rapidOIGrowth) score += 30;
  if (leverageAcceleration) score += 25;
  if (excessiveLongLeverage || excessiveShortLeverage) score += 20;
  if (lsImbalance) score += 15;
  if (oiGrowth > 20) score += 10;

  const riskLevel = score >= 70 ? 'KRİTİK' : score >= 50 ? 'YÜKSEK' : score >= 30 ? 'ORTA' : 'DÜŞÜK';
  const direction = excessiveLongLeverage ? 'LONG_HEAVY' : excessiveShortLeverage ? 'SHORT_HEAVY' : 'DENGELI';

  return {
    score: clamp(score),
    riskLevel,
    buildup: score >= 50,
    direction,
    oiGrowth:   parseFloat(oiGrowth.toFixed(2)),
    priceChange: parseFloat(priceChange.toFixed(2)),
    leverageAcceleration,
    excessiveLongLeverage,
    excessiveShortLeverage,
    verdict: score >= 70 ? '⛔ AŞIRI KALDIRAC — ÇÖZÜLME RİSKİ YÜKSEK' : score >= 50 ? '⚠ Kaldıraç birikimi var' : '✓ Normal',
    timestamp: Date.now(),
  };
}

// ─── UNWIND DETECTOR ─────────────────────────────────────────────────────────
export function runUnwindDetector({
  openInterestHistory = [],
  priceHistory = [],
  volumeHistory = [],
}) {
  if (openInterestHistory.length < 5 || priceHistory.length < 5) {
    return { detected: false, score: 0, type: 'NONE' };
  }

  const recentOI   = openInterestHistory.slice(-5);
  const recentPrice = priceHistory.slice(-5);
  const recentVol  = volumeHistory.slice(-5);

  const oiChange    = recentOI.length > 1 ? (recentOI[recentOI.length-1] - recentOI[0]) / Math.abs(recentOI[0] || 1) * 100 : 0;
  const priceChange = recentPrice.length > 1 ? (recentPrice[recentPrice.length-1] - recentPrice[0]) / Math.abs(recentPrice[0] || 1) * 100 : 0;
  const avgVol = recentVol.reduce((a,b)=>a+b,0)/Math.max(recentVol.length,1);
  const volSpike = recentVol[recentVol.length-1] > avgVol * 1.5;

  // Çözülme tipleri:
  // 1. Long Unwind: OI düşüyor + fiyat düşüyor
  const longUnwind = oiChange < -5 && priceChange < -2;
  // 2. Short Unwind (short squeeze): OI düşüyor + fiyat artıyor
  const shortUnwind = oiChange < -5 && priceChange > 2;
  // 3. Forced Liquidation: Çok hızlı OI düşüşü + hacim spike
  const forcedLiq = oiChange < -10 && volSpike;

  let score = 0;
  let type = 'NONE';
  if (forcedLiq)    { score = 85; type = 'FORCED_LIQUIDATION'; }
  else if (longUnwind)  { score = clamp(Math.abs(oiChange) * 3 + Math.abs(priceChange) * 4); type = 'LONG_UNWIND'; }
  else if (shortUnwind) { score = clamp(Math.abs(oiChange) * 3 + priceChange * 4); type = 'SHORT_SQUEEZE'; }

  return {
    detected: score >= 40,
    score: clamp(score),
    type,
    oiChange:    parseFloat(oiChange.toFixed(2)),
    priceChange: parseFloat(priceChange.toFixed(2)),
    volSpike,
    forcedLiq,
    longUnwind,
    shortUnwind,
    verdict: type === 'FORCED_LIQUIDATION' ? '⛔ ZORUNLU LİKİDASYON' : type === 'SHORT_SQUEEZE' ? '🔥 SHORT SQUEEZE' : type === 'LONG_UNWIND' ? '📉 LONG ÇÖZÜLÜYOR' : '✓ NORMAL',
    recommendation: type === 'FORCED_LIQUIDATION' ? 'Volatilite çok yüksek — giriş yapma' : type === 'SHORT_SQUEEZE' ? 'Long fırsatı oluşuyor olabilir' : '—',
    timestamp: Date.now(),
  };
}

// ─── FUNDING EXTREME ENGINE ───────────────────────────────────────────────────
export function runFundingExtremeEngine(fundingHistory = [], currentFunding = 0) {
  const allRates = fundingHistory.length ? fundingHistory : [currentFunding];
  const avg = allRates.reduce((a, b) => a + b, 0) / allRates.length;
  const maxRate = Math.max(...allRates.map(Math.abs));

  // Aşırılık kriterleri
  const isExtremeLong  = currentFunding > 0.08;  // %0.08+ aşırı long
  const isExtremeShort = currentFunding < -0.08; // %-0.08 aşırı short
  const isAnomaly      = Math.abs(currentFunding - avg) > 0.05;
  const trendUp        = allRates.length > 3 && allRates[allRates.length-1] > allRates[0];

  let score = 0;
  if (isExtremeLong || isExtremeShort) score += 50;
  if (Math.abs(currentFunding) > 0.12) score += 25;
  if (isAnomaly) score += 15;
  if (maxRate > 0.1) score += 10;

  const signal = isExtremeLong ? 'SHORT_BIAS' : isExtremeShort ? 'LONG_BIAS' : 'NEUTRAL';

  return {
    score: clamp(score),
    isExtreme: score >= 50,
    isExtremeLong,
    isExtremeShort,
    currentFunding: parseFloat(currentFunding.toFixed(4)),
    avgFunding: parseFloat(avg.toFixed(4)),
    signal,
    verdict: score >= 70
      ? `⛔ AŞIRI FUNDING (${(currentFunding*100).toFixed(3)}%) — ${signal === 'SHORT_BIAS' ? 'Satış baskısı yaklaşabilir' : 'Alış baskısı yaklaşabilir'}`
      : score >= 50
      ? `⚠ Yüksek funding: ${(currentFunding*100).toFixed(3)}%`
      : `✓ Normal funding: ${(currentFunding*100).toFixed(3)}%`,
    recommendation: isExtremeLong ? 'Uzun pozisyon taşıma maliyeti yüksek' : isExtremeShort ? 'Short squeeze riski var' : '—',
    timestamp: Date.now(),
  };
}

// ─── OI DIVERGENCE ENGINE ─────────────────────────────────────────────────────
export function runOIDivergenceEngine({
  priceHistory = [],
  oiHistory = [],
}) {
  if (priceHistory.length < 5 || oiHistory.length < 5) {
    return { divergence: false, score: 0, type: 'NONE' };
  }

  const n = Math.min(priceHistory.length, oiHistory.length);
  const prices = priceHistory.slice(-n);
  const ois    = oiHistory.slice(-n);

  const priceUp = prices[n-1] > prices[0];
  const oiUp    = ois[n-1] > ois[0];
  const priceChange = Math.abs((prices[n-1] - prices[0]) / prices[0] * 100);
  const oiChange    = Math.abs((ois[n-1] - ois[0]) / (ois[0] || 1) * 100);

  // Uyumsuzluk tipleri:
  // 1. Fiyat artıyor + OI azalıyor → zayıf yükseliş (short covering)
  const bullishDivergence = priceUp && !oiUp;
  // 2. Fiyat düşüyor + OI azalıyor → zayıf düşüş (long capitulation)
  const bearishDivergence = !priceUp && !oiUp;
  // 3. Fiyat düşüyor + OI artıyor → yeni short açılıyor (bearish)
  const newShorts = !priceUp && oiUp;
  // 4. Fiyat artıyor + OI artıyor → yeni long açılıyor (bullish)
  const newLongs = priceUp && oiUp;

  let score = 0;
  let type  = 'NONE';
  if (bullishDivergence && priceChange > 1 && oiChange > 3) { score = clamp(40 + oiChange * 2); type = 'WEAK_BULL'; }
  else if (newShorts && priceChange > 0.5) { score = clamp(50 + priceChange * 3); type = 'NEW_SHORTS'; }
  else if (bearishDivergence) { score = clamp(30 + oiChange * 1.5); type = 'CAPITULATION'; }
  else if (newLongs) { type = 'NEW_LONGS'; score = 20; }

  return {
    divergence: score >= 40,
    score: clamp(score),
    type,
    priceChange: parseFloat(priceChange.toFixed(2)),
    oiChange:    parseFloat(oiChange.toFixed(2)),
    priceUp,
    oiUp,
    verdict: type === 'NEW_SHORTS' ? '⚠ Yeni shortlar açılıyor — düşüş baskısı' : type === 'WEAK_BULL' ? '⚠ Short covering — kalıcı değil' : type === 'CAPITULATION' ? '📉 Long teslimiyeti' : type === 'NEW_LONGS' ? '✓ Yeni longlar — güçlü alım' : '—',
    timestamp: Date.now(),
  };
}

// ─── CASCADE RISK ENGINE ──────────────────────────────────────────────────────
export function runCascadeRiskEngine({
  liquidationLevels = [],  // [{price, amount, side}]
  currentPrice = 0,
  volatility = 0,
  openInterest = 0,
}) {
  if (!liquidationLevels.length || !currentPrice) {
    return { score: 0, riskLevel: 'DÜŞÜK', cascadeRisk: false };
  }

  // Yakın likidasyon seviyeleri
  const closeRange = currentPrice * 0.03; // %3 içi
  const nearLiq = liquidationLevels.filter(l =>
    Math.abs(l.price - currentPrice) < closeRange
  );

  const totalNearLiqAmount = nearLiq.reduce((s, l) => s + (l.amount || 0), 0);
  const totalLiqAmount     = liquidationLevels.reduce((s, l) => s + (l.amount || 0), 0);
  const nearLiqRatio       = totalLiqAmount > 0 ? totalNearLiqAmount / totalLiqAmount : 0;

  // Domino etkisi: Bir likidasyon diğerini tetikler
  const sortedLiq = [...liquidationLevels].sort((a, b) => a.price - b.price);
  let cascadeChain = 0;
  for (let i = 1; i < sortedLiq.length; i++) {
    const gap = Math.abs(sortedLiq[i].price - sortedLiq[i-1].price) / currentPrice;
    if (gap < 0.005) cascadeChain++; // %0.5 içinde yan yana likidasyon
  }

  let score = 0;
  if (nearLiqRatio > 0.3) score += 40;
  if (nearLiqRatio > 0.5) score += 20;
  if (cascadeChain > 3)  score += 25;
  if (cascadeChain > 8)  score += 15;
  if (volatility > 0.04) score += 10; // Yüksek volatilite cascade'i hızlandırır
  if (nearLiq.length > 5) score += 10;

  const riskLevel = score >= 70 ? 'KRİTİK' : score >= 50 ? 'YÜKSEK' : score >= 30 ? 'ORTA' : 'DÜŞÜK';

  return {
    score: clamp(score),
    riskLevel,
    cascadeRisk: score >= 50,
    nearLiqCount: nearLiq.length,
    nearLiqRatio: parseFloat(nearLiqRatio.toFixed(3)),
    cascadeChain,
    totalNearLiqAmount: parseFloat(totalNearLiqAmount.toFixed(2)),
    verdict: score >= 70 ? '⛔ KASKAİ LİKİDASYON RİSKİ — BEKLE' : score >= 50 ? '⚠ Yüksek cascade riski' : score >= 30 ? 'Dikkat — likidasyon yakın' : '✓ Güvenli bölge',
    recommendation: score >= 60 ? 'Pozisyona girme — cascade zinciri başlayabilir' : '—',
    timestamp: Date.now(),
  };
}

// ─── DERIVATIVE TRAP ENGINE ───────────────────────────────────────────────────
export function runDerivativeTrapEngine({
  fundingExtreme = {},
  leverageBuildup = {},
  oiDivergence = {},
  cascadeRisk = {},
  unwind = {},
  currentPrice = 0,
  priceChange = 0,
}) {
  // Tüm türev sinyallerini birleştir — manipülasyon tuzağı var mı?

  const fundingScore   = fundingExtreme.score  || 0;
  const leverageScore  = leverageBuildup.score || 0;
  const divScore       = oiDivergence.score    || 0;
  const cascadeScore   = cascadeRisk.score     || 0;
  const unwindScore    = unwind.score          || 0;

  const totalScore = (
    fundingScore  * 0.20 +
    leverageScore * 0.25 +
    divScore      * 0.20 +
    cascadeScore  * 0.20 +
    unwindScore   * 0.15
  );

  const activeAlerts = [];
  if (fundingScore   >= 50) activeAlerts.push('AŞIRI FUNDING');
  if (leverageScore  >= 50) activeAlerts.push('KALDIRAC BİRİKİMİ');
  if (divScore       >= 40) activeAlerts.push('OI UYUMSUZLUK: ' + (oiDivergence.type || ''));
  if (cascadeScore   >= 50) activeAlerts.push('CASCADE RİSKİ');
  if (unwindScore    >= 40) activeAlerts.push('POZİSYON ÇÖZÜLÜYOR: ' + (unwind.type || ''));

  const isTrap = totalScore >= 55;
  const riskLevel = totalScore >= 75 ? 'KRİTİK' : totalScore >= 55 ? 'YÜKSEK' : totalScore >= 35 ? 'ORTA' : 'DÜŞÜK';

  return {
    isTrap,
    totalScore: parseFloat(totalScore.toFixed(1)),
    riskLevel,
    activeAlerts,
    scores: { fundingScore, leverageScore, divScore, cascadeScore, unwindScore },
    verdict: isTrap
      ? `⛔ TÜREV TUZAĞI TESPİT EDİLDİ — ${activeAlerts[0] || 'RİSKLİ'}`
      : totalScore >= 35
      ? `⚠ Türev baskısı var — dikkat`
      : `✓ Türev yapısı sağlıklı`,
    action: isTrap ? 'WAIT' : 'PASS',
    timestamp: Date.now(),
  };
}
