/**
 * GRID MASTER GLOBAL — MODULE DISTRIBUTION REGISTRY
 * ====================================================
 * 95 modül → 4 AI Konseyi'ne tam iş ayrımı ile dağıtılmıştır.
 * Her konsey kendi domain'inde UZMAN, diğer alanlara bakmaz.
 *
 * COUNCIL I   — ALPHA COUNCIL   (Teknik + Grafik + Pattern)     ~24 modül
 * COUNCIL II  — FLOW COUNCIL    (Likidite + Orderbook + Market)  ~24 modül
 * COUNCIL III — RISK COUNCIL    (Risk + Manipülasyon + Volatilite) ~24 modül
 * COUNCIL IV  — MACRO COUNCIL   (Kripto Uzmanlık + AI Fusion)   ~23 modül
 */

// ─── COUNCIL I: ALPHA — Teknik Analiz + Grafik + Pattern ─────────────────────
// Sorumlu: Grafik yapısı, trend, formasyon, teknik sinyaller
export const ALPHA_COUNCIL_MODULES = [
  // Teknik Analiz
  { id: 'RSI_STATE',         name: 'RSI State',          domain: 'technical', weight: 0.8 },
  { id: 'EMA_TREND',         name: 'EMA Trend',          domain: 'technical', weight: 0.9 },
  { id: 'KELTNER_CORE',      name: 'Keltner Core',       domain: 'technical', weight: 0.7 },
  { id: 'BOLLINGER_BAND',    name: 'Bollinger Band',     domain: 'technical', weight: 0.8 },
  { id: 'TREND_CLOUD',       name: 'Trend Cloud',        domain: 'technical', weight: 0.8 },
  { id: 'REVERSAL_TRIGGER',  name: 'Reversal Trigger',   domain: 'technical', weight: 0.9 },
  { id: 'SUPERTRIGGER',      name: 'SuperTrigger',       domain: 'technical', weight: 1.0 },
  { id: 'BREAKOUT_FILTER',   name: 'Breakout Filter',    domain: 'technical', weight: 0.9 },
  { id: 'TREND_ACCELERATION',name: 'Trend Acceleration', domain: 'technical', weight: 0.7 },
  { id: 'MEAN_REVERSION',    name: 'Mean Reversion',     domain: 'technical', weight: 0.7 },
  { id: 'PATTERN_MATRIX',    name: 'Pattern Matrix',     domain: 'technical', weight: 1.0 },
  { id: 'STEALTH_TREND',     name: 'Stealth Trend',      domain: 'technical', weight: 0.8 },
  // Grafik Modülü (yeni)
  { id: 'CHART_FORMATION',   name: 'Chart Formation',    domain: 'chart',     weight: 1.0 },
  { id: 'HISTORICAL_MATCH',  name: 'Historical Match',   domain: 'chart',     weight: 0.9 },
  { id: 'CANDLESTICK_ENGINE',name: 'Candlestick Engine', domain: 'chart',     weight: 0.8 },
  { id: 'SUPPORT_RESISTANCE',name: 'S/R Touch Engine',   domain: 'chart',     weight: 0.9 },
  { id: 'STRUCTURE_DETECT',  name: 'Structure Detector', domain: 'chart',     weight: 1.0 },
  { id: 'PULLBACK_ESTIM',    name: 'Pullback Estimator', domain: 'chart',     weight: 0.8 },
  // Çoklu zaman dilimi
  { id: 'MTF_PATTERN',       name: 'MTF Pattern',        domain: 'mtf',       weight: 0.9 },
  { id: 'MTF_CONFLUENCE',    name: 'MTF Confluence',     domain: 'mtf',       weight: 0.9 },
  // Arayüz
  { id: 'FINAL_VISUAL_CORE', name: 'Final Visual Core',  domain: 'ui',        weight: 0.5 },
  { id: 'NEON_UI_RENDER',    name: 'Neon UI Render',     domain: 'ui',        weight: 0.5 },
  { id: 'GRID_MASTER_GLOBAL',name: 'Grid Master Global', domain: 'core',      weight: 0.5 },
  { id: 'NEON_CORE_IFACE',   name: 'Neon Core Interface',domain: 'ui',        weight: 0.5 },
];

// ─── COUNCIL II: FLOW — Likidite + Orderbook + Piyasa Akışı ──────────────────
// Sorumlu: Para nereye akıyor, alıcı/satıcı baskısı, duvarlar
export const FLOW_COUNCIL_MODULES = [
  // Altyapı
  { id: 'GLOBAL_LIQ_FETCH',  name: 'Global Liquidity Fetching', domain: 'infra',  weight: 0.7 },
  { id: 'MULTI_EXCHANGE',    name: 'Multi Exchange Sync',        domain: 'infra',  weight: 0.8 },
  { id: 'WEBSOCKET_STREAM',  name: 'WebSocket Stream',           domain: 'infra',  weight: 0.7 },
  { id: 'ORDERBOOK_ENGINE',  name: 'Orderbook Engine',           domain: 'ob',     weight: 1.0 },
  { id: 'MARKET_STRUCT_ENG', name: 'Market Structure Engine',    domain: 'infra',  weight: 0.8 },
  // Likidite & Flow
  { id: 'LIQUIDITY_MAP',     name: 'Liquidity Map',              domain: 'liq',    weight: 1.0 },
  { id: 'DELTA_FLOW',        name: 'Delta Flow',                 domain: 'flow',   weight: 0.9 },
  { id: 'CVD_PULSE',         name: 'CVD Pulse',                  domain: 'flow',   weight: 0.9 },
  { id: 'BOOK_PRESSURE',     name: 'Book Pressure',              domain: 'ob',     weight: 0.9 },
  { id: 'BID_ASK_IMBALANCE', name: 'Bid/Ask Imbalance',          domain: 'ob',     weight: 0.8 },
  { id: 'OB_WALL_TRACKER',   name: 'Orderbook Wall Tracker',     domain: 'ob',     weight: 0.9 },
  { id: 'LIQ_VOID_ENGINE',   name: 'Liquidity Void Engine',      domain: 'liq',    weight: 0.8 },
  { id: 'CROSS_EXCHANGE_ARB',name: 'Cross Exchange Arbitrage',   domain: 'arb',    weight: 0.7 },
  // Piyasa İstihbarat
  { id: 'VOLUME_SPIKE',      name: 'Volume Spike',               domain: 'vol',    weight: 0.9 },
  { id: 'MOMENTUM_BIAS',     name: 'Momentum Bias',              domain: 'flow',   weight: 0.8 },
  { id: 'REGIME_DETECTOR',   name: 'Regime Detector',            domain: 'market', weight: 0.8 },
  { id: 'GRID_DRIVERS',      name: 'Grid Drivers',               domain: 'core',   weight: 0.9 },
  { id: 'WHALE_TRACE',       name: 'Whale Trace',                domain: 'whale',  weight: 0.9 },
  // Türev
  { id: 'FUNDING_BIAS',      name: 'Funding Bias',               domain: 'deriv',  weight: 0.8 },
  { id: 'OPEN_INTEREST',     name: 'Open Interest',              domain: 'deriv',  weight: 0.8 },
  { id: 'VOLATILITY_LOCK',   name: 'Volatility Lock',            domain: 'vol',    weight: 0.7 },
  { id: 'CORRELATION_MAP',   name: 'Correlation Map',            domain: 'market', weight: 0.7 },
  // Yeni modül
  { id: 'WHALE_INFLOW',      name: 'Whale Inflow/Outflow',       domain: 'whale',  weight: 0.9 },
  { id: 'SIGNAL_CONFIDENCE', name: 'Signal Confidence Score',    domain: 'ai',     weight: 0.8 },
];

// ─── COUNCIL III: RISK — Manipülasyon + Risk + Volatilite ────────────────────
// Sorumlu: Tuzak, manipülasyon, stop hunt, risk sınıflandırma
export const RISK_COUNCIL_MODULES = [
  // Manipülasyon
  { id: 'STOP_HUNT_RADAR',   name: 'Stop Hunt Radar',     domain: 'manip',  weight: 1.0 },
  { id: 'LIQUIDATION_WATCH', name: 'Liquidation Watch',   domain: 'manip',  weight: 1.0 },
  { id: 'FAKE_MOVE_FILTER',  name: 'Fake Move Filter',    domain: 'manip',  weight: 0.9 },
  { id: 'LIQ_TRAP_SCANNER',  name: 'Liq Trap Scanner',    domain: 'trap',   weight: 0.9 },
  { id: 'LIQ_SWEEP_DETECT',  name: 'Liq Sweep Detector',  domain: 'trap',   weight: 0.9 },
  { id: 'SPOOFING_DETECTOR', name: 'Spoofing Detector',   domain: 'manip',  weight: 0.8 },
  { id: 'MM_BEHAVIOR',       name: 'Market Maker Behavior',domain: 'manip',  weight: 0.9 },
  { id: 'HFT_PULSE',         name: 'HFT Pulse',           domain: 'manip',  weight: 0.7 },
  // Risk
  { id: 'RISK_CLASSIFIER',   name: 'Risk Classifier',     domain: 'risk',   weight: 1.0 },
  { id: 'RISK_HUB',          name: 'Risk Hub',            domain: 'risk',   weight: 1.0 },
  { id: 'VOL_REGIME',        name: 'Vol Regime',          domain: 'vol',    weight: 0.8 },
  { id: 'BTC_SHOCK_SENT',    name: 'BTC Shock Sentinel',  domain: 'risk',   weight: 0.9 },
  // İstihbarat
  { id: 'PUMP_EARLY_SCAN',   name: 'Pump Early Scan',     domain: 'intel',  weight: 0.9 },
  { id: 'DUMP_EARLY_SCAN',   name: 'Dump Early Scan',     domain: 'intel',  weight: 0.9 },
  { id: 'MEXC_PUMP_HUNTER',  name: 'MEXC Pump Hunter',    domain: 'intel',  weight: 0.8 },
  { id: 'NEW_LISTING_MON',   name: 'New Listing Monitor', domain: 'intel',  weight: 0.7 },
  { id: 'SOCIAL_HYPE_ENG',   name: 'Social Hype Engine',  domain: 'intel',  weight: 0.6 },
  // Olasılık
  { id: 'PROBABILITY_ENG',   name: 'Probability Engine',  domain: 'ai',     weight: 0.9 },
  { id: 'HIST_PATTERN_CMP',  name: 'Historical Pattern Compare', domain: 'ai', weight: 0.9 },
  // Scalp
  { id: 'SCALP_ENGINE',      name: 'Scalp Engine',        domain: 'scalp',  weight: 0.9 },
  { id: 'TOP200_SCANNER',    name: 'Top200 Scanner',      domain: 'scan',   weight: 0.8 },
  { id: 'ACCUMULATION_ENG',  name: 'Accumulation Engine', domain: 'scan',   weight: 0.8 },
  { id: 'GLOBAL_ALERT_ENG',  name: 'Global Alert Engine', domain: 'alert',  weight: 0.7 },
  { id: 'MACRO_FACTORS',     name: 'Macro Factors',       domain: 'macro',  weight: 0.8 },
];

// ─── COUNCIL IV: MACRO — Kripto Uzmanlık + AI Fusion ─────────────────────────
// Sorumlu: BTC dominans, alt sezon, sektör, on-chain, haber, AI sentez
export const MACRO_COUNCIL_MODULES = [
  // Kripto Uzmanlık
  { id: 'ALT_ROTATION',      name: 'Alt Rotation',          domain: 'crypto', weight: 0.8 },
  { id: 'BTC_REL_POWER',     name: 'BTC Relative Power',    domain: 'crypto', weight: 0.9 },
  { id: 'SECTOR_STRENGTH',   name: 'Sector Strength',       domain: 'crypto', weight: 0.8 },
  { id: 'BTC_DOMINANCE',     name: 'BTC Dominance Engine',  domain: 'crypto', weight: 0.9 },
  { id: 'STABLE_DOM',        name: 'Stablecoin Dominance',  domain: 'crypto', weight: 0.8 },
  { id: 'ALT_SEASON_ENG',    name: 'Alt Season Engine',     domain: 'crypto', weight: 0.8 },
  { id: 'CRYPTO_SECTOR',     name: 'Crypto Sector Analysis',domain: 'crypto', weight: 0.7 },
  { id: 'ONCHAIN_ANALYSIS',  name: 'Onchain Analysis Engine',domain:'chain',  weight: 0.9 },
  { id: 'STABLE_FLOW_ENG',   name: 'Stablecoin Flow Engine',domain: 'chain',  weight: 0.8 },
  { id: 'TOKEN_DIST_ANLYZ',  name: 'Token Distribution Analyzer',domain:'chain',weight:0.7 },
  // AI Karar
  { id: 'SIGNAL_FUSION',     name: 'Signal Fusion',         domain: 'ai',     weight: 1.0 },
  { id: 'AI_DECISION_LAYER', name: 'AI Decision Layer',     domain: 'ai',     weight: 1.0 },
  { id: 'TECHNICAL_COUNCIL', name: 'Technical Council',     domain: 'ai',     weight: 0.9 },
  { id: 'FLOW_COUNCIL_MOD',  name: 'Flow Council',          domain: 'ai',     weight: 0.9 },
  { id: 'NEWS_COUNCIL',      name: 'News Council',          domain: 'ai',     weight: 0.8 },
  { id: 'RISK_COUNCIL_MOD',  name: 'Risk Council',          domain: 'ai',     weight: 0.9 },
  { id: 'ASSET_SPEC_CNCL',   name: 'Asset Specialist Council',domain:'ai',    weight: 0.9 },
  { id: 'FINAL_COUNCIL_OUT', name: 'Final Council Output',  domain: 'ai',     weight: 1.0 },
  { id: 'MARKET_STATE',      name: 'Market State',          domain: 'ai',     weight: 0.9 },
  { id: 'COUNCIL_OUTPUT',    name: 'Council Output',        domain: 'ai',     weight: 0.9 },
  // Haber + Haberler
  { id: 'NEWS_INTEL_ENG',    name: 'News Intelligence Engine',domain:'news',  weight: 0.8 },
  { id: 'FEAR_GREED',        name: 'Fear & Greed Engine',   domain: 'sentiment',weight:0.9},
  { id: 'MULTI_ASSET_ENG',   name: 'Multi Asset Engine',    domain: 'multi',  weight: 0.7 },
];

// ─── MODULE REGISTRY ──────────────────────────────────────────────────────────
export const ALL_MODULES = {
  ALPHA: ALPHA_COUNCIL_MODULES,
  FLOW:  FLOW_COUNCIL_MODULES,
  RISK:  RISK_COUNCIL_MODULES,
  MACRO: MACRO_COUNCIL_MODULES,
};

export const COUNCIL_META = {
  ALPHA: {
    id: 'ALPHA',
    name: 'Alpha Council',
    subtitle: 'Teknik · Grafik · Pattern',
    color: '#00aaff',
    bgColor: '#00aaff08',
    icon: '◈',
    focus: 'Grafik formasyonları, teknik sinyaller ve tarihsel pattern eşleşmesi',
    moduleCount: ALPHA_COUNCIL_MODULES.length,
  },
  FLOW: {
    id: 'FLOW',
    name: 'Flow Council',
    subtitle: 'Likidite · Orderbook · Hacim',
    color: '#00ff88',
    bgColor: '#00ff8808',
    icon: '⟁',
    focus: 'Orderbook baskısı, para akışı, balina hareketi ve türev pozisyonlar',
    moduleCount: FLOW_COUNCIL_MODULES.length,
  },
  RISK: {
    id: 'RISK',
    name: 'Risk Council',
    subtitle: 'Manipülasyon · Tuzak · Volatilite',
    color: '#ff3366',
    bgColor: '#ff336608',
    icon: '⬡',
    focus: 'Stop hunt, sahte kırılım, likidasyon bölgeleri ve pump/dump tespiti',
    moduleCount: RISK_COUNCIL_MODULES.length,
  },
  MACRO: {
    id: 'MACRO',
    name: 'Macro Council',
    subtitle: 'BTC Dom. · Sektör · AI Sentez',
    color: '#ffcc00',
    bgColor: '#ffcc0008',
    icon: '⎈',
    focus: 'BTC dominansı, alt sezon, on-chain akışı ve AI karar sentezi',
    moduleCount: MACRO_COUNCIL_MODULES.length,
  },
};
