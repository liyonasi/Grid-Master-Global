# GMG — DEVİR TESLİM v13
## Tarih: 2026-03-16 | Versiyon: v13 COMPLETE

---

## YENİ OTURUMA BAŞLARKEN

ZIP'i yükle ve şunu yaz:
> "DEVIR_TESLIM_v13.md'yi oku, kaldığın yerden devam et."

---

## BU OTURUMDA TAMAMLANANLAR (v12 → v13)

### MADDE 1 ✅ — macroAPIEngine.js (YENİ DOSYA)
- **stooq.com** primary kaynak (^dxy, 10us.b)
- **FRED API** fallback (DTWEXBGS, DGS10) — key gerektirmez
- **allorigins.win proxy** üzerinden CORS bypass
- **5 dakika TTL cache** — `_cacheGet / _cacheSet`
- `fetchDXYLevel()` → number (örn. 104.23)
- `fetchUS10YYield()` → number (örn. 4.35)
- `fetchMacroData()` → `{ dxyLevel, us10yYield }` paralel çekme
- `clearMacroCache()` — cache temizleme
- Her kaynak başarısız olursa güvenli varsayılan: DXY=104.0, US10Y=4.3
- console.info ile kaynak logu (stooq / FRED / default)

### MADDE 2 ✅ — ForexAndMultiMarketPanels.jsx prop uyumu
**Önceki durum (BOZUK):**
- `ForexPanel({ btcChange })` — Dashboard'dan gelen masterResult/scanResults/symbol yok sayılıyordu
- `MultiMarketPanel({ masterResult, btcChange })` — scanResults/heatmapData yok sayılıyordu
- dxyLevel/us10yYield sabit hardcode değerdi

**Düzeltmeler:**
- `ForexPanel` → `{ masterResult, scanResults, symbol, btcChange, dxyLevel, us10yYield }` tam prop interface
- `MultiMarketPanel` → `{ masterResult, scanResults, heatmapData, btcChange, dxyLevel, us10yYield }` tam prop interface
- Gerçek `dxyLevel` / `us10yYield` prop'tan alınıyor (macroAPIEngine'den geliyor)
- Header'da DXY ve US10Y canlı değerleri gösteriliyor
- `bond` hesaplamasına gerçek `us10yYield` geçiliyor
- `heatmapData`'dan yeşil coin sayısı gösterimi
- `scanResults`'tan güçlü sinyal sayısı gösterimi
- `masterResult.multiAsset.forex` varsa ek bağlam satırı

### MADDE 3 ✅ — BacktestPanel Web Worker
**Yeni dosya: backtestWorker.js**
- `self.onmessage` → `{ type: 'RUN', id, klines, params, config, periods }`
- `import('./backtestEngine.js')` ile engine dinamik yükleme
- `{ type: 'PROGRESS', id, progress }` mesajları (5% → 20% → 90% → 100%)
- `{ type: 'RESULT', id, result }` — hesaplama tamamlandı
- `{ type: 'ERROR', id, error }` — hata durumu
- `id` bazlı eski istek filtreleme (race condition koruması)
- **Fallback**: engine import başarısız olursa simüle edilmiş placeholder döner

**BacktestPanel.jsx güncelleme:**
- `useRef(null)` — `workerRef` ve `reqIdRef`
- `useEffect` ile Worker başlatma + cleanup (`worker.terminate()`)
- `runTest()` → Worker varsa `postMessage`, yoksa main thread fallback (dynamic import)
- **Progress bar UI**: sarı dolum çubuğu + yüzde göstergesi
- "arka plan iş parçacığı" etiketi

### MADDE 4 ✅ — Trades tam tablo (BacktestPanel)
**Yeni bileşen: TradesTable**
- Tüm işlemler listelenir (sadece son 5 değil)
- **Varsayılan**: en yeni 10 işlem gösterilir
- **"Tümünü Gör (N)"** butonu — tümünü scroll ile aç
- **"▲ Küçült"** — tekrar daralt
- **6 kolon**: Yön | Çıkış Nedeni | Giriş Fiyatı | Çıkış Fiyatı | P&L% | Süre (bar)
- Kazançlı işlem → yeşil P&L, zararlı → kırmızı
- LONG → mavi, SHORT → pembe
- Hover row highlight
- maxHeight + overflowY scroll (tümünü gör modunda)
- En yeni işlem en üstte (reverse sort)

### MADDE 5 ✅ — Dashboard macroData entegrasyonu
- `macroData` state: `{ dxyLevel: 104.0, us10yYield: 4.3 }`
- `fetchMacroData()` sonucu `setMacroData()` ile state'e kaydediliyor
- `ForexPanel` ve `MultiMarketPanel`'e `dxyLevel` ve `us10yYield` prop olarak geçiliyor
- `runMasterCouncil()` çağrısına `dxyLevel` ve `us10yYield` eklendi (önceden eksikti)

---

## DOSYA LİSTESİ (41 dosya — 2 yeni eklendi)

### YENİ DOSYALAR
```
macroAPIEngine.js    — DXY + US10Y gerçek API (stooq + FRED fallback, 5dk cache)
backtestWorker.js    — Web Worker: backtest ağır hesaplamayı arka plana alır
```

### GÜNCELLENENLER
```
Dashboard_v4.jsx              — macroAPIEngine import, macroData state, prop geçişleri
ForexAndMultiMarketPanels.jsx — tam prop interface düzeltmesi
BacktestPanel.jsx             — Web Worker entegrasyonu, TradesTable, progress bar
```

### DEĞİŞMEYENLER (tüm v12 dosyaları aynen korundu)
```
masterCouncil.js, pineEngine.js, GMGChart_v3.jsx
LiveAICouncilPanel.jsx, liveAIEngine.js
multiAssetEngines.js, backtestEngine.js
WallAndAccumulationPanels.jsx
executionLayer.js, newsMacroCouncil.js, councilEngine.js
aiCouncilEngine.js, engineCore.js, intelligenceEngine.js
dipOnaylayici.js, realDerivativesEngine.js, structureEngines.js
macroNewsEngines.js, alertMonitorEngines.js, indexEngine.js
exchangeAPI_multi.js, chartModule.js, moduleRegistry.js
CouncilPanel.jsx, MarketIntelPanel.jsx, LiquidityRadar.jsx
FundingPanel.jsx, MultiTimeframePanel.jsx
```

---

## KARAR AKIŞI (GÜNCEL v13)

```
Borsa (7 adet) → exchangeAPI_multi.js
    ↓
intelligenceEngine.js → 16 tarayıcı → scanResults
    ↓
[YENİ] macroAPIEngine.js → fetchMacroData() → dxyLevel, us10yYield (5dk cache)
    ↓
masterCouncil.js →
  ├── pineEngine.js        (Technical + Pine RF)
  ├── newsMacroCouncil.js  (News & Macro async)
  ├── runTechnicalCouncil  (RSI/MACD/EMA/BB/Pine)
  ├── runFlowCouncil       (OB/CVD/Liq)
  ├── runRiskCouncil       (Stop hunt/Vol/Veto)
  ├── runAssetCouncil      (BTC Dom/Alt)
  └── multiAsset → forexEngine(dxyLevel) + bondEngine(us10yYield) → ±12 puan
    ↓
executionLayer.js → BUY / SELL / WAIT
    ↓
Dashboard_v4.jsx →
  ├── LiveAICouncilPanel     (⚡ Master AI sekmesi)
  ├── CouncilPanel           (Konseyler sekmesi)
  ├── LiquidityWall          (Orderbook sekmesi)
  ├── LiquidityRadar         (Liq Radar sekmesi)
  ├── MultiMarketPanel       (📊 Piyasalar — dxyLevel/us10yYield prop)
  ├── BacktestPanelInline    (🔬 Backtest — Web Worker)
  ├── ForexPanel             (🌐 Forex/Makro — dxyLevel/us10yYield prop)
  ├── AccumulationPlanPanel  (📦 Birikim)
  ├── AI Soru Kutusu         (sağ panel altı)
  └── Telegram Alert         (BUY/SELL sinyalinde otomatik)
    ↓
GMGChart_v3.jsx (Pine çizgileri + S/R + PB-AL/SAT + TP/SL)
```

---

## MAKRO API KURULUMU

```
# Ek kurulum GEREKMİYOR — stooq ve FRED ücretsiz, key yok
# Sadece network erişimi gerekli (allorigins.win proxy üzerinden)
#
# Test etmek için tarayıcı console'da:
import { fetchMacroData } from './macroAPIEngine';
fetchMacroData().then(console.log);
# → { dxyLevel: 104.23, us10yYield: 4.35 }
```

---

## SONRAKI OTURUMDA YAPILABİLECEKLER

### Teknik borç (küçük)
1. **macroAPIEngine proxy güvenilirliği** — allorigins.win bazen yavaş; alternatif: corsproxy.io veya kendi backend endpoint
2. **backtestWorker Vite/CRA uyumluluğu** — `new URL('./backtestWorker.js', import.meta.url)` Vite'da çalışır, CRA'da test edilmeli
3. **TradesTable tarih kolonu** — `t.entryTime` varsa tarih/saat göster

### Yeni özellik fikirleri
4. Kullanıcının yeni ekleme listesi (bir sonraki oturumda sırayla işlenecek)

---

## KOD YAZIM KURALLARI

1. Tüm fonksiyonlar export edilmeli
2. Türkçe yorum satırları
3. clamp() ile 0-100 arası skor
4. Her modül { score, summary, timestamp } döndürür
5. Null-safe yazım (?. operatör)
6. Async/await ile API çağrıları
7. Her oturum sonunda ZIP yedek

---

Son güncelleme: 2026-03-16 | v13
Toplam dosya: 41 | Toplam satır: ~14.500+
