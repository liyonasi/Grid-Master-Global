/**
 * newsAdvancedEngine.js — GMG v16
 * Gelişmiş Haber & Sentiment Motorları:
 *   158. News Cleaner Engine
 *   159. Deduplication Engine
 *   160. Event Classifier
 *   161. Fake News Filter
 *   163. Asset Impact Engine
 *   164. Time Horizon Engine
 *   167. Panic News Engine
 *   168. Confusion Filter
 */

const clamp = (v, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, v));

// ─── NEWS CLEANER ENGINE ──────────────────────────────────────────────────────
export function runNewsCleanerEngine(rawNews = []) {
  const SPAM_KEYWORDS = [
    'click here', 'sign up now', 'limited offer', 'advertisement',
    'sponsored', 'affiliate', 'earn money fast', 'guaranteed profit',
    '100x', 'moon soon', 'lambo', 'get rich',
  ];
  const LOW_QUALITY_DOMAINS = ['spam', 'clickbait', 'fake'];

  return rawNews.filter(news => {
    if (!news || !news.title) return false;
    const titleLower = news.title.toLowerCase();
    const bodyLower  = (news.body || '').toLowerCase();

    // Spam keyword filtresi
    if (SPAM_KEYWORDS.some(kw => titleLower.includes(kw) || bodyLower.includes(kw))) return false;

    // Çok kısa haberler
    if (news.title.length < 15) return false;

    // Kalitesiz domain
    if (LOW_QUALITY_DOMAINS.some(d => (news.source || '').toLowerCase().includes(d))) return false;

    // Çok eski haberler (6 saatten eski)
    if (news.publishedAt && Date.now() - news.publishedAt > 6 * 60 * 60 * 1000) return false;

    return true;
  }).map(news => ({
    ...news,
    cleanTitle: news.title.replace(/[^a-zA-Z0-9\s.,!?'-ğüşöçıİĞÜŞÖÇ]/g, ' ').trim(),
    wordCount:  (news.body || news.title).split(/\s+/).length,
    hasNumbers: /\d+/.test(news.title),
  }));
}

// ─── DEDUPLICATION ENGINE ─────────────────────────────────────────────────────
const _seenTitles = new Map();

export function runDeduplicationEngine(news = [], ttlMs = 3600000) {
  const unique = [];
  const now = Date.now();

  // Eski hash'leri temizle
  for (const [k, v] of _seenTitles) {
    if (now - v > ttlMs) _seenTitles.delete(k);
  }

  for (const item of news) {
    if (!item?.title) continue;

    // Basit fingerprint: ilk 80 karakter lowercase + kaynak
    const fp = (item.title.toLowerCase().slice(0, 80) + (item.source || '')).replace(/\s+/g, '');

    // Benzer haber var mı? (Levenshtein yerine prefix kontrolü)
    const existingKeys = [..._seenTitles.keys()];
    const isDuplicate  = existingKeys.some(k => {
      // İlk 50 karakter aynıysa duplicate say
      return k.slice(0, 50) === fp.slice(0, 50);
    });

    if (!isDuplicate) {
      _seenTitles.set(fp, now);
      unique.push(item);
    }
  }

  return {
    original: news.length,
    unique: unique.length,
    removed: news.length - unique.length,
    news: unique,
  };
}

// ─── EVENT CLASSIFIER ─────────────────────────────────────────────────────────
const EVENT_RULES = [
  { type: 'REGULATORY', keywords: ['sec', 'regul', 'ban', 'law', 'legal', 'government', 'court', 'lawsuit'], impact: 'HIGH', sentiment: -0.6 },
  { type: 'ETF_FLOW',   keywords: ['etf', 'blackrock', 'fidelity', 'grayscale', 'spot etf', 'inflow', 'outflow'], impact: 'HIGH', sentiment: 0.7 },
  { type: 'HACK',       keywords: ['hack', 'exploit', 'breach', 'stolen', 'vulnerability', 'attack'], impact: 'HIGH', sentiment: -0.8 },
  { type: 'PARTNERSHIP',keywords: ['partner', 'collaboration', 'integration', 'deal', 'agreement'], impact: 'MEDIUM', sentiment: 0.4 },
  { type: 'MACRO',      keywords: ['fed', 'interest rate', 'inflation', 'gdp', 'recession', 'ecb', 'fomc'], impact: 'HIGH', sentiment: 0 },
  { type: 'LISTING',    keywords: ['listing', 'listed on', 'adds', 'now trading'], impact: 'MEDIUM', sentiment: 0.5 },
  { type: 'WHALE',      keywords: ['whale', 'large transfer', 'moved', 'billion', 'million btc'], impact: 'MEDIUM', sentiment: 0 },
  { type: 'TECHNICAL',  keywords: ['halving', 'upgrade', 'fork', 'protocol', 'network upgrade'], impact: 'HIGH', sentiment: 0.3 },
  { type: 'FUD',        keywords: ['crash', 'bear', 'dump', 'sell off', 'panic', 'fear'], impact: 'MEDIUM', sentiment: -0.5 },
  { type: 'HYPE',       keywords: ['bull', 'ath', 'all time high', 'moon', 'rally', 'surge'], impact: 'MEDIUM', sentiment: 0.5 },
];

export function runEventClassifier(news = []) {
  return news.map(item => {
    const text = (item.title + ' ' + (item.body || '')).toLowerCase();
    const matches = EVENT_RULES.filter(rule => rule.keywords.some(kw => text.includes(kw)));

    const primaryEvent = matches.sort((a, b) => {
      const impactScore = { HIGH: 3, MEDIUM: 2, LOW: 1 };
      return (impactScore[b.impact] || 0) - (impactScore[a.impact] || 0);
    })[0];

    return {
      ...item,
      eventType:   primaryEvent?.type    || 'GENERAL',
      eventImpact: primaryEvent?.impact  || 'LOW',
      sentiment:   primaryEvent?.sentiment ?? 0,
      allTypes:    matches.map(m => m.type),
    };
  });
}

// ─── FAKE NEWS FILTER ─────────────────────────────────────────────────────────
const TRUSTED_SOURCES = [
  'coindesk', 'cointelegraph', 'theblock', 'decrypt', 'bloomberg',
  'reuters', 'ft.com', 'wsj', 'cnbc', 'forbes', 'binance', 'bybit',
];
const FAKE_PATTERNS = [
  /\d+x\s+gain/i, /guaranteed\s+profit/i, /\$\d+k\s+in\s+\d+\s+days/i,
  /secret\s+(method|strategy)/i, /insiders\s+(say|reveal)/i,
  /anonymous\s+source/i,
];

export function runFakeNewsFilter(news = []) {
  return news.map(item => {
    if (!item?.title) return { ...item, fakeScore: 0, trusted: false };

    let fakeScore = 0;
    const title = item.title;
    const source = (item.source || '').toLowerCase();

    // Güvenilir kaynak mı?
    const isTrusted = TRUSTED_SOURCES.some(s => source.includes(s));
    if (!isTrusted) fakeScore += 15;

    // Sahte haber kalıpları
    FAKE_PATTERNS.forEach(p => { if (p.test(title)) fakeScore += 25; });

    // Aşırı büyük iddialar
    if (/\d{3,}x/i.test(title)) fakeScore += 30;
    if (/\$\d+\s*(million|billion)\s+profit/i.test(title)) fakeScore += 20;

    // Çok fazla büyük harf
    const upperRatio = (title.match(/[A-Z]/g) || []).length / title.length;
    if (upperRatio > 0.5) fakeScore += 15;

    return {
      ...item,
      fakeScore: clamp(fakeScore),
      trusted:   isTrusted,
      filtered:  fakeScore >= 50,
    };
  }).filter(item => !item.filtered);
}

// ─── ASSET IMPACT ENGINE ──────────────────────────────────────────────────────
const ASSET_KEYWORDS = {
  BTC:    ['bitcoin', 'btc', 'satoshi', 'lightning network', 'bitcoin etf'],
  ETH:    ['ethereum', 'eth', 'vitalik', 'solidity', 'erc20', 'defi'],
  BNB:    ['binance', 'bnb', 'bsc', 'cz'],
  SOL:    ['solana', 'sol'],
  XRP:    ['ripple', 'xrp', 'sec ripple'],
  GLOBAL: ['crypto', 'blockchain', 'defi', 'web3', 'nft', 'market'],
  FOREX:  ['dollar', 'euro', 'yen', 'fed', 'ecb', 'currency'],
  GOLD:   ['gold', 'silver', 'precious metal', 'safe haven'],
  OIL:    ['oil', 'opec', 'crude', 'energy'],
  INDEX:  ['sp500', 'nasdaq', 'dow', 'stock market', 'equity'],
};

export function runAssetImpactEngine(news = []) {
  return news.map(item => {
    const text = (item.title + ' ' + (item.body || '')).toLowerCase();
    const impacts = {};

    Object.entries(ASSET_KEYWORDS).forEach(([asset, keywords]) => {
      const matchCount = keywords.filter(kw => text.includes(kw)).length;
      if (matchCount > 0) {
        impacts[asset] = {
          relevance: Math.min(matchCount / keywords.length * 100, 100),
          sentiment: item.sentiment || 0,
        };
      }
    });

    const primaryAsset = Object.entries(impacts).sort((a, b) => b[1].relevance - a[1].relevance)[0];

    return {
      ...item,
      impacts,
      primaryAsset: primaryAsset?.[0] || 'GLOBAL',
      primaryRelevance: parseFloat((primaryAsset?.[1]?.relevance || 0).toFixed(1)),
    };
  });
}

// ─── TIME HORIZON ENGINE ──────────────────────────────────────────────────────
export function runTimeHorizonEngine(news = []) {
  const SHORT_TERM  = ['today', 'hours', 'minutes', 'breaking', 'just', 'now', 'live', 'instant'];
  const MEDIUM_TERM = ['week', 'month', 'quarterly', 'earnings', 'roadmap'];
  const LONG_TERM   = ['year', 'future', 'vision', '2025', '2026', '2030', 'decade', 'long term'];

  return news.map(item => {
    const text = (item.title + ' ' + (item.body || '')).toLowerCase();
    const isShort  = SHORT_TERM.some(kw => text.includes(kw));
    const isMedium = MEDIUM_TERM.some(kw => text.includes(kw));
    const isLong   = LONG_TERM.some(kw => text.includes(kw));
    const horizon  = isShort ? 'SHORT' : isMedium ? 'MEDIUM' : isLong ? 'LONG' : 'SHORT';

    return {
      ...item,
      timeHorizon: horizon,
      tradingRelevance: horizon === 'SHORT' ? 'HIGH' : horizon === 'MEDIUM' ? 'MEDIUM' : 'LOW',
    };
  });
}

// ─── PANIC NEWS ENGINE ────────────────────────────────────────────────────────
const PANIC_KEYWORDS = [
  'crash', 'collapse', 'plunge', 'dump', 'sell everything', 'panic sell',
  'catastrophe', 'disaster', 'crisis', 'emergency', 'death spiral',
  'hack', 'stolen', 'rug pull', 'scam', 'fraud', 'ponzi',
  'ban', 'illegal', 'shutdown', 'arrest',
];
const CALM_KEYWORDS = [
  'recovery', 'bounce', 'support', 'strong', 'bullish', 'accumulation',
  'institution', 'adoption', 'partnership', 'upgrade',
];

export function runPanicNewsEngine(news = []) {
  let panicCount = 0, calmCount = 0, panicScore = 0;
  const panicNews = [], calmNews = [];

  news.forEach(item => {
    const text = (item.title + ' ' + (item.body || '')).toLowerCase();
    const panicMatches = PANIC_KEYWORDS.filter(kw => text.includes(kw)).length;
    const calmMatches  = CALM_KEYWORDS.filter(kw => text.includes(kw)).length;

    if (panicMatches > 0) { panicCount++; panicNews.push({ ...item, panicMatches }); }
    if (calmMatches > 0)  { calmCount++;  calmNews.push(item); }
    panicScore += panicMatches * 10 - calmMatches * 5;
  });

  const normalizedPanic = news.length > 0 ? clamp(panicScore / news.length * 5) : 0;

  return {
    panicScore: parseFloat(normalizedPanic.toFixed(1)),
    isPanic:    normalizedPanic >= 50,
    panicCount,
    calmCount,
    panicRatio: news.length > 0 ? parseFloat((panicCount / news.length).toFixed(3)) : 0,
    topPanicNews: panicNews.slice(0, 3).map(n => n.title),
    verdict: normalizedPanic >= 70
      ? '⛔ PANİK HABERLER HAKİM — BEKLEME MOD'
      : normalizedPanic >= 40
      ? '⚠ Negatif haber akışı var'
      : '✓ Haber ortamı sakin',
    recommendation: normalizedPanic >= 60 ? 'Haberler sakinleşene kadar bekle' : '—',
    timestamp: Date.now(),
  };
}

// ─── CONFUSION FILTER ─────────────────────────────────────────────────────────
export function runConfusionFilter(news = []) {
  // Çelişkili haberleri tespit et — hem bullish hem bearish haberler varsa sinyal güvenilmez
  const bullish = news.filter(n => (n.sentiment || 0) > 0.3);
  const bearish = news.filter(n => (n.sentiment || 0) < -0.3);

  const conflictRatio = Math.min(bullish.length, bearish.length) / Math.max(news.length, 1);
  const isConfused = conflictRatio > 0.2 && bullish.length > 2 && bearish.length > 2;

  const avgSentiment = news.length
    ? news.reduce((s, n) => s + (n.sentiment || 0), 0) / news.length
    : 0;

  return {
    isConfused,
    conflictRatio: parseFloat(conflictRatio.toFixed(3)),
    bullishCount: bullish.length,
    bearishCount: bearish.length,
    avgSentiment: parseFloat(avgSentiment.toFixed(3)),
    reliability: isConfused ? 'DÜŞÜK' : 'YÜKSEK',
    verdict: isConfused
      ? `⚠ ÇELİŞKİLİ HABERLER — Sinyal güvenilirliği düşük (${bullish.length} bull, ${bearish.length} bear)`
      : avgSentiment > 0.2
      ? `✅ Haberler genel olarak pozitif`
      : avgSentiment < -0.2
      ? `⚠ Haberler genel olarak negatif`
      : `Nötr haber ortamı`,
    recommendation: isConfused ? 'Haber konfüzyonu var — diğer sinyallere ağırlık ver' : '—',
    timestamp: Date.now(),
  };
}

// ─── NEWS INTELLIGENCE ENGINE (tüm modülleri koordine eder) ──────────────────
export function runNewsIntelligenceEngine(rawNews = []) {
  // Pipeline: clean → dedup → classify → fake filter → asset impact → time horizon → panic → confusion
  const cleaned     = runNewsCleanerEngine(rawNews);
  const deduped     = runDeduplicationEngine(cleaned).news;
  const classified  = runEventClassifier(deduped);
  const filtered    = runFakeNewsFilter(classified);
  const withImpact  = runAssetImpactEngine(filtered);
  const withHorizon = runTimeHorizonEngine(withImpact);
  const panicResult = runPanicNewsEngine(withHorizon);
  const confResult  = runConfusionFilter(withHorizon);

  return {
    processedNews: withHorizon,
    stats: {
      raw:       rawNews.length,
      cleaned:   cleaned.length,
      deduped:   deduped.length,
      filtered:  filtered.length,
    },
    panic:     panicResult,
    confusion: confResult,
    summary: {
      totalRelevant: withHorizon.length,
      shortTerm: withHorizon.filter(n => n.timeHorizon === 'SHORT').length,
      highImpact: withHorizon.filter(n => n.eventImpact === 'HIGH').length,
      avgSentiment: withHorizon.length
        ? parseFloat((withHorizon.reduce((s, n) => s + (n.sentiment || 0), 0) / withHorizon.length).toFixed(3))
        : 0,
    },
    timestamp: Date.now(),
  };
}
