import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Zap, Shield, Layers, Waves, ChevronDown, ChevronUp, CheckCircle } from 'lucide-react';

// ─── COUNCIL ICON MAP ─────────────────────────────────────────────────────────
const COUNCIL_META = {
  MOMENTUM:  { Icon: Zap,    label: 'Momentum', color: '#00aaff' },
  RISK:      { Icon: Shield, label: 'Risk',     color: '#ff3366' },
  STRUCTURE: { Icon: Layers, label: 'Yapı',     color: '#00ff88' },
  FLOW:      { Icon: Waves,  label: 'Akış',     color: '#ffcc00' },
};

// ─── SCORE RING ───────────────────────────────────────────────────────────────
function ScoreRing({ score, color, size = 48 }) {
  const r   = (size - 8) / 2;
  const circ = 2 * Math.PI * r;
  const dash = circ * (score / 100);

  return (
    <div className="relative flex-shrink-0" style={{ width: size, height: size }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="-rotate-90">
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="#1a1a2e" strokeWidth="4" />
        <motion.circle
          cx={size/2} cy={size/2} r={r} fill="none"
          stroke={color} strokeWidth="4" strokeLinecap="round"
          strokeDasharray={circ}
          initial={{ strokeDashoffset: circ }}
          animate={{ strokeDashoffset: circ - dash }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
        />
      </svg>
      <div
        className="absolute inset-0 flex items-center justify-center text-[11px] font-black font-mono"
        style={{ color }}
      >
        {score}
      </div>
    </div>
  );
}

// ─── SINGLE COUNCIL CARD ─────────────────────────────────────────────────────
function CouncilCard({ council, isExpanded, onToggle }) {
  const meta = COUNCIL_META[council.id] || { Icon: Zap, label: council.id, color: '#6b7280' };
  const { Icon } = meta;

  return (
    <motion.div
      layout
      className="rounded-lg overflow-hidden"
      style={{ background: '#0a0a0f', border: `1px solid ${isExpanded ? council.color + '40' : '#1a1a2e'}` }}
    >
      {/* Card header */}
      <button
        onClick={onToggle}
        className="w-full flex items-center gap-3 p-3 hover:bg-[#ffffff05] transition-colors"
      >
        <ScoreRing score={council.score} color={council.color} size={44} />

        <div className="flex-1 min-w-0 text-left">
          <div className="flex items-center gap-1.5 mb-0.5">
            <Icon style={{ width: 10, height: 10, color: council.color }} />
            <span className="text-[9px] font-mono font-bold uppercase tracking-wider" style={{ color: council.color }}>
              {meta.label} Konseyi
            </span>
          </div>
          <div className="text-sm font-black font-mono" style={{ color: council.color }}>
            {council.action}
          </div>
          <div className="text-[9px] font-mono text-gray-600 truncate mt-0.5">
            {council.verdict}
          </div>
        </div>

        <div className="flex flex-col items-end gap-1 flex-shrink-0">
          <span
            className="text-[8px] font-mono px-1.5 py-0.5 rounded"
            style={{ background: `${council.color}15`, color: council.color, border: `1px solid ${council.color}30` }}
          >
            {council.confidence}%
          </span>
          {isExpanded
            ? <ChevronUp style={{ width: 12, height: 12, color: '#4b5563' }} />
            : <ChevronDown style={{ width: 12, height: 12, color: '#4b5563' }} />
          }
        </div>
      </button>

      {/* Expanded detail */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="px-3 pb-3 space-y-2 border-t border-[#1a1a2e]">
              {/* Signal breakdown */}
              <div className="pt-2 space-y-1.5">
                <div className="text-[8px] font-mono text-gray-600 uppercase tracking-widest mb-1">
                  Sinyal Detayı
                </div>
                {council.signals?.map((sig, i) => (
                  <div key={i} className="space-y-0.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[9px] font-mono text-gray-500">{sig.label}</span>
                      <span className="text-[9px] font-mono font-bold" style={{
                        color: sig.score >= 60 ? '#00ff88' : sig.score <= 40 ? '#ff3366' : '#ffcc00'
                      }}>
                        {Math.round(sig.score)}
                      </span>
                    </div>
                    <div className="relative h-1 bg-[#1a1a2e] rounded-full overflow-hidden">
                      <motion.div
                        className="absolute left-0 top-0 h-full rounded-full"
                        style={{
                          background: sig.score >= 60 ? '#00ff88' : sig.score <= 40 ? '#ff3366' : '#ffcc00',
                          width: `${sig.score}%`,
                        }}
                        initial={{ width: 0 }}
                        animate={{ width: `${sig.score}%` }}
                        transition={{ duration: 0.4, delay: i * 0.05 }}
                      />
                    </div>
                    <div className="text-[8px] font-mono text-gray-700">{sig.detail}</div>
                  </div>
                ))}
              </div>

              {/* Highlights: risk council special */}
              {council.id === 'RISK' && council.riskLevel && (
                <div
                  className="rounded px-2 py-1.5 flex items-center justify-between"
                  style={{
                    background: `${council.color}10`,
                    border: `1px solid ${council.color}25`,
                  }}
                >
                  <span className="text-[9px] font-mono text-gray-500">Risk Seviyesi</span>
                  <span className="text-[10px] font-mono font-bold" style={{ color: council.color }}>
                    {council.riskLevel}
                  </span>
                </div>
              )}

              {/* Top highlighted coins */}
              {council.highlights && Object.entries(council.highlights).map(([key, coins]) => {
                if (!Array.isArray(coins) || coins.length === 0) return null;
                const labels = {
                  topPumps: 'Pump', topDumps: 'Dump', stealthRising: 'Gizli Yükseliş',
                  stealthFalling: 'Gizli Düşüş', longReady: 'Long Hazır', shortReady: 'Short Hazır',
                  explosionReady: 'Patlama', scalpLongs: 'Scalp L', scalpShorts: 'Scalp S',
                  buyBiasedCoins: 'Alış Baskısı', sellBiasedCoins: 'Satış Baskısı',
                  btcStrong: 'BTC Güçlü', btcWeak: 'BTC Zayıf', multiPumps: 'Çok Borsa Pump',
                  scalpTraps: 'Scalp Tuzak', stopHunts: 'Stop Hunt', sessionRisks: 'Seans Risk',
                  opportunities: 'Fırsatlar',
                };
                const label = labels[key];
                if (!label) return null;

                return (
                  <div key={key} className="space-y-1">
                    <div className="text-[8px] font-mono text-gray-700 uppercase tracking-widest">{label}</div>
                    <div className="flex flex-wrap gap-1">
                      {coins.slice(0, 6).map((c, i) => (
                        <span
                          key={i}
                          className="text-[8px] font-mono px-1.5 py-0.5 rounded"
                          style={{
                            background: '#1a1a2e',
                            color: (c.change || c.relStrength || 0) >= 0 ? '#00ff88' : '#ff3366',
                            border: '1px solid #2a2a3e',
                          }}
                        >
                          {c.symbol || c.name || '?'}
                          {c.change !== undefined && ` ${c.change >= 0 ? '+' : ''}${c.change?.toFixed(1)}%`}
                        </span>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

// ─── FINAL COUNCIL DISPLAY ────────────────────────────────────────────────────
function FinalCouncilCard({ final }) {
  if (!final) return null;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.97 }}
      animate={{ opacity: 1, scale: 1 }}
      className="rounded-xl p-4 relative overflow-hidden"
      style={{
        background: `${final.color}08`,
        border: `2px solid ${final.color}40`,
      }}
    >
      {/* Pulse glow */}
      <motion.div
        className="absolute inset-0 rounded-xl pointer-events-none"
        animate={{ boxShadow: [`0 0 0 ${final.color}00`, `0 0 30px ${final.color}20`, `0 0 0 ${final.color}00`] }}
        transition={{ duration: 3, repeat: Infinity }}
      />

      <div className="relative z-10">
        <div className="text-[9px] font-mono text-gray-500 uppercase tracking-widest mb-2">
          Final Konsey Kararı
        </div>

        <div className="flex items-center justify-between mb-3">
          <div>
            <div className="text-3xl font-black font-mono" style={{ color: final.color, textShadow: `0 0 30px ${final.color}50` }}>
              {final.action}
            </div>
            <div className="text-[10px] font-mono mt-1" style={{ color: final.biasColor }}>
              Piyasa: {final.marketBias}
            </div>
          </div>
          <div className="text-right">
            <div className="text-[9px] font-mono text-gray-600">Final Skor</div>
            <div className="text-4xl font-black font-mono" style={{ color: final.color }}>
              {final.finalScore}
            </div>
            <div className="text-[9px] font-mono text-gray-600">Güven: {final.confidence}%</div>
          </div>
        </div>

        {/* Vote summary */}
        <div className="grid grid-cols-3 gap-2 mb-3">
          {[
            { label: 'AL OYU', count: final.votes?.bullish || 0, color: '#00ff88' },
            { label: 'SAT OYU', count: final.votes?.bearish || 0, color: '#ff3366' },
            { label: 'NÖTR', count: final.votes?.neutral || 0, color: '#ffcc00' },
          ].map(v => (
            <div key={v.label} className="bg-[#0a0a0f] rounded-lg p-2 text-center">
              <div className="text-[8px] font-mono text-gray-600">{v.label}</div>
              <div className="text-lg font-black font-mono" style={{ color: v.color }}>{v.count}/4</div>
            </div>
          ))}
        </div>

        {/* Risk + Summary lines */}
        <div
          className="rounded-lg px-3 py-2 mb-2"
          style={{ background: `${final.riskColor}10`, border: `1px solid ${final.riskColor}25` }}
        >
          <div className="flex items-center justify-between">
            <span className="text-[9px] font-mono text-gray-500">Genel Risk Seviyesi</span>
            <span className="text-[10px] font-mono font-bold" style={{ color: final.riskColor }}>
              {final.riskLevel}
            </span>
          </div>
        </div>

        <div className="space-y-0.5">
          {final.summary?.map((line, i) => (
            <div key={i} className="flex items-start gap-1.5">
              <CheckCircle style={{ width: 8, height: 8, color: '#4b5563', flexShrink: 0, marginTop: 2 }} />
              <span className="text-[8px] font-mono text-gray-600">{line}</span>
            </div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}

// ─── ANA BİLEŞEN ─────────────────────────────────────────────────────────────
export default function CouncilPanel({ councilResults }) {
  const [expanded, setExpanded] = useState(null);

  if (!councilResults) {
    return (
      <div className="cyber-border rounded-lg p-6 flex items-center justify-center">
        <div className="text-[10px] font-mono text-gray-600 animate-pulse">Konseyler toplanıyor...</div>
      </div>
    );
  }

  const { momentum, risk, structure, flow, final } = councilResults;
  const councils = [momentum, risk, structure, flow].filter(Boolean);

  return (
    <div className="cyber-border rounded-lg p-4 space-y-3">
      {/* Header */}
      <div className="flex items-center gap-2">
        <div className="relative w-4 h-4">
          <motion.div
            className="absolute inset-0 rounded-full"
            style={{ border: '1px solid #00aaff' }}
            animate={{ scale: [1, 1.4, 1], opacity: [0.5, 0, 0.5] }}
            transition={{ duration: 2, repeat: Infinity }}
          />
          <CheckCircle className="w-4 h-4 text-[#00aaff] relative z-10" />
        </div>
        <h3 className="text-xs font-bold tracking-widest uppercase text-[#00aaff]">
          Karar Konseyleri
        </h3>
        <span className="text-[9px] font-mono text-gray-600 ml-auto">4 Aktif Konsey</span>
      </div>

      {/* Final decision */}
      <FinalCouncilCard final={final} />

      {/* Individual councils */}
      <div className="space-y-2">
        <div className="text-[9px] font-mono text-gray-600 uppercase tracking-widest">Konsey Detayları</div>
        {councils.map(council => (
          <CouncilCard
            key={council.id}
            council={council}
            isExpanded={expanded === council.id}
            onToggle={() => setExpanded(expanded === council.id ? null : council.id)}
          />
        ))}
      </div>
    </div>
  );
}
