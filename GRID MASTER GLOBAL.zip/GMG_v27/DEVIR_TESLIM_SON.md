# GMG — DEVİR TESLİM v18
## Tarih: 2026-03-17 | 25.116 satır | 66 dosya

## YENİ OTURUMDA BAŞLARKEN
1. ZIP yükle
2. Şunu yaz: "DEVIR_TESLIM_v18.md oku, kaldığın yerden devam et"
3. Claude devam eder

---

## SİSTEM GENEL DURUMU

| Katman | Durum | Dosya |
|--------|-------|-------|
| I. Crypto Modules | ✅ | cryptoMarketEngine.js |
| II. Forex Modules | ✅ | forexEngine.js + multiAssetEngines.js |
| III. Commodity | ✅ | commodityEngine.js |
| IV. Index | ✅ | indexEngine.js |
| V. Bond | ✅ | bondMacroEngine.js + bondMacroAdvancedEngine.js |
| VI. Global Macro | ✅ | bondMacroEngine.js |
| VII. Technical | ✅ | structureEngines.js + technicalAdvancedEngine.js + technicalExtEngine.js |
| VIII. Liquidity | ✅ | technicalExtEngine.js + trapDetectionEngine.js |
| IX. Derivatives | ✅ | realDerivativesEngine.js + derivativesAdvancedEngine.js |
| X. News/Sentiment | ✅ | newsAdvancedEngine.js + newsMacroCouncil.js |
| XI. AI Decision | ✅ | masterCouncil.js + executionLayer.js |
| XII. Council | ✅ | councilEngine.js + councilAdvancedEngine.js |
| XIII. Execution | ✅ | executionLayer.js + executionSafetyFilter.js |
| XIV. UI/Panels | ✅ | Dashboard_v4.jsx + tüm paneller |
| XV. Alert | ✅ | alertMonitorEngines.js |

---

## BU OTURUMDA YAPILAN DEĞİŞİKLİKLER (v18)

### Dashboard_v4.jsx
- `JSONOutputEngine` import eklendi
- `jsonOutputs` state + `jsonEngineRef` (useRef) eklendi
- `setMasterResult` sonrasına `generateAll()` çağrısı bağlandı
- Her scan sonrası tüm JSON çıktıları `jsonOutputs` state'inde

### councilAdvancedEngine.js
- `specialistEngines.js` runtime import (require + try/catch)
- `runForexSpecialistFull()` — internal + specialist %60/%40 blend
- `runCommoditySpecialistFull()` — internal + specialist %60/%40 blend
- `CouncilMemoryEngine.getHistory(councilId, limit)` — son N karar
- `CouncilMemoryEngine.getWinRate()` — genel win rate
- `CouncilMemoryEngine.getStats()` — { total, resolved, winRate, councils }

### masterCouncil.js
- `initInfra()` null-safe try/catch
- `LoggingEngine.log` null-safe wrapper

### LiveAICouncilPanel.jsx
- CouncilMemory panel genişletildi
- `getStats()` → toplam/resolved gösterge
- `getHistory(null, 10)` → son 10 karar listesi
- Her satır: councilId | action | score | ✓/✗ | saat

### MarketIntelPanel.jsx
- Database + Link icon eklendi
- ZİNCİR sekmesi (OnchainTab) eklendi
- ETF sekmesi (ETFTab) eklendi
- Her iki sekme `masterResult` prop'undan veri alır

---

## SONRAKI OTURUMDA YAPILACAKLAR (ÖNCELİK SIRASI)

### 1. MarketIntelPanel → masterResult prop (15 dk) ← EN KOLAY
```jsx
// Dashboard_v4.jsx'te MarketIntelPanel çağrısını bul ve ekle:
<MarketIntelPanel
  scanResults={scanResults}
  masterResult={masterResult}   // ← BU SATIRI EKLE
  onRefresh={...}
  loading={scanLoading}
/>
```

### 2. jsonOutputs → LiveAICouncilPanel (20 dk)
```jsx
// Dashboard_v4.jsx'te LiveAICouncilPanel çağrısına ekle:
<LiveAICouncilPanel
  masterResult={masterResult}
  jsonOutputs={jsonOutputs}     // ← EKLE
  ...
/>
// LiveAICouncilPanel içinde props'a al ve kullan
```

### 3. runForexSpecialistFull → masterCouncil (20 dk)
```javascript
// masterCouncil.js'te:
import { runForexSpecialistFull, runCommoditySpecialistFull } from './councilAdvancedEngine.js';
// specialist council çağrılarını Full versiyonla değiştir
```

### 4. CouncilMemoryEngine.record() → masterCouncil sonu (15 dk)
```javascript
// masterCouncil.js — return'den önce:
try {
  const councilMap = {
    TECHNICAL: master.councils?.technical,
    FLOW:      master.councils?.flow,
    RISK:      master.councils?.risk,
    ASSET:     master.councils?.asset,
    NEWS_MACRO:master.councils?.newsMacro,
    SPECIALIST:master.councils?.specialist,
  };
  Object.entries(councilMap).forEach(([id, c]) => {
    if (c?.action && c?.score != null) {
      CouncilMemoryEngine.record({ councilId: id+'_COUNCIL', action: c.action, score: c.score });
    }
  });
} catch(e) {}
```

### 5. socialSentimentEngine → CryptoPanic API (30 dk)
```javascript
// specialistEngines.js runSocialSentimentEngine içine ekle:
export async function fetchCryptoPanicNews(symbol = 'BTC') {
  const url = `https://cryptopanic.com/api/v1/posts/?auth_token=free&currencies=${symbol}&filter=hot`;
  const res  = await fetch(url, { signal: AbortSignal.timeout(5000) });
  const data = await res.json();
  return (data.results || []).slice(0, 10).map(p => ({
    title:     p.title,
    sentiment: p.votes?.positive > p.votes?.negative ? 'positive' : 'negative',
    source:    p.source?.title,
    published: p.published_at,
  }));
}
```

### 6. TrapScore widget modal (45 dk)
- Header'daki 🪤 widget'a `onClick` + modal state ekle
- Modal: trapDetectionEngine detay listesi
- Renk: yeşil(0-40) sarı(41-70) kırmızı(71-100)

---

## ÖNEMLİ API REFERANSI

### masterCouncil.js — runMasterCouncil parametreleri
```javascript
await runMasterCouncil({
  candles,           // OHLCV array
  I,                 // { rsi, macd, bb, ema, adx, mfi }
  scanResults,       // intelligenceEngine çıktısı
  orderbook,         // { bids, asks }
  heatmapData,       // coin array
  fundingRates,      // [{ ex, rate }]
  btcChange,
  vixLevel,
  dxyLevel,          // varsayılan 104
  us10yYield,        // varsayılan 4.5
  goldChange,        // varsayılan 0
  oilChange,         // varsayılan 0
  pineParams,        // { rfPer:100, rfMult:3.0, signalMode:'KLASİK' }
  macroOverrides,
})
// Döner: { action, label, score, confidence, councils, advanced,
//          multiAsset, health, probability, chartOverlay, summary }
```

### councilAdvancedEngine.js — Yeni metodlar
```javascript
CouncilMemoryEngine.getHistory(councilId?, limit=20)
CouncilMemoryEngine.getWinRate()          // 0-100
CouncilMemoryEngine.getStats()            // { total, resolved, pending, winRate, councils }
runForexSpecialistFull(params)            // enhanced — specialistEngines entegre
runCommoditySpecialistFull(params)        // enhanced — specialistEngines entegre
```

### jsonOutputEngine.js
```javascript
const engine = new JSONOutputEngine();
engine.generateAll(masterResult, scanResults, { scalpResult, accuResult, trapData, alerts });
engine.get('ai_decision_output')   // { action, score, confidence, councils, pine, probability }
engine.get('council_output')       // { councils, finalCouncil, specialist }
engine.get('live_bridge_output')   // live bridge formatı
engine.get('scalp_output')         // scalp sinyalleri
engine.get('health_output')        // sistem sağlık
engine.get('multi_asset_output')   // forex/commodity/index
```

### RiskModeSelector
```javascript
RiskModeSelector.getParams('NORMAL')       // { minScore:60, maxRisk:'ORTA', ... }
RiskModeSelector.getParams('AGRESIF')      // { minScore:50, maxRisk:'YÜKSEK', ... }
RiskModeSelector.getParams('MUHAFAZAKAR')  // { minScore:72, maxRisk:'DÜŞÜK', doubleConfirm:true }
```

---

## DOSYA LİSTESİ (66 dosya)

### JS Engine'ler (54 adet)
advancedOnchainEngine.js, aiCouncilEngine.js, alertMonitorEngines.js,
autoAIEngine.js, backtestEngine.js, backtestWorker.js, backtestingEngine.js,
bondMacroAdvancedEngine.js, bondMacroEngine.js, btcShockSentinel.js,
chartModule.js, commodityEngine.js, councilAdvancedEngine.js, councilEngine.js,
cryptoMarketEngine.js, derivativesAdvancedEngine.js, dipOnaylayici.js,
engineCore.js, exchangeAPI_multi.js, executionLayer.js, executionSafetyFilter.js,
forexEngine.js, historicalPatternEngine.js, indexEngine.js, infraEngine.js,
intelligenceAdvancedEngine.js, intelligenceEngine.js, jsonOutputEngine.js,
liveAIEngine.js, liveAIQueryEngine.js, liveBridgeEngine.js, macroAPIEngine.js,
macroNewsEngines.js, masterCouncil.js, moduleRegistry.js, multiAssetEngine.js,
multiAssetEngines.js, newsMacroCouncil.js, newsSentimentAlertExt.js,
newsAdvancedEngine.js, performanceCacheEngine.js, pineEngine.js,
probabilityEngine.js, realDerivativesEngine.js, socialSentimentEngine.js,
specialistEngines.js, stockBondIntelligenceEngine.js, structureEngines.js,
technicalAdvancedEngine.js, technicalExtEngine.js, trapDetectionEngine.js,
userPlanningEngine.js, userProfileEngine.js, whaleInflowOutflowEngine.js

### JSX Paneller (12 adet)
BacktestPanel.jsx, CouncilPanel.jsx, Dashboard_v4.jsx, DipOnayPanel.jsx,
ForexAndMultiMarketPanels.jsx, FundingPanel.jsx, GMGChart_v3.jsx,
LiveAICouncilPanel.jsx, LiquidityRadar.jsx, MarketIntelPanel.jsx,
MultiTimeframePanel.jsx, WallAndAccumulationPanels.jsx

---
Son güncelleme: 2026-03-17 | v18 | 25.116 satır
