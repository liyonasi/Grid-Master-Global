/**
 * GMG — JSON OUTPUT ENGINE
 * =========================
 * Tüm gerekli JSON çıktılarını üretir ve günceller.
 * live_bridge_output, council_output, health_output, alert_output vs.
 */

export class JSONOutputEngine {
  constructor() {
    this.outputs = {};
    this.listeners = new Map();
  }

  // Tüm çıktıları master result'tan üret
  generateAll(masterResult, scanResults, extraData = {}) {
    if (!masterResult) return;

    const ts = Date.now();

    // 1. AI Decision Output
    this.outputs['ai_decision_output'] = {
      action:     masterResult.action,
      label:      masterResult.label,
      score:      masterResult.score,
      confidence: masterResult.confidence,
      riskLevel:  masterResult.riskLevel,
      color:      masterResult.color,
      councils: {
        technical: { score: masterResult.councils?.technical?.score, action: masterResult.councils?.technical?.action },
        flow:      { score: masterResult.councils?.flow?.score,      action: masterResult.councils?.flow?.action },
        risk:      { score: masterResult.councils?.risk?.score,      level: masterResult.councils?.risk?.riskLevel },
        asset:     { score: masterResult.councils?.asset?.score,     action: masterResult.councils?.asset?.action },
        newsMacro: { score: masterResult.councils?.newsMacro?.score, verdict: masterResult.councils?.newsMacro?.verdict },
        specialist:{ score: masterResult.councils?.specialist?.score,action: masterResult.councils?.specialist?.action },
      },
      pine: {
        trendDir: masterResult.pineData?.rf?.trendDir,
        buySignal: masterResult.pineData?.rf?.buySignal,
        sellSignal: masterResult.pineData?.rf?.sellSignal,
        pbBuy:    masterResult.pineData?.pb?.pbBuy,
        pbSell:   masterResult.pineData?.pb?.pbSell,
        councilScore: masterResult.pineData?.council?.councilScore,
        tpsl:     masterResult.pineData?.tpsl,
      },
      probability: masterResult.probability?.probability,
      vetoed:      masterResult.execution?.filters?.veto?.wasVetoed,
      summary:     masterResult.summary?.[0],
      timestamp:   ts,
    };

    // 2. Council Output
    this.outputs['council_output'] = {
      councils: masterResult.councils,
      finalCouncil: masterResult.finalCouncil,
      specialist: masterResult.advanced ? {
        crypto:    masterResult.advanced.cryptoSpecialist,
        forex:     masterResult.advanced.forexSpecialist,
        commodity: masterResult.advanced.commoditySpecialist,
        index:     masterResult.advanced.indexSpecialist,
      } : null,
      multiAsset: masterResult.multiAsset,
      timestamp:  ts,
    };

    // 3. Live Bridge Output
    this.outputs['live_bridge_output'] = {
      action:     masterResult.action,
      score:      masterResult.score,
      confidence: masterResult.confidence,
      risk:       masterResult.riskLevel,
      pine_trend: masterResult.pineData?.rf?.trendDir,
      buy_signal: masterResult.pineData?.rf?.buySignal,
      sell_signal:masterResult.pineData?.rf?.sellSignal,
      pb_buy:     masterResult.pineData?.pb?.pbBuy,
      pb_sell:    masterResult.pineData?.pb?.pbSell,
      tp1:        masterResult.pineData?.tpsl?.tp1,
      tp2:        masterResult.pineData?.tpsl?.tp2,
      sl:         masterResult.pineData?.tpsl?.sl,
      veto:       masterResult.execution?.filters?.veto?.wasVetoed,
      timestamp:  ts,
    };

    // 4. Scalp Output
    if (extraData.scalpResult) {
      this.outputs['scalp_output'] = { ...extraData.scalpResult, timestamp: ts };
    }

    // 5. Accumulation Output
    if (extraData.accuResult) {
      this.outputs['accumulation_output'] = { ...extraData.accuResult, timestamp: ts };
    }

    // 6. Funding Output
    if (extraData.fundingData) {
      this.outputs['funding_output'] = { ...extraData.fundingData, timestamp: ts };
    }

    // 7. Top200 Output
    if (scanResults?.enrichedCoins?.length) {
      this.outputs['top200_output'] = {
        coins:       scanResults.enrichedCoins.slice(0, 200).map(c => ({
          symbol:    c.symbol,
          price:     c.price,
          change24h: c.change_24h,
          rsi:       c.rsi,
          volume:    c.volume,
          score:     c.score,
        })),
        scanTime:    ts,
        totalCoins:  scanResults.enrichedCoins.length,
      };
    }

    // 8. Liquidity Trap Output
    if (scanResults?.scalpTraps?.length) {
      this.outputs['liquidity_trap_output'] = {
        traps:    scanResults.scalpTraps.slice(0, 20),
        count:    scanResults.scalpTraps.length,
        timestamp: ts,
      };
    }

    // 9. Alert Output
    if (extraData.alerts?.length) {
      this.outputs['alert_output'] = {
        alerts:   extraData.alerts.slice(0, 50),
        count:    extraData.alerts.length,
        critical: extraData.alerts.filter(a => a.severity === 'critical').length,
        timestamp: ts,
      };
    }

    // 10. Health Output
    this.outputs['health_output'] = {
      modulesOnline: masterResult.health?.modulesOnline || [],
      infraStatus:   masterResult.health?.infraStatus || 'OK',
      timestamp:     ts,
      uptime:        ts,
    };

    // 11. Multi Asset Output
    this.outputs['multi_asset_output'] = {
      forex:     masterResult.multiAsset?.forex,
      bond:      masterResult.multiAsset?.bond,
      squeeze:   masterResult.multiAsset?.squeeze,
      buyWall:   masterResult.multiAsset?.buyWall,
      sellWall:  masterResult.multiAsset?.sellWall,
      adjustment: masterResult.multiAsset?.adjustment,
      timestamp:  ts,
    };

    // 12. Liquidity Special Output (Dark Pool + Flash Crash + OTC)
    if (masterResult.liquiditySpecial) {
      const ls = masterResult.liquiditySpecial;
      this.outputs['liquidity_special_output'] = {
        score:      ls.score,
        critical:   ls.critical,
        darkPool: {
          detected:   ls.darkPool?.detected,
          type:       ls.darkPool?.type,
          score:      ls.darkPool?.score,
          signal:     ls.darkPool?.signal,
          enhanced:   ls.darkPool?.enhanced || false,
          glassnode:  ls.darkPool?.glassnode || null,
        },
        flashCrash: {
          detected:  ls.flashCrash?.detected,
          severity:  ls.flashCrash?.severity,
          maxDrop:   ls.flashCrash?.maxDrop,
          recovered: ls.flashCrash?.recovered,
        },
        otcFlow: {
          isAccumulating: ls.otcFlow?.isAccumulating,
          isDistributing: ls.otcFlow?.isDistributing,
          score:          ls.otcFlow?.score,
          enhanced:       ls.otcFlow?.enhanced || false,
          cryptoquant:    ls.otcFlow?.cryptoquant || null,
        },
        alerts:    ls.alerts,
        summary:   ls.summary,
        timestamp: ts,
      };
    }

    // 13. Missing Bundle Output
    if (masterResult.missingBundle) {
      const mb = masterResult.missingBundle;
      this.outputs['missing_bundle_output'] = {
        bonusScore:  mb.bonusScore,
        supertrend:  mb.supertrend ? { trend: mb.supertrend.trend, score: mb.supertrend.score } : null,
        keltner:     mb.keltner    ? { position: mb.keltner.position, score: mb.keltner.score }   : null,
        trendCloud:  mb.trendCloud ? { signal: mb.trendCloud.signal, score: mb.trendCloud.score }  : null,
        panic:       mb.panic      ? { isPanic: mb.panic.isPanic, level: mb.panic.level }           : null,
        contagion:   mb.contagion  ? { contagion: mb.contagion.contagion, score: mb.contagion.score }: null,
        indexStress: mb.indexStress? { level: mb.indexStress.level, score: mb.indexStress.score }   : null,
        rateExpect:  mb.rateExpect ? { expectation: mb.rateExpect.expectation, score: mb.rateExpect.score }: null,
        alerts:      mb.alerts,
        timestamp:   ts,
      };
    }

    // 14. Health + CrossFeed Output
    if (masterResult.health) {
      this.outputs['health_output'] = {
        modulesOnline: masterResult.health.modulesOnline,
        infraStatus:   masterResult.health.infraStatus,
        latencyMs:     masterResult.health.latencyMs,
        crossFeed: masterResult.health.crossFeed ? {
          isValid:      masterResult.health.crossFeed.isValid,
          maxDeviation: masterResult.health.crossFeed.maxDeviation,
          anomalies:    masterResult.health.crossFeed.anomalies,
        } : null,
        timestamp: ts,
      };
    }

    // Listener'ları bildir
    this.notify();
    return this.outputs;
  }

  get(key) { return this.outputs[key] || null; }
  getAll() { return { ...this.outputs }; }

  subscribe(key, fn) {
    if (!this.listeners.has(key)) this.listeners.set(key, []);
    this.listeners.get(key).push(fn);
  }

  notify() {
    for (const [key, fns] of this.listeners) {
      const data = this.outputs[key];
      if (data) fns.forEach(fn => { try { fn(data); } catch {} });
    }
  }
}

// Singleton
export const jsonOutputEngine = new JSONOutputEngine();
