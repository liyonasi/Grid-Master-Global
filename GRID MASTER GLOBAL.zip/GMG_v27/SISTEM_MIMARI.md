# GMG — SİSTEM MİMARİSİ DETAY

## KLASÖR YAPISI (Önerilen)

```
src/
├── components/
│   └── grid-master/
│       ├── GMGChart_v3.jsx          ← Ana grafik
│       ├── CouncilPanel.jsx         ← 4 Konsey paneli
│       ├── LiquidityRadar.jsx       ← Liq radar
│       ├── FundingPanel.jsx         ← Funding + OI
│       ├── MarketIntelPanel.jsx     ← İstihbarat 7 sekme
│       ├── MultiTimeframePanel.jsx  ← MTF analizi
│       └── Dashboard_v4.jsx         ← Ana dashboard
│
├── engines/
│   ├── masterCouncil.js    ← ANA GİRİŞ
│   ├── pineEngine.js       ← Pine indikatör
│   ├── executionLayer.js   ← Execution + Veto
│   ├── newsMacroCouncil.js ← News & Macro
│   ├── engineCore.js       ← 16 tarayıcı
│   ├── intelligenceEngine.js
│   ├── aiCouncilEngine.js
│   ├── councilEngine.js
│   ├── chartModule.js      ← Pattern recognition
│   ├── indexEngine.js      ← Index modülleri
│   ├── alertMonitorEngines.js
│   └── moduleRegistry.js   ← 95 modül dağılımı
│
└── api/
    └── exchangeAPI_multi.js  ← 7 borsa
```

---

## VERİ AKIŞI DETAYI

### 1. WebSocket (canlı veri)
```javascript
// exchangeAPI_multi.js
const ws = new MultiExchangeWS('BTC', 'USDT',
  (candle) => {
    // Her mum kapandığında
    setRaw(prev => [...prev, candle]);
  },
  (tick) => {
    // Her trade'de
    setLastPrice(tick.price);
  }
);
ws.connect('binance', '1m');
// Binance düşerse → otomatik Bybit → OKX → MEXC
```

### 2. Gösterge Hesaplama (her mum kapanışında)
```javascript
// GMGChart_v3.jsx içinden
const I = useMemo(() => {
  const cs = candles.map(c => c.c);
  return {
    e9:  ema(cs, 9),
    e21: ema(cs, 21),
    rsi: rsiCalc(cs),
    macd: macdCalc(cs),
    bb:  bollCalc(cs),
    atr: atrCalc(candles),
    adx: adxCalc(candles),
    mfi: mfiCalc(candles),
    obv: obvCalc(candles),
  };
}, [candles]);
```

### 3. Tarama (her 10 saniyede)
```javascript
// engineCore.js
const scan = runAllScanners({
  coins:        heatmapData,    // CoinGecko top 200
  btcChange:    btcChange24h,
  orderbookMap: { 'BTC/USDT': currentOrderbook },
  klineMap:     klineCache,     // son 30 coin için cache
});
```

### 4. Master Council (her mum kapanışında + 10s)
```javascript
// masterCouncil.js
const result = await runMasterCouncil({ candles, I, scanResults, ... });
setCouncilResult(result);
```

### 5. Grafik Render (requestAnimationFrame)
```javascript
// GMGChart_v3.jsx
useEffect(() => {
  rafRef.current = requestAnimationFrame(draw);
  return () => cancelAnimationFrame(rafRef.current);
}, [draw]);  // draw candles, I, councilResult bağımlı
```

---

## 5 KONSEYİN AĞIRLIKLARI VE GİRDİLERİ

### TECHNICAL COUNCIL (%30)
| Girdi | Ağırlık |
|-------|---------|
| RSI | %12 |
| MACD | %12 |
| EMA Trend | %12 |
| Bollinger | %10 |
| ADX Güç | %8 |
| MFI | %8 |
| **Pine: RF Trend Yönü** | **%15** |
| **Pine: RF Flip Sinyali** | **%12** |
| **Pine: S/R Yakınlık** | **%8** |
| **Pine: PB-AL/SAT** | **%13** |

### FLOW COUNCIL (%25)
| Girdi | Ağırlık |
|-------|---------|
| Orderbook Buy% | %28 |
| Liq Sensitivity | %22 |
| Piyasa Genişliği | %20 |
| Pump/Dump Dengesi | %18 |
| Funding Bias | %12 |

### NEWS & MACRO COUNCIL (%15)
| Girdi | Ağırlık |
|-------|---------|
| Fear & Greed | %30 |
| DXY Baskısı | %20 |
| VIX Volatilite | %20 |
| Global Likidite | %15 |
| BTC Dominans | %10 |
| Macro Events | %5 |

### RISK COUNCIL (%10) + VETO YETKİSİ
| Girdi | Ağırlık |
|-------|---------|
| Scalp Tuzak | %20 |
| Stop Hunt | %25 |
| Kritik Dump | %20 |
| Liq Risk | %15 |
| VIX | %12 |
| Funding Aşırılık | %8 |
| **Pine: PB-SAT Uyarısı** | **+%10** |

### ASSET SPECIALIST COUNCIL (%20)
| Girdi | Ağırlık |
|-------|---------|
| Alt Sezon | %28 |
| Sektör Gücü | %25 |
| BTC Dominans | %22 |
| Para Rotasyonu | %15 |
| Stablecoin Akış | %10 |

---

## EXECUTION LAYER FİLTRE ZİNCİRİ

```
Girdi: proposedAction = 'BUY' | 'SELL' | 'WAIT'

1. FALSE SIGNAL FILTER
   ├── Konsey anlaşması < 3/5  → BLOK
   ├── Hacim z-score < -0.5    → BLOK
   ├── Son 3 barda sinyal var  → BLOK
   └── Pine RF ters yön        → BLOK

2. MANIPULATION FILTER
   ├── Stop hunt aktif         → manipScore += 20
   ├── OB imbalance > %85      → manipScore += 25
   └── manipScore >= 50        → isManipulated = true

3. RISK FILTER
   ├── Risk Council < 30       → riskPenalty += 30
   ├── VIX > 80                → riskPenalty += 25
   ├── Funding > %0.1          → riskPenalty += 20
   └── adjustedScore < 40      → isAcceptable = false

4. RISK VETO
   ├── riskLevel == 'KRİTİK'   → action = 'WAIT' (ezer)
   ├── manipSeverity == 'KRİTİK' → action = 'WAIT' (ezer)
   ├── riskLevel == 'YÜKSEK' + BUY → action = 'WAIT'
   └── falseSignalPassed == false  → action = 'WAIT'

5. DOUBLE CONFIRM
   ├── barCount < requireBars  → PENDING
   ├── Pine RF ters yön        → PENDING
   └── prevScore tutarsız      → PENDING

Çıktı: BUY / SELL / WAIT + confidence + riskLevel
```

---

## PINE İNDİKATÖR PARAMETRELERİ (Önerilen)

```javascript
const pineParams = {
  rfPer:       100,   // Range Filter periyodu (50-200 arası dene)
  rfMult:      3.0,   // Range Multiplier (2.0-4.0 arası dene)
  srPrd:       10,    // S/R pivot periyodu
  srChannelW:  5,     // S/R kanal genişliği %
  srMaxNum:    6,     // Max S/R bölgesi sayısı
  atrLen:      14,    // ATR periyodu
  proxMode:    'ATR', // 'ATR' veya 'Yüzde'
  proxATRmult: 0.60,  // Yakınlık (ATR x)
  proxPct:     0.35,  // Yakınlık (%)
  pbsStrict:   true,  // PB-SAT sıkı kural
  pbaStrict:   true,  // PB-AL sıkı kural
};
```

---

Son güncelleme: 2026-03-15 | v10
