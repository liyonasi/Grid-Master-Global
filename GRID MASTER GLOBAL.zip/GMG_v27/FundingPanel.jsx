import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { BarChart2, TrendingUp, TrendingDown, Activity, Target } from 'lucide-react';

// ─── FETCH HELPERS ────────────────────────────────────────────────────────────

async function fetchBinanceFunding(symbol) {
  try {
    const s = symbol.replace('/', '');
    const res = await fetch(`https://fapi.binance.com/fapi/v1/premiumIndex?symbol=${s}`);
    const d = await res.json();
    return {
      fundingRate: parseFloat(d.lastFundingRate) * 100,
      nextFundingTime: d.nextFundingTime,
      markPrice: parseFloat(d.markPrice),
    };
  } catch { return null; }
}

async function fetchBinanceOI(symbol) {
  try {
    const s = symbol.replace('/', '');
    const res = await fetch(`https://fapi.binance.com/fapi/v1/openInterest?symbol=${s}`);
    const d = await res.json();
    return { openInterest: parseFloat(d.openInterest), openInterestValue: parseFloat(d.openInterest) * parseFloat(d.price || 0) };
  } catch { return null; }
}

async function fetchBinanceOIHistory(symbol) {
  try {
    const s = symbol.replace('/', '');
    const res = await fetch(`https://fapi.binance.com/futures/data/openInterestHist?symbol=${s}&period=5m&limit=12`);
    const d = await res.json();
    return Array.isArray(d) ? d.map(r => ({
      time: new Date(r.timestamp).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }),
      value: parseFloat(r.sumOpenInterest),
    })) : [];
  } catch { return []; }
}

async function fetchBybitFunding(symbol) {
  try {
    const s = symbol.replace('/', '');
    const res = await fetch(`https://api.bybit.com/v5/market/tickers?category=linear&symbol=${s}`);
    const d = await res.json();
    const t = d.result?.list?.[0];
    if (!t) return null;
    return { fundingRate: parseFloat(t.fundingRate) * 100 };
  } catch { return null; }
}

// ─── MARKET STRUCTURE DETECTOR (BOS / CHoCH) ─────────────────────────────────

function detectMarketStructure(priceHistory) {
  if (!priceHistory || priceHistory.length < 20) return null;
  const prices = priceHistory.map(p => p.price || p.close || p);
  const n = prices.length;

  // Swing highs & lows (simplified — local extremes over 5-bar window)
  const swingHighs = [], swingLows = [];
  for (let i = 2; i < n - 2; i++) {
    if (prices[i] > prices[i-1] && prices[i] > prices[i-2] && prices[i] > prices[i+1] && prices[i] > prices[i+2])
      swingHighs.push({ idx: i, price: prices[i] });
    if (prices[i] < prices[i-1] && prices[i] < prices[i-2] && prices[i] < prices[i+1] && prices[i] < prices[i+2])
      swingLows.push({ idx: i, price: prices[i] });
  }

  if (swingHighs.length < 2 || swingLows.length < 2) return { structure: 'BELIRSIZ', bos: null, choch: null };

  const lastHigh  = swingHighs[swingHighs.length - 1];
  const prevHigh  = swingHighs[swingHighs.length - 2];
  const lastLow   = swingLows[swingLows.length - 1];
  const prevLow   = swingLows[swingLows.length - 2];
  const current   = prices[n - 1];

  let structure = 'YATAY';
  let bos = null;
  let choch = null;

  // HH / HL = uptrend | LH / LL = downtrend
  const higherHighs = lastHigh.price > prevHigh.price;
  const higherLows  = lastLow.price  > prevLow.price;
  const lowerHighs  = lastHigh.price < prevHigh.price;
  const lowerLows   = lastLow.price  < prevLow.price;

  if (higherHighs && higherLows) structure = 'YUKARI TREND';
  else if (lowerHighs && lowerLows) structure = 'AŞAĞI TREND';

  // BOS — Break of Structure: current price breaks last swing
  if (current > lastHigh.price) bos = { direction: 'YUKARI', price: lastHigh.price, type: 'BOS' };
  else if (current < lastLow.price) bos = { direction: 'AŞAĞI', price: lastLow.price, type: 'BOS' };

  // CHoCH — Change of Character: trend reversal signal
  if (structure === 'YUKARI TREND' && current < lastLow.price) choch = { direction: 'AŞAĞI', price: lastLow.price };
  else if (structure === 'AŞAĞI TREND' && current > lastHigh.price) choch = { direction: 'YUKARI', price: lastHigh.price };

  // Key levels
  const resistance = Math.max(...swingHighs.map(s => s.price));
  const support    = Math.min(...swingLows.map(s => s.price));

  return { structure, bos, choch, resistance, support, lastHigh: lastHigh.price, lastLow: lastLow.price };
}

// ─── SESSION TRACKER ──────────────────────────────────────────────────────────

function getMarketSessions() {
  const now = new Date();
  const utcH = now.getUTCHours();
  const utcM = now.getUTCMinutes();
  const utcTime = utcH + utcM / 60;

  return [
    {
      name: 'ASYA',
      color: '#00aaff',
      range: [0, 8],
      active: utcTime >= 0 && utcTime < 8,
      cities: 'Tokyo · Singapur',
    },
    {
      name: 'AVRUPA',
      color: '#ffcc00',
      range: [7, 16],
      active: utcTime >= 7 && utcTime < 16,
      cities: 'Londra · Frankfurt',
    },
    {
      name: 'ABD',
      color: '#ff8800',
      range: [13, 22],
      active: utcTime >= 13 && utcTime < 22,
      cities: 'New York · Chicago',
    },
  ];
}

// ─── SUB-COMPONENTS ───────────────────────────────────────────────────────────

function FundingBadge({ rate }) {
  if (rate === null || rate === undefined) return <span className="text-gray-600 font-mono text-xs">—</span>;
  const color = rate > 0.05 ? '#ff3366' : rate < -0.05 ? '#00ff88' : '#ffcc00';
  const label = rate > 0.05 ? 'AŞIRI LONG' : rate < -0.05 ? 'AŞIRI SHORT' : 'NÖTR';
  return (
    <div className="text-right">
      <div className="text-sm font-black font-mono" style={{ color }}>
        {rate > 0 ? '+' : ''}{rate.toFixed(4)}%
      </div>
      <div className="text-[9px] font-mono" style={{ color }}>{label}</div>
    </div>
  );
}

function OISparkline({ history }) {
  if (!history || history.length < 2) return null;
  const vals = history.map(h => h.value);
  const min = Math.min(...vals), max = Math.max(...vals);
  const range = max - min || 1;
  const w = 120, h = 28;
  const points = vals.map((v, i) => [
    (i / (vals.length - 1)) * w,
    h - ((v - min) / range) * (h - 4) - 2,
  ]);
  const path = points.map((p, i) => `${i === 0 ? 'M' : 'L'}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' ');
  const trend = vals[vals.length - 1] > vals[0];

  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`}>
      <path d={path} fill="none" stroke={trend ? '#00ff88' : '#ff3366'} strokeWidth="1.5" strokeLinecap="round" />
      <circle cx={points[points.length - 1][0]} cy={points[points.length - 1][1]} r="2" fill={trend ? '#00ff88' : '#ff3366'} />
    </svg>
  );
}

function SessionBar() {
  const sessions = getMarketSessions();
  const now = new Date();
  const utcH = now.getUTCHours();
  const utcM = now.getUTCMinutes();
  const dayPct = ((utcH * 60 + utcM) / 1440) * 100;

  return (
    <div className="space-y-2">
      <div className="text-[9px] font-mono text-gray-600 uppercase tracking-widest">
        Aktif Seans · UTC {String(utcH).padStart(2,'0')}:{String(utcM).padStart(2,'0')}
      </div>
      {/* 24h bar */}
      <div className="relative h-4 rounded-full overflow-hidden bg-[#1a1a2e]">
        {sessions.map(s => (
          <div
            key={s.name}
            className="absolute top-0 h-full rounded-sm"
            style={{
              left: `${(s.range[0] / 24) * 100}%`,
              width: `${((s.range[1] - s.range[0]) / 24) * 100}%`,
              background: s.active ? `${s.color}40` : `${s.color}18`,
              border: s.active ? `1px solid ${s.color}60` : '1px solid transparent',
            }}
          />
        ))}
        {/* Current time cursor */}
        <div
          className="absolute top-0 w-0.5 h-full bg-white/60"
          style={{ left: `${dayPct}%` }}
        />
      </div>
      {/* Session badges */}
      <div className="flex gap-2">
        {sessions.map(s => (
          <div
            key={s.name}
            className="flex-1 rounded-lg px-2 py-1.5 text-center"
            style={{
              background: s.active ? `${s.color}12` : '#0a0a0f',
              border: `1px solid ${s.active ? s.color + '40' : '#1a1a2e'}`,
            }}
          >
            <div className="text-[9px] font-mono font-bold" style={{ color: s.active ? s.color : '#4b5563' }}>
              {s.name}
              {s.active && (
                <motion.span
                  className="inline-block ml-1 w-1 h-1 rounded-full align-middle"
                  style={{ background: s.color }}
                  animate={{ opacity: [1, 0, 1] }}
                  transition={{ duration: 1, repeat: Infinity }}
                />
              )}
            </div>
            <div className="text-[8px] text-gray-600 font-mono">{s.cities}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function StructureBadge({ structure }) {
  const cfg = {
    'YUKARI TREND': { color: '#00ff88', icon: '↑' },
    'AŞAĞI TREND':  { color: '#ff3366', icon: '↓' },
    'YATAY':        { color: '#ffcc00', icon: '→' },
    'BELIRSIZ':     { color: '#6b7280', icon: '?' },
  }[structure] || { color: '#6b7280', icon: '?' };
  return (
    <span className="text-[10px] font-mono font-bold" style={{ color: cfg.color }}>
      {cfg.icon} {structure}
    </span>
  );
}

// ─── MAIN ─────────────────────────────────────────────────────────────────────

export default function FundingPanel({ symbol, priceHistory }) {
  const [funding, setFunding] = useState(null);
  const [bybitFunding, setBybitFunding] = useState(null);
  const [oi, setOi] = useState(null);
  const [oiHistory, setOiHistory] = useState([]);
  const [lastUpdate, setLastUpdate] = useState(null);

  const ms = detectMarketStructure(priceHistory);

  const fetchData = useCallback(async () => {
    if (!symbol) return;
    const [f, bf, o, oh] = await Promise.allSettled([
      fetchBinanceFunding(symbol),
      fetchBybitFunding(symbol),
      fetchBinanceOI(symbol),
      fetchBinanceOIHistory(symbol),
    ]);
    if (f.status === 'fulfilled' && f.value) setFunding(f.value);
    if (bf.status === 'fulfilled' && bf.value) setBybitFunding(bf.value);
    if (o.status === 'fulfilled' && o.value) setOi(o.value);
    if (oh.status === 'fulfilled') setOiHistory(oh.value || []);
    setLastUpdate(new Date());
  }, [symbol]);

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 30000);
    return () => clearInterval(interval);
  }, [fetchData]);

  const avgFunding = funding && bybitFunding
    ? (funding.fundingRate + bybitFunding.fundingRate) / 2
    : funding?.fundingRate ?? null;

  const oiTrend = oiHistory.length >= 2
    ? oiHistory[oiHistory.length - 1].value > oiHistory[0].value ? 'ARTIYOR' : 'AZALIYOR'
    : null;

  return (
    <div className="cyber-border rounded-lg p-4 space-y-3">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <BarChart2 className="w-4 h-4 text-[#00aaff]" />
          <h3 className="text-xs font-bold tracking-widest uppercase text-[#00aaff]">
            Türev & Yapı
          </h3>
        </div>
        {lastUpdate && (
          <span className="text-[9px] font-mono text-gray-600">
            {lastUpdate.toLocaleTimeString('tr-TR')}
          </span>
        )}
      </div>

      {/* Funding Rate */}
      <div className="bg-[#0a0a0f] rounded-lg p-3">
        <div className="text-[9px] font-mono text-gray-600 uppercase tracking-widest mb-2">
          Fonlama Oranı (8s)
        </div>
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-[9px] font-mono text-gray-600">BNC</span>
              <FundingBadge rate={funding?.fundingRate} />
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[9px] font-mono text-gray-600">BBT</span>
              <FundingBadge rate={bybitFunding?.fundingRate} />
            </div>
          </div>
          {avgFunding !== null && (
            <div className="text-right">
              <div className="text-[9px] font-mono text-gray-600">ORT</div>
              <div
                className="text-lg font-black font-mono"
                style={{ color: avgFunding > 0.05 ? '#ff3366' : avgFunding < -0.05 ? '#00ff88' : '#ffcc00' }}
              >
                {avgFunding > 0 ? '+' : ''}{avgFunding.toFixed(4)}%
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Open Interest */}
      <div className="bg-[#0a0a0f] rounded-lg p-3">
        <div className="flex items-center justify-between mb-2">
          <div className="text-[9px] font-mono text-gray-600 uppercase tracking-widest">Açık Pozisyon (OI)</div>
          {oiTrend && (
            <span
              className="text-[9px] font-mono font-bold"
              style={{ color: oiTrend === 'ARTIYOR' ? '#00ff88' : '#ff3366' }}
            >
              {oiTrend === 'ARTIYOR' ? '↑' : '↓'} {oiTrend}
            </span>
          )}
        </div>
        <div className="flex items-center justify-between">
          <div>
            {oi ? (
              <>
                <div className="text-sm font-black font-mono text-white">
                  {oi.openInterest.toLocaleString('tr-TR', { maximumFractionDigits: 0 })}
                </div>
                <div className="text-[9px] font-mono text-gray-600">
                  {symbol?.replace('/USDT', '')} adet
                </div>
              </>
            ) : (
              <div className="text-xs font-mono text-gray-600">Futures verisi yükleniyor...</div>
            )}
          </div>
          <OISparkline history={oiHistory} />
        </div>
      </div>

      {/* Market Structure */}
      <div className="bg-[#0a0a0f] rounded-lg p-3 space-y-2">
        <div className="text-[9px] font-mono text-gray-600 uppercase tracking-widest">Market Yapısı</div>
        {ms ? (
          <>
            <div className="flex items-center justify-between">
              <span className="text-[9px] font-mono text-gray-500">Yapı</span>
              <StructureBadge structure={ms.structure} />
            </div>
            {ms.bos && (
              <motion.div
                initial={{ opacity: 0, x: 4 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex items-center justify-between rounded px-2 py-1"
                style={{ background: ms.bos.direction === 'YUKARI' ? '#00ff8812' : '#ff336612', border: `1px solid ${ms.bos.direction === 'YUKARI' ? '#00ff8830' : '#ff336630'}` }}
              >
                <span className="text-[9px] font-mono font-bold" style={{ color: ms.bos.direction === 'YUKARI' ? '#00ff88' : '#ff3366' }}>
                  BOS {ms.bos.direction}
                </span>
                <span className="text-[9px] font-mono text-gray-500">
                  @ {ms.bos.price > 1 ? ms.bos.price.toFixed(2) : ms.bos.price.toFixed(6)}
                </span>
              </motion.div>
            )}
            {ms.choch && (
              <motion.div
                initial={{ opacity: 0, x: 4 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex items-center justify-between rounded px-2 py-1"
                style={{ background: '#ff880012', border: '1px solid #ff880030' }}
              >
                <span className="text-[9px] font-mono font-bold text-[#ff8800]">CHoCH {ms.choch.direction}</span>
                <span className="text-[9px] font-mono text-gray-500">
                  @ {ms.choch.price > 1 ? ms.choch.price.toFixed(2) : ms.choch.price.toFixed(6)}
                </span>
              </motion.div>
            )}
            <div className="grid grid-cols-2 gap-1.5 mt-1">
              <div className="text-center bg-[#050505] rounded p-1">
                <div className="text-[8px] font-mono text-gray-600">Direnç</div>
                <div className="text-[9px] font-mono text-[#ff3366] font-bold">
                  {ms.resistance > 1 ? ms.resistance.toFixed(2) : ms.resistance.toFixed(5)}
                </div>
              </div>
              <div className="text-center bg-[#050505] rounded p-1">
                <div className="text-[8px] font-mono text-gray-600">Destek</div>
                <div className="text-[9px] font-mono text-[#00ff88] font-bold">
                  {ms.support > 1 ? ms.support.toFixed(2) : ms.support.toFixed(5)}
                </div>
              </div>
            </div>
          </>
        ) : (
          <div className="text-[10px] font-mono text-gray-600">Fiyat geçmişi bekleniyor...</div>
        )}
      </div>

      {/* Session Tracker */}
      <div className="bg-[#0a0a0f] rounded-lg p-3">
        <SessionBar />
      </div>
    </div>
  );
}
