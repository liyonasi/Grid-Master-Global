/**
 * intelligenceAdvancedEngine.js — GMG v16
 * Gelişmiş İstihbarat Motorları:
 *   86. Correlation Engine
 *   87. Regime Shift Detector
 *   91. Whale Trace Engine (gelişmiş)
 *   92. Whale Inflow/Outflow Engine
 *   93. Smart Money Tracker
 *   94. Exchange Reserve Engine
 *   100. Strength Rank Engine
 *   112. Crypto Risk Spread Engine
 *   115. Crypto Contagion Engine
 */

const clamp = (v, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, v));

// ─── CORRELATION ENGINE ────────────────────────────────────────────────────────
export function runCorrelationEngine(assetPriceMap = {}) {
  // assetPriceMap: { BTC: [prices], ETH: [prices], GOLD: [prices], ... }
  const assets = Object.keys(assetPriceMap);
  if (assets.length < 2) return { correlations: {}, summary: {} };

  function pearson(a, b) {
    const n = Math.min(a.length, b.length);
    if (n < 5) return 0;
    const ax = a.slice(-n), bx = b.slice(-n);
    const ma = ax.reduce((s, v) => s + v, 0) / n;
    const mb = bx.reduce((s, v) => s + v, 0) / n;
    let num = 0, da = 0, db = 0;
    for (let i = 0; i < n; i++) {
      const dA = ax[i] - ma, dB = bx[i] - mb;
      num += dA * dB; da += dA * dA; db += dB * dB;
    }
    const denom = Math.sqrt(da * db);
    return denom > 0 ? parseFloat((num / denom).toFixed(3)) : 0;
  }

  const correlations = {};
  const summary = { strongPositive: [], strongNegative: [], neutral: [] };

  for (let i = 0; i < assets.length; i++) {
    for (let j = i + 1; j < assets.length; j++) {
      const a = assets[i], b = assets[j];
      const corr = pearson(assetPriceMap[a], assetPriceMap[b]);
      const key = `${a}_${b}`;
      correlations[key] = corr;
      if (corr > 0.7)       summary.strongPositive.push({ pair: key, corr });
      else if (corr < -0.7) summary.strongNegative.push({ pair: key, corr });
      else                  summary.neutral.push({ pair: key, corr });
    }
  }

  // BTC dominance etkisi
  const btcCorrs = Object.entries(correlations).filter(([k]) => k.startsWith('BTC'));
  const avgBtcCorr = btcCorrs.length
    ? btcCorrs.reduce((s, [, v]) => s + v, 0) / btcCorrs.length : 0;

  return {
    correlations,
    summary,
    avgBtcCorrelation: parseFloat(avgBtcCorr.toFixed(3)),
    altCoinIndependence: avgBtcCorr < 0.5,
    riskOffSignal: summary.strongNegative.some(p => p.pair.includes('GOLD') || p.pair.includes('USD')),
    timestamp: Date.now(),
  };
}

// ─── REGIME SHIFT DETECTOR ────────────────────────────────────────────────────
export function runRegimeShiftDetector(klines, volumeHistory = []) {
  if (!klines || klines.length < 40) return { detected: false, newRegime: 'UNKNOWN', score: 0 };

  const recent = klines.slice(-40);
  const old20  = recent.slice(0, 20);
  const new20  = recent.slice(20);

  // ATR karşılaştırması (volatilite rejim değişimi)
  function avgATR(ks) {
    return ks.slice(1).reduce((s, k, i) => s + (k.h - k.l), 0) / Math.max(ks.length - 1, 1);
  }
  const oldATR = avgATR(old20);
  const newATR = avgATR(new20);
  const atrRatio = oldATR > 0 ? newATR / oldATR : 1;

  // Trend yönü değişimi
  const oldTrend = old20[old20.length-1].c > old20[0].c ? 'UP' : 'DOWN';
  const newTrend = new20[new20.length-1].c > new20[0].c ? 'UP' : 'DOWN';
  const trendFlip = oldTrend !== newTrend;

  // Volatilite rejimi
  const oldIsRange = atrRatio < 0.8 || atrRatio > 1.2;
  const volExpansion = atrRatio > 1.5;
  const volContraction = atrRatio < 0.6;

  let score = 0;
  let newRegime = 'DEVAM';
  if (trendFlip) { score += 40; newRegime = `TREND_FLIP_${newTrend}`; }
  if (volExpansion) { score += 30; newRegime = 'BREAKOUT_START'; }
  if (volContraction) { score += 20; newRegime = 'RANGE_SIKI'; }
  if (trendFlip && volExpansion) { score += 20; newRegime = 'MAJOR_REVERSAL'; }

  return {
    detected: score >= 40,
    score: clamp(score),
    newRegime,
    oldTrend,
    newTrend,
    trendFlip,
    atrRatio: parseFloat(atrRatio.toFixed(3)),
    volExpansion,
    volContraction,
    verdict: score >= 70 ? `⚡ REJİM DEĞİŞİMİ: ${newRegime}` : score >= 40 ? `⚠ Rejim kayıyor: ${newRegime}` : `✓ Mevcut rejim devam`,
    timestamp: Date.now(),
  };
}

// ─── WHALE TRACE ENGINE (gelişmiş) ────────────────────────────────────────────
export function runWhaleTraceEngine(largeTrades = [], currentPrice = 0) {
  // largeTrades: [{amount, price, side, time}]
  if (!largeTrades.length) return { detected: false, score: 0, direction: 'NEUTRAL' };

  const threshold = currentPrice > 1000 ? 100 : currentPrice > 10 ? 10000 : 1000000;
  const whales = largeTrades.filter(t => t.amount > threshold);
  if (!whales.length) return { detected: false, score: 0, direction: 'NEUTRAL' };

  const buyWhales  = whales.filter(t => t.side === 'buy');
  const sellWhales = whales.filter(t => t.side === 'sell');
  const buyVolume  = buyWhales.reduce((s, t) => s + t.amount * t.price, 0);
  const sellVolume = sellWhales.reduce((s, t) => s + t.amount * t.price, 0);

  const totalVol   = buyVolume + sellVolume;
  const buyPct     = totalVol > 0 ? buyVolume / totalVol : 0.5;
  const imbalance  = Math.abs(buyPct - 0.5) * 2;

  const direction = buyPct > 0.6 ? 'ACCUMULATION' : buyPct < 0.4 ? 'DISTRIBUTION' : 'NEUTRAL';

  let score = clamp(imbalance * 80 + (whales.length / 5) * 20);

  return {
    detected: score >= 40,
    score: clamp(score),
    direction,
    whaleCount: whales.length,
    buyWhales: buyWhales.length,
    sellWhales: sellWhales.length,
    buyVolume: parseFloat(buyVolume.toFixed(0)),
    sellVolume: parseFloat(sellVolume.toFixed(0)),
    buyPct: parseFloat(buyPct.toFixed(3)),
    imbalance: parseFloat(imbalance.toFixed(3)),
    verdict: direction === 'ACCUMULATION' ? `🐋 BALINA BİRİKTİRİYOR (${buyWhales.length} işlem)` : direction === 'DISTRIBUTION' ? `🐋 BALINA DAĞITIYYOR (${sellWhales.length} işlem)` : `🐋 Balina hareketi nötr`,
    timestamp: Date.now(),
  };
}

// ─── WHALE INFLOW/OUTFLOW ENGINE ──────────────────────────────────────────────
export function runWhaleInflowOutflow(exchangeFlows = []) {
  // exchangeFlows: [{exchange, inflow, outflow, netFlow, time}]
  if (!exchangeFlows.length) return { netFlow: 0, signal: 'NEUTRAL', score: 0 };

  const recent = exchangeFlows.slice(-24); // son 24 saat
  const totalInflow  = recent.reduce((s, f) => s + (f.inflow  || 0), 0);
  const totalOutflow = recent.reduce((s, f) => s + (f.outflow || 0), 0);
  const netFlow = totalInflow - totalOutflow;

  // Borsa girişi = satış baskısı (satılmak üzere)
  // Borsa çıkışı = uzun dönem tutma (holding = bull)
  const inflowPressure  = netFlow > 0 && totalInflow > totalOutflow * 1.2;
  const outflowBullish  = netFlow < 0 && totalOutflow > totalInflow * 1.2;

  // Ani büyük giriş = dump yaklaşabilir
  const bigInflow = totalInflow > 1e9;

  let score = 0;
  let signal = 'NEUTRAL';
  if (outflowBullish) { score = clamp(Math.abs(netFlow) / 1e8 * 30 + 40); signal = 'BULLISH'; }
  else if (inflowPressure) { score = clamp(Math.abs(netFlow) / 1e8 * 30 + 30); signal = 'BEARISH'; }
  if (bigInflow) { score = Math.min(score + 20, 100); }

  return {
    netFlow: parseFloat(netFlow.toFixed(0)),
    totalInflow: parseFloat(totalInflow.toFixed(0)),
    totalOutflow: parseFloat(totalOutflow.toFixed(0)),
    score: clamp(score),
    signal,
    inflowPressure,
    outflowBullish,
    verdict: signal === 'BULLISH'
      ? `✅ Borsadan çıkış: ${(totalOutflow/1e6).toFixed(0)}M — HODLing güçlü`
      : signal === 'BEARISH'
      ? `⚠ Borsaya giriş: ${(totalInflow/1e6).toFixed(0)}M — Satış baskısı`
      : 'Dengeli akış',
    timestamp: Date.now(),
  };
}

// ─── SMART MONEY TRACKER ──────────────────────────────────────────────────────
export function runSmartMoneyTracker({
  institutionalFlows = [],   // ETF, OTC girişleri
  whaleTrace = {},
  exchangeReserve = {},
  orderFlowImbalance = 0,
}) {
  const instScore   = institutionalFlows.reduce((s, f) => s + (f.amount || 0), 0) / 1e8;
  const whaleScore  = (whaleTrace.score  || 0) * (whaleTrace.direction === 'ACCUMULATION' ? 1 : -0.5);
  const reserveScore = exchangeReserve.decreasing ? 30 : 0;
  const flowScore   = orderFlowImbalance * 0.3;

  const totalScore = clamp(instScore * 20 + whaleScore * 0.4 + reserveScore + flowScore);

  const signals = [];
  if (instScore > 2)   signals.push('KURUMSAL GİRİŞ');
  if (whaleTrace.direction === 'ACCUMULATION') signals.push('BALINA BİRİKİM');
  if (exchangeReserve.decreasing) signals.push('BORSA REZERVİ DÜŞÜYOR');

  return {
    score: clamp(totalScore),
    signals,
    isBullish: totalScore > 50,
    isBearish: totalScore < -20,
    verdict: totalScore > 60
      ? `✅ Akıllı para ALIYOR — ${signals.join(' + ')}`
      : totalScore > 30
      ? `📈 Pozitif akıllı para akışı`
      : totalScore < -20
      ? `⚠ Akıllı para ÇIKIYOR`
      : `Nötr`,
    timestamp: Date.now(),
  };
}

// ─── EXCHANGE RESERVE ENGINE ──────────────────────────────────────────────────
export function runExchangeReserveEngine(reserveHistory = []) {
  if (reserveHistory.length < 2) return { trend: 'UNKNOWN', score: 0 };

  const old = reserveHistory.slice(0, Math.floor(reserveHistory.length / 2));
  const nw  = reserveHistory.slice(Math.floor(reserveHistory.length / 2));
  const oldAvg = old.reduce((s, v) => s + v, 0) / Math.max(old.length, 1);
  const newAvg = nw.reduce((s, v) => s + v, 0)  / Math.max(nw.length, 1);
  const change = oldAvg > 0 ? (newAvg - oldAvg) / oldAvg * 100 : 0;

  const decreasing = change < -2;
  const increasing = change > 2;
  const rapid = Math.abs(change) > 5;

  return {
    trend: decreasing ? 'DECREASING' : increasing ? 'INCREASING' : 'STABLE',
    change: parseFloat(change.toFixed(2)),
    decreasing,
    increasing,
    rapid,
    score: clamp(Math.abs(change) * 8),
    verdict: decreasing
      ? `✅ Borsa rezervi azalıyor (${change.toFixed(1)}%) — HODLing artıyor`
      : increasing
      ? `⚠ Borsa rezervi artıyor (${change.toFixed(1)}%) — Satış baskısı`
      : `Dengeli rezerv`,
    timestamp: Date.now(),
  };
}

// ─── STRENGTH RANK ENGINE ─────────────────────────────────────────────────────
export function runStrengthRankEngine(coinData = []) {
  // coinData: [{symbol, change1h, change24h, change7d, volume, rsi}]
  if (!coinData.length) return { ranked: [], top: [], bottom: [] };

  const scored = coinData.map(c => {
    let score = 50;
    score += (c.change1h  || 0) * 5;
    score += (c.change24h || 0) * 3;
    score += (c.change7d  || 0) * 1;
    // RSI normalize
    const rsiScore = c.rsi ? (c.rsi - 50) * 0.3 : 0;
    score += rsiScore;
    // Hacim bonusu
    if (c.volume > 1e9) score += 5;

    return { ...c, strengthScore: clamp(parseFloat(score.toFixed(1))) };
  }).sort((a, b) => b.strengthScore - a.strengthScore);

  return {
    ranked: scored,
    top:    scored.slice(0, 5),
    bottom: scored.slice(-5),
    strongest: scored[0]?.symbol || '—',
    weakest:   scored[scored.length - 1]?.symbol || '—',
    timestamp: Date.now(),
  };
}

// ─── CRYPTO RISK SPREAD ENGINE ────────────────────────────────────────────────
export function runCryptoRiskSpreadEngine(coinData = [], btcChange = 0) {
  // Kripto içi risk dağılımı — hangi segmentler riskli?
  const segments = {
    largeCap:  coinData.filter(c => c.marketCapRank <= 10),
    midCap:    coinData.filter(c => c.marketCapRank > 10 && c.marketCapRank <= 50),
    smallCap:  coinData.filter(c => c.marketCapRank > 50 && c.marketCapRank <= 200),
    meme:      coinData.filter(c => c.type === 'meme'),
    defi:      coinData.filter(c => c.type === 'defi'),
    ai:        coinData.filter(c => c.type === 'ai'),
  };

  function avgChange(coins) {
    return coins.length ? coins.reduce((s, c) => s + (c.change24h || 0), 0) / coins.length : 0;
  }

  const segmentAnalysis = Object.entries(segments).map(([name, coins]) => ({
    name,
    avgChange: parseFloat(avgChange(coins).toFixed(2)),
    count: coins.length,
    risk: avgChange(coins) < btcChange - 5 ? 'HIGH' : avgChange(coins) > btcChange + 5 ? 'OUTPERFORM' : 'NORMAL',
  }));

  const highRiskSegments = segmentAnalysis.filter(s => s.risk === 'HIGH').map(s => s.name);

  return {
    segments: segmentAnalysis,
    highRiskSegments,
    overallRisk: highRiskSegments.length >= 3 ? 'YÜKSEK' : highRiskSegments.length >= 1 ? 'ORTA' : 'DÜŞÜK',
    verdict: highRiskSegments.length >= 3
      ? `⚠ Geniş tabanlı satış: ${highRiskSegments.join(', ')}`
      : `✓ Risk yayılımı normal`,
    timestamp: Date.now(),
  };
}

// ─── CRYPTO CONTAGION ENGINE ──────────────────────────────────────────────────
export function runCryptoContagionEngine({
  btcChange = 0,
  coinChanges = [],  // [{symbol, change}]
  threshold = -5,
}) {
  // BTC düştüğünde diğer coinlere bulaşma hızı ve genişliği
  if (btcChange > -2) return { contagion: false, score: 0, affectedCoins: [] };

  const affected = coinChanges.filter(c => c.change < btcChange - 2); // BTC'den daha kötü
  const severe   = coinChanges.filter(c => c.change < threshold);
  const contagionRatio = coinChanges.length > 0 ? affected.length / coinChanges.length : 0;

  let score = 0;
  if (contagionRatio > 0.6) score += 50;
  if (contagionRatio > 0.8) score += 20;
  if (severe.length > coinChanges.length * 0.3) score += 20;
  if (btcChange < -5) score += 10;

  return {
    contagion: score >= 50,
    score: clamp(score),
    contagionRatio: parseFloat(contagionRatio.toFixed(3)),
    affectedCoins: affected.slice(0, 10).map(c => c.symbol),
    severeCoins: severe.slice(0, 5).map(c => c.symbol),
    btcChange: parseFloat(btcChange.toFixed(2)),
    verdict: score >= 70
      ? `⛔ Bulaşma riski yüksek — ${(contagionRatio*100).toFixed(0)}% coin etkileniyor`
      : score >= 50
      ? `⚠ Bulaşma başladı — alt coinler zayıflıyor`
      : `BTC etkisi kontrollü`,
    timestamp: Date.now(),
  };
}
