/**
 * GRID MASTER GLOBAL — BACKTESTING ENGINE v1
 * ============================================
 * Geçmiş mum verisinde GMG sinyal sistemini test eder.
 *
 * ÖZELLİKLER:
 *   - 1ay / 3ay / 6ay / 1yıl periyot seçimi
 *   - Win rate, drawdown, max loss/gain
 *   - Council başarı istatistiği
 *   - Trade log (her sinyal kaydedilir)
 *   - Sharpe & Profit Factor hesabı
 *
 * KULLANIM:
 *   const result = await runBacktest({ symbol: 'BTCUSDT', interval: '4h', period: '3m' });
 */

import { clamp, computeRSI, ema } from './engineCore.js';

// ─── SABİTLER ────────────────────────────────────────────────────────────────
const BINANCE_KLINE_URL = 'https://api.binance.com/api/v3/klines';

const PERIOD_DAYS = {
  '1m':  30,
  '3m':  90,
  '6m':  180,
  '1y':  365,
};

const INTERVAL_MS = {
  '1m':   60_000,
  '5m':   300_000,
  '15m':  900_000,
  '1h':   3_600_000,
  '4h':   14_400_000,
  '1d':   86_400_000,
};

// ─── BINANCE GEÇMİŞ VERİ ÇEK ────────────────────────────────────────────────
async function fetchHistoricalKlines(symbol, interval, days) {
  const endTime   = Date.now();
  const startTime = endTime - days * 86_400_000;
  const limit     = 1000;
  let   allKlines = [];
  let   startMs   = startTime;

  // Binance max 1000 mum verir → iterasyon
  while (startMs < endTime) {
    const url = `${BINANCE_KLINE_URL}?symbol=${symbol}&interval=${interval}&startTime=${startMs}&endTime=${endTime}&limit=${limit}`;
    try {
      const res  = await fetch(url);
      const data = await res.json();
      if (!Array.isArray(data) || data.length === 0) break;
      allKlines = allKlines.concat(data);
      const lastTs = data[data.length - 1][6]; // closeTime
      startMs = lastTs + 1;
      if (data.length < limit) break;
    } catch (e) {
      console.error('[BACKTEST] Kline fetch hatası:', e.message);
      break;
    }
  }

  // Normalize
  return allKlines.map(k => ({
    openTime:  k[0],
    open:      parseFloat(k[1]),
    high:      parseFloat(k[2]),
    low:       parseFloat(k[3]),
    close:     parseFloat(k[4]),
    volume:    parseFloat(k[5]),
    closeTime: k[6],
  }));
}

// ─── HAM SİNYAL ÜRETME (basitleştirilmiş GMG motoru) ────────────────────────
function computeSignal(candles, i) {
  if (i < 50) return null; // Yeterli geçmiş yok

  const slice  = candles.slice(Math.max(0, i - 100), i + 1);
  const closes = slice.map(c => c.close);
  const vols   = slice.map(c => c.volume);
  const highs  = slice.map(c => c.high);
  const lows   = slice.map(c => c.low);
  const cur    = candles[i];

  // ── RSI ──
  const rsi = computeRSI(closes, 14);

  // ── EMA Trend ──
  const ema20 = ema(closes, 20);
  const ema50 = ema(closes, 50);
  const emaTrend = ema20 && ema50 ? (ema20 > ema50 ? 1 : -1) : 0;

  // ── Hacim artışı ──
  const avgVol = vols.slice(-20).reduce((a, b) => a + b, 0) / 20;
  const volSpike = cur.volume > avgVol * 1.5;

  // ── Mum formasyonu ──
  const body  = Math.abs(cur.close - cur.open);
  const range = cur.high - cur.low;
  const isBullEngulf = cur.close > cur.open && body / (range || 1) > 0.6;
  const isHammer     = cur.low < cur.open && cur.low < cur.close &&
                       (Math.min(cur.open, cur.close) - cur.low) > body * 2;

  // ── Destek / Direnç yakınlığı (basit) ──
  const recentLows  = lows.slice(-20);
  const nearSupport = recentLows.some(l => Math.abs(l - cur.close) / cur.close < 0.005);

  // ── Skor hesabı ──
  let score = 50;
  if (rsi < 35)       score += 15; // Oversold
  if (rsi > 65)       score -= 15; // Overbought
  if (emaTrend > 0)   score += 10;
  if (emaTrend < 0)   score -= 10;
  if (volSpike)       score += 8;
  if (isBullEngulf)   score += 10;
  if (isHammer)       score += 8;
  if (nearSupport)    score += 7;

  score = clamp(score);

  // ── Karar ──
  let action = 'BEKLE';
  if (score >= 65) action = 'AL';
  if (score <= 35) action = 'SAT';

  return { score, action, rsi, emaTrend, volSpike };
}

// ─── TRADE SİMÜLASYONU ───────────────────────────────────────────────────────
function simulateTrades(candles, signals, { tpPct = 3, slPct = 1.5 }) {
  const trades = [];
  let   openTrade = null;

  for (let i = 0; i < candles.length; i++) {
    const sig = signals[i];
    const cur = candles[i];

    // Açık trade var mı → TP/SL kontrolü
    if (openTrade) {
      const pctChange = (cur.close - openTrade.entryPrice) / openTrade.entryPrice * 100;
      const hitTP = cur.high >= openTrade.tp;
      const hitSL = cur.low  <= openTrade.sl;

      if (hitTP || hitSL || pctChange >= tpPct || pctChange <= -slPct) {
        const exitPrice = hitTP ? openTrade.tp : hitSL ? openTrade.sl : cur.close;
        const pnlPct    = (exitPrice - openTrade.entryPrice) / openTrade.entryPrice * 100;
        const result    = pnlPct >= 0 ? 'WIN' : 'LOSS';
        trades.push({
          ...openTrade,
          exitTime:  cur.closeTime,
          exitPrice,
          pnlPct:    parseFloat(pnlPct.toFixed(3)),
          result,
          exitReason: hitTP ? 'TP' : hitSL ? 'SL' : 'CLOSE',
          holdBars:   i - openTrade.entryIndex,
        });
        openTrade = null;
      }
    }

    // Yeni sinyal
    if (!openTrade && sig && sig.action === 'AL') {
      openTrade = {
        entryTime:  cur.openTime,
        entryPrice: cur.close,
        entryIndex: i,
        tp:         cur.close * (1 + tpPct / 100),
        sl:         cur.close * (1 - slPct / 100),
        score:      sig.score,
        rsi:        sig.rsi,
      };
    }
  }

  // Kapanmamış trade varsa force-close
  if (openTrade) {
    const last    = candles[candles.length - 1];
    const pnlPct  = (last.close - openTrade.entryPrice) / openTrade.entryPrice * 100;
    trades.push({
      ...openTrade,
      exitTime:   last.closeTime,
      exitPrice:  last.close,
      pnlPct:     parseFloat(pnlPct.toFixed(3)),
      result:     pnlPct >= 0 ? 'WIN' : 'LOSS',
      exitReason: 'FORCE_CLOSE',
      holdBars:   candles.length - 1 - openTrade.entryIndex,
    });
  }

  return trades;
}

// ─── İSTATİSTİK HESAPLA ──────────────────────────────────────────────────────
function computeStats(trades) {
  if (!trades.length) return {
    totalTrades: 0, winRate: 0, avgPnl: 0, totalPnl: 0,
    maxGain: 0, maxLoss: 0, maxDrawdown: 0, sharpe: 0, profitFactor: 0,
  };

  const wins   = trades.filter(t => t.result === 'WIN');
  const losses = trades.filter(t => t.result === 'LOSS');
  const pnls   = trades.map(t => t.pnlPct);

  const totalPnl   = pnls.reduce((a, b) => a + b, 0);
  const avgPnl     = totalPnl / trades.length;
  const maxGain    = Math.max(...pnls);
  const maxLoss    = Math.min(...pnls);

  // Drawdown hesabı
  let peak = 0, drawdown = 0, maxDD = 0, equity = 0;
  for (const p of pnls) {
    equity += p;
    if (equity > peak) peak = equity;
    drawdown = peak - equity;
    if (drawdown > maxDD) maxDD = drawdown;
  }

  // Sharpe (basit)
  const mean   = avgPnl;
  const stddev = Math.sqrt(pnls.map(p => (p - mean) ** 2).reduce((a, b) => a + b, 0) / pnls.length);
  const sharpe = stddev ? parseFloat((mean / stddev).toFixed(3)) : 0;

  // Profit Factor
  const grossWin  = wins.reduce((a, t) => a + t.pnlPct, 0);
  const grossLoss = Math.abs(losses.reduce((a, t) => a + t.pnlPct, 0));
  const profitFactor = grossLoss > 0 ? parseFloat((grossWin / grossLoss).toFixed(3)) : grossWin > 0 ? 999 : 0;

  // Council başarı istatistiği (sinyal skoru bazlı)
  const highScoreTrades = trades.filter(t => t.score >= 70);
  const highScoreWinRate = highScoreTrades.length
    ? highScoreTrades.filter(t => t.result === 'WIN').length / highScoreTrades.length * 100
    : 0;

  return {
    totalTrades:      trades.length,
    wins:             wins.length,
    losses:           losses.length,
    winRate:          parseFloat((wins.length / trades.length * 100).toFixed(1)),
    avgPnl:           parseFloat(avgPnl.toFixed(3)),
    totalPnl:         parseFloat(totalPnl.toFixed(2)),
    maxGain:          parseFloat(maxGain.toFixed(3)),
    maxLoss:          parseFloat(maxLoss.toFixed(3)),
    maxDrawdown:      parseFloat(maxDD.toFixed(3)),
    sharpe,
    profitFactor,
    highScoreWinRate: parseFloat(highScoreWinRate.toFixed(1)),
    avgHoldBars:      parseFloat((trades.reduce((a, t) => a + t.holdBars, 0) / trades.length).toFixed(1)),
  };
}

// ─── COUNCIL BAŞARI DAĞILIMI ─────────────────────────────────────────────────
function councilStats(trades) {
  const bands = [
    { label: 'Skor 80-100', min: 80,  max: 100 },
    { label: 'Skor 65-79',  min: 65,  max: 79  },
    { label: 'Skor 50-64',  min: 50,  max: 64  },
    { label: 'Skor <50',    min: 0,   max: 49  },
  ];

  return bands.map(b => {
    const group = trades.filter(t => t.score >= b.min && t.score <= b.max);
    const wins  = group.filter(t => t.result === 'WIN').length;
    return {
      band:      b.label,
      count:     group.length,
      winRate:   group.length ? parseFloat((wins / group.length * 100).toFixed(1)) : 0,
      avgPnl:    group.length ? parseFloat((group.reduce((a, t) => a + t.pnlPct, 0) / group.length).toFixed(3)) : 0,
    };
  });
}

// ─── ANA BACKTEST FONKSİYONU ─────────────────────────────────────────────────
/**
 * runBacktest — Ana backtest çalıştırıcı
 *
 * @param {object} params
 *   symbol   — 'BTCUSDT', 'ETHUSDT' vb.
 *   interval — '1h', '4h', '1d' vb.
 *   period   — '1m', '3m', '6m', '1y'
 *   tpPct    — Take profit yüzdesi (default: 3)
 *   slPct    — Stop loss yüzdesi (default: 1.5)
 */
export async function runBacktest({ symbol = 'BTCUSDT', interval = '4h', period = '3m', tpPct = 3, slPct = 1.5 } = {}) {
  const startTs = Date.now();
  const days    = PERIOD_DAYS[period] || 90;

  console.log(`[BACKTEST] Başlıyor: ${symbol} ${interval} ${period} (${days} gün)`);

  // 1. Veri çek
  const candles = await fetchHistoricalKlines(symbol, interval, days);
  if (candles.length < 60) {
    return { error: 'Yetersiz veri', candles: candles.length };
  }

  // 2. Her mum için sinyal üret
  const signals = candles.map((_, i) => computeSignal(candles, i));

  // 3. Trade simüle et
  const trades = simulateTrades(candles, signals, { tpPct, slPct });

  // 4. İstatistik hesapla
  const stats   = computeStats(trades);
  const council = councilStats(trades);

  const elapsed = ((Date.now() - startTs) / 1000).toFixed(2);

  return {
    symbol,
    interval,
    period,
    tpPct,
    slPct,
    candleCount:  candles.length,
    tradeLog:     trades,
    stats,
    councilStats: council,
    timestamp:    new Date().toISOString(),
    elapsedSec:   parseFloat(elapsed),
    summary: `${symbol} ${interval} ${period}: ${stats.totalTrades} işlem, WR=${stats.winRate}%, PnL=${stats.totalPnl}%, DD=${stats.maxDrawdown}%`,
  };
}

// ─── ÇOKLU SEMBOL BACKTEST ───────────────────────────────────────────────────
/**
 * runMultiBacktest — Birden fazla sembol için toplu test
 *
 * @param {string[]} symbols  — ['BTCUSDT','ETHUSDT','SOLUSDT']
 * @param {object}   options  — interval, period, tpPct, slPct
 */
export async function runMultiBacktest(symbols = [], options = {}) {
  const results = [];
  for (const symbol of symbols) {
    try {
      const r = await runBacktest({ symbol, ...options });
      results.push(r);
    } catch (e) {
      results.push({ symbol, error: e.message });
    }
  }

  // Genel özet
  const valid   = results.filter(r => r.stats);
  const avgWR   = valid.length ? valid.reduce((a, r) => a + r.stats.winRate, 0) / valid.length : 0;
  const avgPnl  = valid.length ? valid.reduce((a, r) => a + r.stats.totalPnl, 0) / valid.length : 0;

  return {
    results,
    summary: {
      tested:   symbols.length,
      success:  valid.length,
      avgWinRate: parseFloat(avgWR.toFixed(1)),
      avgTotalPnl: parseFloat(avgPnl.toFixed(2)),
    },
    timestamp: new Date().toISOString(),
  };
}

// ─── BACKTEST ÖZET RAPORU (UI için) ─────────────────────────────────────────
/**
 * getBacktestSummary — Dashboard'a kısa özet ver
 */
export function getBacktestSummary(backtestResult) {
  if (!backtestResult || backtestResult.error) {
    return { score: 0, summary: 'Backtest verisi yok', timestamp: new Date().toISOString() };
  }
  const s = backtestResult.stats;
  const score = clamp(
    (s.winRate > 60 ? 30 : s.winRate > 50 ? 15 : 0) +
    (s.profitFactor > 1.5 ? 25 : s.profitFactor > 1 ? 12 : 0) +
    (s.maxDrawdown < 5 ? 25 : s.maxDrawdown < 10 ? 12 : 0) +
    (s.sharpe > 1 ? 20 : s.sharpe > 0.5 ? 10 : 0)
  );
  return {
    score,
    winRate:       s.winRate,
    totalPnl:      s.totalPnl,
    maxDrawdown:   s.maxDrawdown,
    profitFactor:  s.profitFactor,
    sharpe:        s.sharpe,
    totalTrades:   s.totalTrades,
    summary:       `WR:${s.winRate}% | PF:${s.profitFactor} | DD:${s.maxDrawdown}%`,
    timestamp:     backtestResult.timestamp,
  };
}
