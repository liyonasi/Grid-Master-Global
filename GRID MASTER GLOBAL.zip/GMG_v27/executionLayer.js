/**
 * GMG — EXECUTION LAYER (TAM)
 * =============================
 * Final Council kararı buradan geçer.
 * 
 * Katmanlar:
 * 1. FALSE SIGNAL FILTER     — Sahte sinyal tespiti
 * 2. MANIPULATION FILTER     — Manipülasyon tespiti
 * 3. RISK FILTER             — Risk seviyesi kontrolü
 * 4. RISK VETO MECHANISM     — Yüksek risk = override
 * 5. DOUBLE CONFIRM          — Çift onay protokolü
 * 6. FINAL EXECUTION SIGNAL  — BUY / SELL / WAIT
 */

// ─── 1. FALSE SIGNAL FILTER ──────────────────────────────────────────────────
/**
 * Sahte sinyal tespiti:
 * - Konsey oyları bölünmüş mü?
 * - Sinyal gücü yeterli mi?
 * - Hacim onayı var mı?
 * - Son N barda sinyal var mıydı (çift sinyal)?
 */
export function falseSignalFilter({
  councilScores,      // { alpha, flow, risk, macro, news }
  finalScore,         // 0-100
  volumeZScore,       // hacim z-score
  lastSignalBarsAgo,  // kaç bar önce son sinyal vardı
  pineSignal,         // { buySignal, sellSignal, pbBuy, pbSell }
  minCouncilAgreement = 3, // kaç konsey hemfikir olmalı (3/5)
  minSignalStrength   = 55,
  minVolumeZScore     = -0.5,
  minBarsSinceLastSig = 3,
} = {}) {
  const reasons = [];
  let passed = true;

  // Konsey anlaşması kontrolü
  const isBull = finalScore >= 55;
  const isBear = finalScore <= 45;
  const councilList = [
    councilScores.alpha,
    councilScores.flow,
    councilScores.risk,
    councilScores.macro,
    councilScores.news || 50,
  ];

  const agreeingBull = councilList.filter(s => s >= 55).length;
  const agreeingBear = councilList.filter(s => s <= 45).length;
  const agreeing = isBull ? agreeingBull : isBear ? agreeingBear : 0;

  if (agreeing < minCouncilAgreement) {
    passed = false;
    reasons.push(`Konsey anlaşması yetersiz: ${agreeing}/${councilList.length} (min ${minCouncilAgreement})`);
  }

  // Sinyal gücü
  const absStrength = Math.abs(finalScore - 50) * 2; // 0-100
  if (absStrength < (minSignalStrength - 50) * 2) {
    passed = false;
    reasons.push(`Sinyal gücü zayıf: ${finalScore}/100`);
  }

  // Hacim onayı
  if (volumeZScore !== undefined && volumeZScore < minVolumeZScore) {
    passed = false;
    reasons.push(`Hacim onayı yok: z-score ${volumeZScore?.toFixed(2)}`);
  }

  // Çift sinyal önleme
  if (lastSignalBarsAgo !== undefined && lastSignalBarsAgo < minBarsSinceLastSig) {
    passed = false;
    reasons.push(`Çok yakın sinyal: ${lastSignalBarsAgo} bar önce`);
  }

  // Pine sinyal onayı — aynı yönde mi?
  if (pineSignal) {
    if (isBull && pineSignal.sellSignal && !pineSignal.buySignal) {
      passed = false;
      reasons.push('Range Filter ters yön: SELL sinyali aktif');
    }
    if (isBear && pineSignal.buySignal && !pineSignal.sellSignal) {
      passed = false;
      reasons.push('Range Filter ters yön: BUY sinyali aktif');
    }
  }

  return {
    passed,
    reasons,
    agreeing,
    absStrength: parseFloat(absStrength.toFixed(1)),
  };
}

// ─── 2. MANIPULATION FILTER ──────────────────────────────────────────────────
/**
 * Manipülasyon tespiti:
 * - Stop hunt aktif mi?
 * - Fake breakout var mı?
 * - Spoofing tespit edildi mi?
 * - Likidite tuzağı var mı?
 * - Pine indikatörden: S/R kırılım sahte mi?
 */
export function manipulationFilter({
  stopHunts        = [],
  scalpTraps       = [],
  liqTraps         = [],
  pineData         = null,
  orderbookImbalance = 0.5,
  maxStopHunts     = 1,
  maxScalpTraps    = 2,
  maxLiqTraps      = 1,
} = {}) {
  const warnings = [];
  let manipScore = 0; // 0-100, yüksek = manipülatif

  // Stop hunt
  if (stopHunts.length > 0) {
    manipScore += stopHunts.length * 20;
    warnings.push(`${stopHunts.length} stop hunt sinyali aktif`);
  }

  // Scalp tuzak
  if (scalpTraps.length > maxScalpTraps) {
    manipScore += (scalpTraps.length - maxScalpTraps) * 10;
    warnings.push(`${scalpTraps.length} scalp tuzağı tespit edildi`);
  }

  // Liq trap
  if (liqTraps.length > 0) {
    manipScore += liqTraps.length * 15;
    warnings.push(`${liqTraps.length} likidite tuzağı`);
  }

  // Orderbook extreme imbalance (spoofing işareti)
  if (orderbookImbalance > 0.85 || orderbookImbalance < 0.15) {
    manipScore += 25;
    warnings.push(`Aşırı OB dengesizliği: ${(orderbookImbalance * 100).toFixed(0)}%`);
  }

  // Pine: S/R kanal içinde fiyat + ters sinyal = tuzak olabilir
  if (pineData?.pb?.inAnyChannel && pineData?.rf?.buySignal && pineData?.rf?.trendDown) {
    manipScore += 20;
    warnings.push('S/R kanal içi + ters trend = potansiyel tuzak');
  }

  const isManipulated = manipScore >= 50;
  const severity =
    manipScore >= 75 ? 'KRİTİK' :
    manipScore >= 50 ? 'YÜKSEK' :
    manipScore >= 25 ? 'ORTA'   : 'DÜŞÜK';

  return {
    isManipulated,
    manipScore: Math.min(100, manipScore),
    severity,
    warnings,
  };
}

// ─── 3. RISK FILTER ──────────────────────────────────────────────────────────
/**
 * Risk seviyesi kontrolü:
 * - Risk Council skoru
 * - Volatilite rejimi
 * - Funding rate aşırı mı?
 * - Likidasyon bölgesi yakın mı?
 */
export function riskFilter({
  riskCouncilScore = 50,   // yüksek = güvenli
  vixLevel         = 50,
  fundingRates     = [],   // [{ ex, rate }]
  volatilityZScore = 0,
  nearLiquidation  = false,
  maxFundingRate   = 0.1,  // %0.1
  maxVolZScore     = 2.5,
} = {}) {
  const flags = [];
  let riskPenalty = 0;

  // Risk Council
  if (riskCouncilScore < 30) {
    riskPenalty += 30;
    flags.push(`Risk Council kritik: ${riskCouncilScore}/100`);
  } else if (riskCouncilScore < 50) {
    riskPenalty += 15;
    flags.push(`Risk Council yüksek: ${riskCouncilScore}/100`);
  }

  // VIX
  if (vixLevel > 80) {
    riskPenalty += 25;
    flags.push(`VIX çok yüksek: ${vixLevel?.toFixed(1)}`);
  } else if (vixLevel > 60) {
    riskPenalty += 10;
    flags.push(`VIX yüksek: ${vixLevel?.toFixed(1)}`);
  }

  // Funding rate
  const avgFunding = fundingRates.length
    ? fundingRates.reduce((s, f) => s + Math.abs(f.rate || 0), 0) / fundingRates.length
    : 0;
  if (avgFunding > maxFundingRate) {
    riskPenalty += 20;
    flags.push(`Aşırı funding: ${avgFunding.toFixed(4)}%`);
  }

  // Volatilite
  if (Math.abs(volatilityZScore) > maxVolZScore) {
    riskPenalty += 15;
    flags.push(`Aşırı volatilite: z=${volatilityZScore?.toFixed(2)}`);
  }

  // Likidasyon bölgesi
  if (nearLiquidation) {
    riskPenalty += 20;
    flags.push('Likidasyon bölgesi yakın');
  }

  const adjustedScore = Math.max(0, 100 - riskPenalty);
  const riskLevel =
    adjustedScore >= 70 ? 'DÜŞÜK' :
    adjustedScore >= 50 ? 'ORTA'  :
    adjustedScore >= 30 ? 'YÜKSEK' : 'KRİTİK';

  return {
    adjustedScore,
    riskLevel,
    riskPenalty,
    flags,
    isAcceptable: adjustedScore >= 40,
  };
}

// ─── 4. RISK VETO MECHANISM ───────────────────────────────────────────────────
/**
 * Risk Council veto yetkisi:
 * - Risk KRİTİK → her kararı WAIT'e çevirir
 * - Risk YÜKSEK → AL sinyalini zayıflatır
 * - Manipülasyon KRİTİK → her kararı WAIT'e çevirir
 */
export function applyRiskVeto({
  proposedAction,   // 'BUY' | 'SELL' | 'WAIT'
  proposedScore,
  riskLevel,        // 'DÜŞÜK' | 'ORTA' | 'YÜKSEK' | 'KRİTİK'
  manipSeverity,    // 'DÜŞÜK' | 'ORTA' | 'YÜKSEK' | 'KRİTİK'
  falseSignalPassed,
} = {}) {
  let finalAction = proposedAction;
  let finalScore  = proposedScore;
  const vetoes    = [];

  // Kritik risk → WAIT
  if (riskLevel === 'KRİTİK') {
    finalAction = 'WAIT';
    finalScore  = 50;
    vetoes.push('VETO: Risk seviyesi KRİTİK — WAIT');
  }

  // Kritik manipülasyon → WAIT
  if (manipSeverity === 'KRİTİK') {
    finalAction = 'WAIT';
    finalScore  = 50;
    vetoes.push('VETO: Manipülasyon KRİTİK — WAIT');
  }

  // Yüksek risk + AL sinyali → zayıflat
  if (riskLevel === 'YÜKSEK' && finalAction === 'BUY') {
    finalAction = 'WAIT';
    finalScore  = Math.max(50, finalScore - 15);
    vetoes.push('VETO: Yüksek risk — AL → BEKLE');
  }

  // False signal → WAIT
  if (!falseSignalPassed) {
    finalAction = 'WAIT';
    finalScore  = 50;
    vetoes.push('VETO: False signal filtresi geçilemedi — WAIT');
  }

  const wasVetoed = vetoes.length > 0;

  return {
    finalAction,
    finalScore: Math.round(Math.max(0, Math.min(100, finalScore))),
    wasVetoed,
    vetoes,
  };
}

// ─── 5. DOUBLE CONFIRM PROTOCOL ──────────────────────────────────────────────
/**
 * Çift onay — sinyal en az N dakika / N bar boyunca devam etmeli
 * Pine indikatör: CondIni flip onayı
 * Council: ardışık bar onayı
 */
export function doubleConfirmProtocol({
  action,
  currentScore,
  prevScore,
  pineSignal,
  requireBars = 1,
  barCount    = 0,    // kaç bardır bu sinyal devam ediyor
} = {}) {
  const confirmed = [];
  const pending   = [];
  let isConfirmed = true;

  // Bar devam onayı
  if (barCount < requireBars) {
    isConfirmed = false;
    pending.push(`Bar onayı bekleniyor: ${barCount}/${requireBars}`);
  } else {
    confirmed.push(`Bar onayı: ${barCount} bar`);
  }

  // Pine Range Filter onayı
  if (action === 'BUY') {
    if (pineSignal?.rfTrendUp) {
      confirmed.push('Range Filter: YUKARI trend onaylı');
    } else if (pineSignal?.rfTrendDown) {
      isConfirmed = false;
      pending.push('Range Filter: AŞAĞI trend — ters sinyal');
    }
    if (pineSignal?.pbBuy) {
      confirmed.push('PB-AL aktif');
    }
  }

  if (action === 'SELL') {
    if (pineSignal?.rfTrendDown) {
      confirmed.push('Range Filter: AŞAĞI trend onaylı');
    } else if (pineSignal?.rfTrendUp) {
      isConfirmed = false;
      pending.push('Range Filter: YUKARI trend — ters sinyal');
    }
    if (pineSignal?.pbSell) {
      confirmed.push('PB-SAT aktif');
    }
  }

  // Score tutarlılığı
  if (prevScore !== undefined) {
    const sameSide = (action === 'BUY' && prevScore >= 50) || (action === 'SELL' && prevScore <= 50);
    if (!sameSide) {
      isConfirmed = false;
      pending.push(`Önceki bar skoru tutarsız: ${prevScore}`);
    }
  }

  return {
    isConfirmed,
    confirmed,
    pending,
    action: isConfirmed ? action : 'WAIT',
  };
}

// ─── 6. EXECUTION LAYER ANA MOTORU ───────────────────────────────────────────
/**
 * Final Council kararını tüm filtrelerden geçirir.
 * Çıkış: BUY / SELL / WAIT + gerekçe
 */
export function runExecutionLayer({
  // Council çıktıları
  councilScores,       // { alpha, flow, risk, macro, news }
  finalScore,          // 0-100
  proposedAction,      // 'BUY' | 'SELL' | 'WAIT'

  // Pine indikatör
  pineSignal,          // runPineEngine() çıktısı

  // Risk verileri
  riskCouncilScore,
  vixLevel,
  fundingRates,
  volatilityZScore,
  nearLiquidation,

  // Tarama verileri
  stopHunts,
  scalpTraps,
  liqTraps,
  orderbookImbalance,
  volumeZScore,

  // Trap Detection (yeni)
  trapScore        = 0,
  wickManipulation = false,
  panicNews        = false,

  // Geçmiş sinyal
  lastSignalBarsAgo,
  prevFinalScore,
  signalBarCount,
} = {}) {

  // 0. Trap Score Veto (trapDetectionEngine)
  const trapVeto = trapScore > 70 || wickManipulation;
  if (trapVeto) {
    return {
      action: 'WAIT', label: 'BEKLE — TUZAK TESPİT', score: Math.min(finalScore, 35),
      color: '#ff0055', confidence: 0, riskLevel: 'KRİTİK', riskColor: '#ff0055',
      filters: {
        falseSignal:    { blocked: false, reason: '' },
        manipulation:   { blocked: true,  reason: 'Tuzak tespit edildi' },
        risk:           { blocked: false, reason: '' },
        veto:           { wasVetoed: true, reason: `TrapScore: ${trapScore}, Wick: ${wickManipulation}` },
        doubleConfirm:  { passed: false },
      },
    };
  }

  // 0b. Panic News Veto
  if (panicNews) {
    return {
      action: 'WAIT', label: 'BEKLE — PANİK HABER', score: Math.min(finalScore, 40),
      color: '#ff6d00', confidence: 10, riskLevel: 'YÜKSEK', riskColor: '#ff6d00',
      filters: {
        falseSignal:   { blocked: false, reason: '' },
        manipulation:  { blocked: false, reason: '' },
        risk:          { blocked: true, reason: 'Panik haberi aktif' },
        veto:          { wasVetoed: true, reason: 'Panik haberi veto' },
        doubleConfirm: { passed: false },
      },
    };
  }

  // 1. False Signal Filter
  const fsResult = falseSignalFilter({
    councilScores,
    finalScore,
    volumeZScore,
    lastSignalBarsAgo,
    pineSignal: pineSignal?.technicalSignal,
    minCouncilAgreement: 3,
    minSignalStrength:   55,
  });

  // 2. Manipulation Filter
  const manipResult = manipulationFilter({
    stopHunts:          stopHunts || [],
    scalpTraps:         scalpTraps || [],
    liqTraps:           liqTraps || [],
    pineData:           pineSignal,
    orderbookImbalance: orderbookImbalance || 0.5,
  });

  // 3. Risk Filter
  const riskResult = riskFilter({
    riskCouncilScore,
    vixLevel,
    fundingRates:    fundingRates || [],
    volatilityZScore: volatilityZScore || 0,
    nearLiquidation: nearLiquidation || false,
  });

  // 4. Risk Veto
  const vetoResult = applyRiskVeto({
    proposedAction,
    proposedScore:    finalScore,
    riskLevel:        riskResult.riskLevel,
    manipSeverity:    manipResult.severity,
    falseSignalPassed: fsResult.passed,
  });

  // 5. Double Confirm
  const confirmResult = doubleConfirmProtocol({
    action:       vetoResult.finalAction,
    currentScore: vetoResult.finalScore,
    prevScore:    prevFinalScore,
    pineSignal:   pineSignal?.technicalSignal,
    requireBars:  1,
    barCount:     signalBarCount || 0,
  });

  // ─── FINAL EXECUTION SIGNAL ──────────────────────────────
  const execAction = confirmResult.action;
  const execScore  = vetoResult.finalScore;

  const execColor =
    execAction === 'BUY'  ? '#00e676' :
    execAction === 'SELL' ? '#ff1744' : '#ffd600';

  const execLabel =
    execAction === 'BUY'  && execScore >= 75 ? 'GÜÇLÜ AL' :
    execAction === 'BUY'                      ? 'AL' :
    execAction === 'SELL' && execScore <= 25  ? 'GÜÇLÜ SAT' :
    execAction === 'SELL'                     ? 'SAT' :
    'BEKLE';

  // Güven skoru
  const confidence = Math.round(Math.min(95, Math.max(20,
    30 +
    (fsResult.passed ? 15 : 0) +
    (!manipResult.isManipulated ? 15 : 0) +
    (riskResult.isAcceptable ? 10 : 0) +
    (confirmResult.isConfirmed ? 15 : 0) +
    Math.abs(execScore - 50) * 0.5
  )));

  // Gerekçe özeti
  const summary = [
    `False Signal: ${fsResult.passed ? '✓ GEÇTİ' : '✗ BLOK'}`,
    `Manipülasyon: ${manipResult.severity}`,
    `Risk: ${riskResult.riskLevel}`,
    `Veto: ${vetoResult.wasVetoed ? vetoResult.vetoes[0] : 'YOK'}`,
    `Onay: ${confirmResult.isConfirmed ? '✓ ONAYLANDI' : '⏳ BEKLIYOR'}`,
    ...(pineSignal ? [`Range Filter: ${pineSignal.technicalSignal?.rfTrendDir || '—'} | PB: ${pineSignal.pb?.pbBuy ? 'AL' : pineSignal.pb?.pbSell ? 'SAT' : '-'}`] : []),
  ];

  return {
    // Ana çıktı
    action:     execAction,
    label:      execLabel,
    score:      execScore,
    color:      execColor,
    confidence,

    // Filtre detayları
    filters: {
      falseSignal:    fsResult,
      manipulation:   manipResult,
      risk:           riskResult,
      veto:           vetoResult,
      doubleConfirm:  confirmResult,
    },

    // Özet
    summary,
    riskLevel:  riskResult.riskLevel,
    riskColor:  riskResult.riskLevel === 'DÜŞÜK' ? '#00e676' :
                riskResult.riskLevel === 'ORTA'  ? '#ffd600' :
                riskResult.riskLevel === 'YÜKSEK'? '#ff6d00' : '#ff1744',

    timestamp: Date.now(),
  };
}
