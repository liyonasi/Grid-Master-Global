/**
 * DipOnayPanel.jsx — GMG v14
 * dipOnaylayici.js çıktısını görsel olarak gösterir.
 * Dashboard sol panelin "🎯 Dip Onay" sekmesinde render edilir.
 */

import React, { useState } from 'react';

// ─── RENK HARİTASI ────────────────────────────────────────────────────────────
function scoreColor(score) {
  if (score >= 75) return '#00e676';
  if (score >= 55) return '#7eff7e';
  if (score >= 40) return '#ffd600';
  return '#ff1744';
}

function verdictColor(verdict) {
  if (!verdict) return '#444466';
  if (verdict.includes('GÜÇLÜ'))   return '#00e676';
  if (verdict.includes('ONAYLI'))   return '#7eff7e';
  if (verdict.includes('ŞÜPHELİ')) return '#ffd600';
  return '#ff1744';
}

function ScoreBar({ score, color }) {
  return (
    <div style={{ background: '#0a0a1c', borderRadius: 2, height: 4, width: '100%' }}>
      <div style={{
        width: `${Math.min(100, score)}%`,
        height: '100%',
        background: color,
        borderRadius: 2,
        transition: 'width 0.4s ease',
      }} />
    </div>
  );
}

function CoinRow({ coin }) {
  const [expanded, setExpanded] = useState(false);
  const col = scoreColor(coin.dipScore);
  const vc  = verdictColor(coin.verdict);

  return (
    <div
      className="border-b border-[#0f0f22] cursor-pointer"
      style={{ background: expanded ? '#07071a' : 'transparent' }}
      onClick={() => setExpanded(v => !v)}
    >
      {/* Ana satır */}
      <div className="flex items-center gap-1 px-2 py-1.5">
        {/* Sembol */}
        <span className="text-[10px] font-mono font-bold text-gray-300 w-16 truncate">
          {coin.symbol}
        </span>

        {/* Skor bar */}
        <div className="flex-1">
          <ScoreBar score={coin.dipScore} color={col} />
        </div>

        {/* Skor sayı */}
        <span className="text-[9px] font-mono font-bold w-8 text-right" style={{ color: col }}>
          {coin.dipScore ?? 0}
        </span>

        {/* Verdict badge */}
        <span
          className="text-[7px] font-mono px-1 py-0.5 rounded w-16 text-center truncate"
          style={{ color: vc, background: vc + '15', border: `1px solid ${vc}25` }}
        >
          {coin.verdict || '—'}
        </span>

        {/* RSI */}
        <span className="text-[8px] font-mono text-gray-600 w-10 text-right">
          RSI {coin.rsi?.toFixed(0) ?? '—'}
        </span>

        {/* 24s değişim */}
        <span
          className="text-[8px] font-mono w-12 text-right"
          style={{ color: (coin.change24h ?? 0) >= 0 ? '#00e676' : '#ff4466' }}
        >
          {(coin.change24h ?? 0) >= 0 ? '+' : ''}{(coin.change24h ?? 0).toFixed(1)}%
        </span>

        {/* Expand arrow */}
        <span className="text-[8px] text-gray-700 ml-1">{expanded ? '▲' : '▼'}</span>
      </div>

      {/* Genişletilmiş detay */}
      {expanded && (
        <div className="px-3 pb-2 pt-0.5 space-y-1">
          {/* Katman skorları */}
          {coin.layers && (
            <div className="grid grid-cols-4 gap-1">
              {Object.entries(coin.layers).map(([key, val]) => (
                <div key={key} className="text-center">
                  <div className="text-[7px] font-mono text-gray-700 truncate">{key}</div>
                  <div className="text-[8px] font-mono font-bold" style={{ color: scoreColor(val) }}>
                    {val}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Kritik uyarılar */}
          {coin.criticalFail && (
            <div className="text-[8px] font-mono text-[#ff1744] bg-[#ff174410] px-2 py-1 rounded">
              ⛔ Kritik: {coin.criticalFailReason || 'Koşul sağlanamadı'}
            </div>
          )}

          {/* Fiyat */}
          <div className="flex justify-between text-[8px] font-mono text-gray-600">
            <span>Fiyat: ${coin.price > 1 ? coin.price.toFixed(2) : coin.price.toFixed(6)}</span>
            <span>BB: {coin.bbPosition != null ? (coin.bbPosition * 100).toFixed(0) + '%' : '—'}</span>
            <span>Vol Z: {coin.volumeZScore != null ? coin.volumeZScore.toFixed(2) : '—'}</span>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── ANA PANEL ────────────────────────────────────────────────────────────────
export default function DipOnayPanel({ dipData, loading }) {
  const [tab, setTab] = useState('confirmed'); // confirmed | suspicious | all

  if (loading && !dipData) {
    return (
      <div className="flex items-center justify-center h-24 text-[9px] font-mono text-gray-600 animate-pulse">
        Dip analizi yükleniyor...
      </div>
    );
  }

  if (!dipData) {
    return (
      <div className="flex items-center justify-center h-24 text-[9px] font-mono text-gray-700">
        Dip verisi yok — tarama bekleniyor
      </div>
    );
  }

  const { confirmed, suspicious, all, stats } = dipData;

  const tabData = {
    confirmed:  confirmed  || [],
    suspicious: suspicious || [],
    all:        all        || [],
  };

  const tabCounts = {
    confirmed:  confirmed?.length  || 0,
    suspicious: suspicious?.length || 0,
    all:        all?.length        || 0,
  };

  const tabColors = {
    confirmed:  '#00e676',
    suspicious: '#ffd600',
    all:        '#00b0ff',
  };

  return (
    <div className="bg-[#050510] border border-[#1a1a2e] rounded overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-[#1a1a2e]">
        <span className="text-[9px] font-mono font-bold text-gray-400 tracking-wider">
          🎯 DİP ONAYLAYICI
        </span>
        {stats && (
          <span className="text-[8px] font-mono text-gray-700">
            {stats.confirmed} onaylı / {stats.total} aday
          </span>
        )}
      </div>

      {/* Top dip varsa banner */}
      {stats?.topDip && (
        <div className="px-3 py-1.5 border-b border-[#1a1a2e]"
          style={{ background: `${scoreColor(stats.topDip.dipScore)}08` }}>
          <div className="flex items-center justify-between">
            <span className="text-[9px] font-mono font-bold"
              style={{ color: scoreColor(stats.topDip.dipScore) }}>
              ⭐ En Güçlü Dip: {stats.topDip.symbol}
            </span>
            <span className="text-[9px] font-mono" style={{ color: scoreColor(stats.topDip.dipScore) }}>
              {stats.topDip.dipScore}/100 — {stats.topDip.verdict}
            </span>
          </div>
        </div>
      )}

      {/* Sekme seçici */}
      <div className="flex border-b border-[#1a1a2e]">
        {[
          { id: 'confirmed',  label: 'Onaylı'   },
          { id: 'suspicious', label: 'Şüpheli'  },
          { id: 'all',        label: 'Tümü'      },
        ].map(t => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className="flex-1 py-1.5 text-[8px] font-mono font-bold uppercase tracking-wider transition-all"
            style={{
              color:      tab === t.id ? tabColors[t.id] : '#333355',
              background: tab === t.id ? `${tabColors[t.id]}12` : 'transparent',
              borderBottom: tab === t.id ? `2px solid ${tabColors[t.id]}` : '2px solid transparent',
            }}
          >
            {t.label} ({tabCounts[t.id]})
          </button>
        ))}
      </div>

      {/* Kolon başlıkları */}
      <div className="flex items-center gap-1 px-2 py-1 bg-[#08081a]">
        <span className="text-[7px] font-mono text-gray-700 w-16">SEM.</span>
        <span className="flex-1 text-[7px] font-mono text-gray-700">SKOR</span>
        <span className="text-[7px] font-mono text-gray-700 w-8 text-right">PT</span>
        <span className="text-[7px] font-mono text-gray-700 w-16 text-center">KARAR</span>
        <span className="text-[7px] font-mono text-gray-700 w-10 text-right">RSI</span>
        <span className="text-[7px] font-mono text-gray-700 w-12 text-right">24s</span>
        <span className="w-4" />
      </div>

      {/* Liste */}
      <div style={{ maxHeight: 320, overflowY: 'auto' }}>
        {tabData[tab].length === 0 ? (
          <div className="flex items-center justify-center h-16 text-[9px] font-mono text-gray-700">
            {tab === 'confirmed' ? 'Onaylı dip adayı yok' :
             tab === 'suspicious' ? 'Şüpheli aday yok' : 'Aday yok'}
          </div>
        ) : (
          tabData[tab].map((coin, i) => <CoinRow key={coin.symbol || i} coin={coin} />)
        )}
      </div>

      {/* Footer */}
      <div className="px-3 py-1.5 border-t border-[#1a1a2e] flex justify-between">
        <span className="text-[7px] font-mono text-gray-700">
          8 katmanlı analiz · RSI + MACD + BB + Hacim + ATR + Formasyon + MTF
        </span>
        {dipData.timestamp && (
          <span className="text-[7px] font-mono text-gray-700">
            {new Date(dipData.timestamp).toLocaleTimeString('tr-TR')}
          </span>
        )}
      </div>
    </div>
  );
}
