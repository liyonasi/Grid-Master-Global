/**
 * macroAPIEngine.js — GMG v21
 * ===========================
 * Gerçek makro veri çekiciler:
 *
 *   DXY      → stooq.com (^dxy) → FRED (DTWEXBGS) → EUR/USD proxy
 *   US10Y    → stooq.com (10us.b) → FRED (DGS10) → sabit fallback
 *   US2Y     → stooq.com (2us.b) → FRED (DGS2)
 *   VIX      → stooq.com (^vix) → BTC vol proxy
 *   GOLD     → stooq.com (xauusd) → metals.live → goldprice.org
 *   OIL(WTI) → stooq.com (cl.f) → Brent fallback
 *   FEAR&GREED → alternative.me (direkt, proxy gerekmez)
 *
 * Proxy zinciri (CORS bypass):
 *   1. corsproxy.io  2. allorigins.win  3. codetabs.com
 *
 * Cache: TTL tabanlı (DXY/US10Y: 5dk, VIX: 3dk, Gold/Oil: 2dk, Fear: 10dk)
 */

// ─── CACHE ───────────────────────────────────────────────────────────────────
const _cache  = {};
const _status = {};

const CACHE_TTL = {
  DXY: 5*60*1000, US10Y: 5*60*1000, US2Y: 5*60*1000,
  VIX: 3*60*1000, GOLD: 2*60*1000, OIL: 2*60*1000, FEAR: 10*60*1000,
};

function _cacheGet(key) {
  const e = _cache[key];
  if (!e) return null;
  if (Date.now() - e.ts > (CACHE_TTL[key] || 5*60*1000)) return null;
  return e.value;
}
function _cacheSet(key, value) {
  _cache[key] = { value, ts: Date.now() };
  _status[key] = { ...value, fetchedAt: new Date().toLocaleTimeString('tr-TR') };
}

// ─── PROXY ZİNCİRİ ───────────────────────────────────────────────────────────
const PROXIES = [
  url => `https://corsproxy.io/?${encodeURIComponent(url)}`,
  url => `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`,
  url => `https://api.codetabs.com/v1/proxy?quest=${encodeURIComponent(url)}`,
];

async function _fetchWithProxies(targetUrl, timeoutMs = 8000) {
  let lastErr;
  for (const buildProxy of PROXIES) {
    try {
      const res = await fetch(buildProxy(targetUrl), { signal: AbortSignal.timeout(timeoutMs) });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const text = await res.text();
      if (!text || text.trim().length < 5) throw new Error('Boş yanıt');
      return text;
    } catch (e) { lastErr = e; }
  }
  throw new Error(`Tüm proxy başarısız: ${lastErr?.message}`);
}

// ─── CSV PARSE ────────────────────────────────────────────────────────────────
function _parseStooqCSV(text, col = 4) {
  const lines = text.trim().split('\n').filter(l => l && !/^date/i.test(l));
  if (!lines.length) throw new Error('stooq: satır yok');
  for (let i = lines.length - 1; i >= 0; i--) {
    const parts = lines[i].split(',');
    const val = parseFloat(parts[col]);
    if (!isNaN(val) && val > 0) {
      const prev = i > 0 ? parseFloat(lines[i-1].split(',')[col]) : val;
      const change = prev > 0 ? parseFloat(((val - prev) / prev * 100).toFixed(3)) : 0;
      return { value: val, change };
    }
  }
  throw new Error('stooq: geçerli değer yok');
}

function _parseFREDCSV(text) {
  const lines = text.trim().split('\n').filter(l => l && !/^date/i.test(l));
  for (let i = lines.length - 1; i >= 0; i--) {
    const val = parseFloat(lines[i].split(',')[1]);
    if (!isNaN(val) && val > 0) return val;
  }
  throw new Error('FRED: geçerli değer yok');
}

async function _stooq(symbol) {
  const text = await _fetchWithProxies(
    `https://stooq.com/q/d/l/?s=${encodeURIComponent(symbol)}&i=d`, 8000
  );
  return _parseStooqCSV(text);
}

async function _fred(seriesId) {
  const text = await _fetchWithProxies(
    `https://fred.stlouisfed.org/graph/fredgraph.csv?id=${seriesId}`, 10000
  );
  return _parseFREDCSV(text);
}

// ─── DXY ─────────────────────────────────────────────────────────────────────
export async function fetchDXYLevel() {
  const cached = _cacheGet('DXY');
  if (cached) return cached;

  let result = { value: 104.0, change: 0, source: 'default', ok: false };

  // 1. stooq — ^dxy (gerçek DXY endeksi)
  try {
    const { value, change } = await _stooq('^dxy');
    result = { value: parseFloat(value.toFixed(3)), change, source: 'stooq', ok: true };
    console.info(`[Macro] DXY=${result.value} (${change>=0?'+':''}${change}%) ← stooq`);
    _cacheSet('DXY', result); return result;
  } catch {}

  // 2. FRED — Broad Dollar Index
  try {
    const val = await _fred('DTWEXBGS');
    result = { value: parseFloat(val.toFixed(3)), change: 0, source: 'FRED', ok: true };
    console.info(`[Macro] DXY=${result.value} ← FRED`);
    _cacheSet('DXY', result); return result;
  } catch {}

  // 3. EUR/USD ters proxy (Binance — direkt CORS yok)
  try {
    const r = await fetch('https://api.binance.com/api/v3/ticker/24hr?symbol=EURUSDT',
      { signal: AbortSignal.timeout(5000) });
    const d = await r.json();
    const eurUsd    = parseFloat(d.lastPrice || 1.08);
    const eurChange = parseFloat(d.priceChangePercent || 0);
    // DXY ≈ 107 - (EUR/USD - 1.0) * 80
    const approx = parseFloat((107 - (eurUsd - 1.0) * 80).toFixed(2));
    result = { value: approx, change: parseFloat((-eurChange).toFixed(3)), source: 'EUR/USD proxy', ok: true };
    console.info(`[Macro] DXY≈${result.value} ← EUR/USD proxy`);
    _cacheSet('DXY', result); return result;
  } catch {}

  console.warn('[Macro] DXY — sabit 104 kullanılıyor');
  _cacheSet('DXY', result); return result;
}

// ─── US10Y ────────────────────────────────────────────────────────────────────
export async function fetchUS10YYield() {
  const cached = _cacheGet('US10Y');
  if (cached) return cached;

  let result = { value: 4.3, change: 0, source: 'default', ok: false };

  try {
    const { value, change } = await _stooq('10us.b');
    result = { value: parseFloat(value.toFixed(3)), change, source: 'stooq', ok: true };
    console.info(`[Macro] US10Y=${result.value}% ← stooq`);
    _cacheSet('US10Y', result); return result;
  } catch {}

  try {
    const val = await _fred('DGS10');
    result = { value: parseFloat(val.toFixed(3)), change: 0, source: 'FRED', ok: true };
    _cacheSet('US10Y', result); return result;
  } catch {}

  _cacheSet('US10Y', result); return result;
}

// ─── US2Y ─────────────────────────────────────────────────────────────────────
export async function fetchUS2YYield() {
  const cached = _cacheGet('US2Y');
  if (cached) return cached;

  let result = { value: 4.8, change: 0, source: 'default', ok: false };

  try {
    const { value, change } = await _stooq('2us.b');
    result = { value: parseFloat(value.toFixed(3)), change, source: 'stooq', ok: true };
    _cacheSet('US2Y', result); return result;
  } catch {}

  try {
    const val = await _fred('DGS2');
    result = { value: parseFloat(val.toFixed(3)), change: 0, source: 'FRED', ok: true };
    _cacheSet('US2Y', result); return result;
  } catch {}

  _cacheSet('US2Y', result); return result;
}

// ─── VIX ─────────────────────────────────────────────────────────────────────
export async function fetchVIXLevel() {
  const cached = _cacheGet('VIX');
  if (cached) return cached;

  const _classify = v => v > 40 ? 'KRİTİK' : v > 30 ? 'YÜKSEK' : v > 20 ? 'NORMAL' : 'DÜŞÜK';
  let result = { value: 20, level: 'NORMAL', change: 0, source: 'default', ok: false };

  // 1. stooq — ^vix (gerçek CBOE VIX)
  try {
    const { value, change } = await _stooq('^vix');
    result = { value: parseFloat(value.toFixed(2)), level: _classify(value), change, source: 'stooq', ok: true };
    console.info(`[Macro] VIX=${result.value} (${result.level}) ← stooq`);
    _cacheSet('VIX', result); return result;
  } catch {}

  // 2. BTC annualized volatilite proxy
  try {
    const r = await fetch('https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval=1d&limit=8',
      { signal: AbortSignal.timeout(5000) });
    const d = await r.json();
    const closes  = d.map(k => parseFloat(k[4]));
    const returns = closes.slice(1).map((c, i) => Math.log(c / closes[i]));
    const mean    = returns.reduce((a, b) => a + b, 0) / returns.length;
    const variance = returns.reduce((s, r) => s + (r - mean) ** 2, 0) / returns.length;
    const vol = parseFloat((Math.sqrt(variance * 252) * 100).toFixed(2));
    result = { value: vol, level: _classify(vol), change: 0, source: 'BTC vol proxy', ok: true };
    console.info(`[Macro] VIX≈${vol} ← BTC vol proxy`);
    _cacheSet('VIX', result); return result;
  } catch {}

  _cacheSet('VIX', result); return result;
}

// ─── ALTIN ────────────────────────────────────────────────────────────────────
export async function fetchGoldPrice() {
  const cached = _cacheGet('GOLD');
  if (cached) return cached;

  let result = { value: 2000, change: 0, source: 'default', ok: false };

  // 1. stooq — xauusd
  try {
    const { value, change } = await _stooq('xauusd');
    result = { value: parseFloat(value.toFixed(2)), change, source: 'stooq', ok: true };
    console.info(`[Macro] GOLD=$${result.value} (${change>=0?'+':''}${change}%) ← stooq`);
    _cacheSet('GOLD', result); return result;
  } catch {}

  // 2. metals.live (ücretsiz, CORS destekli)
  try {
    const r = await fetch('https://api.metals.live/v1/spot/gold', { signal: AbortSignal.timeout(5000) });
    const d = await r.json();
    if (d?.price > 100) {
      result = { value: parseFloat(d.price.toFixed(2)), change: 0, source: 'metals.live', ok: true };
      _cacheSet('GOLD', result); return result;
    }
  } catch {}

  // 3. goldprice.org
  try {
    const r = await fetch('https://data-asg.goldprice.org/dbXRates/USD', { signal: AbortSignal.timeout(5000) });
    const d = await r.json();
    const price = d?.items?.[0]?.xauPrice;
    if (price > 100) {
      result = { value: parseFloat(price.toFixed(2)), change: 0, source: 'goldprice.org', ok: true };
      _cacheSet('GOLD', result); return result;
    }
  } catch {}

  _cacheSet('GOLD', result); return result;
}

// ─── PETROL ───────────────────────────────────────────────────────────────────
export async function fetchOilPrice() {
  const cached = _cacheGet('OIL');
  if (cached) return cached;

  let result = { value: 75, change: 0, type: 'WTI', source: 'default', ok: false };

  // 1. stooq — cl.f (WTI vadeli)
  try {
    const { value, change } = await _stooq('cl.f');
    result = { value: parseFloat(value.toFixed(2)), change, type: 'WTI', source: 'stooq', ok: true };
    console.info(`[Macro] OIL(WTI)=$${result.value} (${change>=0?'+':''}${change}%) ← stooq`);
    _cacheSet('OIL', result); return result;
  } catch {}

  // 2. Brent fallback
  try {
    const { value, change } = await _stooq('brn.f');
    result = { value: parseFloat(value.toFixed(2)), change, type: 'Brent', source: 'stooq(brent)', ok: true };
    _cacheSet('OIL', result); return result;
  } catch {}

  _cacheSet('OIL', result); return result;
}

// ─── FEAR & GREED ─────────────────────────────────────────────────────────────
export async function fetchFearGreed() {
  const cached = _cacheGet('FEAR');
  if (cached) return cached;

  let result = { value: 50, label: 'Neutral', prev: 50, change: 0, source: 'default', ok: false };

  try {
    const r = await fetch('https://api.alternative.me/fng/?limit=2', { signal: AbortSignal.timeout(5000) });
    const d = await r.json();
    const cur  = parseInt(d.data?.[0]?.value || 50);
    const prev = parseInt(d.data?.[1]?.value || 50);
    result = {
      value:  cur,
      label:  d.data?.[0]?.value_classification || 'Neutral',
      prev,
      change: cur - prev,
      source: 'alternative.me',
      ok:     true,
    };
    _cacheSet('FEAR', result); return result;
  } catch (e) {
    console.warn('[Macro] Fear&Greed hata:', e.message);
    _cacheSet('FEAR', result); return result;
  }
}

// ─── TÜM MAKRO VERİ (PARALEL) ────────────────────────────────────────────────
/**
 * fetchAllMacro() → {
 *   dxy, us10y, us2y, vix, gold, oil, fearGreed,
 *   yieldSpread, isInvertedCurve, riskMode, riskScore, summary, timestamp
 * }
 */
export async function fetchAllMacro() {
  const [dxyR, us10yR, us2yR, vixR, goldR, oilR, fearR, silverR, sp500R, nasdaqR] = await Promise.allSettled([
    fetchDXYLevel(), fetchUS10YYield(), fetchUS2YYield(),
    fetchVIXLevel(), fetchGoldPrice(),  fetchOilPrice(), fetchFearGreed(),
    fetch('https://corsproxy.io/?https://stooq.com/q/l/?s=xagusd&f=sd2t2ohlcv&h&e=csv')
      .then(r => r.text()).then(t => {
        const lines = t.trim().split('\n');
        if (lines.length < 2) throw new Error('no data');
        const cols = lines[1].split(',');
        const close = parseFloat(cols[6]);
        const open  = parseFloat(cols[3]);
        const chg   = open > 0 ? parseFloat(((close - open) / open * 100).toFixed(2)) : 0;
        return { value: close, change: chg, source: 'stooq', ok: true };
      }).catch(() => ({ value: 24, change: 0, source: 'default', ok: false })),
    // S&P 500
    fetch('https://corsproxy.io/?https://stooq.com/q/l/?s=^spx&f=sd2t2ohlcv&h&e=csv')
      .then(r => r.text()).then(t => {
        const lines = t.trim().split('\n');
        if (lines.length < 2) throw new Error('no data');
        const cols  = lines[1].split(',');
        const close = parseFloat(cols[6]);
        const open  = parseFloat(cols[3]);
        const chg   = open > 0 ? parseFloat(((close - open) / open * 100).toFixed(2)) : 0;
        return { value: close, change: chg, source: 'stooq', ok: true };
      }).catch(() => ({ value: 5800, change: 0, source: 'default', ok: false })),
    // Nasdaq
    fetch('https://corsproxy.io/?https://stooq.com/q/l/?s=^ndx&f=sd2t2ohlcv&h&e=csv')
      .then(r => r.text()).then(t => {
        const lines = t.trim().split('\n');
        if (lines.length < 2) throw new Error('no data');
        const cols  = lines[1].split(',');
        const close = parseFloat(cols[6]);
        const open  = parseFloat(cols[3]);
        const chg   = open > 0 ? parseFloat(((close - open) / open * 100).toFixed(2)) : 0;
        return { value: close, change: chg, source: 'stooq', ok: true };
      }).catch(() => ({ value: 20000, change: 0, source: 'default', ok: false })),
  ]);

  const ok = v => v.status === 'fulfilled' ? v.value : null;
  const dxy    = ok(dxyR)    || { value: 104.0, change: 0, source: 'default', ok: false };
  const us10y  = ok(us10yR)  || { value: 4.3,   change: 0, source: 'default', ok: false };
  const us2y   = ok(us2yR)   || { value: 4.8,   change: 0, source: 'default', ok: false };
  const vix    = ok(vixR)    || { value: 20,    level: 'NORMAL', ok: false };
  const gold   = ok(goldR)   || { value: 2000,  change: 0, ok: false };
  const oil    = ok(oilR)    || { value: 75,    change: 0, ok: false };
  const fear   = ok(fearR)   || { value: 50,    label: 'Neutral', ok: false };
  const silver = ok(silverR) || { value: 24,    change: 0, ok: false };
  const sp500  = ok(sp500R)  || { value: 5800,  change: 0, source: 'default', ok: false };
  const nasdaq = ok(nasdaqR) || { value: 20000, change: 0, source: 'default', ok: false };

  // Getiri eğrisi spread
  const yieldSpread     = parseFloat((us10y.value - us2y.value).toFixed(3));
  const isInvertedCurve = yieldSpread < 0;

  // Risk modu skoru
  const riskScore =
    (fear.value > 60 ?  20 : fear.value < 30 ? -20 : 0) +
    (vix.value   < 20 ?  15 : vix.value  > 30 ? -20 : 0) +
    (dxy.change  < -0.5 ? 10 : dxy.change > 0.5 ? -10 : 0) +
    (gold.change >  1 ? -10 : gold.change < -1 ? 5 : 0) +
    (us10y.value <  4 ?  10 : us10y.value > 5  ? -10 : 0) +
    (isInvertedCurve   ? -15 : yieldSpread > 0.5 ? 5 : 0);

  const riskMode = riskScore > 20 ? 'RISK_ON' : riskScore < -20 ? 'RISK_OFF' : 'NEUTRAL';

  // Piyasa genişliği tahmini (VIX + Fear&Greed bazlı)
  const breadth = Math.max(0.1, Math.min(0.9,
    0.5 + (fear.value - 50) / 100 + (20 - Math.min(vix.value, 40)) / 100
  ));

  const summary = [
    `DXY: ${dxy.value.toFixed(1)} (${dxy.change >= 0 ? '+' : ''}${dxy.change?.toFixed(2)}%) [${dxy.source}]`,
    `US10Y: ${us10y.value.toFixed(2)}% | US2Y: ${us2y.value.toFixed(2)}% | Spread: ${yieldSpread >= 0 ? '+' : ''}${yieldSpread}%${isInvertedCurve ? ' ⚠ TERSINE' : ''}`,
    `VIX: ${vix.value.toFixed(1)} — ${vix.level} [${vix.source}]`,
    `GOLD: $${gold.value.toFixed(0)} (${gold.change >= 0 ? '+' : ''}${gold.change?.toFixed(2)}%) | SILVER: $${silver.value.toFixed(2)} [${gold.source}]`,
    `OIL(${oil.type || 'WTI'}): $${oil.value.toFixed(1)} (${oil.change >= 0 ? '+' : ''}${oil.change?.toFixed(2)}%)`,
    `Fear&Greed: ${fear.value}/100 — ${fear.label}`,
    `Risk Modu: ${riskMode} (skor: ${riskScore >= 0 ? '+' : ''}${riskScore})`,
  ];

  return {
    dxy, us10y, us2y, vix, gold, oil, fearGreed: fear, silver,
    sp500, nasdaq,
    yieldSpread, isInvertedCurve, riskMode, riskScore,
    breadth: parseFloat(breadth.toFixed(2)),
    summary, timestamp: Date.now(),
  };
}

// ─── GERİYE DÖNÜK UYUMLULUK ──────────────────────────────────────────────────
/**
 * fetchMacroData() — eski Dashboard_v4.jsx çağrıları için korunuyor.
 * Döner: { dxyLevel, us10yYield, ok, dxy, us10y }
 */
export async function fetchMacroData() {
  const [dxyR, us10yR] = await Promise.allSettled([
    fetchDXYLevel(), fetchUS10YYield(),
  ]);
  const dxy   = dxyR.status   === 'fulfilled' ? dxyR.value   : null;
  const us10y = us10yR.status === 'fulfilled' ? us10yR.value : null;
  return {
    dxyLevel:   dxy?.value   ?? 104.0,
    us10yYield: us10y?.value ?? 4.3,
    ok: !!(dxy?.ok || us10y?.ok),
    dxy,
    us10y,
  };
}

// ─── YARDIMCI ─────────────────────────────────────────────────────────────────
export function clearMacroCache(key = null) {
  if (key) delete _cache[key];
  else ['DXY','US10Y','US2Y','VIX','GOLD','OIL','FEAR'].forEach(k => delete _cache[k]);
}

export async function testProxies() {
  const testUrl = 'https://stooq.com/q/d/l/?s=%5Edxy&i=d';
  const results = [];
  for (const buildProxy of PROXIES) {
    const url = buildProxy(testUrl);
    const t0  = Date.now();
    try {
      const res = await fetch(url, { signal: AbortSignal.timeout(5000) });
      results.push({ proxy: url.split('?')[0], ok: res.ok, ms: Date.now() - t0 });
    } catch (e) {
      results.push({ proxy: url.split('?')[0], ok: false, error: e.message });
    }
  }
  return results;
}

export function getMacroStatus() {
  return { ..._status };
}
