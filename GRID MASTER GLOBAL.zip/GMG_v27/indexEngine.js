/**
 * GRID MASTER GLOBAL — INDEX ENGINE v1
 * ======================================
 * INDEX BREADTH ENGINE
 * SECTOR ROTATION ENGINE
 * FUTURES PRESSURE ENGINE
 * EQUITY MOMENTUM ENGINE
 * VIX VOLATILITY ENGINE
 * INSTITUTIONAL FLOW ENGINE
 * INDEX CORRELATION ENGINE
 */

import { clamp } from './engineCore.js';

// ════════════════════════════════════════════════════════════════════════════════
// 1. INDEX BREADTH ENGINE
// ════════════════════════════════════════════════════════════════════════════════
/**
 * Piyasa genişliği: Kaç hisse yükseliyor vs düşüyor?
 * Yüksek genişlik = güçlü piyasa, Dar genişlik = zayıf piyasa
 */
export function runIndexBreadthEngine({
  advancingStocks = 250,   // Yükselen hisse sayısı
  decliningStocks = 150,   // Düşen hisse sayısı
  newHighs        = 50,    // 52 hafta yüksek yapan
  newLows         = 20,    // 52 hafta düşük yapan
  aboveMA200Pct   = 65,    // MA200 üzerindeki hisse %
} = {}) {

  const total     = advancingStocks + decliningStocks || 1;
  const advRatio  = advancingStocks / total;
  const adLine    = advancingStocks - decliningStocks;
  const nhNlRatio = (newHighs + newLows) > 0 ? newHighs / (newHighs + newLows) : 0.5;

  let   score   = 50;
  const signals = [];

  if (advRatio >= 0.70)     { score += 20; signals.push(`Güçlü genişlik: %${(advRatio*100).toFixed(0)} yükseliyor`); }
  else if (advRatio >= 0.55){ score += 10; }
  else if (advRatio <= 0.35){ score -= 20; signals.push(`Zayıf genişlik: sadece %${(advRatio*100).toFixed(0)} yükseliyor`); }
  else if (advRatio <= 0.45){ score -= 10; }

  if (aboveMA200Pct >= 70)  { score += 12; signals.push(`MA200 üzerinde: %${aboveMA200Pct} — Sağlıklı trend`); }
  else if (aboveMA200Pct <= 40) { score -= 12; signals.push(`MA200 üzerinde: sadece %${aboveMA200Pct} — Zayıf piyasa`); }

  if (nhNlRatio >= 0.7)     { score += 8; }
  else if (nhNlRatio <= 0.3){ score -= 8; }

  score = clamp(score);

  // Geniş piyasa = kripto destekli (risk-on)
  return {
    score,
    advancingStocks, decliningStocks,
    adLine, advRatio: parseFloat((advRatio*100).toFixed(1)),
    newHighs, newLows, nhNlRatio: parseFloat(nhNlRatio.toFixed(3)),
    aboveMA200Pct,
    broadMarket: score >= 60,
    narrowMarket: score <= 40,
    signals,
    summary: signals[0] || `Piyasa genişliği: ${advancingStocks} yükseliyor / ${decliningStocks} düşüyor`,
    timestamp: new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// 2. SECTOR ROTATION ENGINE
// ════════════════════════════════════════════════════════════════════════════════
/**
 * Hangi sektörler öne çıkıyor?
 * Teknoloji güçlüyse = risk iştahı var = kripto pozitif
 * Savunma/Fayda güçlüyse = risk-off
 */
export const SECTORS = {
  technology:   { label: 'Teknoloji',  riskType: 'RISK_ON',  cryptoCorr:  0.65 },
  financials:   { label: 'Finans',     riskType: 'NEUTRAL',  cryptoCorr:  0.30 },
  healthcare:   { label: 'Sağlık',     riskType: 'DEFENSIVE',cryptoCorr: -0.10 },
  energy:       { label: 'Enerji',     riskType: 'NEUTRAL',  cryptoCorr:  0.10 },
  utilities:    { label: 'Fayda',      riskType: 'DEFENSIVE',cryptoCorr: -0.25 },
  consumer_disc:{ label: 'Tüketim',    riskType: 'RISK_ON',  cryptoCorr:  0.45 },
  materials:    { label: 'Malzeme',    riskType: 'NEUTRAL',  cryptoCorr:  0.20 },
  real_estate:  { label: 'Gayrimenkul',riskType: 'DEFENSIVE',cryptoCorr: -0.15 },
  industrials:  { label: 'Sanayi',     riskType: 'NEUTRAL',  cryptoCorr:  0.25 },
  comm_services:{ label: 'İletişim',   riskType: 'RISK_ON',  cryptoCorr:  0.40 },
};

export function runSectorRotationEngine(sectorChanges = {}) {
  let   cryptoImpact = 0;
  let   totalWeight  = 0;
  const details      = [];
  const riskOn       = [];
  const defensive    = [];

  for (const [key, sector] of Object.entries(SECTORS)) {
    const chg    = sectorChanges[key] || 0;
    const impact = sector.cryptoCorr * chg;
    const weight = Math.abs(sector.cryptoCorr);

    cryptoImpact += impact * weight;
    totalWeight  += weight;

    details.push({ sector: sector.label, change: chg, riskType: sector.riskType, impact: parseFloat(impact.toFixed(3)) });

    if (sector.riskType === 'RISK_ON' && chg > 0)    riskOn.push(sector.label);
    if (sector.riskType === 'DEFENSIVE' && chg > 0.5) defensive.push(sector.label);
  }

  const raw   = totalWeight ? cryptoImpact / totalWeight : 0;
  const score = clamp(50 + raw * 6);

  const riskOnActive  = riskOn.length >= 2;
  const defensiveMode = defensive.length >= 2;

  return {
    score:      parseFloat(score.toFixed(1)),
    details,
    riskOn,
    defensive,
    riskOnActive,
    defensiveMode,
    verdict:    riskOnActive ? '🟢 Risk-on rotasyon — Kripto destekli' :
                defensiveMode ? '🔴 Savunmaya geçiş — Risk-off' : 'Nötr rotasyon',
    summary:    riskOnActive
      ? `Risk-On: ${riskOn.join(', ')} güçlü`
      : defensiveMode ? `Savunma: ${defensive.join(', ')} güçlü` : 'Sektör rotasyonu: Nötr',
    timestamp:  new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// 3. FUTURES PRESSURE ENGINE
// ════════════════════════════════════════════════════════════════════════════════
/**
 * Endeks vadeli piyasası baskısını ölçer.
 * S&P vadeli negatif açılıyorsa = Risk-off
 */
export function runFuturesPressureEngine({
  spxFuturesChange = 0,  // S&P500 vadeli % değişim
  nasdaqFutChange  = 0,
  djiChange        = 0,
  preMarketGap     = 0,  // Pre-market gap %
} = {}) {

  const avgChange = (spxFuturesChange + nasdaqFutChange + djiChange) / 3;
  let   score     = 50;
  const signals   = [];

  if (avgChange >= 0.8)       { score += 20; signals.push(`Endeks vadeli +${avgChange.toFixed(2)}% — Güçlü açılış beklentisi`); }
  else if (avgChange >= 0.3)  { score += 10; }
  else if (avgChange <= -0.8) { score -= 20; signals.push(`Endeks vadeli ${avgChange.toFixed(2)}% — Zayıf açılış`); }
  else if (avgChange <= -0.3) { score -= 10; }

  if (Math.abs(preMarketGap) >= 1.5) {
    signals.push(`Pre-market gap: ${preMarketGap >= 0 ? '+' : ''}${preMarketGap.toFixed(2)}%`);
  }

  return {
    score:        clamp(score),
    spxFuturesChange, nasdaqFutChange, djiChange, avgChange: parseFloat(avgChange.toFixed(3)),
    positive:     avgChange >= 0.3,
    negative:     avgChange <= -0.3,
    signals,
    summary:      signals[0] || `Vadeli piyasa: ${avgChange >= 0 ? '+' : ''}${avgChange.toFixed(2)}%`,
    timestamp:    new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// 4. EQUITY MOMENTUM ENGINE
// ════════════════════════════════════════════════════════════════════════════════
export function runEquityMomentumEngine({
  spx1m = 0, spx3m = 0, spx6m = 0,
  nasdaq1m = 0, nasdaq3m = 0,
  rsi14 = 50,
} = {}) {

  let   score = 50;
  if (spx1m >= 5)        { score += 15; }
  else if (spx1m <= -5)  { score -= 15; }
  if (spx3m >= 10)       { score += 10; }
  else if (spx3m <= -10) { score -= 10; }
  if (rsi14 >= 70)       { score -= 10; } // Aşırı alım
  else if (rsi14 <= 30)  { score += 10; } // Aşırı satım = fırsat

  const momentum = score >= 60 ? 'GÜÇLÜ' : score <= 40 ? 'ZAYIF' : 'NÖTR';

  return {
    score: clamp(score),
    spx1m, spx3m, spx6m, nasdaq1m, nasdaq3m, rsi14,
    momentum,
    summary: `Equity momentum: ${momentum} (SPX 1m:${spx1m >= 0 ? '+' : ''}${spx1m}%)`,
    timestamp: new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// 5. VIX VOLATILITY ENGINE
// ════════════════════════════════════════════════════════════════════════════════
export function runVIXVolatilityEngine({
  vixLevel    = 20,
  vixChange1d = 0,
  vix52wHigh  = 35,
  vix52wLow   = 12,
  vixTermStr  = 0,   // Term structure: spot-futures fark (pozitif=normal, negatif=panik)
} = {}) {

  let   score   = 50;
  const signals = [];

  // VIX seviyesi
  if (vixLevel >= 35)      { score -= 30; signals.push(`🚨 VIX ${vixLevel} — KORKU/PANİK — Risk-off`); }
  else if (vixLevel >= 25) { score -= 18; signals.push(`⚠️ VIX ${vixLevel} — Yüksek volatilite`); }
  else if (vixLevel <= 15) { score += 15; signals.push(`VIX ${vixLevel} — Düşük korku — Risk iştahı açık`); }
  else if (vixLevel <= 18) { score += 8; }

  // Günlük değişim
  if (vixChange1d >= 15)   { score -= 15; signals.push(`VIX +%${vixChange1d.toFixed(0)} — Ani korku artışı`); }
  else if (vixChange1d <= -10) { score += 10; signals.push('VIX düşüyor — Korku azalıyor'); }

  // Term structure
  if (vixTermStr < -2)     { score -= 10; signals.push('VIX backwardation — Panik modu'); }
  else if (vixTermStr > 2) { score += 5; }

  score = clamp(score);

  const regime =
    vixLevel >= 30 ? 'PANİK' :
    vixLevel >= 20 ? 'ENDIŞE' :
    vixLevel >= 15 ? 'NÖTR'   : 'KOMPLASANLİK';

  return {
    score, vixLevel, vixChange1d, vixTermStr,
    regime,
    fearHigh:     vixLevel >= 25,
    fearLow:      vixLevel <= 15,
    cryptoImpact: score >= 60 ? 'POZİTİF' : score <= 40 ? 'NEGATİF' : 'NÖTR',
    signals,
    summary:      signals[0] || `VIX ${vixLevel} — ${regime}`,
    timestamp:    new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// 6. INSTITUTIONAL FLOW ENGINE
// ════════════════════════════════════════════════════════════════════════════════
export function runInstitutionalFlowEngine({
  spxFundFlowBln  = 0,   // S&P ETF fonları giriş/çıkış ($mlr)
  bondFundFlowBln = 0,   // Tahvil fonu akışı
  moneyMarketBln  = 0,   // Para piyasası fonu değişimi (pozitif = kenarda bekliyor)
  darkPoolRatio   = 0.4, // Dark pool işlem oranı (yüksek = kurumsal sessiz alım)
} = {}) {

  let   score = 50;
  const signals = [];

  if (spxFundFlowBln >= 5)    { score += 20; signals.push(`Hisse ETF giriş: $${spxFundFlowBln}B — Kurumsal alım`); }
  else if (spxFundFlowBln <= -5) { score -= 20; signals.push(`Hisse ETF çıkış: $${spxFundFlowBln}B — Kurumsal satış`); }

  if (moneyMarketBln >= 20)   { score -= 8; signals.push(`Para piyasasında $${moneyMarketBln}B — Kurumlar kenarda`); }
  else if (moneyMarketBln <= -10) { score += 10; signals.push('Para piyasasından çıkış — Hisse/kripto'ye dönüş'); }

  if (darkPoolRatio >= 0.55)  { score += 12; signals.push(`Dark pool: %${(darkPoolRatio*100).toFixed(0)} — Sessiz kurumsal alım`); }

  return {
    score:         clamp(score),
    spxFundFlowBln, bondFundFlowBln, moneyMarketBln, darkPoolRatio,
    institutionalBuying: score >= 60,
    signals,
    summary:       signals[0] || 'Kurumsal akış: Nötr',
    timestamp:     new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// 7. INDEX CORRELATION ENGINE
// ════════════════════════════════════════════════════════════════════════════════
export function runIndexCorrelationEngine(indexChanges = {}) {
  const correlations = {
    SPX:    { corr:  0.65, change: indexChanges.SPX    || 0 },
    NASDAQ: { corr:  0.70, change: indexChanges.NASDAQ || 0 },
    DJI:    { corr:  0.50, change: indexChanges.DJI    || 0 },
    DAX:    { corr:  0.45, change: indexChanges.DAX    || 0 },
    NIKKEI: { corr:  0.35, change: indexChanges.NIKKEI || 0 },
    VIX:    { corr: -0.55, change: indexChanges.VIX    || 0 },
  };

  let weighted = 0; let totalW = 0;
  const details = [];

  for (const [idx, { corr, change }] of Object.entries(correlations)) {
    const impact = corr * change;
    const w      = Math.abs(corr);
    weighted    += impact * w;
    totalW      += w;
    details.push({ index: idx, change, corr, impact: parseFloat(impact.toFixed(3)) });
  }

  const raw   = totalW ? weighted / totalW : 0;
  const score = clamp(50 + raw * 7);

  return {
    score:      parseFloat(score.toFixed(1)),
    details,
    rawImpact:  parseFloat(raw.toFixed(3)),
    verdict:    score >= 60 ? 'Endeksler kripto destekliyor' : score <= 40 ? 'Endeksler kripto baskılıyor' : 'Nötr',
    summary:    `Endeks→Kripto: ${raw > 0 ? '+' : ''}${raw.toFixed(3)} | ${score >= 55 ? 'Pozitif' : score <= 45 ? 'Negatif' : 'Nötr'}`,
    timestamp:  new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// ANA INDEX ENGINE
// ════════════════════════════════════════════════════════════════════════════════
export function runIndexEngine(params = {}) {
  const {
    breadth = {}, sectorChanges = {}, futures = {},
    equity = {}, vix = {}, institutional = {}, indexChanges = {},
  } = params;

  const breadthR      = runIndexBreadthEngine(breadth);
  const sectorR       = runSectorRotationEngine(sectorChanges);
  const futuresR      = runFuturesPressureEngine(futures);
  const equityR       = runEquityMomentumEngine(equity);
  const vixR          = runVIXVolatilityEngine(vix);
  const institutionalR= runInstitutionalFlowEngine(institutional);
  const correlationR  = runIndexCorrelationEngine(indexChanges);

  const score = clamp(
    breadthR.score       * 0.15 +
    sectorR.score        * 0.15 +
    futuresR.score       * 0.15 +
    equityR.score        * 0.10 +
    vixR.score           * 0.20 +
    institutionalR.score * 0.15 +
    correlationR.score   * 0.10
  );

  const topSignal = vixR.signals[0] || sectorR.verdict || futuresR.signals[0] || breadthR.signals[0];

  return {
    score:       parseFloat(score.toFixed(1)),
    modules: { breadth: breadthR, sector: sectorR, futures: futuresR, equity: equityR, vix: vixR, institutional: institutionalR, correlation: correlationR },
    topSignal:   topSignal || 'Endeks: Normal',
    verdict:     score >= 60 ? 'ENDEKS POZİTİF' : score <= 40 ? 'ENDEKS NEGATİF' : 'NÖTR',
    summary:     `${score >= 60 ? 'POZİTİF' : score <= 40 ? 'NEGATİF' : 'NÖTR'} (${score.toFixed(0)}/100) — ${topSignal || 'Normal'}`,
    timestamp:   new Date().toISOString(),
  };
}
