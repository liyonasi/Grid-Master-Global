/**
 * GRID MASTER GLOBAL — FOREX ENGINE v1
 * ======================================
 * FOREX INTELLIGENCE ENGINE
 * CURRENCY STRENGTH ENGINE
 * RATE DIFFERENTIAL ENGINE
 * CARRY TRADE ANALYZER
 * SESSION FLOW ENGINE
 * FOREX CORRELATION ENGINE
 * FOREX LIQUIDITY MAP
 * CENTRAL BANK SIGNAL ENGINE
 * DXY PRESSURE ENGINE
 */

import { clamp } from './engineCore.js';

// ─── ÖNBELLEK ─────────────────────────────────────────────────────────────────
const _cache = new Map();
function cacheGet(k, ttl = 5 * 60 * 1000) { const e = _cache.get(k); return e && Date.now() - e.ts < ttl ? e.v : null; }
function cacheSet(k, v) { _cache.set(k, { v, ts: Date.now() }); }

// ─── PARA BİRİMLERİ ───────────────────────────────────────────────────────────
export const CURRENCIES = ['USD', 'EUR', 'GBP', 'JPY', 'CHF', 'AUD', 'CAD', 'NZD'];

export const PAIRS = [
  'EURUSD', 'GBPUSD', 'USDJPY', 'USDCHF',
  'AUDUSD', 'USDCAD', 'NZDUSD', 'EURGBP',
  'EURJPY', 'GBPJPY', 'AUDJPY', 'XAUUSD',
];

// Faiz oranları (merkez bankası politika faizi — statik, güncellenir)
export const INTEREST_RATES = {
  USD: 5.25, EUR: 4.50, GBP: 5.25, JPY: 0.10,
  CHF: 1.75, AUD: 4.35, CAD: 5.00, NZD: 5.50,
};

// ─── FOREX VERİ ÇEK ──────────────────────────────────────────────────────────
async function fetchForexRate(pair) {
  const cached = cacheGet(`fx_${pair}`);
  if (cached) return cached;

  const base   = pair.slice(0, 3);
  const target = pair.slice(3);

  try {
    const url  = `https://api.exchangerate-api.com/v4/latest/${base}`;
    const res  = await fetch(url, { signal: AbortSignal.timeout(5000) });
    const data = await res.json();
    const rate = data?.rates?.[target];
    if (!rate) return null;
    const result = { pair, rate, base, target, timestamp: Date.now() };
    cacheSet(`fx_${pair}`, result);
    return result;
  } catch (e) {
    return null;
  }
}

// ════════════════════════════════════════════════════════════════════════════════
// 1. CURRENCY STRENGTH ENGINE
// ════════════════════════════════════════════════════════════════════════════════
/**
 * 8 major para biriminin göreceli gücünü hesaplar.
 * Güçlü para = o ülke ekonomisi iyi / faiz yüksek
 *
 * @param {object} pairChanges — { EURUSD: 0.3, GBPUSD: -0.2, ... } (% değişim)
 */
export function runCurrencyStrengthEngine(pairChanges = {}) {
  const strength = {};
  CURRENCIES.forEach(c => { strength[c] = 0; });

  const weights = {
    EURUSD: 1.0, GBPUSD: 0.9, USDJPY: 1.0, USDCHF: 0.7,
    AUDUSD: 0.7, USDCAD: 0.7, NZDUSD: 0.5, EURGBP: 0.8,
    EURJPY: 0.8, GBPJPY: 0.7, AUDJPY: 0.6, XAUUSD: 0.5,
  };

  for (const [pair, chg] of Object.entries(pairChanges)) {
    if (!chg) continue;
    const base   = pair.slice(0, 3);
    const quote  = pair.slice(3, 6);
    const w      = weights[pair] || 0.5;

    if (CURRENCIES.includes(base))  strength[base]  += chg * w;
    if (CURRENCIES.includes(quote)) strength[quote] -= chg * w;
  }

  // Normalize 0-100
  const vals   = Object.values(strength);
  const min    = Math.min(...vals);
  const max    = Math.max(...vals);
  const range  = max - min || 1;

  const normalized = {};
  for (const [cur, val] of Object.entries(strength)) {
    normalized[cur] = clamp(Math.round((val - min) / range * 100));
  }

  const ranked = Object.entries(normalized).sort((a, b) => b[1] - a[1]);

  // USD gücü → kripto için önemli (güçlü USD = kripto baskı)
  const usdStrength  = normalized['USD'] ?? 50;
  const cryptoImpact = clamp(100 - usdStrength); // USD güçlüyse kripto zayıflar

  return {
    score:        cryptoImpact,
    strength:     normalized,
    ranked,
    strongest:    ranked[0]?.[0] || 'USD',
    weakest:      ranked[ranked.length - 1]?.[0] || 'JPY',
    usdStrength,
    cryptoImpact,
    usdBullish:   usdStrength >= 65,
    summary:      `En güçlü: ${ranked[0]?.[0]} (${ranked[0]?.[1]}) | En zayıf: ${ranked[ranked.length-1]?.[0]} | USD:${usdStrength}`,
    timestamp:    new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// 2. RATE DIFFERENTIAL ENGINE
// ════════════════════════════════════════════════════════════════════════════════
/**
 * Faiz oranı farkı analizi.
 * Yüksek faiz farkı → Carry trade fırsatı veya risk
 *
 * @param {object} currentRates — { USD: 5.25, EUR: 4.50, ... }
 */
export function runRateDifferentialEngine(currentRates = INTEREST_RATES) {
  const diffs = [];

  for (const pair of PAIRS) {
    const base  = pair.slice(0, 3);
    const quote = pair.slice(3, 6);
    if (!currentRates[base] || !currentRates[quote]) continue;

    const diff = currentRates[base] - currentRates[quote];
    diffs.push({ pair, base, quote, diff: parseFloat(diff.toFixed(2)), baseRate: currentRates[base], quoteRate: currentRates[quote] });
  }

  diffs.sort((a, b) => Math.abs(b.diff) - Math.abs(a.diff));

  // En yüksek diferansiyeller = carry trade fırsatı
  const topCarry = diffs.slice(0, 3);

  // USD-JPY diferansiyali kripto için kritik (yüksek = risk-on)
  const usdJpy = diffs.find(d => d.pair === 'USDJPY');
  let   score  = 50;
  if (usdJpy) {
    if (usdJpy.diff >= 4)      score += 15; // Yüksek fark = risk iştahı açık
    else if (usdJpy.diff <= 2) score -= 10;
  }

  return {
    score:       clamp(score),
    differentials: diffs,
    topCarry,
    usdJpyDiff: usdJpy?.diff || null,
    highestDiff: diffs[0] || null,
    summary:    `En yüksek fark: ${diffs[0]?.pair} (${diffs[0]?.diff > 0 ? '+' : ''}${diffs[0]?.diff}%)`,
    timestamp:  new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// 3. CARRY TRADE ANALYZER
// ════════════════════════════════════════════════════════════════════════════════
/**
 * Carry trade pozisyonlarını ve unwinding riskini analiz eder.
 * Carry unwind = ani JPY/CHF güçlenmesi = Risk-off = kripto düşer
 */
export function runCarryTradeAnalyzer({
  usdJpyChange  = 0,  // USD/JPY % değişim
  usdChfChange  = 0,  // USD/CHF % değişim
  vixLevel      = 20, // VIX seviyesi
  riskAppetite  = 50, // Genel risk iştahı 0-100
} = {}) {

  let   score   = 50;
  const signals = [];

  // Carry unwind tespiti: JPY veya CHF ani güçlenmesi
  const jpy_str = -usdJpyChange; // USDJPY düşerse JPY güçleniyor
  const chf_str = -usdChfChange;

  if (jpy_str >= 1.5) { score -= 25; signals.push(`⚠️ JPY güçleniyor (+${jpy_str.toFixed(2)}%) — Carry unwind riski`); }
  else if (jpy_str <= -1) { score += 12; signals.push('JPY zayıflıyor — Carry trade aktif'); }

  if (chf_str >= 1.0) { score -= 15; signals.push(`CHF güçleniyor — Safe haven talebi`); }

  // VIX
  if (vixLevel >= 30)  { score -= 20; signals.push(`VIX ${vixLevel} — Panik, carry unwind tetiklendi`); }
  else if (vixLevel <= 15) { score += 10; signals.push('VIX düşük — Risk iştahı açık'); }

  // Risk iştahı
  score += (riskAppetite - 50) * 0.2;
  score  = clamp(score);

  const carryUnwind = score < 35;

  return {
    score,
    carryUnwind,
    carryActive: score >= 60,
    jpy_strength: parseFloat(jpy_str.toFixed(3)),
    chf_strength: parseFloat(chf_str.toFixed(3)),
    signals,
    warning:  carryUnwind ? '🚨 Carry trade çözülüyor — Tüm risk varlıkları tehlikede' : null,
    summary:  signals[0] || 'Carry trade: Normal',
    timestamp: new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// 4. SESSION FLOW ENGINE
// ════════════════════════════════════════════════════════════════════════════════
/**
 * Forex seans akışını analiz eder.
 * Tokyo / Londra / New York seans geçişlerinde volatilite artar.
 */
const SESSIONS = {
  TOKYO:     { open: 0,  close: 9,  pairs: ['USDJPY', 'AUDJPY', 'NZDJPY'], volatility: 0.7 },
  LONDON:    { open: 8,  close: 17, pairs: ['EURUSD', 'GBPUSD', 'EURGBP'], volatility: 1.0 },
  NEW_YORK:  { open: 13, close: 22, pairs: ['EURUSD', 'GBPUSD', 'USDCAD'], volatility: 1.0 },
  SYDNEY:    { open: 22, close: 7,  pairs: ['AUDUSD', 'NZDUSD'],            volatility: 0.5 },
};

export function runSessionFlowEngine(utcHour = new Date().getUTCHours()) {
  const activeSessions = [];
  const overlaps       = [];

  for (const [name, session] of Object.entries(SESSIONS)) {
    const isOpen = session.open <= session.close
      ? utcHour >= session.open && utcHour < session.close
      : utcHour >= session.open || utcHour < session.close;

    if (isOpen) activeSessions.push({ name, ...session });
  }

  // Overlap tespiti (en yüksek volatilite)
  if (activeSessions.find(s => s.name === 'LONDON') && activeSessions.find(s => s.name === 'NEW_YORK')) {
    overlaps.push({ name: 'LONDON-NY OVERLAP', volatilityMult: 1.8, note: 'En yüksek likidite penceresi' });
  }
  if (activeSessions.find(s => s.name === 'TOKYO') && activeSessions.find(s => s.name === 'LONDON')) {
    overlaps.push({ name: 'TOKYO-LONDON OVERLAP', volatilityMult: 1.4, note: 'Yüksek likidite' });
  }

  const maxVol     = Math.max(...activeSessions.map(s => s.volatility), 0.3);
  const score      = clamp(50 + (maxVol - 0.5) * 40 + overlaps.length * 10);
  const activeNow  = activeSessions.map(s => s.name).join(' + ') || 'KAPALIM';

  return {
    score:       parseFloat(score.toFixed(1)),
    utcHour,
    activeSessions,
    overlaps,
    activeNow,
    maxVolatility: maxVol,
    bestPairs:   activeSessions.flatMap(s => s.pairs).filter((v, i, a) => a.indexOf(v) === i).slice(0, 4),
    isHighLiquidity: overlaps.length > 0,
    summary:     `${activeNow} | ${overlaps[0]?.name || 'Overlap yok'} | ${score >= 65 ? 'Yüksek aktivite' : 'Normal'}`,
    timestamp:   new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// 5. FOREX CORRELATION ENGINE
// ════════════════════════════════════════════════════════════════════════════════
/**
 * Forex paritelerinin birbiriyle ve kripto ile korelasyonunu ölçer.
 */
export const FOREX_CRYPTO_CORR = {
  EURUSD: { crypto:  0.35, note: 'Güçlü EUR = hafif kripto destekler' },
  USDJPY: { crypto: -0.40, note: 'Güçlü JPY = risk-off = kripto düşer' },
  GBPUSD: { crypto:  0.30, note: 'Hafif pozitif korelasyon' },
  USDCHF: { crypto: -0.35, note: 'Güçlü CHF = safe haven = kripto düşer' },
  AUDUSD: { crypto:  0.45, note: 'Risk-on para = kripto ile paralel' },
  XAUUSD: { crypto:  0.40, note: 'Altın + kripto genelde aynı yönde' },
};

export function runForexCorrelationEngine(pairChanges = {}) {
  let   weightedImpact = 0;
  let   totalWeight    = 0;
  const details        = [];

  for (const [pair, corr] of Object.entries(FOREX_CRYPTO_CORR)) {
    const chg = pairChanges[pair] || 0;
    const impact = corr.crypto * chg;
    const weight = Math.abs(corr.crypto);

    weightedImpact += impact * weight;
    totalWeight    += weight;

    details.push({ pair, change: chg, corr: corr.crypto, impact: parseFloat(impact.toFixed(3)), note: corr.note });
  }

  const raw   = totalWeight ? weightedImpact / totalWeight : 0;
  const score = clamp(50 + raw * 8);

  return {
    score:       parseFloat(score.toFixed(1)),
    details,
    rawImpact:   parseFloat(raw.toFixed(3)),
    cryptoBullish: raw > 0.3,
    cryptoBearish: raw < -0.3,
    summary:     `Forex→Kripto etki: ${raw > 0 ? '+' : ''}${raw.toFixed(3)} | ${score >= 55 ? 'Destekleyici' : score <= 45 ? 'Baskılayıcı' : 'Nötr'}`,
    timestamp:   new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// 6. FOREX LIQUIDITY MAP
// ════════════════════════════════════════════════════════════════════════════════
/**
 * Forex piyasasındaki likidite yoğunlaşmalarını haritalar.
 * Yuvarlak sayılar = likidite mıknatısları
 */
export function runForexLiquidityMap(pair = 'EURUSD', currentRate = 0, dailyRange = 0) {
  if (!currentRate) return { score: 50, summary: 'Veri yok', levels: [] };

  // Yuvarlak seviyeler (piyasa maker'lar burada emir yığar)
  const roundLevels = [];
  const step = pair.includes('JPY') ? 1 : 0.01; // JPY çiftleri için farklı

  for (let mult = -5; mult <= 5; mult++) {
    const level = Math.round(currentRate / step) * step + mult * step;
    const dist  = Math.abs(level - currentRate) / currentRate * 100;
    roundLevels.push({
      level:    parseFloat(level.toFixed(pair.includes('JPY') ? 2 : 4)),
      dist:     parseFloat(dist.toFixed(4)),
      strength: dist < 0.1 ? 'GÜÇLÜ' : dist < 0.3 ? 'ORTA' : 'ZAYIF',
      type:     level > currentRate ? 'DİRENÇ' : level < currentRate ? 'DESTEK' : 'ANLIK',
    });
  }

  const nearestLevel = roundLevels.sort((a, b) => a.dist - b.dist)[1]; // [0] anlik seviye

  return {
    score:        50,
    pair,
    currentRate,
    levels:       roundLevels.sort((a, b) => a.level - b.level),
    nearestLevel,
    dailyRange,
    summary:      `${pair} yakın seviye: ${nearestLevel?.level} (${nearestLevel?.type})`,
    timestamp:    new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// 7. CENTRAL BANK SIGNAL ENGINE
// ════════════════════════════════════════════════════════════════════════════════
/**
 * Merkez bankası sinyallerini analiz eder.
 * Hawkish = faiz artırımı = güçlü para = kripto baskı
 * Dovish  = faiz indirimi = zayıf para = kripto için pozitif
 */
export const CB_STANCE = {
  FED:  { bank: 'Federal Reserve', currency: 'USD', currentStance: 'HAWKISH', rate: 5.25 },
  ECB:  { bank: 'Avrupa Merkez Bankası', currency: 'EUR', currentStance: 'HAWKISH', rate: 4.50 },
  BOJ:  { bank: 'Bank of Japan', currency: 'JPY', currentStance: 'ULTRA_DOVISH', rate: 0.10 },
  BOE:  { bank: 'Bank of England', currency: 'GBP', currentStance: 'HAWKISH', rate: 5.25 },
  SNB:  { bank: 'Swiss National Bank', currency: 'CHF', currentStance: 'NEUTRAL', rate: 1.75 },
  RBA:  { bank: 'Reserve Bank of Australia', currency: 'AUD', currentStance: 'NEUTRAL', rate: 4.35 },
  BOC:  { bank: 'Bank of Canada', currency: 'CAD', currentStance: 'HAWKISH', rate: 5.00 },
};

export function runCentralBankSignalEngine(overrides = {}) {
  const banks = { ...CB_STANCE, ...overrides };
  let   score = 50;
  const signals = [];

  for (const [code, bank] of Object.entries(banks)) {
    const stance = bank.currentStance;

    if (code === 'FED') {
      // FED hawkish = USD güçlü = kripto baskı altında
      if (stance === 'HAWKISH')       { score -= 15; signals.push(`FED Hawkish (${bank.rate}%) — USD güçlü, kripto baskı`); }
      else if (stance === 'DOVISH')   { score += 20; signals.push(`FED Dovish — Likidite genişliyor, kripto destekli`); }
      else if (stance === 'PIVOT')    { score += 25; signals.push(`🔔 FED PIVOT — Kripto boğa sinyali`); }
    }

    if (code === 'BOJ') {
      // BOJ sıkılaşırsa → JPY güçlenir → carry unwind → risk-off
      if (stance === 'HAWKISH' || stance === 'TIGHTENING') {
        score -= 12; signals.push('BOJ sıkılaşıyor — Carry unwind riski');
      }
    }
  }

  score = clamp(score);

  const fedStance = banks.FED?.currentStance;
  const verdict   =
    fedStance === 'PIVOT'    ? '🔔 FED PIVOT — Tarihi boğa sinyali' :
    fedStance === 'DOVISH'   ? 'FED Dovish — Kripto dostu' :
    fedStance === 'HAWKISH'  ? 'FED Hawkish — Kripto baskı altında' : 'Merkez bankası: Nötr';

  return {
    score,
    banks,
    fedStance,
    verdict,
    signals,
    summary:    `${verdict} | Skor: ${score}/100`,
    timestamp:  new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// 8. DXY PRESSURE ENGINE
// ════════════════════════════════════════════════════════════════════════════════
/**
 * Dolar endeksi (DXY) baskısını ölçer.
 * DXY yükseliyor = USD güçleniyor = BTC/Kripto genelde düşer
 */
export function runDXYPressureEngine({
  dxyLevel    = 103,
  dxyChange1d = 0,
  dxyChange7d = 0,
  dxy52wHigh  = 107,
  dxy52wLow   = 99,
} = {}) {

  let   score   = 50;
  const signals = [];

  // Günlük değişim
  if (dxyChange1d >= 0.5)       { score -= 20; signals.push(`DXY +${dxyChange1d.toFixed(2)}% — Güçlü USD, kripto baskı`); }
  else if (dxyChange1d >= 0.2)  { score -= 10; }
  else if (dxyChange1d <= -0.5) { score += 20; signals.push(`DXY ${dxyChange1d.toFixed(2)}% — Zayıf USD, kripto için pozitif`); }
  else if (dxyChange1d <= -0.2) { score += 10; }

  // Haftalık trend
  if (dxyChange7d >= 1.5)       { score -= 12; signals.push(`DXY haftalık +${dxyChange7d.toFixed(1)}% — Güçlü trend`); }
  else if (dxyChange7d <= -1.5) { score += 12; signals.push(`DXY haftalık ${dxyChange7d.toFixed(1)}% — Zayıflıyor`); }

  // Mutlak seviye
  const range   = dxy52wHigh - dxy52wLow || 8;
  const posInRange = (dxyLevel - dxy52wLow) / range; // 0=dipte, 1=tepede
  if (posInRange >= 0.8)  { score -= 12; signals.push(`DXY 52h. yüksek yakını (${dxyLevel}) — Kritik direnç`); }
  else if (posInRange <= 0.2) { score += 10; signals.push(`DXY 52h. düşük yakını — Destek bölgesi`); }

  score = clamp(score);

  return {
    score,
    dxyLevel,
    dxyChange1d,
    dxyChange7d,
    posInRange:    parseFloat(posInRange.toFixed(3)),
    pressureHigh:  dxyChange1d >= 0.3,
    pressureLow:   dxyChange1d <= -0.3,
    signals,
    cryptoImpact:  score >= 60 ? 'POZİTİF' : score <= 40 ? 'NEGATİF' : 'NÖTR',
    summary:       signals[0] || `DXY ${dxyLevel} (${dxyChange1d >= 0 ? '+' : ''}${dxyChange1d.toFixed(2)}% günlük)`,
    timestamp:     new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// ANA FOREX ENGINE — HEPSİNİ BİRLEŞTİR
// ════════════════════════════════════════════════════════════════════════════════
/**
 * runForexEngine — Tüm forex modüllerini çalıştır
 *
 * @param {object} params
 *   pairChanges  — { EURUSD: 0.3, ... }
 *   dxyData      — { dxyLevel, dxyChange1d, ... }
 *   carryData    — { usdJpyChange, usdChfChange, vixLevel }
 *   cbOverrides  — Merkez bankası stance güncellemeleri
 */
export async function runForexEngine({ pairChanges = {}, dxyData = {}, carryData = {}, cbOverrides = {} } = {}) {
  const currStrength = runCurrencyStrengthEngine(pairChanges);
  const rateDiff     = runRateDifferentialEngine();
  const carryTrade   = runCarryTradeAnalyzer(carryData);
  const session      = runSessionFlowEngine();
  const fxCorr       = runForexCorrelationEngine(pairChanges);
  const cbSignal     = runCentralBankSignalEngine(cbOverrides);
  const dxyPressure  = runDXYPressureEngine(dxyData);

  // Ağırlıklı nihai skor
  const score = clamp(
    currStrength.score * 0.15 +
    carryTrade.score   * 0.20 +
    fxCorr.score       * 0.20 +
    cbSignal.score     * 0.25 +
    dxyPressure.score  * 0.20
  );

  const carryAlert = carryTrade.carryUnwind
    ? '🚨 CARRY UNWIND — Tüm risk varlıkları tehlikede!'
    : null;

  return {
    score:          parseFloat(score.toFixed(1)),
    currencyStrength: currStrength,
    rateDifferential: rateDiff,
    carryTrade,
    session,
    correlation:    fxCorr,
    centralBank:    cbSignal,
    dxyPressure,
    carryAlert,
    topSignal:      carryAlert || cbSignal.signals[0] || dxyPressure.signals[0] || 'Forex: Normal',
    summary:        `Forex Etki: ${score >= 60 ? 'POZİTİF' : score <= 40 ? 'NEGATİF' : 'NÖTR'} (${score.toFixed(0)}/100)`,
    timestamp:      new Date().toISOString(),
  };
}
