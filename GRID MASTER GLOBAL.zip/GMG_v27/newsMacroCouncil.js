/**
 * GMG — NEWS & MACRO COUNCIL (TAM)
 * ==================================
 * DXY, VIX, Fear&Greed, Global Liquidity, Macro Events
 * Haber sentiment, Fed/CPI/NFP etki analizi
 */

// ─── VERİ ÇEKİCİLER ──────────────────────────────────────────────────────────

export async function fetchFearGreed() {
  try {
    const r = await fetch('https://api.alternative.me/fng/?limit=1');
    const d = await r.json();
    const val  = parseInt(d.data?.[0]?.value || 50);
    const label = d.data?.[0]?.value_classification || 'Neutral';
    return { value: val, label, ok: true };
  } catch {
    return { value: 50, label: 'Neutral', ok: false };
  }
}

export async function fetchDXY() {
  // macroAPIEngine'den gerçek DXY verisi (stooq → FRED → proxy zinciri)
  try {
    // Dinamik import — döngüsel bağımlılığı önler
    const { fetchDXYLevel } = await import('./macroAPIEngine.js');
    const result = await fetchDXYLevel();
    return {
      level:  result.value,
      change: result.change,
      proxy:  result.source !== 'stooq' && result.source !== 'FRED',
      source: result.source,
      ok:     result.ok,
    };
  } catch {
    // Fallback: EUR/USD proxy
    try {
      const r = await fetch('https://api.binance.com/api/v3/ticker/24hr?symbol=EURUSDT');
      const d = await r.json();
      const eurChange = parseFloat(d.priceChangePercent || 0);
      return { level: parseFloat(d.lastPrice || 1), change: -eurChange, proxy: true, ok: true };
    } catch {
      return { level: 104, change: 0, proxy: true, ok: false };
    }
  }
}

export async function fetchVIX() {
  // macroAPIEngine'den gerçek VIX verisi (stooq ^vix → BTC vol proxy)
  try {
    const { fetchVIXLevel } = await import('./macroAPIEngine.js');
    const result = await fetchVIXLevel();
    return {
      level:  result.value,
      proxy:  result.source !== 'stooq',
      source: result.source,
      high:   result.value > 30,
      medium: result.value > 20 && result.value <= 30,
      low:    result.value <= 20,
      ok:     result.ok,
    };
  } catch {
    // BTC vol proxy fallback
    try {
      const r = await fetch('https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval=1d&limit=8');
      const d = await r.json();
      const closes = d.map(k => parseFloat(k[4]));
      const returns = closes.slice(1).map((c, i) => Math.log(c / closes[i]));
      const mean = returns.reduce((a, b) => a + b, 0) / returns.length;
      const variance = returns.reduce((s, r) => s + Math.pow(r - mean, 2), 0) / returns.length;
      const vol = Math.sqrt(variance * 252) * 100;
      return { level: parseFloat(vol.toFixed(2)), proxy: true, high: vol > 30, medium: vol > 20, low: vol <= 20, ok: true };
    } catch {
      return { level: 20, proxy: true, high: false, medium: true, low: false, ok: false };
    }
  }
}

export async function fetchGlobalLiquidity() {
  // Global M2 proxy — BTC + Stablecoin hacmi üzerinden
  try {
    const r = await fetch('https://api.coingecko.com/api/v3/global');
    const d = await r.json();
    const data = d.data;
    return {
      totalMarketCap:     data.total_market_cap?.usd || 0,
      totalVolume24h:     data.total_volume?.usd || 0,
      btcDominance:       parseFloat((data.market_cap_percentage?.btc || 50).toFixed(2)),
      ethDominance:       parseFloat((data.market_cap_percentage?.eth || 15).toFixed(2)),
      marketCapChange24h: parseFloat((data.market_cap_change_percentage_24h_usd || 0).toFixed(2)),
      activeCryptos:      data.active_cryptocurrencies || 0,
      ok: true,
    };
  } catch {
    return { totalMarketCap: 0, btcDominance: 50, marketCapChange24h: 0, ok: false };
  }
}

// ─── MAKRO EVENT TAKVİMİ ──────────────────────────────────────────────────────
// Gerçek API olmadan sabit takvim mantığı
// Gerçek entegrasyon için: Forex Factory, Investing.com API

export function getMacroEventImpact(eventType) {
  const impacts = {
    'FED_DECISION':    { weight: 0.9, bullish: null, desc: 'Fed faiz kararı' },
    'CPI':             { weight: 0.8, bullish: null, desc: 'Enflasyon verisi' },
    'NFP':             { weight: 0.7, bullish: null, desc: 'Tarım dışı istihdam' },
    'ETF_NEWS':        { weight: 0.8, bullish: true,  desc: 'ETF haberi' },
    'REGULATION':      { weight: 0.7, bullish: false, desc: 'Regülasyon haberi' },
    'WAR_GEOPOLITICAL':{ weight: 0.6, bullish: false, desc: 'Jeopolitik risk' },
    'HALVING':         { weight: 0.9, bullish: true,  desc: 'Halving' },
    'EXCHANGE_HACK':   { weight: 0.8, bullish: false, desc: 'Borsa hack' },
  };
  return impacts[eventType] || { weight: 0.3, bullish: null, desc: eventType };
}

// ─── SENTIMENT ANALİZİ ────────────────────────────────────────────────────────

export function analyzeSentiment({ fearGreed, vixLevel, btcChange7d, globalLiqChange }) {
  let score = 50;

  // Fear & Greed (0-100, yüksek = açgözlü = bullish ama dikkat)
  if (fearGreed >= 75)      score += 5;  // Aşırı açgözlü → dikkat
  else if (fearGreed >= 55) score += 12;
  else if (fearGreed >= 45) score += 0;
  else if (fearGreed >= 25) score -= 12;
  else                      score -= 5;  // Aşırı korku → dip olabilir

  // VIX (yüksek = risk-off = bearish)
  if (vixLevel > 80)      score -= 20;
  else if (vixLevel > 60) score -= 12;
  else if (vixLevel > 40) score -= 5;
  else if (vixLevel < 20) score += 10;

  // BTC 7 günlük değişim
  if (btcChange7d > 10)       score += 10;
  else if (btcChange7d > 3)   score += 5;
  else if (btcChange7d > 0)   score += 2;
  else if (btcChange7d > -3)  score -= 2;
  else if (btcChange7d > -10) score -= 5;
  else                         score -= 12;

  // Global likidite değişimi
  if (globalLiqChange > 2)   score += 8;
  else if (globalLiqChange > 0)   score += 3;
  else if (globalLiqChange < -2)  score -= 8;
  else if (globalLiqChange < 0)   score -= 3;

  return Math.max(0, Math.min(100, Math.round(score)));
}

// ─── DXY BASKISI ─────────────────────────────────────────────────────────────

export function analyzeDXYPressure({ dxyChange }) {
  // DXY yükselince kripto genellikle düşer
  let score = 50;
  if (dxyChange > 1.5)       score -= 20;
  else if (dxyChange > 0.5)  score -= 10;
  else if (dxyChange > 0)    score -= 3;
  else if (dxyChange < -1.5) score += 20;
  else if (dxyChange < -0.5) score += 10;
  else if (dxyChange < 0)    score += 3;
  return Math.max(0, Math.min(100, Math.round(score)));
}

// ─── NEWS & MACRO COUNCIL ANA MOTORU ─────────────────────────────────────────

export async function runNewsMacroCouncil(overrides = {}) {
  // Veri çek (parallel)
  const [fg, dxy, vix, globalLiq] = await Promise.allSettled([
    fetchFearGreed(),
    fetchDXY(),
    fetchVIX(),
    fetchGlobalLiquidity(),
  ]);

  const fgData  = fg.status  === 'fulfilled' ? fg.value  : { value: 50, label: 'Neutral', ok: false };
  const dxyData = dxy.status === 'fulfilled' ? dxy.value : { change: 0, ok: false };
  const vixData = vix.status === 'fulfilled' ? vix.value : { level: 50, ok: false };
  const glData  = globalLiq.status === 'fulfilled' ? globalLiq.value : { marketCapChange24h: 0, btcDominance: 50, ok: false };

  // Override desteği (kullanıcı manuel event girebilir)
  const btcChange7d    = overrides.btcChange7d    || 0;
  const activeEvents   = overrides.activeEvents   || [];

  // Sentiment analizi
  const sentimentScore = analyzeSentiment({
    fearGreed:      fgData.value,
    vixLevel:       vixData.level,
    btcChange7d,
    globalLiqChange: glData.marketCapChange24h,
  });

  const dxyScore = analyzeDXYPressure({ dxyChange: dxyData.change });

  // Event etki analizi
  let eventImpact = 50;
  for (const ev of activeEvents) {
    const impact = getMacroEventImpact(ev.type);
    if (impact.bullish === true)  eventImpact += impact.weight * 15;
    if (impact.bullish === false) eventImpact -= impact.weight * 15;
  }
  eventImpact = Math.max(0, Math.min(100, Math.round(eventImpact)));

  // BTC Dominans etkisi
  const btcDomScore = glData.btcDominance > 55
    ? 38  // BTC dominant → alt coins zayıf
    : glData.btcDominance < 45
    ? 65  // Alt season
    : 50;

  // Ağırlıklı final skoru
  const signals = [
    { label: 'Fear & Greed',     score: sentimentScore,  weight: 0.30, detail: `${fgData.value}/100 — ${fgData.label}` },
    { label: 'DXY Baskısı',      score: dxyScore,        weight: 0.20, detail: `DXY ${dxyData.change >= 0 ? '+' : ''}${dxyData.change?.toFixed(2) || 0}%` },
    { label: 'VIX Volatilite',   score: vixData.level > 60 ? 25 : vixData.level > 40 ? 45 : 65, weight: 0.20, detail: `VIX proxy: ${vixData.level?.toFixed(1)}` },
    { label: 'Global Likidite',  score: glData.marketCapChange24h > 0 ? 65 : 38, weight: 0.15, detail: `Piyasa ${glData.marketCapChange24h >= 0 ? '+' : ''}${glData.marketCapChange24h?.toFixed(2)}%` },
    { label: 'BTC Dominans',     score: btcDomScore,     weight: 0.10, detail: `BTC Dom: ${glData.btcDominance?.toFixed(1)}%` },
    { label: 'Macro Events',     score: eventImpact,     weight: 0.05, detail: activeEvents.length ? `${activeEvents.length} aktif event` : 'Event yok' },
  ];

  const totalW = signals.reduce((s, g) => s + g.weight, 0);
  const finalScore = Math.round(Math.max(0, Math.min(100,
    signals.reduce((s, g) => s + g.score * g.weight, 0) / totalW
  )));

  const verdict =
    finalScore >= 65 ? 'MACRO BULLISH' :
    finalScore >= 55 ? 'MACRO ZAYIF BULLISH' :
    finalScore <= 35 ? 'MACRO BEARISH' :
    finalScore <= 45 ? 'MACRO ZAYIF BEARISH' : 'MACRO NEUTRAL';

  const color =
    finalScore >= 55 ? '#00e676' :
    finalScore <= 45 ? '#ff1744' : '#ffd600';

  return {
    id: 'NEWS_MACRO',
    name: 'News & Macro Council',
    icon: '📰',
    score: finalScore,
    verdict,
    color,
    signals,
    raw: {
      fearGreed:    fgData,
      dxy:          dxyData,
      vix:          vixData,
      globalLiq:    glData,
    },
    debate: [
      `Fear&Greed: ${fgData.value}/100 (${fgData.label})`,
      `VIX seviyesi: ${vixData.level?.toFixed(1)} → ${vixData.high ? 'YÜKSEK RİSK' : vixData.medium ? 'ORTA' : 'DÜŞÜK'}`,
      `DXY baskısı: ${dxyData.change >= 0 ? '+' : ''}${dxyData.change?.toFixed(2)}% → ${dxyScore > 55 ? 'Olumlu' : dxyScore < 45 ? 'Olumsuz' : 'Nötr'}`,
      `Piyasa likiditesi: ${glData.marketCapChange24h >= 0 ? '+' : ''}${glData.marketCapChange24h?.toFixed(2)}%`,
      `BTC Dominans: ${glData.btcDominance?.toFixed(1)}%`,
    ],
    timestamp: Date.now(),
  };
}
