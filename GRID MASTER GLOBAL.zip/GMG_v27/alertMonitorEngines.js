/**
 * GRID MASTER GLOBAL — ALERT & MONITORING ENGINES
 * =================================================
 * GLOBAL_ALERT_ENGINE  — Alarm sistemi
 * TELEGRAM_ALERT       — Telegram bot bildirimi
 * HEALTH_MONITOR       — Modül sağlık takibi
 * LOGGING_ENGINE       — Karar arşivi ve loglama
 */

// ═══════════════════════════════════════════════════════════════════════════════
// 1. GLOBAL ALERT ENGINE
// ═══════════════════════════════════════════════════════════════════════════════
export class GlobalAlertEngine {
  constructor() {
    this.alerts     = [];
    this.watchlist  = new Map(); // symbol → { price, condition }
    this.maxAlerts  = 200;
    this.listeners  = [];
  }

  // Alarm ekle
  addAlert({ symbol, type, condition, value, message, severity = 'MEDIUM' }) {
    const alert = {
      id:        `alert_${Date.now()}_${Math.random().toString(36).slice(2,7)}`,
      symbol,
      type,      // 'PRICE_TARGET' | 'COUNCIL_SIGNAL' | 'STOP_HUNT' | 'MANIPULATION' | 'CRITICAL_TRAP'
      condition, // 'ABOVE' | 'BELOW' | 'SIGNAL' | 'CROSS'
      value,
      message,
      severity,  // 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'
      triggered: false,
      createdAt: Date.now(),
    };
    this.alerts.push(alert);
    if (this.alerts.length > this.maxAlerts) this.alerts.shift();
    return alert.id;
  }

  // Fiyat hedef alarmı
  addPriceAlert(symbol, targetPrice, direction = 'ABOVE') {
    return this.addAlert({
      symbol,
      type:      'PRICE_TARGET',
      condition: direction,
      value:     targetPrice,
      message:   `${symbol} ${direction === 'ABOVE' ? '↑' : '↓'} ${targetPrice} hedefine ulaştı`,
      severity:  'HIGH',
    });
  }

  // Council sinyal alarmı
  addCouncilAlert(symbol, minScore = 70) {
    return this.addAlert({
      symbol,
      type:      'COUNCIL_SIGNAL',
      condition: 'SIGNAL',
      value:     minScore,
      message:   `${symbol} için güçlü council sinyali (>${minScore})`,
      severity:  'HIGH',
    });
  }

  // Alarm kontrol et
  checkAlerts(symbol, currentPrice, councilScore = null) {
    const triggered = [];
    for (const alert of this.alerts) {
      if (alert.triggered || alert.symbol !== symbol) continue;

      let fire = false;
      if (alert.type === 'PRICE_TARGET') {
        if (alert.condition === 'ABOVE' && currentPrice >= alert.value) fire = true;
        if (alert.condition === 'BELOW' && currentPrice <= alert.value) fire = true;
      }
      if (alert.type === 'COUNCIL_SIGNAL' && councilScore !== null) {
        if (councilScore >= alert.value) fire = true;
      }

      if (fire) {
        alert.triggered  = true;
        alert.triggeredAt = Date.now();
        alert.triggeredPrice = currentPrice;
        triggered.push(alert);
        this.notify(alert);
      }
    }
    return triggered;
  }

  // Bildirim gönder
  notify(alert) {
    this.listeners.forEach(fn => {
      try { fn(alert); } catch { /* listener hatası */ }
    });
  }

  // Listener ekle (React state setter, WebSocket push vs.)
  subscribe(fn) { this.listeners.push(fn); }
  unsubscribe(fn) { this.listeners = this.listeners.filter(l => l !== fn); }

  getActiveAlerts()    { return this.alerts.filter(a => !a.triggered); }
  getTriggeredAlerts() { return this.alerts.filter(a => a.triggered).slice(-20); }
  clearAll()           { this.alerts = []; }

  // Web Push bildirimi (tarayıcı izni gerekli)
  async sendWebPush(title, body, icon = '🔔') {
    if (!('Notification' in window)) return;
    if (Notification.permission === 'granted') {
      new Notification(title, { body, icon });
    } else if (Notification.permission !== 'denied') {
      const perm = await Notification.requestPermission();
      if (perm === 'granted') new Notification(title, { body, icon });
    }
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// 2. TELEGRAM ALERT ENGINE
// ═══════════════════════════════════════════════════════════════════════════════
export class TelegramAlertEngine {
  constructor(botToken = '', chatId = '') {
    this.botToken = botToken;
    this.chatId   = chatId;
    this.enabled  = !!(botToken && chatId);
    this.queue    = [];
    this.lastSent = 0;
    this.minInterval = 3000; // min 3s arası
  }

  // Mesaj gönder
  async send(message, parseMode = 'HTML') {
    if (!this.enabled) {
      console.log('[Telegram MOCK]', message);
      return { ok: true, mock: true };
    }

    const now = Date.now();
    if (now - this.lastSent < this.minInterval) {
      this.queue.push({ message, parseMode });
      return { queued: true };
    }

    try {
      const url = `https://api.telegram.org/bot${this.botToken}/sendMessage`;
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: this.chatId, text: message, parse_mode: parseMode }),
      });
      this.lastSent = Date.now();
      return await res.json();
    } catch (e) {
      return { ok: false, error: e.message };
    }
  }

  // Sinyal mesajı formatla
  formatSignalMessage({ symbol, action, score, confidence, tp1, sl, reason, phase }) {
    const emoji = action?.includes('AL') ? '🟢' : action?.includes('SAT') ? '🔴' : '🟡';
    return `${emoji} <b>GRID MASTER GLOBAL</b>

📊 <b>${symbol}</b>
🎯 Karar: <b>${action}</b>
📈 Skor: <b>${score}/100</b>
🔒 Güven: <b>%${confidence}</b>
${tp1 ? `✅ TP: <code>${tp1}</code>\n` : ''}${sl  ? `❌ SL: <code>${sl}</code>\n` : ''}${phase ? `⚡ Faz: <b>${phase}</b>\n` : ''}📝 <i>${reason || 'Council onaylı sinyal'}</i>

⏰ ${new Date().toLocaleTimeString('tr-TR')} UTC+3`;
  }

  // Alarm mesajı formatla
  formatAlertMessage(alert) {
    const severityEmoji = { CRITICAL: '🚨', HIGH: '⚠️', MEDIUM: '📢', LOW: 'ℹ️' };
    return `${severityEmoji[alert.severity] || '📢'} <b>ALARM</b>

💰 <b>${alert.symbol}</b>
📌 Tür: ${alert.type}
💬 ${alert.message}
💲 Fiyat: <code>${alert.triggeredPrice || '—'}</code>

⏰ ${new Date().toLocaleTimeString('tr-TR')}`;
  }

  // Stop Hunt alarmı
  async sendStopHuntAlert(symbol, phase, direction) {
    const msg = `🎯 <b>STOP HUNT TESPİT EDİLDİ</b>

🪙 <b>${symbol}</b>
📍 Faz: <b>${phase}</b>
↕️ Yön: <b>${direction === 'UP' ? '⬆️ YUKARI SWEEP' : '⬇️ AŞAĞI SWEEP'}</b>
⚡ <i>İkinci tur yükleniyor — DİKKAT!</i>

⏰ ${new Date().toLocaleTimeString('tr-TR')}`;
    return this.send(msg);
  }

  // İkinci tur teyidi alarmı
  async sendPhase2Alert(symbol, prob) {
    return this.send(
      `‼️ <b>2. SWEEP KESİN — ${symbol}</b>\n\n` +
      `Olasılık: <b>%${prob}</b>\n` +
      `Tüm konsey + modül onayları tamam!\n\n` +
      `⏰ ${new Date().toLocaleTimeString('tr-TR')}`
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// 3. HEALTH MONITOR ENGINE
// ═══════════════════════════════════════════════════════════════════════════════
export class HealthMonitor {
  constructor() {
    this.modules = new Map();
    this.startTime = Date.now();
  }

  // Modül durumunu güncelle
  ping(moduleId, status = 'ONLINE', latencyMs = 0) {
    this.modules.set(moduleId, {
      id:        moduleId,
      status,
      latencyMs,
      lastPing:  Date.now(),
      errorCount: (this.modules.get(moduleId)?.errorCount || 0) + (status === 'ERROR' ? 1 : 0),
    });
  }

  // Tüm modüllerin durumunu al
  getStatus() {
    const all     = Array.from(this.modules.values());
    const online  = all.filter(m => m.status === 'ONLINE').length;
    const offline = all.filter(m => m.status === 'OFFLINE' || m.status === 'ERROR').length;
    const slow    = all.filter(m => m.latencyMs > 2000).length;
    const uptime  = Math.round((Date.now() - this.startTime) / 1000 / 60); // dakika

    return {
      modules: all,
      online,
      offline,
      slow,
      total:   all.length,
      uptime,
      healthScore: all.length ? Math.round(online / all.length * 100) : 0,
      warnings: [
        offline > 0 && `${offline} modül çevrimdışı`,
        slow    > 2 && `${slow} modül yavaş (>2s)`,
      ].filter(Boolean),
      summary: `${online}/${all.length} modül aktif | Uptime: ${uptime}dk`,
    };
  }

  // Veri akışı durdu mu?
  checkDataFlow(symbol, lastDataTime, maxStaleMs = 30000) {
    const stale = Date.now() - lastDataTime > maxStaleMs;
    return {
      symbol,
      stale,
      age:     Date.now() - lastDataTime,
      warning: stale ? `${symbol} verisi ${Math.round((Date.now()-lastDataTime)/1000)}s önce güncellendi` : null,
    };
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// 4. LOGGING & AUDIT ENGINE
// ═══════════════════════════════════════════════════════════════════════════════
export class LoggingEngine {
  constructor(maxLogs = 500) {
    this.logs     = [];
    this.maxLogs  = maxLogs;
  }

  // Council kararı logla
  logCouncilDecision({ symbol, councilId, score, action, reason, timestamp }) {
    this._log('COUNCIL_DECISION', {
      symbol, councilId, score, action, reason,
      timestamp: timestamp || Date.now(),
    });
  }

  // Sinyal logla
  logSignal({ symbol, signalType, score, confidence, price, tp1, sl }) {
    this._log('SIGNAL', { symbol, signalType, score, confidence, price, tp1, sl, timestamp: Date.now() });
  }

  // Stop hunt logla
  logStopHunt({ symbol, phase, direction, prob }) {
    this._log('STOP_HUNT', { symbol, phase, direction, prob, timestamp: Date.now() });
  }

  // Genel hata logla
  logError(module, error, context = {}) {
    this._log('ERROR', { module, error: error?.message || error, context, timestamp: Date.now() });
  }

  // İç log fonksiyonu
  _log(type, data) {
    this.logs.push({ type, ...data, _id: `log_${Date.now()}_${Math.random().toString(36).slice(2,5)}` });
    if (this.logs.length > this.maxLogs) this.logs.shift();
  }

  // Sorgula
  getByType(type)      { return this.logs.filter(l => l.type === type); }
  getBySymbol(symbol)  { return this.logs.filter(l => l.symbol === symbol); }
  getRecent(n = 50)    { return this.logs.slice(-n); }
  getErrors()          { return this.getByType('ERROR'); }

  // İstatistikler
  getStats() {
    const signals  = this.getByType('SIGNAL');
    const councils = this.getByType('COUNCIL_DECISION');
    const errors   = this.getByType('ERROR');
    return {
      totalLogs:     this.logs.length,
      signalCount:   signals.length,
      councilCount:  councils.length,
      errorCount:    errors.length,
      lastActivity:  this.logs[this.logs.length-1]?.timestamp || null,
    };
  }

  // Temizle
  clear() { this.logs = []; }

  // Export JSON
  export() { return JSON.stringify(this.logs, null, 2); }
}

// Singleton instance'lar
export const globalAlerts = new GlobalAlertEngine();
export const healthMonitor = new HealthMonitor();
export const logger = new LoggingEngine();

// ═══════════════════════════════════════════════════════════════════════════════
// 5. EMAIL ALERT ENGINE (EmailJS — tarayıcıdan direkt gönderim, backend yok)
// ═══════════════════════════════════════════════════════════════════════════════
// Kurulum: https://emailjs.com → ücretsiz (200 email/ay)
// Dashboard'dan: Service ID, Template ID, Public Key al
// Template değişkenleri: {{to_email}}, {{subject}}, {{signal}}, {{symbol}},
//   {{action}}, {{score}}, {{confidence}}, {{tp1}}, {{sl}}, {{reason}}, {{time}}

export class EmailAlertEngine {
  constructor({ serviceId = '', templateId = '', publicKey = '', toEmail = '' } = {}) {
    this.serviceId  = serviceId;
    this.templateId = templateId;
    this.publicKey  = publicKey;
    this.toEmail    = toEmail;
    this.enabled    = !!(serviceId && templateId && publicKey && toEmail);
    this.lastSent   = 0;
    this.minInterval = 60000; // 1 dakika minimum aralık (spam önlem)
  }

  // EmailJS SDK'yı dinamik yükle
  async _loadSDK() {
    if (window.emailjs) return window.emailjs;
    return new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = 'https://cdn.jsdelivr.net/npm/@emailjs/browser@4/dist/email.min.js';
      s.onload = () => {
        window.emailjs.init({ publicKey: this.publicKey });
        resolve(window.emailjs);
      };
      s.onerror = reject;
      document.head.appendChild(s);
    });
  }

  // Sinyal emaili gönder
  async sendSignal({ symbol, action, score, confidence, tp1, sl, reason, phase }) {
    if (!this.enabled) {
      console.log('[Email MOCK] Sinyal:', symbol, action, score);
      return { ok: true, mock: true };
    }
    const now = Date.now();
    if (now - this.lastSent < this.minInterval) {
      return { ok: false, reason: 'Rate limit — 1dk bekle' };
    }
    try {
      const ejsx = await this._loadSDK();
      const params = {
        to_email:   this.toEmail,
        subject:    `GMG Sinyal: ${action} — ${symbol}`,
        signal:     `${action} (${score}/100)`,
        symbol,
        action,
        score:      String(score),
        confidence: String(confidence),
        tp1:        tp1 ? String(tp1) : '—',
        sl:         sl  ? String(sl)  : '—',
        reason:     reason || 'Council onaylı sinyal',
        phase:      phase || '—',
        time:       new Date().toLocaleString('tr-TR'),
      };
      await ejsx.send(this.serviceId, this.templateId, params);
      this.lastSent = Date.now();
      return { ok: true };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  }

  // Genel metin emaili
  async sendRaw(subject, body) {
    if (!this.enabled) { console.log('[Email MOCK]', subject); return { ok: true, mock: true }; }
    try {
      const ejsx = await this._loadSDK();
      await ejsx.send(this.serviceId, this.templateId, {
        to_email: this.toEmail,
        subject,
        signal: body,
        symbol: '—', action: '—', score: '—', confidence: '—',
        tp1: '—', sl: '—', reason: body, phase: '—',
        time: new Date().toLocaleString('tr-TR'),
      });
      return { ok: true };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// 6. WEB PUSH ENGINE — tam izin yönetimi + bildirim gönderimi
// ═══════════════════════════════════════════════════════════════════════════════
export class WebPushEngine {
  constructor() {
    this.enabled = 'Notification' in window;
    this.permission = this.enabled ? Notification.permission : 'denied';
  }

  // İzin iste (kullanıcı onayı)
  async requestPermission() {
    if (!this.enabled) return 'not-supported';
    if (this.permission === 'granted') return 'granted';
    try {
      const perm = await Notification.requestPermission();
      this.permission = perm;
      return perm;
    } catch { return 'denied'; }
  }

  // Bildirim gönder
  async send(title, body, { icon = '📊', tag = 'gmg-signal', requireInteraction = false } = {}) {
    if (!this.enabled || this.permission !== 'granted') {
      // İzin yoksa iste
      const perm = await this.requestPermission();
      if (perm !== 'granted') {
        console.log('[WebPush MOCK]', title, body);
        return { ok: true, mock: true };
      }
    }
    try {
      const n = new Notification(title, { body, icon, tag, requireInteraction });
      return { ok: true, notification: n };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  }

  // Sinyal bildirimi — standart format
  async sendSignal({ symbol, action, score, confidence, tp1, sl }) {
    const title = `${action.includes('AL') ? '🟢' : action.includes('SAT') ? '🔴' : '🟡'} GMG — ${symbol}`;
    const body  = [
      `${action} · Skor: ${score}/100 · Güven: %${confidence}`,
      tp1 ? `TP: ${Number(tp1).toFixed(2)}` : '',
      sl  ? `SL: ${Number(sl).toFixed(2)}`  : '',
    ].filter(Boolean).join('\n');
    return this.send(title, body, { tag: `gmg-${symbol}`, requireInteraction: score >= 75 });
  }

  getStatus() {
    return {
      supported:  this.enabled,
      permission: this.permission,
      active:     this.enabled && this.permission === 'granted',
    };
  }
}

// Singleton
export const emailAlerts  = new EmailAlertEngine();
export const webPush      = new WebPushEngine();
