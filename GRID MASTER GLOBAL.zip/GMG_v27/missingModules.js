/**
 * missingModules.js — GMG v22
 * ============================
 * 235 modül hedefinden eksik kalan 18 modül — tek dosyada
 *
 * İçerik:
 *   TEKNİK: Keltner, Supertrend, TrendCloud
 *   KRİPTO: PanicDetector, NewListingMonitor, MEXCPumpHunter, CryptoContagion
 *   FOREX: SessionVolatility, InterventionRisk
 *   EMTİA: OPECPolicy, EnergyVolatility, PreciousMetalMomentum
 *   ENDEKS: IndexStress
 *   MAKRO: MacroEventCalendar, MacroSurprise, RateExpectation
 *   ALTYAPI: LatencyMonitor, CrossFeedValidator
 */

const clamp = (v, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, v ?? 0));

// ══════════════════════════════════════════════════════════════
// TEKNİK ANALİZ MODÜLLERİ
// ══════════════════════════════════════════════════════════════

/**
 * 22. Keltner Channel Engine
 * Kanal içi/dışı baskıyı ölçer — BB ile birlikte squeeze tespiti
 */
export function runKeltnerEngine(klines, emaPeriod = 20, atrPeriod = 10, mult = 1.5) {
  if (!klines || klines.length < emaPeriod) return { score: 50, squeeze: false, position: 'INSIDE' };

  const closes = klines.map(k => k.c);
  const highs  = klines.map(k => k.h || k.c);
  const lows   = klines.map(k => k.l || k.c);

  // EMA
  const k = 2 / (emaPeriod + 1);
  let ema = closes.slice(0, emaPeriod).reduce((a, b) => a + b) / emaPeriod;
  for (let i = emaPeriod; i < closes.length; i++) ema = closes[i] * k + ema * (1 - k);

  // ATR
  const atrs = [];
  for (let i = 1; i < klines.length; i++) {
    atrs.push(Math.max(highs[i] - lows[i], Math.abs(highs[i] - closes[i - 1]), Math.abs(lows[i] - closes[i - 1])));
  }
  const atr = atrs.slice(-atrPeriod).reduce((a, b) => a + b) / atrPeriod;

  const upper = ema + mult * atr;
  const lower = ema - mult * atr;
  const cur   = closes[closes.length - 1];

  const position = cur > upper ? 'ABOVE' : cur < lower ? 'BELOW' : 'INSIDE';
  const pct = clamp(((cur - lower) / (upper - lower)) * 100);

  let score = 50;
  if (position === 'ABOVE') score = 75;
  else if (position === 'BELOW') score = 25;

  return {
    score,
    ema:  parseFloat(ema.toFixed(4)),
    upper: parseFloat(upper.toFixed(4)),
    lower: parseFloat(lower.toFixed(4)),
    atr:  parseFloat(atr.toFixed(4)),
    position,
    pct:  parseFloat(pct.toFixed(1)),
    squeeze: false, // BB ile birlikte kullanıldığında doldurul
    signal: position === 'ABOVE' ? 'KIRILIM_YUKARI' : position === 'BELOW' ? 'KIRILIM_ASAGI' : 'KANAL_İÇİ',
    timestamp: Date.now(),
  };
}

/**
 * 23. Supertrend Engine
 * Trend filtresi — ATR bazlı destek/direnç çizgisi
 */
export function runSupertrendEngine(klines, period = 10, mult = 3) {
  if (!klines || klines.length < period + 1) return { trend: 'UP', score: 60, level: 0 };

  const highs  = klines.map(k => k.h || k.c);
  const lows   = klines.map(k => k.l || k.c);
  const closes = klines.map(k => k.c);

  // ATR hesapla
  const atrs = [0];
  for (let i = 1; i < klines.length; i++) {
    atrs.push(Math.max(highs[i] - lows[i], Math.abs(highs[i] - closes[i-1]), Math.abs(lows[i] - closes[i-1])));
  }
  // Smoothed ATR
  const smoothATR = (idx) => {
    const sl = atrs.slice(Math.max(0, idx - period + 1), idx + 1);
    return sl.reduce((a, b) => a + b, 0) / sl.length;
  };

  let trend = 1; // 1=UP, -1=DOWN
  let supertrend = 0;
  let prevUpper = Infinity, prevLower = 0;

  for (let i = period; i < klines.length; i++) {
    const atr    = smoothATR(i);
    const hl2    = (highs[i] + lows[i]) / 2;
    let upper = hl2 + mult * atr;
    let lower = hl2 - mult * atr;

    // Supertrend güncelleme
    lower = Math.max(lower, prevLower);
    upper = Math.min(upper, prevUpper);

    if (closes[i] > prevUpper)      trend = 1;
    else if (closes[i] < prevLower) trend = -1;

    supertrend = trend === 1 ? lower : upper;
    prevUpper  = upper;
    prevLower  = lower;
  }

  const cur     = closes[closes.length - 1];
  const bullish = trend === 1;
  const dist    = bullish ? (cur - supertrend) / cur * 100 : (supertrend - cur) / cur * 100;

  return {
    trend:      bullish ? 'UP' : 'DOWN',
    level:      parseFloat(supertrend.toFixed(4)),
    distance:   parseFloat(dist.toFixed(3)),
    score:      bullish ? clamp(55 + dist * 3) : clamp(45 - dist * 3),
    signal:     bullish ? 'AL' : 'SAT',
    color:      bullish ? '#00e676' : '#ff2255',
    timestamp:  Date.now(),
  };
}

/**
 * 24. Trend Cloud Engine (basit Ichimoku benzeri)
 * Trendin güç ve yön haritası
 */
export function runTrendCloudEngine(klines, fast = 9, slow = 26, signal = 52) {
  if (!klines || klines.length < slow) return { inCloud: true, above: false, score: 50 };

  const tenkan = (n) => {
    const sl = klines.slice(-n);
    return (Math.max(...sl.map(k => k.h || k.c)) + Math.min(...sl.map(k => k.l || k.c))) / 2;
  };

  const tk = tenkan(fast);   // Dönüşüm çizgisi
  const kj = tenkan(slow);   // Temel çizgi
  const sA = (tk + kj) / 2; // Span A (bulutun üst sınırı)
  const sB = tenkan(signal); // Span B (bulutun alt sınırı)

  const cur      = klines[klines.length - 1].c;
  const cloudTop = Math.max(sA, sB);
  const cloudBot = Math.min(sA, sB);

  const aboveCloud = cur > cloudTop;
  const belowCloud = cur < cloudBot;
  const inCloud    = !aboveCloud && !belowCloud;
  const tkAboveKj  = tk > kj; // Dönüşüm temel çizginin üzerinde

  let score = 50;
  if (aboveCloud && tkAboveKj) score = 72;
  else if (aboveCloud)         score = 62;
  else if (belowCloud && !tkAboveKj) score = 28;
  else if (belowCloud)         score = 38;

  return {
    score,
    tenkan:    parseFloat(tk.toFixed(4)),
    kijun:     parseFloat(kj.toFixed(4)),
    spanA:     parseFloat(sA.toFixed(4)),
    spanB:     parseFloat(sB.toFixed(4)),
    cloudTop:  parseFloat(cloudTop.toFixed(4)),
    cloudBot:  parseFloat(cloudBot.toFixed(4)),
    aboveCloud,
    belowCloud,
    inCloud,
    tkAboveKj,
    signal:    aboveCloud ? 'GÜÇLÜ TREND YUKARI' : belowCloud ? 'GÜÇLÜ TREND AŞAĞI' : 'BULUT İÇİ — BEKLİYOR',
    timestamp: Date.now(),
  };
}

// ══════════════════════════════════════════════════════════════
// KRİPTO ÖZEL MODÜLLERİ
// ══════════════════════════════════════════════════════════════

/**
 * 111. Panic Detector
 * Topluluk paniğini ve ani satış baskısını ölçer
 */
export function runPanicDetector({
  priceChange1h = 0,
  priceChange15m = 0,
  volumeSpike = 1,      // avgVol'a oran
  fearGreed = 50,
  liquidationVolume = 0,
  socialSentiment = 0,  // -100 → +100
}) {
  let panicScore = 0;

  if (priceChange15m < -3)  panicScore += 30;
  else if (priceChange15m < -1.5) panicScore += 15;

  if (priceChange1h < -5)   panicScore += 25;
  else if (priceChange1h < -2) panicScore += 12;

  if (volumeSpike > 3)      panicScore += 20;
  else if (volumeSpike > 2) panicScore += 10;

  if (fearGreed < 20)       panicScore += 15;
  else if (fearGreed < 30)  panicScore += 8;

  if (liquidationVolume > 1e8) panicScore += 15;
  else if (liquidationVolume > 5e7) panicScore += 8;

  if (socialSentiment < -50) panicScore += 10;

  const isPanic = panicScore >= 50;
  const level   = panicScore >= 75 ? 'KRİTİK' : panicScore >= 50 ? 'YÜKSEK' : panicScore >= 30 ? 'ORTA' : 'DÜŞÜK';

  return {
    score: clamp(panicScore),
    isPanic,
    level,
    priceChange15m,
    priceChange1h,
    volumeSpike: parseFloat(volumeSpike.toFixed(2)),
    verdict: isPanic
      ? `⛔ PANİK TESPİT EDİLDİ (${level}) — Giriş yapma`
      : panicScore >= 30
      ? `⚠️ Artan satış baskısı`
      : `✓ Normal piyasa`,
    action: isPanic ? 'WAIT' : 'PASS',
    timestamp: Date.now(),
  };
}

/**
 * 96. New Listing Monitor
 * Yeni listelenen coinlerdeki pump/dump riskini ölçer
 */
export function runNewListingMonitor(listings = []) {
  // listings: [{symbol, listingDate, exchange, priceChange24h, volume24h, marketCap}]
  if (!listings.length) return { alerts: [], riskCount: 0 };

  const now = Date.now();
  const alerts = listings.map(l => {
    const ageHours = (now - (l.listingDate || now)) / 3600000;
    const isNew    = ageHours < 72;
    const isPump   = l.priceChange24h > 50;
    const isDump   = l.priceChange24h < -30;
    const lowLiq   = (l.volume24h || 0) < 1e6;
    const noMcap   = !l.marketCap || l.marketCap < 5e6;

    let riskScore = 0;
    if (isNew)   riskScore += 20;
    if (isPump)  riskScore += 30;
    if (isDump)  riskScore += 25;
    if (lowLiq)  riskScore += 15;
    if (noMcap)  riskScore += 10;

    return {
      ...l,
      ageHours:  parseFloat(ageHours.toFixed(1)),
      riskScore: clamp(riskScore),
      isPump, isDump, lowLiq, isNew,
      warning: riskScore >= 50
        ? `⛔ ${l.symbol}: Yeni listing + ${isPump ? 'PUMP' : 'DUMP'} — yüksek risk`
        : riskScore >= 30
        ? `⚠️ ${l.symbol}: Yeni listing, dikkat`
        : null,
    };
  });

  return {
    alerts:    alerts.filter(a => a.warning),
    all:       alerts,
    riskCount: alerts.filter(a => a.riskScore >= 50).length,
    timestamp: Date.now(),
  };
}

/**
 * 97. MEXC Pump Hunter
 * MEXC'e özgü düşük hacimli pump sinyallerini ayıklar
 */
export function runMEXCPumpHunter(mexcCoins = []) {
  // mexcCoins: [{symbol, priceChange1h, priceChange24h, volume24h, listingDate}]
  const suspects = mexcCoins.filter(c => {
    const bigMove    = Math.abs(c.priceChange1h || 0) > 20;
    const lowVolume  = (c.volume24h || 0) < 5e5;
    const newListing = c.listingDate && (Date.now() - c.listingDate) < 7 * 24 * 3600000;
    return bigMove || (lowVolume && Math.abs(c.priceChange24h || 0) > 30) || newListing;
  });

  const critical = suspects.filter(c => Math.abs(c.priceChange1h || 0) > 50);

  return {
    suspects:     suspects.slice(0, 10),
    critical:     critical.slice(0, 5),
    suspectCount: suspects.length,
    verdict: critical.length > 0
      ? `⛔ ${critical.length} KRİTİK MEXC pump tespit edildi`
      : suspects.length > 0
      ? `⚠️ ${suspects.length} şüpheli MEXC hareketi`
      : `✓ Anormal MEXC hareketi yok`,
    timestamp: Date.now(),
  };
}

/**
 * 115. Crypto Contagion Engine
 * BTC düşüşünün altcoinlere yayılma hızını ölçer
 */
export function runCryptoContagionEngine({ btcChange = 0, coinChanges = [], threshold = -5 }) {
  if (btcChange > -1) return { contagion: false, score: 0, affectedCoins: [], ratio: 0 };

  const affected = coinChanges.filter(c => (c.change || 0) < btcChange - 1.5);
  const severe   = coinChanges.filter(c => (c.change || 0) < threshold);
  const ratio    = coinChanges.length > 0 ? affected.length / coinChanges.length : 0;

  let score = 0;
  if (ratio > 0.7) score += 50;
  if (ratio > 0.5) score += 20;
  if (severe.length > coinChanges.length * 0.3) score += 20;
  if (btcChange < -5) score += 10;

  return {
    contagion:    score >= 50,
    score:        clamp(score),
    ratio:        parseFloat(ratio.toFixed(3)),
    affectedCoins: affected.slice(0, 10).map(c => c.symbol),
    severeCoins:  severe.slice(0, 5).map(c => c.symbol),
    btcChange:    parseFloat(btcChange.toFixed(2)),
    verdict: score >= 70
      ? `⛔ Yayılma kritik — coinlerin ${(ratio * 100).toFixed(0)}%'i etkileniyor`
      : score >= 50
      ? `⚠️ Bulaşma başladı`
      : `✓ BTC etkisi kontrollü`,
    timestamp: Date.now(),
  };
}

// ══════════════════════════════════════════════════════════════
// FOREX ÖZEL MODÜLLERİ
// ══════════════════════════════════════════════════════════════

/**
 * 125. Session Volatility Engine
 * Seans bazlı (Asya/Londra/NY) oynaklık analizi
 */
export function runSessionVolatilityEngine(utcHour = new Date().getUTCHours(), klines = []) {
  // Seans tanımları (UTC)
  const sessions = {
    asia:     { start: 0,  end: 8,  label: 'Asya',  avgVolMult: 0.7 },
    london:   { start: 7,  end: 16, label: 'Londra', avgVolMult: 1.3 },
    newyork:  { start: 13, end: 22, label: 'New York', avgVolMult: 1.5 },
    overlap:  { start: 13, end: 16, label: 'Londra/NY Çakışma', avgVolMult: 2.0 },
  };

  let activeSession = 'asia';
  if (utcHour >= 13 && utcHour < 16) activeSession = 'overlap';
  else if (utcHour >= 13 && utcHour < 22) activeSession = 'newyork';
  else if (utcHour >= 7 && utcHour < 16) activeSession = 'london';

  const session = sessions[activeSession];

  // Klines varsa gerçek ATR hesapla
  let sessionATR = null;
  if (klines.length > 5) {
    const recent = klines.slice(-20);
    const atrs = recent.slice(1).map((k, i) => Math.max(
      (k.h || k.c) - (k.l || k.c),
      Math.abs((k.h || k.c) - recent[i].c),
      Math.abs((k.l || k.c) - recent[i].c)
    ));
    sessionATR = atrs.reduce((a, b) => a + b) / atrs.length;
  }

  const volScore = clamp(session.avgVolMult * 50);

  return {
    activeSession,
    sessionLabel:  session.label,
    utcHour,
    volMultiplier: session.avgVolMult,
    isHighVol:     session.avgVolMult >= 1.3,
    isOverlap:     activeSession === 'overlap',
    sessionATR,
    score:         parseFloat(volScore.toFixed(1)),
    verdict: activeSession === 'overlap'
      ? '🔥 Londra/NY çakışması — maksimum volatilite'
      : activeSession === 'newyork'
      ? '📈 New York seansı — yüksek hacim'
      : activeSession === 'london'
      ? '📊 Londra seansı — orta-yüksek hacim'
      : '😴 Asya seansı — düşük volatilite',
    recommendation: activeSession === 'asia'
      ? 'Scalp dikkat — spread geniş olabilir'
      : 'Normal işlem koşulları',
    timestamp: Date.now(),
  };
}

/**
 * 124. Intervention Risk Engine
 * Merkez bankası döviz müdahalesi riskini ölçer
 */
export function runInterventionRiskEngine({
  pair = 'USDJPY',
  currentRate = 150,
  historicalRange = { high: 152, low: 130 },
  centralBankTone = 'neutral',  // hawkish | neutral | dovish
  recentInterventions = [],
}) {
  let riskScore = 0;
  const signals = [];

  // Tarihi aralığın uç noktalarına yakınlık
  const rangeSize = historicalRange.high - historicalRange.low;
  const posInRange = rangeSize > 0 ? (currentRate - historicalRange.low) / rangeSize : 0.5;

  if (posInRange > 0.9) {
    riskScore += 40;
    signals.push(`${pair} tarihi yüksek yakınında (${(posInRange * 100).toFixed(0)}%)`);
  } else if (posInRange < 0.1) {
    riskScore += 35;
    signals.push(`${pair} tarihi düşük yakınında`);
  }

  // Merkez bankası tonu
  if (centralBankTone === 'hawkish') { riskScore += 20; signals.push('Merkez bankası şahin ton'); }
  if (centralBankTone === 'dovish')  { riskScore += 15; signals.push('Merkez bankası güvercin ton'); }

  // Son müdahaleler
  if (recentInterventions.length > 0) {
    riskScore += 25;
    signals.push(`Son ${recentInterventions.length} müdahale kaydı var`);
  }

  const isHigh = riskScore >= 50;
  return {
    score:   clamp(riskScore),
    isHigh,
    pair,
    currentRate,
    posInRange: parseFloat((posInRange * 100).toFixed(1)),
    signals,
    verdict: riskScore >= 70
      ? `⛔ ${pair} MÜDAHALESİ RİSKİ YÜKSEK`
      : riskScore >= 50
      ? `⚠️ Merkez bankası müdahalesi mümkün`
      : `✓ Müdahale riski düşük`,
    timestamp: Date.now(),
  };
}

// ══════════════════════════════════════════════════════════════
// EMTİA / ENDEKS MODÜLLERİ
// ══════════════════════════════════════════════════════════════

/**
 * 132. OPEC Policy Engine
 * OPEC üretim kararlarının petrol ve kripto üzerindeki etkisi
 */
export function runOPECPolicyEngine({
  opecDecision = 'hold',  // cut | hold | increase
  cutSize = 0,            // bin bpd
  complianceRate = 85,    // %
  currentWTI = 75,
  wtiChange = 0,
}) {
  let score = 50;
  const signals = [];

  if (opecDecision === 'cut') {
    score += Math.min(25, cutSize / 100 * 5);
    signals.push(`Üretim kesintisi: ${cutSize}K bpd`);
    // Petrol yükselir → enflasyon riski → kripto için olumsuz
    score -= 5;
    signals.push('Enflasyon riski → Kripto baskısı');
  } else if (opecDecision === 'increase') {
    score -= 15;
    signals.push('Üretim artışı → Petrol düşüş baskısı');
  }

  if (complianceRate < 70) {
    score -= 10;
    signals.push(`Düşük uyum oranı: %${complianceRate}`);
  }

  if (wtiChange > 5) {
    score += 10;
    signals.push(`WTI $${currentWTI.toFixed(1)} (+${wtiChange.toFixed(1)}%)`);
  } else if (wtiChange < -5) {
    score -= 10;
    signals.push(`WTI $${currentWTI.toFixed(1)} (${wtiChange.toFixed(1)}%)`);
  }

  return {
    score:       clamp(score),
    opecDecision,
    cutSize,
    complianceRate,
    currentWTI,
    wtiChange,
    signals,
    cryptoEffect: opecDecision === 'cut' && wtiChange > 3 ? 'NEGATIF' : 'NÖTR',
    verdict: opecDecision === 'cut'
      ? `⛔ OPEC kesinti → Petrol artış → Enflasyon riski`
      : opecDecision === 'increase'
      ? `📉 OPEC artış → Petrol baskısı`
      : `✓ OPEC sabit`,
    timestamp: Date.now(),
  };
}

/**
 * 133. Energy Volatility Engine
 * Enerji piyasası oynaklığının kripto üzerindeki etkisi
 */
export function runEnergyVolatilityEngine({
  wtiChange = 0,
  natGasChange = 0,
  wtiPrice = 75,
  energyCrisis = false,
}) {
  let score = 50;
  const signals = [];

  // Petrol ani spike
  if (Math.abs(wtiChange) > 5) {
    score -= Math.abs(wtiChange) * 1.5;
    signals.push(`WTI ani hareket: ${wtiChange >= 0 ? '+' : ''}${wtiChange.toFixed(1)}%`);
  }

  // Doğalgaz krizi
  if (Math.abs(natGasChange) > 10) {
    score -= 10;
    signals.push(`Doğalgaz volatilite: ${natGasChange >= 0 ? '+' : ''}${natGasChange.toFixed(1)}%`);
  }

  // Enerji krizi modu
  if (energyCrisis) {
    score -= 20;
    signals.push('Enerji krizi aktif → Kripto madencilik maliyeti artar');
  }

  // Düşük petrol = iyi (enflasyon baskısı azalır)
  if (wtiPrice < 70 && wtiChange < 0) {
    score += 8;
    signals.push('Petrol düşüyor → Enflasyon baskısı azalıyor');
  }

  return {
    score: clamp(score),
    wtiChange, natGasChange, wtiPrice, energyCrisis,
    signals,
    verdict: clamp(score) < 40
      ? '⚠️ Enerji volatilitesi yüksek — maliyet baskısı'
      : '✓ Enerji piyasası sakin',
    timestamp: Date.now(),
  };
}

/**
 * 128. Precious Metal Momentum Engine
 * Altın ve gümüş momentumunun kripto ile ilişkisi
 */
export function runPreciousMetalMomentumEngine({
  goldChange = 0,
  silverChange = 0,
  platinumChange = 0,
  goldPrice = 2000,
}) {
  // Altın-Kripto: genellikle pozitif korelasyon (enflasyon hedge)
  // Altın ani yükseliş → risk-off → kripto için belirsiz
  let score = 50;
  const signals = [];

  const goldMomentum = goldChange > 1 ? 'YUKARI' : goldChange < -1 ? 'AŞAĞI' : 'YATAY';

  if (goldChange > 2) {
    score -= 5; // Güçlü altın alımı = risk-off = kripto olumsuz
    signals.push(`Altın güçlü yükseliş: +${goldChange.toFixed(2)}% → Safe haven talebi`);
  } else if (goldChange < -2) {
    score += 8; // Altın satışı = risk-on
    signals.push(`Altın düşüyor: ${goldChange.toFixed(2)}% → Risk-on eğilim`);
  }

  if (silverChange > goldChange + 2) {
    score += 5;
    signals.push('Gümüş altını geçiyor → Spekülatif iştah var');
  }

  // Gold/Silver ratio
  const gsRatio = silverChange !== 0 ? goldChange / (silverChange || 1) : 1;

  return {
    score: clamp(score),
    goldChange, silverChange, platinumChange, goldPrice,
    goldMomentum,
    gsRatio: parseFloat(gsRatio.toFixed(2)),
    signals,
    safeHavenActive: goldChange > 1.5,
    verdict: goldChange > 2
      ? '🥇 Güçlü altın → Safe haven talebi artıyor'
      : goldChange < -1.5
      ? '📉 Altın zayıf → Risk iştahı var'
      : '✓ Değerli metaller dengeli',
    timestamp: Date.now(),
  };
}

/**
 * 140. Index Stress Engine
 * Hisse endekslerinin stres/kırılganlık analizi
 */
export function runIndexStressEngine({
  sp500Change = 0,
  nasdaqChange = 0,
  vixLevel = 20,
  marketBreadth = 0.6,  // Yükselen hisse oranı (0-1)
  putCallRatio = 1.0,   // > 1.2 = aşırı koruyucu
  spxAbove200MA = true,
}) {
  let stressScore = 0;
  const signals = [];

  if (vixLevel > 30) { stressScore += 30; signals.push(`VIX ${vixLevel.toFixed(1)} — yüksek korku`); }
  else if (vixLevel > 20) { stressScore += 15; }

  if (sp500Change < -2) { stressScore += 25; signals.push(`S&P 500: ${sp500Change.toFixed(2)}%`); }
  else if (sp500Change < -1) { stressScore += 12; }

  if (nasdaqChange < -3) { stressScore += 20; signals.push(`Nasdaq: ${nasdaqChange.toFixed(2)}%`); }

  if (marketBreadth < 0.3) { stressScore += 20; signals.push(`Piyasa genişliği zayıf: ${(marketBreadth * 100).toFixed(0)}%`); }

  if (putCallRatio > 1.3) { stressScore += 15; signals.push(`Put/Call: ${putCallRatio.toFixed(2)} — aşırı riskten korunma`); }

  if (!spxAbove200MA) { stressScore += 10; signals.push('S&P 500 200 MA altında'); }

  const level = stressScore >= 70 ? 'KRİTİK' : stressScore >= 50 ? 'YÜKSEK' : stressScore >= 30 ? 'ORTA' : 'DÜŞÜK';
  const cryptoImpact = stressScore >= 50 ? 'NEGATIF' : stressScore >= 30 ? 'BASKILI' : 'NÖTR';

  return {
    score: clamp(stressScore),
    level,
    cryptoImpact,
    vixLevel, sp500Change, nasdaqChange, marketBreadth, putCallRatio,
    signals,
    verdict: stressScore >= 60
      ? `⛔ Endeks stresi ${level} → Kripto satış baskısı`
      : stressScore >= 30
      ? `⚠️ Endeks baskısı var`
      : `✓ Endeksler dengeli`,
    timestamp: Date.now(),
  };
}

// ══════════════════════════════════════════════════════════════
// TAHVİL / MAKRO MODÜLLERİ
// ══════════════════════════════════════════════════════════════

/**
 * 148. Macro Event Calendar
 * FOMC/NFP/CPI/GDP gibi olayların risk skoru
 */
export const MacroEventCalendar = {
  // Sabit yüksek etkili olaylar
  HIGH_IMPACT_EVENTS: [
    { name: 'FOMC Kararı',      type: 'FED',  impact: 0.9, cryptoEffect: 'HIGH' },
    { name: 'CPI Enflasyon',    type: 'CPI',  impact: 0.8, cryptoEffect: 'HIGH' },
    { name: 'NFP İstihdam',     type: 'NFP',  impact: 0.7, cryptoEffect: 'MEDIUM' },
    { name: 'GDP Büyüme',       type: 'GDP',  impact: 0.6, cryptoEffect: 'MEDIUM' },
    { name: 'PPI Üretici Fiyat',type: 'PPI',  impact: 0.6, cryptoEffect: 'MEDIUM' },
    { name: 'PCE Fiyat',        type: 'PCE',  impact: 0.7, cryptoEffect: 'HIGH' },
    { name: 'JOLTS İş İlanı',   type: 'JOLTS',impact: 0.5, cryptoEffect: 'LOW' },
    { name: 'Michigan Güven',   type: 'CONF', impact: 0.4, cryptoEffect: 'LOW' },
  ],

  // 2026 FOMC + CPI + NFP tarihleri (hardcode)
  KNOWN_EVENTS_2026: [
    { name:'FOMC Kararı',    type:'FED', impact:0.9, cryptoEffect:'HIGH',   time: new Date('2026-01-29T19:00:00Z').getTime() },
    { name:'CPI Enflasyon',  type:'CPI', impact:0.8, cryptoEffect:'HIGH',   time: new Date('2026-02-12T13:30:00Z').getTime() },
    { name:'NFP İstihdam',   type:'NFP', impact:0.7, cryptoEffect:'MEDIUM', time: new Date('2026-02-06T13:30:00Z').getTime() },
    { name:'FOMC Kararı',    type:'FED', impact:0.9, cryptoEffect:'HIGH',   time: new Date('2026-03-19T18:00:00Z').getTime() },
    { name:'CPI Enflasyon',  type:'CPI', impact:0.8, cryptoEffect:'HIGH',   time: new Date('2026-03-11T13:30:00Z').getTime() },
    { name:'NFP İstihdam',   type:'NFP', impact:0.7, cryptoEffect:'MEDIUM', time: new Date('2026-03-06T13:30:00Z').getTime() },
    { name:'FOMC Kararı',    type:'FED', impact:0.9, cryptoEffect:'HIGH',   time: new Date('2026-05-07T18:00:00Z').getTime() },
    { name:'CPI Enflasyon',  type:'CPI', impact:0.8, cryptoEffect:'HIGH',   time: new Date('2026-04-10T13:30:00Z').getTime() },
    { name:'NFP İstihdam',   type:'NFP', impact:0.7, cryptoEffect:'MEDIUM', time: new Date('2026-04-03T13:30:00Z').getTime() },
    { name:'FOMC Kararı',    type:'FED', impact:0.9, cryptoEffect:'HIGH',   time: new Date('2026-06-18T18:00:00Z').getTime() },
    { name:'PCE Fiyat',      type:'PCE', impact:0.7, cryptoEffect:'HIGH',   time: new Date('2026-05-29T13:30:00Z').getTime() },
  ],

  getUpcoming(withinHours = 48, customEvents = []) {
    const now   = Date.now();
    const limit = withinHours * 3600000;
    const allEvents = [
      ...(this._events || []),
      ...(this.KNOWN_EVENTS_2026 || []),
      ...customEvents,
    ];
    return allEvents
      .filter(e => e.time && e.time > now && (e.time - now) < limit)
      .sort((a, b) => a.time - b.time)
      .slice(0, 10);
  },

  getAll() {
    const now = Date.now();
    return [
      ...(this._events || []),
      ...(this.KNOWN_EVENTS_2026 || []),
    ].sort((a, b) => a.time - b.time)
     .filter(e => e.time > now - 86400000); // son 24s + gelecek
  },

  getRiskScore(upcomingEvents = []) {
    if (!upcomingEvents.length) return { score: 0, events: [], message: 'Yakın vadede önemli olay yok' };
    const highImpact = upcomingEvents.filter(e => e.impact >= 0.7);
    const score = clamp(highImpact.length * 30 + upcomingEvents.length * 10);
    return {
      score,
      events:  upcomingEvents.slice(0, 5),
      message: highImpact.length > 0
        ? `⚠️ ${highImpact.length} yüksek etkili olay: ${highImpact.map(e => e.name).join(', ')}`
        : `📅 ${upcomingEvents.length} orta etkili olay`,
    };
  },

  loadEvents(events) {
    this._events = events;
  },
};

/**
 * 156. Macro Surprise Engine
 * Açıklanan veri vs beklenti sapması analizi
 */
export function runMacroSurpriseEngine(events = []) {
  // events: [{name, type, actual, forecast, prev, impact}]
  if (!events.length) return { surpriseScore: 0, direction: 'NEUTRAL', events: [] };

  const analyzed = events.map(e => {
    if (!e.actual || !e.forecast) return { ...e, surprise: 0, direction: 'NEUTRAL' };
    const pctDev = ((e.actual - e.forecast) / Math.abs(e.forecast || 1)) * 100;

    // Tip bazlı etki:
    // CPI yüksek gelirse → faiz riski → kripto negatif
    // NFP yüksek gelirse → Fed sıkılaşma riski → kripto negatif
    // GDP yüksek gelirse → risk-on → kripto pozitif
    const cryptoEffect = {
      CPI:  pctDev > 0 ? -15 : 10,   // Yüksek enflasyon = kötü
      PPI:  pctDev > 0 ? -10 : 8,
      NFP:  pctDev > 0 ? -8  : 5,    // Güçlü istihdam = Fed sıkılaşır
      GDP:  pctDev > 0 ? 10  : -8,   // Güçlü büyüme = risk-on
      PCE:  pctDev > 0 ? -12 : 8,
      JOLTS:pctDev > 0 ? -5  : 3,
    }[e.type] ?? 0;

    return {
      ...e,
      surprise:    parseFloat(Math.abs(pctDev).toFixed(2)),
      pctDev:      parseFloat(pctDev.toFixed(2)),
      direction:   pctDev > 0 ? 'BEAT' : 'MISS',
      cryptoEffect: parseFloat((cryptoEffect * (e.impact || 0.5)).toFixed(1)),
    };
  });

  const avgSurprise   = analyzed.reduce((s, e) => s + e.surprise, 0) / Math.max(analyzed.length, 1);
  const totalEffect   = analyzed.reduce((s, e) => s + (e.cryptoEffect || 0), 0);
  const direction     = totalEffect > 5 ? 'POSITIVE' : totalEffect < -5 ? 'NEGATIVE' : 'NEUTRAL';

  return {
    surpriseScore: parseFloat(avgSurprise.toFixed(1)),
    direction,
    totalEffect:   parseFloat(totalEffect.toFixed(1)),
    events:        analyzed,
    beatCount:     analyzed.filter(e => e.direction === 'BEAT').length,
    missCount:     analyzed.filter(e => e.direction === 'MISS').length,
    verdict: direction === 'POSITIVE'
      ? `✅ Makro veri sürprizi pozitif (${totalEffect >= 0 ? '+' : ''}${totalEffect.toFixed(0)} etki)`
      : direction === 'NEGATIVE'
      ? `⚠️ Makro veri sürprizi negatif (${totalEffect.toFixed(0)} etki)`
      : `Veri beklenti dahilinde`,
    timestamp: Date.now(),
  };
}

/**
 * 143. Rate Expectation Engine
 * Fed faiz beklentisi — CME FedWatch benzeri analiz
 */
export function runRateExpectationEngine({
  currentRate = 5.25,
  nextMeetingDays = 30,
  inflationTrend = 'stable',   // falling | stable | rising
  laborMarket = 'strong',       // weak | neutral | strong
  fedStatements = [],           // ['dovish', 'hawkish', 'neutral']
  cmeProbs = {},                // { 'hold': 60, '-25bps': 30, '+25bps': 10 }
} = {}) {

  // Fed tonu analizi
  const toneScores = { hawkish: -15, neutral: 0, dovish: 15 };
  const avgTone = fedStatements.length
    ? fedStatements.reduce((s, t) => s + (toneScores[t] || 0), 0) / fedStatements.length
    : 0;

  // Olasılık analizi
  const sortedProbs = Object.entries(cmeProbs).sort((a, b) => b[1] - a[1]);
  const mostLikely  = sortedProbs[0]?.[0] || 'hold';
  const likelyProb  = sortedProbs[0]?.[1] || 50;
  const isCut       = mostLikely.includes('-');
  const isHike      = mostLikely.includes('+');

  // Kripto etkisi skoru
  let cryptoScore = 50;
  cryptoScore += avgTone;
  if (isCut)              cryptoScore += 15; // Faiz kesimi = likidite artar = kripto iyi
  if (isHike)             cryptoScore -= 15; // Faiz artırımı = likidite azalır = kripto kötü
  if (inflationTrend === 'falling')  cryptoScore += 8;
  if (inflationTrend === 'rising')   cryptoScore -= 10;
  if (laborMarket === 'weak')        cryptoScore += 5; // Zayıf istihdam = Fed gevşer
  if (nextMeetingDays < 7)           cryptoScore -= 5; // Yakın toplantı = belirsizlik

  return {
    score:        clamp(cryptoScore),
    currentRate,
    mostLikely,
    likelyProb,
    isCut,
    isHike,
    avgTone:      parseFloat(avgTone.toFixed(1)),
    inflationTrend,
    laborMarket,
    nextMeetingDays,
    cryptoImpact: isCut ? 'POZITIF' : isHike ? 'NEGATIF' : 'NÖTR',
    verdict: isCut
      ? `✅ Faiz kesimi beklentisi (%${likelyProb}) — Kripto için pozitif`
      : isHike
      ? `⚠️ Faiz artırımı beklentisi (%${likelyProb}) — Kripto için negatif`
      : `Fed sabit kalacak (%${likelyProb}) — Nötr etki`,
    timestamp: Date.now(),
  };
}

// ══════════════════════════════════════════════════════════════
// ALTYAPI MODÜLLERİ
// ══════════════════════════════════════════════════════════════

/**
 * 6. Latency Monitor
 * API ve veri kaynağı gecikme takibi
 */
export const LatencyMonitor = {
  _history: {},
  _thresholds: { warn: 1000, critical: 3000 }, // ms

  start(key) {
    this._history[key] = { ...this._history[key], start: Date.now() };
    return this;
  },

  end(key) {
    const h = this._history[key];
    if (!h?.start) return 0;
    const ms = Date.now() - h.start;
    this._history[key] = {
      ...h,
      last: ms,
      avg: h.avg ? h.avg * 0.8 + ms * 0.2 : ms,
      count: (h.count || 0) + 1,
      max: Math.max(h.max || 0, ms),
    };
    delete this._history[key].start;
    return ms;
  },

  get(key) {
    return this._history[key] || { last: 0, avg: 0, count: 0, max: 0 };
  },

  getAll() {
    return Object.entries(this._history).map(([key, v]) => ({
      key,
      last: v.last || 0,
      avg:  parseFloat((v.avg || 0).toFixed(1)),
      count: v.count || 0,
      max: v.max || 0,
      status: (v.last || 0) > this._thresholds.critical ? 'KRİTİK'
        : (v.last || 0) > this._thresholds.warn ? 'YAVAŞ' : 'NORMAL',
    }));
  },

  // record() — start/end çifti olmadan direkt ms kaydet (exchangeAPI_multi için)
  record(key, ms) {
    const h = this._history[key] || { count: 0, max: 0, avg: 0 };
    this._history[key] = {
      ...h,
      last:  ms,
      avg:   h.avg ? h.avg * 0.8 + ms * 0.2 : ms,
      count: (h.count || 0) + 1,
      max:   Math.max(h.max || 0, ms),
    };
    return ms;
  },

  isHighLatency(key, threshold = null) {
    const h = this._history[key];
    const t = threshold || this._thresholds.warn;
    return (h?.last || 0) > t;
  },

  getSummary() {
    const all = this.getAll();
    const slow = all.filter(h => h.status !== 'NORMAL');
    return {
      total: all.length,
      slowCount: slow.length,
      avgOverall: all.length ? parseFloat((all.reduce((s, h) => s + h.avg, 0) / all.length).toFixed(1)) : 0,
      slowEndpoints: slow.map(h => `${h.key}(${h.last}ms)`),
    };
  },
};

/**
 * 14. Cross Feed Validator
 * Aynı veriyi birden fazla kaynaktan doğrular
 */
export const CrossFeedValidator = {
  _tolerance: 0.005, // %0.5 tolerans

  validatePrice(sources = []) {
    // sources: [{name, price}]
    const valid = sources.filter(s => s.price > 0);
    if (valid.length < 2) return { ok: true, sources: valid, message: 'Tek kaynak' };

    const prices = valid.map(s => s.price);
    const avg    = prices.reduce((a, b) => a + b) / prices.length;
    const maxDev = Math.max(...prices.map(p => Math.abs(p - avg) / avg));

    const ok = maxDev < this._tolerance;
    const outliers = valid.filter(s => Math.abs(s.price - avg) / avg > this._tolerance);

    return {
      ok,
      avg:      parseFloat(avg.toFixed(6)),
      maxDev:   parseFloat((maxDev * 100).toFixed(4)),
      outliers: outliers.map(s => s.name),
      sources:  valid,
      verdict:  ok
        ? `✓ Çapraz doğrulama geçti (sapma: ${(maxDev * 100).toFixed(3)}%)`
        : `⚠️ Kaynak uyumsuzluğu! Sapma: ${(maxDev * 100).toFixed(3)}% — ${outliers.map(s => s.name).join(', ')} şüpheli`,
    };
  },

  validateMultiple(dataMap = {}) {
    // dataMap: { BTC: [{name, price}], ETH: [...] }
    const results = {};
    for (const [asset, sources] of Object.entries(dataMap)) {
      results[asset] = this.validatePrice(sources);
    }
    const failCount = Object.values(results).filter(r => !r.ok).length;
    return {
      results,
      allPassed: failCount === 0,
      failCount,
      summary: failCount === 0
        ? '✓ Tüm çapraz doğrulamalar geçti'
        : `⚠️ ${failCount} varlıkta kaynak uyumsuzluğu`,
    };
  },
};

// ══════════════════════════════════════════════════════════════
// MODÜL KAYIT — masterCouncil ve executionLayer için
// ══════════════════════════════════════════════════════════════

/**
 * runMissingModulesBundle — tüm eksik modülleri tek çağrıyla çalıştır
 * masterCouncil içinde kullanılabilir
 */
export function runMissingModulesBundle({
  klines = [],
  sessionUTCHour = new Date().getUTCHours(),
  goldChange = 0,
  silverChange = 0,
  oilChange = 0,
  wtiPrice = 75,
  sp500Change = 0,
  nasdaqChange = 0,
  vixLevel = 20,
  marketBreadth = 0.6,
  btcChange = 0,
  coinChanges = [],
  priceChange15m = 0,
  volumeSpike = 1,
  fearGreed = 50,
  fedRate = 5.25,
  inflationTrend = 'stable',
  laborMarket = 'strong',
} = {}) {

  const keltner    = klines.length >= 20 ? runKeltnerEngine(klines) : null;
  const supertrend = klines.length >= 11 ? runSupertrendEngine(klines) : null;
  const trendCloud = klines.length >= 26 ? runTrendCloudEngine(klines) : null;
  const sessionVol = runSessionVolatilityEngine(sessionUTCHour, klines);
  const precious   = runPreciousMetalMomentumEngine({ goldChange, silverChange });
  const energyVol  = runEnergyVolatilityEngine({ wtiChange: oilChange, wtiPrice });
  const indexStress= runIndexStressEngine({ sp500Change, nasdaqChange, vixLevel, marketBreadth });
  const contagion  = runCryptoContagionEngine({ btcChange, coinChanges });
  const panic      = runPanicDetector({ priceChange15m, volumeSpike, fearGreed });
  const rateExpect = runRateExpectationEngine({ currentRate: fedRate, inflationTrend, laborMarket });

  // Toplam ek skor (masterCouncil'e katkı)
  const bonusScore =
    (keltner?.score      ? (keltner.score - 50) * 0.1  : 0) +
    (supertrend?.score   ? (supertrend.score - 50) * 0.1 : 0) +
    (precious.score      ? (precious.score - 50) * 0.08  : 0) +
    (energyVol.score     ? (energyVol.score - 50) * 0.06  : 0) +
    (indexStress.score   ? (50 - indexStress.score) * 0.08 : 0) + // stres inverse
    (rateExpect.score    ? (rateExpect.score - 50) * 0.1  : 0);

  return {
    keltner, supertrend, trendCloud, sessionVol,
    precious, energyVol, indexStress, contagion,
    panic, rateExpect,
    bonusScore: parseFloat(bonusScore.toFixed(2)),
    alerts: [
      ...(panic.isPanic ? [`⛔ PANİK: ${panic.verdict}`] : []),
      ...(contagion.contagion ? [`⚠️ BULAŞMA: ${contagion.verdict}`] : []),
      ...(indexStress.score >= 60 ? [`📉 ENDEKS STRESİ: ${indexStress.level}`] : []),
    ],
    timestamp: Date.now(),
  };
}

// ─── LatencyMonitor.record() — doğrudan ms kayıt (start/end olmadan) ──────────
// exchangeAPI_multi.js'ten çağrılır
if (typeof LatencyMonitor !== 'undefined' && !LatencyMonitor.record) {
  LatencyMonitor.record = function(key, ms) {
    const h = this._history[key] || { count: 0, avg: 0, max: 0 };
    this._history[key] = {
      last:  ms,
      avg:   h.avg ? h.avg * 0.8 + ms * 0.2 : ms,
      count: (h.count || 0) + 1,
      max:   Math.max(h.max || 0, ms),
    };
  };
}
