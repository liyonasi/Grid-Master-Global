/**
 * infraEngine.js — GMG v16
 * Altyapı Katmanı:
 *   - Health Monitor     (modül online/offline)
 *   - Logging Engine     (karar + hata logları)
 *   - Audit Trail Engine (hangi modül neden karar verdi)
 *   - API Rate Limit Guard
 *   - Latency Monitor
 *   - Data Sanity Check
 *   - Duplicate Data Filter
 *   - Time Sync Engine
 *   - Emergency Safe Mode
 */

const clamp = (v, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, v));

// ─── LOG STORE ────────────────────────────────────────────────────────────────
const _logs = [];
const _audit = [];
const MAX_LOGS = 500;

// ─── LOGGING ENGINE ───────────────────────────────────────────────────────────
export const LoggingEngine = {
  log(level, module, message, data = null) {
    const entry = {
      ts: Date.now(),
      time: new Date().toLocaleTimeString('tr-TR'),
      level,   // 'INFO' | 'WARN' | 'ERROR' | 'SIGNAL' | 'DECISION'
      module,
      message,
      data,
    };
    _logs.push(entry);
    if (_logs.length > MAX_LOGS) _logs.shift();
    if (level === 'ERROR') console.error(`[GMG ${module}]`, message, data || '');
    else if (level === 'WARN') console.warn(`[GMG ${module}]`, message);
  },
  info:   (mod, msg, data) => LoggingEngine.log('INFO', mod, msg, data),
  warn:   (mod, msg, data) => LoggingEngine.log('WARN', mod, msg, data),
  error:  (mod, msg, data) => LoggingEngine.log('ERROR', mod, msg, data),
  signal: (mod, msg, data) => LoggingEngine.log('SIGNAL', mod, msg, data),
  decision:(mod, msg, data)=> LoggingEngine.log('DECISION', mod, msg, data),
  getLogs: (level = null, limit = 100) => {
    let logs = level ? _logs.filter(l => l.level === level) : _logs;
    return logs.slice(-limit).reverse();
  },
  clear: () => { _logs.length = 0; },
};

// ─── AUDIT TRAIL ENGINE ───────────────────────────────────────────────────────
export const AuditTrailEngine = {
  record({ module, action, reason, score, inputs = {}, timestamp = Date.now() }) {
    const entry = { ts: timestamp, time: new Date(timestamp).toLocaleTimeString('tr-TR'), module, action, reason, score, inputs };
    _audit.push(entry);
    if (_audit.length > MAX_LOGS) _audit.shift();
  },
  getTrail: (limit = 50) => _audit.slice(-limit).reverse(),
  getModuleHistory: (moduleName, limit = 20) => _audit.filter(a => a.module === moduleName).slice(-limit).reverse(),
  summarize() {
    const byModule = {};
    _audit.forEach(a => {
      if (!byModule[a.module]) byModule[a.module] = { total: 0, buy: 0, sell: 0, wait: 0 };
      byModule[a.module].total++;
      if (a.action === 'BUY')  byModule[a.module].buy++;
      else if (a.action === 'SELL') byModule[a.module].sell++;
      else byModule[a.module].wait++;
    });
    return byModule;
  },
};

// ─── HEALTH MONITOR ───────────────────────────────────────────────────────────
const _moduleHealth = {};

export const HealthMonitor = {
  register(moduleName) {
    _moduleHealth[moduleName] = { status: 'online', lastSeen: Date.now(), errors: 0, latency: 0 };
  },
  ping(moduleName, latencyMs = 0) {
    if (!_moduleHealth[moduleName]) this.register(moduleName);
    _moduleHealth[moduleName].status = 'online';
    _moduleHealth[moduleName].lastSeen = Date.now();
    _moduleHealth[moduleName].latency = latencyMs;
  },
  fail(moduleName, reason = '') {
    if (!_moduleHealth[moduleName]) this.register(moduleName);
    _moduleHealth[moduleName].status = 'error';
    _moduleHealth[moduleName].errors++;
    _moduleHealth[moduleName].lastError = reason;
    LoggingEngine.error('HealthMonitor', `${moduleName} HATA: ${reason}`);
  },
  offline(moduleName) {
    if (!_moduleHealth[moduleName]) this.register(moduleName);
    const age = Date.now() - (_moduleHealth[moduleName].lastSeen || 0);
    if (age > 30000) _moduleHealth[moduleName].status = 'offline';
  },
  getStatus: () => ({ ..._moduleHealth }),
  isOnline: (moduleName) => _moduleHealth[moduleName]?.status === 'online',
  getOfflineModules: () => Object.entries(_moduleHealth).filter(([,v]) => v.status !== 'online').map(([k]) => k),
  getSummary() {
    const all = Object.values(_moduleHealth);
    return { total: all.length, online: all.filter(m => m.status === 'online').length, offline: all.filter(m => m.status === 'offline').length, error: all.filter(m => m.status === 'error').length };
  },
};

// ─── LATENCY MONITOR ─────────────────────────────────────────────────────────
const _latencyHistory = {};

export const LatencyMonitor = {
  start(key) { _latencyHistory[key] = { start: Date.now() }; },
  end(key) {
    if (!_latencyHistory[key]) return 0;
    const ms = Date.now() - _latencyHistory[key].start;
    _latencyHistory[key].last = ms;
    if (!_latencyHistory[key].avg) _latencyHistory[key].avg = ms;
    else _latencyHistory[key].avg = (_latencyHistory[key].avg * 0.8 + ms * 0.2);
    return ms;
  },
  get: (key) => _latencyHistory[key] || { last: 0, avg: 0 },
  getAll: () => ({ ..._latencyHistory }),
  isHighLatency: (key, thresholdMs = 2000) => (_latencyHistory[key]?.last || 0) > thresholdMs,
};

// ─── API RATE LIMIT GUARD ─────────────────────────────────────────────────────
const _rateLimits = {};

export const RateLimitGuard = {
  // exchange: { limit: req/min, used: count, reset: timestamp }
  init(exchange, limitPerMinute = 1200) {
    _rateLimits[exchange] = { limit: limitPerMinute, used: 0, reset: Date.now() + 60000, blocked: false };
  },
  canRequest(exchange) {
    if (!_rateLimits[exchange]) this.init(exchange);
    const rl = _rateLimits[exchange];
    // Reset her dakika
    if (Date.now() > rl.reset) { rl.used = 0; rl.reset = Date.now() + 60000; rl.blocked = false; }
    if (rl.used >= rl.limit * 0.9) { rl.blocked = true; LoggingEngine.warn('RateLimit', `${exchange} rate limit yaklaşıyor: ${rl.used}/${rl.limit}`); return false; }
    rl.used++;
    return true;
  },
  consume(exchange, weight = 1) {
    if (!_rateLimits[exchange]) this.init(exchange);
    _rateLimits[exchange].used += weight;
  },
  getStatus: (exchange) => _rateLimits[exchange] || null,
  getAllStatus: () => ({ ..._rateLimits }),
  resetAll: () => { Object.keys(_rateLimits).forEach(k => { _rateLimits[k].used = 0; _rateLimits[k].blocked = false; }); },
};

// ─── DATA SANITY CHECK ENGINE ─────────────────────────────────────────────────
export const DataSanityCheck = {
  checkPrice(price, symbol = '') {
    if (!price || typeof price !== 'number') return { ok: false, reason: 'Fiyat geçersiz' };
    if (price <= 0) return { ok: false, reason: 'Fiyat sıfır veya negatif' };
    if (!isFinite(price)) return { ok: false, reason: 'Fiyat Infinite/NaN' };
    return { ok: true };
  },
  checkKline(k) {
    if (!k || typeof k !== 'object') return { ok: false, reason: 'Kline objesi yok' };
    if (!k.c || !k.o || !k.h || !k.l) return { ok: false, reason: 'OHLC eksik' };
    if (k.h < k.l) return { ok: false, reason: 'High < Low: bozuk veri' };
    if (k.h < k.o || k.h < k.c) return { ok: false, reason: 'High < O/C: bozuk veri' };
    if (k.l > k.o || k.l > k.c) return { ok: false, reason: 'Low > O/C: bozuk veri' };
    return { ok: true };
  },
  checkKlines(klines) {
    if (!Array.isArray(klines) || klines.length < 2) return { ok: false, reason: 'Klines dizisi boş' };
    const bad = klines.filter(k => !this.checkKline(k).ok);
    if (bad.length > klines.length * 0.05) return { ok: false, reason: `${bad.length} bozuk kline var` };
    return { ok: true, badCount: bad.length };
  },
  checkOrderbook(ob) {
    if (!ob?.bids?.length || !ob?.asks?.length) return { ok: false, reason: 'Orderbook boş' };
    if (ob.bids[0]?.price >= ob.asks[0]?.price) return { ok: false, reason: 'Bid >= Ask: bozuk OB' };
    return { ok: true };
  },
  sanitizeKlines(klines) {
    // Bozuk kline'ları filtrele
    return klines.filter(k => this.checkKline(k).ok);
  },
};

// ─── DUPLICATE DATA FILTER ────────────────────────────────────────────────────
const _seenHashes = new Map();
const DEDUP_TTL = 10000; // 10 saniye

export const DuplicateDataFilter = {
  _hash(data) {
    const str = JSON.stringify(data);
    let h = 0;
    for (let i = 0; i < str.length; i++) { h = ((h << 5) - h) + str.charCodeAt(i); h |= 0; }
    return h.toString(36);
  },
  isDuplicate(data, ttlMs = DEDUP_TTL) {
    const hash = this._hash(data);
    const seen = _seenHashes.get(hash);
    if (seen && Date.now() - seen < ttlMs) return true;
    _seenHashes.set(hash, Date.now());
    // Eski hash'leri temizle
    if (_seenHashes.size > 10000) {
      for (const [k, v] of _seenHashes) { if (Date.now() - v > ttlMs * 2) _seenHashes.delete(k); }
    }
    return false;
  },
  clear: () => _seenHashes.clear(),
};

// ─── TIME SYNC ENGINE ─────────────────────────────────────────────────────────
let _serverTimeDiff = 0; // ms

export const TimeSyncEngine = {
  async syncWithBinance() {
    try {
      const start = Date.now();
      const r = await fetch('https://api.binance.com/api/v3/time');
      const d = await r.json();
      const rtt = Date.now() - start;
      _serverTimeDiff = d.serverTime - (start + rtt / 2);
      LoggingEngine.info('TimeSync', `Sunucu fark: ${_serverTimeDiff}ms | RTT: ${rtt}ms`);
      return { ok: true, diff: _serverTimeDiff, rtt };
    } catch (e) {
      LoggingEngine.warn('TimeSync', 'Senkronizasyon başarısız: ' + e.message);
      return { ok: false, diff: 0 };
    }
  },
  getServerTime: () => Date.now() + _serverTimeDiff,
  getDiff: () => _serverTimeDiff,
  isInSync: (thresholdMs = 1000) => Math.abs(_serverTimeDiff) < thresholdMs,
};

// ─── CROSS FEED VALIDATOR ─────────────────────────────────────────────────────
export const CrossFeedValidator = {
  validatePrice(prices) {
    // prices: [{ source, price }]
    if (prices.length < 2) return { ok: true, prices };
    const vals = prices.map(p => p.price).filter(Boolean);
    const avg = vals.reduce((a, b) => a + b, 0) / vals.length;
    const maxDev = Math.max(...vals.map(p => Math.abs(p - avg) / avg));
    if (maxDev > 0.005) { // %0.5 sapma
      LoggingEngine.warn('CrossFeed', `Fiyat sapması: ${(maxDev * 100).toFixed(3)}%`);
      return { ok: false, deviation: maxDev, avg, prices };
    }
    return { ok: true, deviation: maxDev, avg, prices };
  },
};

// ─── EMERGENCY SAFE MODE ──────────────────────────────────────────────────────
let _safeMode = false;
let _safeModeReason = '';

export const EmergencySafeMode = {
  activate(reason = 'Bilinmeyen') {
    _safeMode = true;
    _safeModeReason = reason;
    LoggingEngine.warn('SafeMode', `ACİL GÜVENLİ MOD AKTİF: ${reason}`);
  },
  deactivate() {
    _safeMode = false;
    _safeModeReason = '';
    LoggingEngine.info('SafeMode', 'Güvenli mod devre dışı');
  },
  isActive: () => _safeMode,
  getReason: () => _safeModeReason,
  check(conditions = {}) {
    const { dataCorrupted, latencyHigh, apiDown, priceAnomaly } = conditions;
    if (dataCorrupted) this.activate('Veri bozulması tespit edildi');
    else if (latencyHigh) this.activate('Yüksek gecikme — veri güvenilmez');
    else if (apiDown) this.activate('API bağlantısı kesildi');
    else if (priceAnomaly) this.activate('Anormal fiyat hareketi');
    return _safeMode;
  },
};

// ─── GLOBAL INIT ─────────────────────────────────────────────────────────────
export function initInfra() {
  // Standart modülleri kaydet
  ['exchangeAPI', 'masterCouncil', 'pineEngine', 'executionLayer', 'macroAPIEngine',
   'intelligenceEngine', 'dipOnaylayici', 'backtestEngine', 'liveAIEngine',
   'newsMacroCouncil', 'multiAssetEngines', 'realDerivativesEngine'].forEach(m => HealthMonitor.register(m));

  // Rate limitleri kur
  ['binance','bybit','okx','gate','kucoin','mexc','kraken'].forEach(e => RateLimitGuard.init(e, 1200));

  // Zaman senkronizasyonu
  TimeSyncEngine.syncWithBinance().catch(() => {});

  LoggingEngine.info('Infra', 'GMG Altyapı Katmanı başlatıldı ✓');
  return { ok: true };
}
