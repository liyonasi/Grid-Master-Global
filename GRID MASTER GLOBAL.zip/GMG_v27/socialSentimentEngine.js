/**
 * GRID MASTER GLOBAL — SOCIAL SENTIMENT ENGINE v1
 * =================================================
 * Sosyal medya sentiment analizi: FOMO/Panic ayrımı + bot filtresi.
 *
 * KAYNAKLAR:
 *   - LunarCrush API (kripto sosyal metrikler) — ücretsiz tier
 *   - CoinGecko trends (trend coinler)
 *   - Alternative.me Fear & Greed API
 *
 * MODÜLLER:
 *   1. Fear & Greed — piyasa duygu endeksi
 *   2. Social Volume — anlık sosyal hacim
 *   3. FOMO Detector — aşırı yükseliş sinyali
 *   4. Panic Detector — panik satış sinyali
 *   5. Bot Filter Score — şişirilmiş sinyal tespiti
 *   6. Hype Gauge — genel heyecan ölçümü
 */

import { clamp } from './engineCore.js';

// ─── API URL'LERİ ─────────────────────────────────────────────────────────────
const FEAR_GREED_URL  = 'https://api.alternative.me/fng/?limit=2&format=json';
const COINGECKO_TREND = 'https://api.coingecko.com/api/v3/search/trending';

// ─── ÖNBELLEK ─────────────────────────────────────────────────────────────────
const _cache = new Map();
const CACHE_TTL = 10 * 60 * 1000;

function cacheGet(k) { const e = _cache.get(k); return e && Date.now() - e.ts < CACHE_TTL ? e.v : null; }
function cacheSet(k, v) { _cache.set(k, { v, ts: Date.now() }); }

// ─── FEAR & GREED ─────────────────────────────────────────────────────────────
/**
 * fetchFearGreed — Alternative.me Fear & Greed Index
 */
export async function fetchFearGreed() {
  const cached = cacheGet('feargreed');
  if (cached) return cached;

  try {
    const res  = await fetch(FEAR_GREED_URL, { signal: AbortSignal.timeout(5000) });
    const data = await res.json();
    const now  = data?.data?.[0];
    const prev = data?.data?.[1];

    if (!now) return null;

    const value     = parseInt(now.value);
    const prevValue = prev ? parseInt(prev.value) : value;
    const change    = value - prevValue;

    const result = {
      value,
      label:        now.value_classification,
      prevValue,
      change,
      trend:        change > 5 ? 'YÜKSELİYOR' : change < -5 ? 'DÜŞÜYOR' : 'STABIL',
      sentiment:    value >= 75 ? 'AŞIRI AÇGÖZLÜLÜK' :
                    value >= 55 ? 'AÇGÖZLÜLÜK' :
                    value >= 45 ? 'NÖTR' :
                    value >= 25 ? 'KORKU' : 'AŞIRI KORKU',
      timestamp:    new Date().toISOString(),
    };

    cacheSet('feargreed', result);
    return result;
  } catch (e) {
    console.error('[SOCIAL] Fear & Greed hatası:', e.message);
    return null;
  }
}

// ─── TREND COINLER ────────────────────────────────────────────────────────────
/**
 * fetchTrendingCoins — CoinGecko trend coinleri
 */
export async function fetchTrendingCoins() {
  const cached = cacheGet('trending');
  if (cached) return cached;

  try {
    const res  = await fetch(COINGECKO_TREND, { signal: AbortSignal.timeout(5000) });
    const data = await res.json();
    const coins = data?.coins?.map(c => ({
      id:     c.item?.id,
      name:   c.item?.name,
      symbol: c.item?.symbol?.toUpperCase(),
      rank:   c.item?.market_cap_rank,
      score:  c.item?.score,
    })) || [];

    cacheSet('trending', coins);
    return coins;
  } catch (e) {
    console.error('[SOCIAL] Trending fetch hatası:', e.message);
    return [];
  }
}

// ─── FOMO DETECTOR ───────────────────────────────────────────────────────────
/**
 * detectFOMO — Aşırı iyimserlik / FOMO sinyali
 *
 * @param {number} fearGreedValue  — 0-100
 * @param {number} priceChange7d   — 7 günlük değişim %
 * @param {number} socialVolume    — Anlık sosyal hacim (opsiyonel)
 * @param {number} trendingRank    — Trending listesindeki sıra (opsiyonel)
 */
export function detectFOMO({ fearGreedValue = 50, priceChange7d = 0, socialVolume = 0, trendingRank = null }) {
  let fomoScore = 0;
  const signals = [];

  if (fearGreedValue >= 80) { fomoScore += 35; signals.push('Aşırı açgözlülük bölgesi (F&G≥80)'); }
  else if (fearGreedValue >= 65) { fomoScore += 20; signals.push('Yüksek açgözlülük (F&G≥65)'); }

  if (priceChange7d >= 50)      { fomoScore += 30; signals.push(`7g +${priceChange7d.toFixed(0)}% — Aşırı yükseliş`); }
  else if (priceChange7d >= 25) { fomoScore += 18; signals.push(`7g +${priceChange7d.toFixed(0)}% — Güçlü yükseliş`); }
  else if (priceChange7d >= 15) { fomoScore += 10; }

  if (socialVolume > 10000)     { fomoScore += 20; signals.push('Sosyal hacim patlaması'); }
  else if (socialVolume > 5000) { fomoScore += 10; }

  if (trendingRank !== null && trendingRank <= 3) { fomoScore += 15; signals.push(`Trending #${trendingRank}`); }

  fomoScore = clamp(fomoScore);

  return {
    fomoScore,
    active:   fomoScore >= 50,
    level:    fomoScore >= 75 ? 'AŞIRI FOMO' : fomoScore >= 50 ? 'FOMO' : fomoScore >= 25 ? 'HAFİF FOMO' : 'NORMAL',
    signals,
    warning:  fomoScore >= 60 ? '⚠️ FOMO aktif — Tepe yakın olabilir, dikkatli gir' : null,
  };
}

// ─── PANİK DETECTOR ──────────────────────────────────────────────────────────
/**
 * detectPanic — Panik satış sinyali
 */
export function detectPanic({ fearGreedValue = 50, priceChange7d = 0, priceChange24h = 0 }) {
  let panicScore = 0;
  const signals  = [];

  if (fearGreedValue <= 20)      { panicScore += 35; signals.push('Aşırı korku bölgesi (F&G≤20)'); }
  else if (fearGreedValue <= 35) { panicScore += 20; signals.push('Korku bölgesi (F&G≤35)'); }

  if (priceChange24h <= -15)     { panicScore += 30; signals.push(`24s ${priceChange24h.toFixed(1)}% — Sert düşüş`); }
  else if (priceChange24h <= -8) { panicScore += 18; signals.push(`24s ${priceChange24h.toFixed(1)}% — Belirgin düşüş`); }

  if (priceChange7d <= -40)      { panicScore += 20; signals.push(`7g ${priceChange7d.toFixed(0)}% — Panik satış`); }

  panicScore = clamp(panicScore);

  return {
    panicScore,
    active:     panicScore >= 50,
    level:      panicScore >= 70 ? 'AŞIRI PANİK' : panicScore >= 50 ? 'PANİK' : panicScore >= 25 ? 'HAFİF PANİK' : 'NORMAL',
    signals,
    opportunity: panicScore >= 60 ? '💡 Panik satış — Potansiyel dip fırsatı' : null,
  };
}

// ─── BOT FİLTRE ──────────────────────────────────────────────────────────────
/**
 * computeBotFilterScore — Sosyal sinyalin bot kaynaklı olup olmadığını tahmin et
 *
 * @param {object} metrics
 *   accountAge    — ortalama hesap yaşı (gün)
 *   followerRatio — takipçi/takip edilen oranı
 *   repeatPhrases — tekrar eden ifadeler yüzdesi (0-1)
 *   burstPattern  — kısa sürede ani artış var mı?
 */
export function computeBotFilterScore({ accountAge = 180, followerRatio = 1, repeatPhrases = 0, burstPattern = false }) {
  let botProb = 0;

  if (accountAge < 30)       botProb += 30;
  else if (accountAge < 90)  botProb += 15;

  if (followerRatio < 0.1)   botProb += 25; // Çok fazla takip, az takipçi
  if (repeatPhrases > 0.4)   botProb += 25;
  if (burstPattern)          botProb += 20;

  botProb = clamp(botProb);

  return {
    botProbability:  botProb,
    organic:         botProb < 35,
    suspicious:      botProb >= 35 && botProb < 65,
    likelyBot:       botProb >= 65,
    reliabilityScore: clamp(100 - botProb),
    label:           botProb >= 65 ? 'BOT ŞÜPHELİ' : botProb >= 35 ? 'ŞÜPHELI' : 'ORGANİK',
  };
}

// ─── HYPE GAUGE ──────────────────────────────────────────────────────────────
/**
 * computeHypeGauge — Genel heyecan ölçümü
 */
export function computeHypeGauge({ fearGreedValue, fomoScore, panicScore, trendingCount = 0 }) {
  const netSentiment = fearGreedValue - 50; // -50..+50
  let   hype = 50 + netSentiment * 0.4;

  hype += fomoScore  * 0.15;
  hype -= panicScore * 0.15;
  hype += trendingCount * 3;
  hype = clamp(hype);

  return {
    hype:    parseFloat(hype.toFixed(1)),
    label:   hype >= 75 ? 'AŞIRI HEYECAN' : hype >= 60 ? 'HEYECANLI' : hype >= 40 ? 'NÖTR' : hype >= 25 ? 'KARAMSAR' : 'KORKU',
    color:   hype >= 75 ? '#ff4444' : hype >= 60 ? '#ffaa00' : hype >= 40 ? '#888888' : hype >= 25 ? '#4488ff' : '#0044ff',
  };
}

// ─── ANA MOTOR ───────────────────────────────────────────────────────────────
/**
 * runSocialSentimentEngine — Tüm sosyal sinyal katmanlarını çalıştır
 *
 * @param {object} params
 *   symbol        — 'BTC', 'ETH' vb.
 *   priceChange24h
 *   priceChange7d
 *   socialVolume  — (opsiyonel)
 */

// ─── CRYPTOPANIC API ──────────────────────────────────────────────────────────
/**
 * fetchCryptoPanicNews(symbol) → haber listesi + sentiment özeti
 * CryptoPanic free API — key gerektirmez (anonim, rate limit: 5 req/dk)
 * symbol: 'BTC', 'ETH' vb. (USDT suffix olmadan)
 */
export async function fetchCryptoPanicNews(symbol = 'BTC') {
  const clean  = symbol.replace('USDT', '').replace('BUSD', '').toUpperCase();
  const url    = `https://cryptopanic.com/api/v1/posts/?auth_token=free&currencies=${clean}&filter=hot&public=true`;
  const proxy  = `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`;
  try {
    const res  = await fetch(proxy, { signal: AbortSignal.timeout(6000) });
    if (!res.ok) throw new Error(`CryptoPanic HTTP ${res.status}`);
    const data = await res.json();
    const items = (data.results || []).slice(0, 10).map(p => ({
      title:     p.title,
      sentiment: (p.votes?.positive || 0) > (p.votes?.negative || 0) ? 'positive'
               : (p.votes?.negative || 0) > (p.votes?.positive || 0) ? 'negative' : 'neutral',
      source:    p.source?.title || 'unknown',
      published: p.published_at,
      url:       p.url,
      votes:     { positive: p.votes?.positive || 0, negative: p.votes?.negative || 0, saved: p.votes?.saved || 0 },
    }));
    // Sentiment özet skoru (0-100)
    const posCount = items.filter(i => i.sentiment === 'positive').length;
    const negCount = items.filter(i => i.sentiment === 'negative').length;
    const total    = items.length || 1;
    const sentimentScore = Math.round(50 + ((posCount - negCount) / total) * 50);
    return {
      items,
      sentimentScore,
      summary: `${posCount}↑ ${negCount}↓ / ${total} haber — ${sentimentScore >= 60 ? 'Pozitif' : sentimentScore <= 40 ? 'Negatif' : 'Nötr'}`,
      source:  'CryptoPanic',
      timestamp: new Date().toISOString(),
    };
  } catch(e) {
    return { items: [], sentimentScore: 50, summary: 'CryptoPanic erişilemedi', error: e.message, timestamp: new Date().toISOString() };
  }
}

export async function runSocialSentimentEngine({ symbol = 'BTC', priceChange24h = 0, priceChange7d = 0, socialVolume = 0 } = {}) {
  // Paralel veri çek — CryptoPanic dahil
  const [fearGreed, trending, cryptoPanic] = await Promise.all([
    fetchFearGreed(),
    fetchTrendingCoins(),
    fetchCryptoPanicNews(symbol),
  ]);

  const fgValue     = fearGreed?.value ?? 50;
  const trendingRank = trending.findIndex(c => c.symbol === symbol.replace('USDT', ''));
  const isInTrending = trendingRank >= 0;

  const fomo  = detectFOMO({ fearGreedValue: fgValue, priceChange7d, socialVolume, trendingRank: isInTrending ? trendingRank + 1 : null });
  const panic = detectPanic({ fearGreedValue: fgValue, priceChange7d, priceChange24h });

  const botFilter = computeBotFilterScore({
    accountAge:    180,
    followerRatio: 0.8,
    repeatPhrases: 0.1,
    burstPattern:  fomo.active && priceChange24h > 20,
  });

  const hype = computeHypeGauge({
    fearGreedValue: fgValue,
    fomoScore:      fomo.fomoScore,
    panicScore:     panic.panicScore,
    trendingCount:  isInTrending ? 1 : 0,
  });

  // Ana skor: Nötr=50, FOMO yüksekse risk artar (satış sinyali), Panik yüksekse fırsat
  let score = 50;
  if (fomo.active)  score -= fomo.fomoScore * 0.3;  // FOMO = aşırı ısınmış = düşüş riski
  if (panic.active) score += panic.panicScore * 0.2; // Panik = fırsat
  // CryptoPanic haberleri skora %15 ağırlıkla katkı
  const cpScore = cryptoPanic?.sentimentScore ?? 50;
  score = score * 0.85 + cpScore * 0.15;
  score = clamp(score);

  const warnings = [
    fomo.warning,
    panic.opportunity,
    botFilter.likelyBot ? '⚠️ Bot aktivitesi tespit edildi — sosyal sinyale güvenme' : null,
  ].filter(Boolean);

  return {
    score:       parseFloat(score.toFixed(1)),
    fearGreed:   fearGreed || { value: 50, sentiment: 'NÖTR' },
    fomo,
    panic,
    hype,
    botFilter,
    trending:    trending.slice(0, 7),
    isInTrending,
    trendingRank: isInTrending ? trendingRank + 1 : null,
    cryptoPanic,
    warnings,
    summary:     `F&G:${fgValue} | Hype:${hype.label} | CP:${cpScore} | ${fomo.active ? 'FOMO aktif' : panic.active ? 'PANİK aktif' : 'Normal'}`,
    timestamp:   new Date().toISOString(),
  };
}
