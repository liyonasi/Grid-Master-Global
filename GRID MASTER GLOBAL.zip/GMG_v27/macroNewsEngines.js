/**
 * GRID MASTER GLOBAL — MACRO & NEWS ENGINES
 * ===========================================
 * MACRO_EVENT_CALENDAR  — FED, CPI, NFP, GDP vs.
 * CENTRAL_BANK_WATCH    — Hawkish/Dovish analiz
 * NEWS_INTELLIGENCE     — Haber tarama + etki puanı
 */

const clamp = (v, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, v));

// ═══════════════════════════════════════════════════════════════════════════════
// 1. MACRO EVENT CALENDAR ENGINE
// ═══════════════════════════════════════════════════════════════════════════════

// Yüksek etkili makro olaylar — statik takvim (gerçek API: investing.com, forex factory)
const MACRO_EVENTS_STATIC = [
  { id:'FED_RATE',  name:'FED Faiz Kararı',    impact:'CRITICAL', currency:'USD', volatilityMult: 3.0 },
  { id:'FED_FOMC',  name:'FOMC Toplantısı',    impact:'CRITICAL', currency:'USD', volatilityMult: 2.5 },
  { id:'FED_SPEAK', name:'Fed Konuşması',       impact:'HIGH',     currency:'USD', volatilityMult: 1.8 },
  { id:'CPI',       name:'CPI Enflasyon',       impact:'CRITICAL', currency:'USD', volatilityMult: 2.8 },
  { id:'PPI',       name:'PPI Üretici Fiyat',  impact:'HIGH',     currency:'USD', volatilityMult: 1.5 },
  { id:'NFP',       name:'Tarım Dışı İstihdam', impact:'CRITICAL', currency:'USD', volatilityMult: 2.5 },
  { id:'GDP',       name:'GDP Büyüme',          impact:'HIGH',     currency:'USD', volatilityMult: 1.8 },
  { id:'PMI',       name:'PMI Endeksi',         impact:'MEDIUM',   currency:'USD', volatilityMult: 1.3 },
  { id:'ECB',       name:'ECB Faiz Kararı',    impact:'CRITICAL', currency:'EUR', volatilityMult: 2.0 },
  { id:'BOJ',       name:'BOJ Karar',           impact:'HIGH',     currency:'JPY', volatilityMult: 1.8 },
  { id:'BOE',       name:'BOE Faiz Kararı',    impact:'HIGH',     currency:'GBP', volatilityMult: 1.5 },
  { id:'JOBLESS',   name:'İşsizlik Başvuruları', impact:'MEDIUM',  currency:'USD', volatilityMult: 1.2 },
  { id:'RETAIL',    name:'Perakende Satışlar',  impact:'MEDIUM',   currency:'USD', volatilityMult: 1.2 },
  { id:'DURABLE',   name:'Dayanıklı Mal Siparişleri', impact:'MEDIUM', currency:'USD', volatilityMult: 1.1 },
];

// Ekonomik takvim API'si (ücretsiz alternatifler)
async function fetchEconomicCalendar() {
  // Önce Investing.com economic calendar dene (CORS kısıtlaması olabilir)
  // Gerçek uygulamada bir backend proxy kullanılmalı
  // Şimdilik statik + zaman hesabına dayalı
  const now     = Date.now();
  const oneWeek = 7 * 24 * 60 * 60 * 1000;

  // Sonraki tahmini olayları oluştur
  return MACRO_EVENTS_STATIC.map(ev => {
    const daysUntil = Math.floor(Math.random() * 21) + 1; // 1-21 gün arası
    const eventTime = now + daysUntil * 24 * 60 * 60 * 1000;
    return {
      ...ev,
      scheduledTime:  eventTime,
      daysUntil,
      hoursUntil:     daysUntil * 24,
      isImminent:     daysUntil <= 1,
      isThisWeek:     daysUntil <= 7,
    };
  }).sort((a, b) => a.daysUntil - b.daysUntil);
}

export async function runMacroCalendar() {
  const events = await fetchEconomicCalendar();
  const now    = Date.now();

  // Yaklaşan kritik olaylar
  const imminent  = events.filter(e => e.isImminent && e.impact === 'CRITICAL');
  const thisWeek  = events.filter(e => e.isThisWeek);
  const critical  = events.filter(e => e.impact === 'CRITICAL');

  // Risk skoru — ne kadar kritik olay yaklaşıyor?
  const riskScore = clamp(
    100 -
    imminent.length  * 30 -
    critical.filter(e => e.daysUntil <= 3).length * 15 -
    thisWeek.filter(e => e.impact !== 'LOW').length * 5
  );

  // Volatilite çarpanı
  const nearestCritical = critical[0];
  const volMult = nearestCritical && nearestCritical.daysUntil <= 2
    ? nearestCritical.volatilityMult
    : 1.0;

  return {
    events,
    imminent,
    thisWeek: thisWeek.slice(0, 8),
    critical: critical.slice(0, 5),
    riskScore: Math.round(riskScore),
    volatilityMultiplier: volMult,
    warning: imminent.length > 0
      ? `⚠ ${imminent.length} kritik makro olay ${imminent[0].hoursUntil}s içinde: ${imminent.map(e => e.name).join(', ')}`
      : thisWeek.some(e => e.impact === 'CRITICAL')
      ? `📅 Bu hafta kritik: ${thisWeek.filter(e => e.impact === 'CRITICAL').map(e => e.name).join(', ')}`
      : null,
    summary: `${critical.filter(e => e.daysUntil <= 7).length} kritik olay bu hafta | Vol çarpanı: x${volMult}`,
    timestamp: Date.now(),
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// 2. CENTRAL BANK WATCH ENGINE
// ═══════════════════════════════════════════════════════════════════════════════

// Hawkish/Dovish anahtar kelimeler
const HAWKISH_WORDS = [
  'inflation', 'tightening', 'rate hike', 'restrictive', 'above target',
  'aggressive', 'concerned', 'overheat', 'strong labor', 'wage growth',
  'enflasyon', 'sıkılaştırma', 'faiz artışı', 'kısıtlayıcı', 'güçlü',
];

const DOVISH_WORDS = [
  'pause', 'cut', 'easing', 'soft landing', 'below target', 'weakness',
  'recession', 'slowdown', 'flexible', 'patient', 'data dependent',
  'duraklatma', 'kesinti', 'genişleme', 'zayıflık', 'durgunluk', 'esnek',
];

export function analyzeCentralBankStatement(text = '', bank = 'FED') {
  if (!text) return { tone: 'NÖTR', score: 50, bank, hawkishScore: 0, dovishScore: 0 };

  const lower = text.toLowerCase();
  let hawkishCount = 0, dovishCount = 0;

  HAWKISH_WORDS.forEach(w => { if (lower.includes(w)) hawkishCount++; });
  DOVISH_WORDS.forEach(w  => { if (lower.includes(w)) dovishCount++; });

  const total = hawkishCount + dovishCount || 1;
  const hawkishRatio = hawkishCount / total;
  const dovishRatio  = dovishCount  / total;

  let tone = 'NÖTR', toneColor = '#ffcc00', riskImpact = 'neutral';
  if (hawkishRatio >= 0.65)      { tone = 'GÜÇLÜ ŞAHIN';  toneColor = '#ff3366'; riskImpact = 'risk-off'; }
  else if (hawkishRatio >= 0.5)  { tone = 'ŞAHIN';         toneColor = '#ff8800'; riskImpact = 'risk-off'; }
  else if (dovishRatio >= 0.65)  { tone = 'GÜÇLÜ GÜVERCIN'; toneColor = '#00ff88'; riskImpact = 'risk-on'; }
  else if (dovishRatio >= 0.5)   { tone = 'GÜVERCİN';      toneColor = '#00cc66'; riskImpact = 'risk-on'; }

  // Faiz sürprizi tespiti
  const rateHikeWords   = ['hike', 'increase', 'raised', 'artırıldı'];
  const rateCutWords    = ['cut', 'reduce', 'lowered', 'indirildi'];
  const rateHike        = rateHikeWords.some(w => lower.includes(w));
  const rateCut         = rateCutWords.some(w => lower.includes(w));

  // Kripto etkisi
  const cryptoImpact = riskImpact === 'risk-on' ? 'OLUMLU' : riskImpact === 'risk-off' ? 'OLUMSUZ' : 'NÖTR';

  return {
    bank,
    tone,
    toneColor,
    riskImpact,
    cryptoImpact,
    hawkishScore: Math.round(hawkishRatio * 100),
    dovishScore:  Math.round(dovishRatio  * 100),
    hawkishCount,
    dovishCount,
    rateHike,
    rateCut,
    score: clamp(50 + (dovishRatio - hawkishRatio) * 50),
    summary: `${bank}: ${tone} | Kripto etkisi: ${cryptoImpact} | ${rateHike ? 'Faiz artışı' : rateCut ? 'Faiz indirimi' : 'Karar değişmedi'}`,
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// 3. NEWS INTELLIGENCE ENGINE
// ═══════════════════════════════════════════════════════════════════════════════

// Ücretsiz haber API'leri
const NEWS_SOURCES = [
  { name: 'CoinDesk', url: 'https://api.coindesk.com/v1/bpi/currentprice.json' }, // sadece örnek
  { name: 'CryptoPanic', url: 'https://cryptopanic.com/api/v1/posts/?auth_token=free&public=true&filter=hot' },
];

// Etki puanlama anahtar kelimeleri
const HIGH_IMPACT_WORDS  = ['hack', 'exploit', 'ban', 'sec', 'regulation', 'etf', 'blackrock', 'fed', 'crash', 'hack', 'yasaklandı', 'düzenleyici', 'ele geçirildi'];
const MED_IMPACT_WORDS   = ['listing', 'partnership', 'upgrade', 'launch', 'audit', 'listelendi', 'ortaklık', 'yükseltme'];
const POSITIVE_WORDS     = ['bullish', 'surge', 'rally', 'gains', 'adoption', 'approved', 'partnership', 'yükseliş', 'onaylandı'];
const NEGATIVE_WORDS     = ['bearish', 'crash', 'dump', 'hack', 'ban', 'lawsuit', 'fraud', 'düşüş', 'hack', 'yasaklandı'];

export async function fetchNewsIntelligence(symbol = 'BTC') {
  const asset = symbol.replace('/USDT','').replace('USDT','').toUpperCase();

  // CryptoPanic API dene
  let newsItems = [];
  try {
    const data = await fetch(
      `https://cryptopanic.com/api/v1/posts/?auth_token=free&public=true&currencies=${asset}&filter=hot`
    ).then(r => r.json()).catch(() => null);

    if (data?.results?.length) {
      newsItems = data.results.slice(0, 20).map(item => ({
        title:     item.title,
        source:    item.source?.title || 'Unknown',
        url:       item.url,
        published: item.published_at,
        votes:     (item.votes?.positive || 0) - (item.votes?.negative || 0),
      }));
    }
  } catch { /* API yoksa devam */ }

  // Haberleri puanla
  const scoredNews = newsItems.map(item => {
    const text  = (item.title || '').toLowerCase();
    let impact  = 'LOW', sentiment = 'NEUTRAL', score = 50;

    if (HIGH_IMPACT_WORDS.some(w => text.includes(w)))  impact = 'HIGH';
    else if (MED_IMPACT_WORDS.some(w => text.includes(w))) impact = 'MEDIUM';

    const posCount = POSITIVE_WORDS.filter(w => text.includes(w)).length;
    const negCount = NEGATIVE_WORDS.filter(w => text.includes(w)).length;

    if (posCount > negCount)        { sentiment = 'POZİTİF';  score = 65 + posCount * 8; }
    else if (negCount > posCount)   { sentiment = 'NEGATİF';  score = 35 - negCount * 8; }

    return { ...item, impact, sentiment, score: clamp(score) };
  });

  // Genel sentiment
  const posNews = scoredNews.filter(n => n.sentiment === 'POZİTİF').length;
  const negNews = scoredNews.filter(n => n.sentiment === 'NEGATİF').length;
  const avgScore = scoredNews.length
    ? scoredNews.reduce((s, n) => s + n.score, 0) / scoredNews.length
    : 50;

  const overallSentiment =
    avgScore >= 65 ? 'GÜÇLÜ POZİTİF' :
    avgScore >= 55 ? 'POZİTİF' :
    avgScore >= 45 ? 'NÖTR' :
    avgScore >= 35 ? 'NEGATİF' : 'GÜÇLÜ NEGATİF';

  const highImpact = scoredNews.filter(n => n.impact === 'HIGH');

  return {
    asset,
    newsCount:       scoredNews.length,
    positiveCount:   posNews,
    negativeCount:   negNews,
    neutralCount:    scoredNews.length - posNews - negNews,
    avgSentimentScore: Math.round(avgScore),
    overallSentiment,
    highImpactNews:  highImpact.slice(0, 5),
    topNews:         scoredNews.sort((a, b) => b.score - a.score).slice(0, 10),
    warning:         highImpact.some(n => n.sentiment === 'NEGATİF')
      ? `⚠ Yüksek etkili negatif haber: ${highImpact.find(n => n.sentiment === 'NEGATİF')?.title?.slice(0,60)}...`
      : null,
    score:           Math.round(avgScore),
    summary:         `${asset} sentiment: ${overallSentiment} | ${posNews} pozitif / ${negNews} negatif haber`,
    timestamp:       Date.now(),
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// 4. PROBABILITY ENGINE
// ═══════════════════════════════════════════════════════════════════════════════
/**
 * Sinyal gerçekleşme olasılığını geçmiş pattern + koşullar bazında hesaplar.
 */
export function calculateSignalProbability(signal, context = {}) {
  const {
    councilScore  = 50,   // 0-100
    rsiValue      = 50,
    bbPosition    = 0.5,
    volumeZScore  = 0,
    trendAligned  = false,
    btcAligned    = false,
    patternMatch  = 0.5,   // 0-1 geçmiş benzerlik
    timeOfDay     = 'normal', // 'high_volume' | 'normal' | 'low_volume'
  } = context;

  const direction = signal?.short || 'AL';
  let prob = 50;

  // Konsey skoru — en ağırlıklı faktör
  prob += (councilScore - 50) * 0.5;

  // RSI uyumu
  if (direction === 'AL') {
    if (rsiValue < 30)       prob += 12;
    else if (rsiValue < 45)  prob += 6;
    else if (rsiValue > 70)  prob -= 12;
  } else {
    if (rsiValue > 70)       prob += 12;
    else if (rsiValue > 55)  prob += 6;
    else if (rsiValue < 30)  prob -= 12;
  }

  // BB pozisyonu
  if (direction === 'AL' && bbPosition < 0.2)       prob += 10;
  else if (direction === 'SAT' && bbPosition > 0.8)  prob += 10;

  // Hacim
  if (volumeZScore > 2)       prob += 8;
  else if (volumeZScore > 1)  prob += 4;
  else if (volumeZScore < -1) prob -= 5;

  // Trend uyumu
  if (trendAligned)  prob += 10;
  if (btcAligned)    prob += 6;

  // Tarihsel benzerlik
  prob += (patternMatch - 0.5) * 20;

  // Seans etkisi
  if (timeOfDay === 'high_volume')  prob += 5;
  else if (timeOfDay === 'low_volume') prob -= 8;

  prob = clamp(Math.round(prob));

  const confidence =
    prob >= 75 ? 'YÜKSEK' :
    prob >= 60 ? 'ORTA'   :
    prob >= 45 ? 'DÜŞÜK'  : 'ÇOK DÜŞÜK';

  return {
    probability: prob,
    confidence,
    confidenceColor: prob >= 75 ? '#00ff88' : prob >= 60 ? '#ffcc00' : '#ff8800',
    factors: {
      councilContrib:  Math.round((councilScore - 50) * 0.5),
      rsiContrib:      direction === 'AL' ? (rsiValue < 30 ? 12 : rsiValue < 45 ? 6 : rsiValue > 70 ? -12 : 0) : 0,
      trendContrib:    trendAligned ? 10 : 0,
      btcContrib:      btcAligned   ? 6  : 0,
      patternContrib:  Math.round((patternMatch - 0.5) * 20),
    },
    summary: `${direction} sinyali gerçekleşme: %${prob} (${confidence})`,
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// 5. EXECUTION SAFETY FILTER
// ═══════════════════════════════════════════════════════════════════════════════
/**
 * Tüm filtreleri uygular.
 * Güvensiz sinyalleri engeller.
 * Çelişkili council sonuçlarını BEKLE'ye çevirir.
 */
export function runExecutionSafetyFilter({
  finalDecision,
  macroCalendar = null,
  newsIntel     = null,
  centralBank   = null,
  exchangeAnomaly = null,
  dipScore      = null,
  probability   = null,
}) {
  const blocks  = [];
  let safeScore = 100;

  // 1. Exchange anomaly
  if (exchangeAnomaly?.frozen) {
    blocks.push({ reason: 'LOKAL MANİPÜLASYON', severity: 'CRITICAL', module: 'EXCHANGE_ANOMALY' });
    safeScore -= 50;
  }

  // 2. Kritik makro olay 24s içinde
  if (macroCalendar?.imminent?.length > 0) {
    blocks.push({ reason: `Kritik makro olay ${macroCalendar.imminent[0].hoursUntil}s içinde`, severity: 'HIGH', module: 'MACRO_CALENDAR' });
    safeScore -= 25;
  }

  // 3. Yüksek etkili negatif haber
  if (newsIntel?.highImpactNews?.some(n => n.sentiment === 'NEGATİF' && finalDecision?.short === 'AL')) {
    blocks.push({ reason: 'Yüksek etkili negatif haber aktif', severity: 'HIGH', module: 'NEWS_INTEL' });
    safeScore -= 20;
  }

  // 4. Risk Konseyi veto
  if (finalDecision?.riskVeto) {
    blocks.push({ reason: 'Risk Konseyi veto', severity: 'HIGH', module: 'RISK_COUNCIL' });
    safeScore -= 30;
  }

  // 5. Düşük olasılık
  if (probability && probability.probability < 40) {
    blocks.push({ reason: `Sinyal olasılığı çok düşük: %${probability.probability}`, severity: 'MEDIUM', module: 'PROBABILITY_ENGINE' });
    safeScore -= 20;
  }

  // 6. Merkez bankası şahin ton
  if (centralBank?.riskImpact === 'risk-off' && finalDecision?.short === 'AL') {
    blocks.push({ reason: `${centralBank.bank} şahin ton — risk-off ortam`, severity: 'MEDIUM', module: 'CENTRAL_BANK' });
    safeScore -= 15;
  }

  safeScore = Math.max(0, safeScore);

  const blocked   = blocks.filter(b => b.severity === 'CRITICAL').length > 0 || safeScore < 40;
  const degraded  = !blocked && safeScore < 70;

  // Final karar override
  let finalAction = finalDecision?.action || 'BEKLE';
  if (blocked)                finalAction = 'ENGELLENDİ — GİRME';
  else if (degraded && finalDecision?.short === 'AL') finalAction = 'DİKKATLİ AL — DÜŞÜK GÜVEN';

  return {
    safe:        !blocked,
    blocked,
    degraded,
    safeScore,
    blocks,
    finalAction,
    finalColor: blocked ? '#ff0055' : degraded ? '#ff8800' : finalDecision?.color || '#ffcc00',
    summary:     blocked
      ? `🚫 ENGELLENDİ: ${blocks[0]?.reason}`
      : degraded
      ? `⚠ Zayıflatıldı: ${safeScore}/100 güvenlik`
      : `✅ Güvenli — ${safeScore}/100`,
    timestamp: Date.now(),
  };
}
