# GMG — EKSİKLER VE SIRADAKİLER

## YENİ OTURUMDA İLK YAPILACAK: GRAFIK PINE ENTEGRASYONu

GMGChart_v3.jsx'e şunlar eklenecek:

### Adım 1 — pineEngine çalıştır
```javascript
// GMGChart_v3.jsx içinde
import { runPineEngine } from '../engines/pineEngine';

const pineData = useMemo(() => {
  if (!candles || candles.length < 30) return null;
  return runPineEngine(candles, pineParams);
}, [candles]);
```

### Adım 2 — Toolbar'a Pine toggle ekle
```
[Mum] [HA] [Hollow] ... | EMA9 EMA21 ... | [Pine RF] [Pine S/R] [PB]
```

### Adım 3 — draw() içine çizimler
```javascript
// Range Filter çizgisi (renkli — upward=yeşil, downward=kırmızı)
if (act.pineRF && pineData?.filtLine) {
  const rfColor = pineData.rf.trendUp ? '#00e676' : '#ff1744';
  drawLine(cx, pineData.filtLine, vI, rfColor, 2, fi, cw, PL, pMn, pMx, PT, CH);
}

// Üst/alt bant (hafif)
if (act.pineRF && pineData?.hbandLine) {
  drawLine(cx, pineData.hbandLine, vI, 'rgba(0,188,212,0.35)', 0.8, ...);
  drawLine(cx, pineData.lbandLine, vI, 'rgba(213,0,249,0.35)', 0.8, ...);
}

// S/R Kutuları
if (act.pineSR && pineData?.srZones) {
  const curPrice = candles[n-1].c;
  for (const zone of pineData.srZones) {
    const topY = pY(zone.hi, pMn, pMx, PT, CH);
    const botY = pY(zone.lo, pMn, pMx, PT, CH);
    const isRes = zone.hi < curPrice ? false : zone.lo > curPrice ? true : null;
    const col = isRes === true ? '#ff1744' : isRes === false ? '#00e676' : '#888888';
    cx.fillStyle = col + '12';
    cx.fillRect(PL, topY, CW, botY - topY);
    cx.strokeStyle = col + '55';
    cx.lineWidth = 0.8;
    cx.strokeRect(PL, topY, CW, botY - topY);
    // Güç skoru etiketi
    cx.fillStyle = col;
    cx.font = '8px monospace';
    cx.textAlign = 'right';
    cx.fillText(`${zone.touches}x`, PL + CW - 3, topY - 2);
  }
}

// BUY/SELL sinyalleri (Range Filter flip)
if (pineData?.rf?.buySignal) {
  // Yeşil ok + "BUY" etiketi mum altında
  const x = iX(n-1, fi, cw, PL);
  const y = pY(candles[n-1].l || candles[n-1].c, pMn, pMx, PT, CH) + 16;
  cx.fillStyle = '#00e676';
  cx.fillRect(x-15, y-8, 30, 14);
  cx.fillStyle = '#000';
  cx.font = 'bold 8px monospace';
  cx.textAlign = 'center';
  cx.fillText('BUY', x, y+3);
}

if (pineData?.rf?.sellSignal) {
  // Kırmızı ok + "SELL" etiketi mum üstünde
  const x = iX(n-1, fi, cw, PL);
  const y = pY(candles[n-1].h || candles[n-1].c, pMn, pMx, PT, CH) - 16;
  cx.fillStyle = '#ff1744';
  cx.fillRect(x-18, y-8, 36, 14);
  cx.fillStyle = '#fff';
  cx.font = 'bold 8px monospace';
  cx.textAlign = 'center';
  cx.fillText('SELL', x, y+3);
}

// PB-AL / PB-SAT (turuncu/yeşil)
if (pineData?.pb?.pbBuy) {
  const x = iX(n-1, fi, cw, PL);
  const y = pY(candles[n-1].l || candles[n-1].c, pMn, pMx, PT, CH) + 30;
  cx.fillStyle = '#00e676';
  cx.fillRect(x-20, y-8, 40, 14);
  cx.fillStyle = '#000';
  cx.font = 'bold 8px monospace';
  cx.textAlign = 'center';
  cx.fillText('PB-AL', x, y+3);
}

if (pineData?.pb?.pbSell) {
  const x = iX(n-1, fi, cw, PL);
  const y = pY(candles[n-1].h || candles[n-1].c, pMn, pMx, PT, CH) - 30;
  cx.fillStyle = '#ff6d00';
  cx.fillRect(x-22, y-8, 44, 14);
  cx.fillStyle = '#000';
  cx.font = 'bold 8px monospace';
  cx.textAlign = 'center';
  cx.fillText('PB-SAT', x, y+3);
}

// Mum renklendirme (barColor mantığı)
// Artık drawSingleCandle() içinde pine bilgisi kullan:
// rfTrendUp + fiyat > filt → parlak yeşil
// rfTrendDown + fiyat < filt → parlak kırmızı
```

---

## DASHBOARD BAGLANTISI

`Dashboard_v4.jsx` içinde:

```javascript
import { runMasterCouncil } from '../engines/masterCouncil';
import { runAllScanners }   from '../engines/engineCore';

// State ekle
const [masterResult, setMasterResult] = useState(null);

// useEffect içine ekle
const runIntelligence = useCallback(async () => {
  if (!priceHistory.length || !heatmapData.length) return;
  
  // Tarama
  const scan = runAllScanners({
    coins: heatmapData,
    btcChange: tickerData[0]?.change_24h || 0,
    orderbookMap: orderbook ? { [selectedSymbol]: orderbook } : {},
    klineMap: {},
  });

  // Master karar
  const result = await runMasterCouncil({
    candles:     priceHistory,
    I:           computedIndicators,  // mevcut indicators state
    scanResults: scan,
    orderbook,
    heatmapData,
    fundingRates: [],
    btcChange:    tickerData[0]?.change_24h || 0,
    vixLevel:     50,
  });

  setMasterResult(result);
}, [priceHistory, heatmapData, orderbook, tickerData]);

// GMGChart'a geç
<GMGChart
  ...mevcut props
  chartOverlay={masterResult?.chartOverlay}
  councilResult={masterResult}
/>
```

---

## EKSİK ENGINE DOSYALARI (v7'de vardı, v9'da yok)

### forexEngine.js — yeniden yazılacak
```javascript
runForexEngine({ pairChanges, dxyData, carryData })
runCurrencyStrengthEngine(pairChanges)
runCarryTradeAnalyzer({ usdJpyChange, usdChfChange, vixLevel })
runSessionFlowEngine(utcHour)
runDXYPressureEngine({ dxyLevel, dxyChange1d })
runCentralBankSignalEngine(overrides)
```

### commodityEngine.js — yeniden yazılacak
```javascript
runCommodityEngine({ gold, oil, energy, opec, safeHaven })
runSafeHavenFlowEngine({ goldChange, jpyChange, vixLevel })
runOilSupplyShockEngine({ wtiPrice, wtiChange1d, opecCutAnnounced })
```

### bondMacroEngine.js — yeniden yazılacak
```javascript
runBondEngine({ yieldCurve, bondFlow, rateExp, inflPremium })
runGlobalMacroEngine({ liquidity, riskAppetite, geopolitical })
runYieldCurveEngine({ us3m, us2y, us10y, us30y })
runGlobalLiquidityEngine({ fedBalanceSheetChgBln, globalM2Growth })
```

### technicalExtEngine.js — yeniden yazılacak
```javascript
runBOSDetector(candles, lookback)   // Break of Structure
runCHoCHDetector(candles, lookback) // Change of Character
runStealthTrendEngine(candles)
runBuyWallDetector(orderbook, currentPrice)
runSellWallDetector(orderbook, currentPrice)
runLiquidityClusterDetector(orderbook, currentPrice)
runLongShortRatioEngine({ longRatio, shortRatio })
runSqueezeDetector(candles)
```

---

## EKSİK JSX PANELLERİ

### MarketHeatmapPanel.jsx
- Top 48 coin ısı haritası
- Renkler: yüksek değişim = parlak
- Tıklayınca coin seç

### LiveAICouncilPanel.jsx
- 5 Konsey canlı skoru
- Her konseyin vote history
- Execution Layer durumu
- Confidence gauge

### LiquidityWallPanel.jsx
- Buy wall / Sell wall görsel
- Duvar büyüklüğü bar chart
- Stop cluster işaretleri

### AccumulationPlanPanel.jsx
- Seçili coin için birikim planı
- Alım/satım seviyeleri
- Risk/ödül hesabı

### ForexPanel.jsx
- 9 Forex modülü görsel
- Döviz gücü ısı haritası
- Carry trade sinyali

### MultiMarketPanel.jsx
- Kripto + Forex + Emtia + Endeks
- Risk-on / Risk-off göstergesi
- Korelasyon matrisi

---

## TEST ETMEk İÇİN

```javascript
// pineEngine test
import { runPineEngine } from './pineEngine';
const result = runPineEngine(testCandles, { rfPer: 100, rfMult: 3.0 });
console.log('RF Trend:', result.rf.trendDir);
console.log('BUY Signal:', result.rf.buySignal);
console.log('PB-AL:', result.pb.pbBuy);
console.log('S/R bölgeler:', result.sr.all.length);

// Execution Layer test
import { runExecutionLayer } from './executionLayer';
const exec = runExecutionLayer({
  councilScores: { alpha:72, flow:65, risk:60, macro:58, news:55 },
  finalScore: 68,
  proposedAction: 'BUY',
  riskCouncilScore: 60,
  vixLevel: 35,
  stopHunts: [],
  scalpTraps: [],
});
console.log('Final action:', exec.action);   // BUY
console.log('Vetoed:', exec.filters.veto.wasVetoed);  // false
console.log('Confidence:', exec.confidence);  // 78
```

---

Son güncelleme: 2026-03-15 | v10
