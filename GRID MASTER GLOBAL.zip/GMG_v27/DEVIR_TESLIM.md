# GRID MASTER GLOBAL — CLAUDE DEVİR TESLİM DOSYASI
## Yeni Claude oturumu için tam bağlam

---

## BU DOSYAYI CLAUDE'A VER

Şu mesajı yeni oturumda yaz:

> "Bu ZIP dosyasındaki DEVIR_TESLIM.md dosyasını oku ve kaldığın yerden devam et."

---

## PROJE NEDİR?

Grid Master Global — Kripto para trading karar destek platformu.
- Web tabanlı React uygulaması
- 95 modül, 4 AI konseyi
- Tüm coinler için gerçek zamanlı analiz
- Yenilmez trader sistemi hedefi

---

## DOSYA YAPISI

```
GMGChart_v3.jsx          — Ana grafik bileşeni (1735 satır)
Dashboard_v4.jsx         — Ana dashboard
aiCouncilEngine.js       — 4 Konsey + Nihai Karar Motoru
moduleRegistry.js        — 95 modül dağılımı
intelligenceEngine.js    — 16 tarayıcı fonksiyonu
councilEngine.js         — Konsey oylama motoru
engineCore.js            — Math helpers + re-exports
exchangeAPI_multi.js     — 7 borsa API
dipOnaylayici.js         — 8 katmanlı dip onay motoru
realDerivativesEngine.js — Real OI + Funding + Likidasyon
structureEngines.js      — BOS/CHoCH + S/R + Pullback
macroNewsEngines.js      — Makro takvim + Haber + Olasılık
alertMonitorEngines.js   — Alarm + Telegram + Health + Log
MarketIntelPanel.jsx     — Piyasa istihbarat paneli
CouncilPanel.jsx         — Konsey karar paneli
FundingPanel.jsx         — Funding + OI paneli
LiquidityRadar.jsx       — Likidite radar
MultiTimeframePanel.jsx  — Çoklu zaman dilimi
chartModule.js           — Pattern recognition
```

---

## 4 KONSEY YAPISI

### ALPHA COUNCIL (24 modül) — Teknik analiz
RSI, EMA, MACD, Stoch, ADX, CCI, MFI, BB, Keltner,
SuperTrend, Pattern Matrix, Chart Formation, Candlestick,
Historical Match, MTF Pattern, MTF Confluence, S/R Touch,
Trend Cloud, Reversal, SuperTrigger, Breakout, Mean Rev,
Stealth Trend, Trend Acceleration

### FLOW COUNCIL (24 modül) — Likidite + Orderbook
Orderbook Engine, Bid/Ask Imbalance, OB Wall Tracker,
Liquidity Map, Delta Flow, CVD Pulse, Book Pressure,
Void Engine, Cross Arb, Volume Spike, Momentum Bias,
Regime Detector, Grid Drivers, Whale Trace, Whale Inflow,
Funding Bias, Open Interest, Vol Lock, Correlation,
WS Stream, Multi-Exchange, Liq Fetch, Market Struct,
EXCHANGE_ANOMALY (YENİ)

### RISK COUNCIL (24 modül) — Manipülasyon + Tuzak
Stop Hunt Radar, Liq Sweep, Fake Move, Liq Trap,
BAIT_DURATION_TIMER (YENİ), DOUBLE_HUNT_ENGINE (YENİ),
Liquidation Watch, Spoofing, MM Behavior, HFT Pulse,
Risk Classifier, Risk Hub, Vol Regime, BTC Shock,
Pump/Dump Early, MEXC Hunter, New Listing, Social Hype,
LIQUIDITY_MAGNET_GATE (YENİ), Probability, Hist Pattern,
Scalp Engine, Accumulation, Macro Factors

### MACRO COUNCIL (23 modül) — BTC Dom + Haber + AI
Alt Rotation, BTC Rel Power, Sector Strength, BTC Dom,
Stable Dom, Alt Season, Crypto Sector, Onchain, Stable Flow,
Token Dist, News Intel, Fear/Greed, Macro Factors,
Top200, Global Alert, Multi Asset, Signal Fusion,
AI Decision Layer, Signal Confidence, Market State,
Council Output, Final Council, Grid Master Core

---

## NİHAİ ONAY PROTOKOLÜ (5 Şart)

Bir sinyalin GÜÇLÜ sayılması için:
1. 4 konseyden en az 3 onay (score >= 55)
2. Risk Konseyi VETO ETMEMELİ (score >= 40)
3. 95 modülün en az %75'i pozitif
4. Exchange Anomaly aktif değil (frozen = false)
5. Liquidity Magnet Gate geçildi (entryAllowed = true)

---

## DOUBLE STOP HUNT FAZLARI

PHASE_1_APPROACH  → Sweep hazırlığı (önceden)
FAKE_RESET        → Sahte reset — insanlar giriyor (TEHLİKE)
PHASE_2_LOADING   → İkinci tur yükleniyor
PHASE_2_CONFIRMED → Tüm onaylar tamam → İKİNCİ TUR KESİN

BAIT_DURATION_TIMER:
- 10+ mum sahte reset bölgesinde
- Hacim düşüyor
- OI artıyor
= İkinci tur kesin

---

## DİP ONAYLAYICI (dipOnaylayici.js)

8 katman:
1. TimeAlignmentCheck     — Konsey zaman uyumu
2. OppositionCheck        — Muhalefet kontrolü
3. LiquidityConsistencyCheck — Likidite tutarlılık
4. BTCCompatibilityCheck  — BTC uyumu
5. VolatilityApprovalCheck — Volatilite onayı
6. CandleFormationCheck   — Mum formasyonu (Hammer, Engulfing)
7. VolumeDipCheck         — Hacim dip onayı
8. MultiTimeframeCheck    — MTF uyumu

dipScore >= 75 → GÜÇLÜ DİP — GİR
dipScore >= 58 → DİP ONAYLI — DİKKATLİ GİR
dipScore >= 42 → ŞÜPHELİ — BEKLE
dipScore < 42  → DİP DEĞİL

---

## EXCHANGE ANOMALY FİLTRESİ

Binance fiyatı diğer borsalardan %0.15+ düşükse:
→ LOKAL MANİPÜLASYON
→ Tüm AL sinyalleri DONDURULUR
→ Canvas'ta kırmızı neon yazı çıkar

---

## LİKİDİTE MIKNATISI KAPISI

Giriş için 3 şart:
1. Fiyat mıknatıs bölgesine ulaştı (%0.3 içinde)
2. Dönüş formasyonu oluştu (Hammer, Engulfing, Doji)
3. Mıknatıs gücü >= 55

---

## BORSA ENTEGRASYONları

Binance (ana), Bybit, OKX, Gate.io, MEXC, KuCoin, Kraken
Fallback zinciri: Binance → Bybit → OKX → Gate → MEXC

---

## EKLENECEKLER (SONRAKI OTURUMDA YAZI)

### 1. BACKTESTING ENGINE
- geçmiş veride sistem testi
- 1ay/3ay/6ay/1yıl periyot
- win rate, drawdown, max loss/gain
- council başarı istatistiği
- Dosya: backtestingEngine.js

### 2. LIVE AI QUERY ENGINE (Claude API ile)
- Kullanıcı coin sorunca AI cevap verir
- "Neden AL / SAT / BEKLE?" açıklaması
- Council bazlı gerekçe
- Anthropic API entegrasyonu
- Dosya: liveAIQueryEngine.js

### 3. AUTO AI MARKET SUMMARY
- Her 5 dakikada otomatik piyasa özeti
- Genel risk özeti
- Seçili coin otomatik AI yorumu
- Dosya: autoAIEngine.js

### 4. MULTI ASSET ENGINE (Forex/Emtia/Endeks)
- Forex: EUR/USD, GBP/USD, USD/JPY vs.
- Emtia: Altın, Gümüş, Petrol
- Endeks: SP500, Nasdaq, VIX
- Dosya: multiAssetEngine.js

### 5. HISTORICAL PATTERN COMPARE ENGINE
- Son 500 mumun geçmiş benzeri aranır
- %benzerlik skoru
- Geçmişte ne olmuş → tahmin
- Dosya: historicalPatternEngine.js

### 6. SOCIAL SENTIMENT ADVANCED
- Twitter/X sentiment analizi
- Telegram hype tespiti
- FOMO/Panic ayrımı
- Bot şişirmesi filtresi
- Dosya: socialSentimentEngine.js

### 7. USER PROFILE / WATCHLIST ENGINE
- Kullanıcı izleme listesi
- Favori coinler/pariteler
- Risk modu seçimi
- Alarm tercihleri
- Dosya: userProfileEngine.js

### 8. PERFORMANCE / CACHE ENGINE
- Hızlı veri önbelleği
- Rate limit koruması
- WebSocket düşerse fallback
- Dosya: performanceCacheEngine.js

### 9. LIVE BRIDGE OUTPUT ENGINE
- live_bridge_output.json üretimi
- Her coin için council sonucu
- Panel entegrasyonu
- Dosya: liveBridgeEngine.js

### 10. ADVANCED ONCHAIN ENGINE
- Exchange reserve değişimi
- Smart money davranışı
- Active addresses analizi
- Transfer spike tespiti
- Dosya: advancedOnchainEngine.js

---

## KOD YAZIM KURALLARI

1. Tüm fonksiyonlar export edilmeli
2. Türkçe yorum satırları
3. clamp() ile 0-100 arası skor
4. Her modül { score, summary, timestamp } döndürür
5. Null-safe yazım (?.operatör kullan)
6. Async/await ile API çağrıları
7. Her yeni dosya sonunda yedek alınmalı

---

## ÖNEMLİ NOTLAR

- Kullanıcı Türkçe konuşuyor
- Her oturum sonunda ZIP yedek alınıyor
- Dosyalar /mnt/user-data/outputs/ klasörüne kopyalanıyor
- Tüm yeni dosyalar /home/claude/project/ altına yazılıyor
- Her modül eklenince runAllScanners() veya ilgili motora entegre edilmeli
- Dashboard_v4.jsx ana entegrasyon noktası
- GMGChart_v3.jsx canvas render merkezi

---

Son güncelleme: 2026-03-15
Toplam dosya: 20
Toplam satır: ~8500+
