/**
 * GMG CHART — FULL COMPONENT
 * ===========================
 * Tüm mum tipleri: Candlestick, Heikin Ashi, Hollow, Bar, Line, Area, Renko
 * Çoklu borsa: Binance, Bybit, OKX, Gate.io, KuCoin, MEXC, Kraken
 * 4 Konsey: ALPHA, FLOW, RISK, MACRO
 * Likidite Mıknatısı, Sinyaller, S/R, EMA, BB, VWAP
 * Yazılar okunaklı boyutlarda
 *
 * KULLANIM:
 *   import GMGChart from './GMGChart_v3';
 *   <GMGChart symbol="BTC/USDT" onCouncilUpdate={cb} />
 */

import React, {
  useRef, useEffect, useState, useCallback, useMemo, useLayoutEffect,
} from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  fetchBestKlines,
  fetchAggregatedPrice,
  fetchOrderbook,
  fetchFundingRates,
  MultiExchangeWS,
  EXCHANGES,
} from './exchangeAPI_multi';
import { runPineEngine } from './pineEngine';

// ─── DESIGN ──────────────────────────────────────────────────────────────────
const T = {
  bg:'#010109', s1:'#03030d', s2:'#060614', s3:'#0a0a1c',
  b1:'#0f0f28', b2:'#181838',
  g:'#00e676', r:'#ff1744', b:'#00b0ff', y:'#ffd600',
  o:'#ff6d00', p:'#d500f9', t:'#00bcd4', w:'#ddddf8',
  dim:'#252550', mid:'#404070', txt:'#9090c0',
};

// Font sizes — büyük ve okunaklı
const F = {
  label:  '11px',
  value:  '13px',
  price:  '20px',
  header: '12px',
  tiny:   '10px',
  badge:  '10px',
};

// ─── MATH ────────────────────────────────────────────────────────────────────
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const fmt = p => !p ? '0' : p > 10000 ? p.toFixed(0) : p > 100 ? p.toFixed(2) : p > 1 ? p.toFixed(4) : p.toFixed(6);
const fmtV = v => v > 1e9 ? (v/1e9).toFixed(2)+'B' : v > 1e6 ? (v/1e6).toFixed(2)+'M' : v > 1e3 ? (v/1e3).toFixed(1)+'K' : Math.round(v)+'';

function ema(d, p) {
  const k = 2/(p+1), r = Array(d.length).fill(null);
  let s = 0, c = 0;
  for (let i = 0; i < p && i < d.length; i++) if (d[i] != null) { s += d[i]; c++; }
  if (!c) return r;
  r[p-1] = s/c;
  for (let i = p; i < d.length; i++) r[i] = d[i] != null ? d[i]*k + (r[i-1] ?? d[i])*(1-k) : null;
  return r;
}

function rsiCalc(c, p = 14) {
  const r = Array(c.length).fill(null);
  if (c.length < p+1) return r;
  let g = 0, l = 0;
  for (let i = 1; i <= p; i++) { const d = c[i]-c[i-1]; d > 0 ? g+=d : l-=d; }
  let ag = g/p, al = l/p;
  r[p] = al === 0 ? 100 : 100-100/(1+ag/al);
  for (let i = p+1; i < c.length; i++) {
    const d = c[i]-c[i-1];
    ag = (ag*(p-1)+(d>0?d:0))/p;
    al = (al*(p-1)+(d<0?-d:0))/p;
    r[i] = al === 0 ? 100 : 100-100/(1+ag/al);
  }
  return r;
}

function macdCalc(c) {
  const f = ema(c, 12), s = ema(c, 26);
  const ml = c.map((_, i) => f[i] != null && s[i] != null ? f[i]-s[i] : null);
  const vl = ml.filter(v => v != null), sg = ema(vl, 9);
  const sl = Array(c.length).fill(null); let si = 0;
  for (let i = 0; i < c.length; i++) if (ml[i] != null) { sl[i] = sg[si] ?? null; si++; }
  return { ml, sl, h: ml.map((v, i) => v != null && sl[i] != null ? v-sl[i] : null) };
}

function bollCalc(c, p = 20) {
  const u = [], l = [], m = [];
  for (let i = 0; i < c.length; i++) {
    if (i < p-1) { u.push(null); l.push(null); m.push(null); continue; }
    const sl = c.slice(i-p+1, i+1), mn = sl.reduce((a,b) => a+b, 0)/p;
    const sd = Math.sqrt(sl.reduce((a,b) => a+(b-mn)**2, 0)/p);
    u.push(mn+2*sd); l.push(mn-2*sd); m.push(mn);
  }
  return { u, l, m };
}

function stochCalc(c, h, l, p = 14, sm = 3) {
  const rk = c.map((_, i) => {
    if (i < p-1) return null;
    const hh = Math.max(...h.slice(i-p+1, i+1)), ll = Math.min(...l.slice(i-p+1, i+1));
    return hh !== ll ? ((c[i]-ll)/(hh-ll))*100 : 50;
  });
  const k = ema(rk.map(v => v ?? 50), sm);
  return { k, d: ema(k, sm) };
}

function atrCalc(ds, p = 14) {
  const tr = ds.map((c, i) => {
    if (!i) return (c.h||c.c)-(c.l||c.c);
    const pc = ds[i-1].c;
    return Math.max((c.h||c.c)-(c.l||c.c), Math.abs((c.h||c.c)-pc), Math.abs((c.l||c.c)-pc));
  });
  return ema(tr, p);
}

function mfiCalc(ds, p = 14) {
  const r = Array(ds.length).fill(null);
  for (let i = p; i < ds.length; i++) {
    const sl = ds.slice(i-p+1, i+1); let pmf = 0, nmf = 0;
    for (let j = 1; j < sl.length; j++) {
      const tp = ((sl[j].h||sl[j].c)+(sl[j].l||sl[j].c)+sl[j].c)/3;
      const ptp = ((sl[j-1].h||sl[j-1].c)+(sl[j-1].l||sl[j-1].c)+sl[j-1].c)/3;
      const mf = tp*(sl[j].v||0);
      tp > ptp ? pmf += mf : nmf += mf;
    }
    r[i] = nmf === 0 ? 100 : 100-100/(1+pmf/nmf);
  }
  return r;
}

function vwapCalc(ds) {
  let cv = 0, cv2 = 0;
  return ds.map(c => {
    const tp = ((c.h||c.c)+(c.l||c.c)+c.c)/3;
    cv += tp*(c.v||0); cv2 += (c.v||0);
    return cv2 > 0 ? cv/cv2 : c.c;
  });
}

function adxCalc(ds, p = 14) {
  const r = Array(ds.length).fill(null);
  if (ds.length < p*2) return r;
  let dp = 0, dm = 0, at = 0;
  for (let i = 1; i <= p; i++) {
    const c = ds[i], pv = ds[i-1];
    const up = (c.h||c.c)-(pv.h||pv.c), dn = (pv.l||pv.c)-(c.l||c.c);
    dp += up > 0 && up > dn ? up : 0;
    dm += dn > 0 && dn > up ? dn : 0;
    at += Math.max((c.h||c.c)-(c.l||c.c), Math.abs((c.h||c.c)-pv.c), Math.abs((c.l||c.c)-pv.c));
  }
  let dip = (dp/at)*100, dim = (dm/at)*100, dx = Math.abs(dip-dim)/(dip+dim+.001)*100, adv = dx;
  r[p] = adv;
  for (let i = p+1; i < ds.length; i++) {
    const c = ds[i], pv = ds[i-1], k = 2/(p+1);
    const up = (c.h||c.c)-(pv.h||pv.c), dn = (pv.l||pv.c)-(c.l||c.c);
    const tr = Math.max((c.h||c.c)-(c.l||c.c), Math.abs((c.h||c.c)-pv.c), Math.abs((c.l||c.c)-pv.c));
    dp = dp*(p-1)/p+(up>0&&up>dn?up:0); dm = dm*(p-1)/p+(dn>0&&dn>up?dn:0); at = at*(p-1)/p+tr;
    dip = (dp/(at||1))*100; dim = (dm/(at||1))*100;
    dx = Math.abs(dip-dim)/(dip+dim+.001)*100; adv = adv*(1-k)+dx*k; r[i] = adv;
  }
  return r;
}

function cciCalc(ds, p = 20) {
  const r = [];
  for (let i = 0; i < ds.length; i++) {
    if (i < p-1) { r.push(null); continue; }
    const sl = ds.slice(i-p+1, i+1);
    const tp = sl.map(c => ((c.h||c.c)+(c.l||c.c)+c.c)/3);
    const mn = tp.reduce((a,b) => a+b, 0)/p;
    const mad = tp.reduce((a,b) => a+Math.abs(b-mn), 0)/p;
    r.push(mad > 0 ? (tp[tp.length-1]-mn)/(0.015*mad) : 0);
  }
  return r;
}

function obvCalc(ds) {
  const r = [0]; let o = 0;
  for (let i = 1; i < ds.length; i++) {
    const d = ds[i].c-ds[i-1].c;
    o += d > 0 ? (ds[i].v||0) : d < 0 ? -(ds[i].v||0) : 0;
    r.push(o);
  }
  return r;
}

// ─── CHART TYPE BUILDERS ──────────────────────────────────────────────────────
function buildHA(raw) {
  return raw.map((c, i, arr) => {
    const haC = (c.o+c.h+c.l+c.c)/4;
    const haO = i === 0 ? (c.o+c.c)/2 : (arr[i-1]._haO + arr[i-1]._haC)/2;
    const haH = Math.max(c.h, haO, haC);
    const haL = Math.min(c.l, haO, haC);
    return { ...c, o: haO, h: haH, l: haL, c: haC, _haO: haO, _haC: haC };
  });
}

function buildRenko(raw, brickSize) {
  if (!raw.length) return [];
  const bricks = []; let lastClose = raw[0].c;
  for (const c of raw) {
    const up = Math.floor((c.c-lastClose)/brickSize);
    const dn = Math.floor((lastClose-c.c)/brickSize);
    for (let i = 0; i < Math.abs(up); i++) {
      const o = lastClose+i*brickSize, cl = o+brickSize;
      bricks.push({ t: c.t, ts: c.ts, o, h: cl, l: o, c: cl, v: c.v, bull: true });
    }
    for (let i = 0; i < Math.abs(dn); i++) {
      const o = lastClose-i*brickSize, cl = o-brickSize;
      bricks.push({ t: c.t, ts: c.ts, o, h: o, l: cl, c: cl, v: c.v, bull: false });
    }
    if (Math.abs(up) > 0) lastClose += up*brickSize;
    if (Math.abs(dn) > 0) lastClose -= dn*brickSize;
  }
  return bricks.slice(-250);
}

// ─── MAGNET ENGINE ────────────────────────────────────────────────────────────
function computeMagnets(raw) {
  if (raw.length < 40) return { up: [], dn: [] };
  const n = raw.length;
  const hs = raw.map(c => c.h||c.c), ls = raw.map(c => c.l||c.c), vs = raw.map(c => c.v||0);
  const cur = raw[n-1].c, avgV = vs.reduce((a,b) => a+b, 0)/n;

  const swH = [], swL = [];
  for (let i = 4; i < n-4; i++) {
    let mH = true, mL = true;
    for (let j = i-4; j <= i+4; j++) {
      if (j !== i && hs[j] >= hs[i]) mH = false;
      if (j !== i && ls[j] <= ls[i]) mL = false;
    }
    if (mH) swH.push({ p: hs[i], v: vs[i], idx: i });
    if (mL) swL.push({ p: ls[i], v: vs[i], idx: i });
  }

  // Psychological round levels
  const base = cur > 50000 ? 500 : cur > 5000 ? 50 : cur > 500 ? 5 : cur > 50 ? 1 : 0.1;
  const roundPts = [];
  for (let m = -10; m <= 10; m++) {
    const lvl = Math.round(cur/base)*base + m*base;
    if (lvl <= 0) continue;
    const nb = raw.filter(c => Math.abs(c.c-lvl)/lvl < 0.004);
    if (nb.length >= 2) roundPts.push({ p: lvl, v: nb.reduce((s,c) => s+(c.v||0), 0)/nb.length, isRound: true, touches: nb.length });
  }

  // High volume nodes
  const hvnPts = raw.filter(c => (c.v||0) > avgV*2.2).map(c => ({ p: c.c, v: c.v||0, isHVN: true, touches: 1 }));

  function cluster(pts, above) {
    const filt = above ? pts.filter(p => p.p > cur*1.0008) : pts.filter(p => p.p < cur*0.9992);
    const zones = [];
    for (const pt of filt) {
      const ex = zones.find(z => Math.abs(z.price-pt.p)/pt.p < 0.007);
      if (ex) {
        ex.touches += (pt.touches||1); ex.totalVol += (pt.v||0);
        ex.price = (ex.price+pt.p)/2;
        ex.isRound = ex.isRound || pt.isRound;
        ex.isHVN   = ex.isHVN   || pt.isHVN;
      } else {
        zones.push({ price: pt.p, touches: pt.touches||1, totalVol: pt.v||0, isRound: !!pt.isRound, isHVN: !!pt.isHVN, recency: pt.idx||0 });
      }
    }
    return zones.map(z => {
      const dist = Math.abs(z.price-cur)/cur;
      const sc = z.touches*5 + (z.totalVol/avgV)*2.5 + (z.isRound?14:0) + (z.isHVN?9:0) + (z.recency/n)*4 + Math.max(0, 8-dist*200);
      return {
        ...z,
        score:    sc,
        dist:     parseFloat(((Math.abs(z.price-cur)/cur)*100).toFixed(2)),
        strength: clamp(Math.round(8+sc*1.8), 20, 98),
        stopProb: clamp(Math.round(18+z.touches*7+(z.isRound?16:0)+(z.isHVN?10:0)), 20, 94),
      };
    }).sort((a, b) => b.score-a.score).slice(0, 7);
  }

  const allU = [...swH.map(s => ({ p: s.p, v: s.v, touches: 1, idx: s.idx })), ...roundPts.filter(r => r.p > cur), ...hvnPts.filter(r => r.p > cur)];
  const allD = [...swL.map(s => ({ p: s.p, v: s.v, touches: 1, idx: s.idx })), ...roundPts.filter(r => r.p < cur), ...hvnPts.filter(r => r.p < cur)];

  return { up: cluster(allU, true), dn: cluster(allD, false) };
}

// ─── COUNCIL ENGINE ───────────────────────────────────────────────────────────
function computeCouncil(candles, I, mags) {
  if (!candles.length || !I.rsi) return null;
  const n = candles.length-1, cur = candles[n].c;
  const rv = I.rsi[n] ?? 50, mh = I.macd?.h?.[n] ?? 0;
  const e9 = I.e9?.[n] ?? cur, e21 = I.e21?.[n] ?? cur, e50 = I.e50?.[n] ?? cur;
  const bbu = I.bb?.u?.[n], bbl = I.bb?.l?.[n];
  const bp = bbu && bbl ? (cur-bbl)/(bbu-bbl)*100 : 50;
  const adv = I.adx?.[n] ?? 20, atrV = I.atr?.[n] || cur*0.003;
  const posR = candles.filter(c => c.c >= c.o).length / candles.length;
  const us = mags.up[0]?.strength || 50, ds = mags.dn[0]?.strength || 50, mb = us-ds;
  const mfi = I.mfi?.[n] ?? 50, obv = I.obv?.[n] ?? 0, obvPrev = I.obv?.[n-5] ?? obv;

  const alpha = clamp(Math.round(
    (rv<30?86:rv<45?68:rv>75?20:rv>60?36:52)*0.2 +
    (mh>0?70:30)*0.2 +
    (e9>e21&&e21>e50?78:e9>e21?62:22)*0.2 +
    (bp<20?78:bp<40?62:bp>80?22:bp>65?36:52)*0.18 +
    (adv>30?62:adv>20?52:44)*0.12 +
    (mfi<35?75:mfi>70?28:50)*0.1
  ), 1, 99);

  const flow = clamp(Math.round(
    (50+mb*0.45)*0.3 + (posR*100)*0.28 + (mh>0?65:35)*0.18 +
    (obv>obvPrev?62:38)*0.14 + (mfi>60?62:mfi<40?38:50)*0.1
  ), 1, 99);

  const risk = clamp(Math.round(
    (100-(rv>72||rv<28?18:rv>65||rv<35?8:0))*0.28 +
    (adv>45?38:adv>30?52:68)*0.22 +
    (Math.abs(mh)/(atrV*0.01||1)>2.5?36:62)*0.22 +
    (us>80||ds>80?42:62)*0.18 +
    (bp>85||bp<12?42:62)*0.1
  ), 1, 99);

  const macro = clamp(Math.round(
    (posR*100)*0.38 + (e21>e50?65:35)*0.28 + (us>ds?63:37)*0.22 + (mfi>50?58:42)*0.12
  ), 1, 99);

  const fin = Math.round(alpha*0.28 + flow*0.27 + risk*0.22 + macro*0.23);
  const act = fin>=74?'GÜÇLÜ AL':fin>=60?'AL':fin>=52?'ZAYIF AL':fin>=45?'BEKLE':fin>=35?'SAT':'GÜÇLÜ SAT';
  const fc = fin>=58?T.g:fin<=45?T.r:T.y;
  const rl = risk>=72?'DÜŞÜK':risk>=50?'ORTA':risk>=30?'YÜKSEK':'KRİTİK';
  const bias = fin>=60?'BULLISH':fin<=45?'BEARISH':'NÖTR';

  return { alpha, flow, risk, macro, fin, act, fc, rl, bias };
}

// ─── SIGNALS ─────────────────────────────────────────────────────────────────
function computeSignals(candles, I, mags) {
  if (!candles.length || !I.rsi) return [];
  const sigs = [];
  const n = candles.length-1, cur = candles[n].c;
  const rv = I.rsi[n] ?? 50, mh = I.macd?.h?.[n] ?? 0;
  const e9 = I.e9?.[n] ?? cur, e21 = I.e21?.[n] ?? cur;
  const bbu = I.bb?.u?.[n], bbl = I.bb?.l?.[n];
  const bp = bbu && bbl ? (cur-bbl)/(bbu-bbl) : 0.5;
  const us = mags.up[0]?.strength || 0, ds = mags.dn[0]?.strength || 0;
  const md = us>ds+10?'UP':ds>us+10?'DN':'N';
  const mfi = I.mfi?.[n] ?? 50, adv = I.adx?.[n] ?? 0;

  const pbAlSc = (rv<42?3:rv<50?1:0)+(mh>0?2:0)+(e9>e21?2:0)+(bp<0.35?2:0)+(md==='UP'?3:0)+(adv>20?1:0)+(mfi<35?2:0);
  if (pbAlSc >= 7) sigs.push({ type:'PB-AL', col:T.g, str:clamp(50+pbAlSc*5,60,96), up:true });

  const pbSatSc = (rv>62?3:rv>55?1:0)+(mh<0?2:0)+(e9<e21?2:0)+(bp>0.72?2:0)+(md==='DN'?3:0)+(adv>20?1:0)+(mfi>68?2:0);
  if (pbSatSc >= 7) sigs.push({ type:'PB-SAT', col:T.r, str:clamp(50+pbSatSc*5,60,96), up:false });

  if (rv<35&&mh>0&&md==='UP')  sigs.push({ type:'BUY',  col:T.g, str:88, up:true  });
  if (rv>70&&mh<0&&md==='DN')  sigs.push({ type:'SELL', col:T.r, str:88, up:false });

  return sigs;
}

// ─── S/R ─────────────────────────────────────────────────────────────────────
function computeSR(raw) {
  if (raw.length < 20) return { r: [], s: [] };
  const hs = raw.map(x => x.h||x.c), ls = raw.map(x => x.l||x.c), cur = raw[raw.length-1].c;
  const sH = [], sL = [];
  for (let i = 3; i < raw.length-3; i++) {
    let mH = true, mL = true;
    for (let j = i-3; j <= i+3; j++) { if (j!==i && hs[j]>=hs[i]) mH=false; if (j!==i && ls[j]<=ls[i]) mL=false; }
    if (mH) sH.push(hs[i]); if (mL) sL.push(ls[i]);
  }
  function cl(arr, ab) {
    const f = ab ? arr.filter(p => p>cur*1.001) : arr.filter(p => p<cur*0.999);
    const z = [];
    for (const p of f) { const e = z.find(x => Math.abs(x.p-p)/p<0.005); if (e) { e.t++; e.p=(e.p+p)/2; } else z.push({ p, t:1 }); }
    return z.sort((a,b) => b.t-a.t).slice(0, 4);
  }
  return { r: cl(sH, true).sort((a,b) => a.p-b.p), s: cl(sL, false).sort((a,b) => b.p-a.p) };
}

// ─── CANVAS DRAWING ───────────────────────────────────────────────────────────
const pY = (p, mn, mx, t, h) => t + h*(1-(p-mn)/(mx-mn));
const iX = (i, fi, cw, pl) => pl + (i-fi)*cw + cw/2;

function drawLine(cx, vals, vis, col, lw, fi, cw, pl, mn, mx, t, h) {
  cx.strokeStyle = col; cx.lineWidth = lw; cx.beginPath(); let s = false;
  for (const i of vis) {
    const v = vals[i]; if (v == null) { s = false; continue; }
    const x = iX(i, fi, cw, pl), y = pY(v, mn, mx, t, h);
    s ? cx.lineTo(x, y) : (cx.moveTo(x, y), s = true);
  }
  cx.stroke();
}

function drawSingleCandle(cx, cd, x, bw, pMn, pMx, PT, CH, type, pineBarColor = null) {
  const o = cd.o ?? cd.c, cl = cd.c, h = cd.h ?? cd.c, l = cd.l ?? cd.c;
  const bull = cl >= o;
  const bT = pY(Math.max(o,cl), pMn, pMx, PT, CH);
  const bB = pY(Math.min(o,cl), pMn, pMx, PT, CH);
  const bH = Math.max(1, bB-bT);

  // Pine barColor renk haritası
  const pineColorMap = {
    'lime':   '#00e676', 'green':  '#00c853',
    'red':    '#ff1744', 'maroon': '#b71c1c',
    'orange': '#ff6d00',
  };
  const pCol = pineBarColor ? (pineColorMap[pineBarColor] || null) : null;

  if (type === 'bar') {
    const bc = pCol || (bull ? T.g : T.r);
    cx.strokeStyle = bc; cx.lineWidth = 1.5;
    cx.beginPath(); cx.moveTo(x, pY(h,pMn,pMx,PT,CH)); cx.lineTo(x, pY(l,pMn,pMx,PT,CH)); cx.stroke();
    cx.beginPath(); cx.moveTo(x-bw*0.6, pY(o,pMn,pMx,PT,CH)); cx.lineTo(x, pY(o,pMn,pMx,PT,CH)); cx.stroke();
    cx.beginPath(); cx.moveTo(x, pY(cl,pMn,pMx,PT,CH)); cx.lineTo(x+bw*0.6, pY(cl,pMn,pMx,PT,CH)); cx.stroke();
    return;
  }
  if (type === 'hollow') {
    const bc = pCol || (bull ? T.g : T.r);
    const hw = Math.max(0.8, bw*0.08);
    cx.strokeStyle = bc; cx.lineWidth = hw;
    cx.beginPath(); cx.moveTo(x, pY(h,pMn,pMx,PT,CH)); cx.lineTo(x, bT); cx.stroke();
    cx.beginPath(); cx.moveTo(x, bB); cx.lineTo(x, pY(l,pMn,pMx,PT,CH)); cx.stroke();
    if (bull) { cx.strokeStyle=bc; cx.lineWidth=1.2; cx.strokeRect(x-bw/2, bT, bw, bH); }
    else { cx.fillStyle=bc; cx.fillRect(x-bw/2, bT, bw, bH); }
    return;
  }
  if (type === 'renko') {
    const col = cd.bull !== undefined ? (cd.bull?T.g:T.r) : (bull?T.g:T.r);
    cx.fillStyle = col+'50'; cx.fillRect(x-bw*0.47, bT, bw*0.94, bH);
    cx.strokeStyle = col; cx.lineWidth = 1.2; cx.strokeRect(x-bw*0.47, bT, bw*0.94, bH);
    return;
  }
  // candle / heikin ashi — Pine barColor uygulanır
  const hw = Math.max(0.8, bw*0.08);
  if (pCol) {
    // Pine renklendirmesi aktif
    cx.strokeStyle = pCol; cx.lineWidth = hw;
    cx.beginPath(); cx.moveTo(x, pY(h,pMn,pMx,PT,CH)); cx.lineTo(x, bT); cx.stroke();
    cx.beginPath(); cx.moveTo(x, bB); cx.lineTo(x, pY(l,pMn,pMx,PT,CH)); cx.stroke();
    cx.fillStyle = pCol + '55';
    cx.fillRect(x-bw/2, bT, bw, bH);
    if (bH > 1.5) { cx.strokeStyle = pCol; cx.lineWidth = 0.9; cx.strokeRect(x-bw/2, bT, bw, bH); }
  } else {
    // Standart renk
    cx.strokeStyle = bull ? T.g : T.r; cx.lineWidth = hw;
    cx.beginPath(); cx.moveTo(x, pY(h,pMn,pMx,PT,CH)); cx.lineTo(x, bT); cx.stroke();
    cx.beginPath(); cx.moveTo(x, bB); cx.lineTo(x, pY(l,pMn,pMx,PT,CH)); cx.stroke();
    if (bull) { cx.fillStyle=`${T.g}35`; cx.fillRect(x-bw/2,bT,bw,bH); if(bH>1.5){cx.strokeStyle=T.g;cx.lineWidth=0.9;cx.strokeRect(x-bw/2,bT,bw,bH);} }
    else { cx.fillStyle=T.r; cx.fillRect(x-bw/2,bT,bw,bH); }
  }
}

// ─── MAIN COMPONENT ───────────────────────────────────────────────────────────
const TIMEFRAMES = ['1m','3m','5m','15m','30m','1h','4h','1d','1w'];
const CHART_TYPES = [
  { id:'candle',  label:'Mum'        },
  { id:'heikin',  label:'Heikin Ashi'},
  { id:'hollow',  label:'Hollow'     },
  { id:'bar',     label:'Bar'        },
  { id:'line',    label:'Çizgi'      },
  { id:'area',    label:'Alan'       },
  { id:'renko',   label:'Renko'      },
];
const OSCS = ['RSI','MACD','STOCH','ADX','CCI','MFI','OBV'];

export default function GMGChart({ symbol = 'BTC/USDT', onCouncilUpdate, chartOverlay = null, councilResult = null, missingBundle = null }) {
  const [base, quote]        = symbol.includes('/') ? symbol.split('/') : [symbol, 'USDT'];
  const containerRef         = useRef(null);
  const canvasRef            = useRef(null);
  const overlayRef           = useRef(null);
  const stateRef             = useRef({});
  const rafRef               = useRef(null);
  const isDrag               = useRef(false);
  const dragStartX           = useRef(0);
  const dragOff              = useRef(0);
  const wsRef                = useRef(null);

  const [raw, setRaw]               = useState([]);
  const [oX, setOX]                 = useState(0);
  const [sX, setSX]                 = useState(1);
  const [tf, setTf]                 = useState('1m');
  const [chartType, setChartType]   = useState('candle');
  const [osc, setOsc]               = useState('RSI');
  const [act, setAct]               = useState({
    e9:1,e21:1,e50:1,e200:0,vw:1,bb:1,liq:1,mag:1,sr:1,vol:1,sig:1,con:1,cross:1,
    pineRF:1, pineSR:1, pinePB:1,
    supertrend:1, keltner:0, trendCloud:0,
  });
  const [dims, setDims]             = useState({ w: 900, h: 520 });
  const [hover, setHover]           = useState(null);
  const [exchange, setExchange]     = useState('binance');
  const [connected, setConnected]   = useState(false);
  const [aggPrice, setAggPrice]     = useState(null);
  const [funding, setFunding]       = useState([]);

  // Computed candles based on chart type
  const candles = useMemo(() => {
    if (!raw.length) return [];
    if (chartType === 'heikin') return buildHA(raw);
    if (chartType === 'renko') {
      const atrArr = atrCalc(raw);
      const brickSz = atrArr[atrArr.length-1]*2 || raw[raw.length-1].c*0.003;
      return buildRenko(raw, brickSz);
    }
    return raw;
  }, [raw, chartType]);

  // Indicators
  const I = useMemo(() => {
    if (!candles.length) return {};
    const cs = candles.map(c => c.c), hs = candles.map(c => c.h||c.c), ls = candles.map(c => c.l||c.c);
    return {
      e9:  ema(cs, 9),  e21: ema(cs, 21), e50: ema(cs, 50), e200: ema(cs, 200),
      vw:  vwapCalc(candles), bb: bollCalc(cs),
      rsi: rsiCalc(cs), macd: macdCalc(cs), stoch: stochCalc(cs, hs, ls),
      atr: atrCalc(candles), adx: adxCalc(candles),
      cci: cciCalc(candles), mfi: mfiCalc(candles), obv: obvCalc(candles),
    };
  }, [candles]);

  const mags    = useMemo(() => computeMagnets(raw), [raw]);
  const council = useMemo(() => computeCouncil(candles, I, mags), [candles, I, mags]);
  const sigs    = useMemo(() => computeSignals(candles, I, mags), [candles, I, mags]);
  const srLvls  = useMemo(() => computeSR(raw), [raw]);

  // Pine Engine — filtLine, hband, lband, srZones, pbBuy, pbSell
  const pineData = useMemo(() => {
    if (!candles || candles.length < 30) return null;
    try { return runPineEngine(candles, { rfPer:100, rfMult:3.0, srPrd:10, srChannelW:5 }); }
    catch { return null; }
  }, [candles]);

  useEffect(() => { if (council) onCouncilUpdate?.(council); }, [council]);

  // Resize
  useLayoutEffect(() => {
    const obs = new ResizeObserver(entries => {
      const { width, height } = entries[0].contentRect;
      setDims({ w: Math.floor(width), h: Math.floor(height) });
    });
    if (containerRef.current) obs.observe(containerRef.current);
    return () => obs.disconnect();
  }, []);

  useEffect(() => {
    if (canvasRef.current)  { canvasRef.current.width  = dims.w; canvasRef.current.height  = dims.h; }
    if (overlayRef.current) { overlayRef.current.width = dims.w; overlayRef.current.height = dims.h; }
  }, [dims]);

  // Load data
  const loadData = useCallback(async (newTf) => {
    try {
      const { klines } = await fetchBestKlines(base, quote, newTf, 400);
      setRaw(klines);
      setConnected(true);
    } catch {
      // demo fallback
      let p = 84200;
      const demo = Array.from({ length: 400 }, (_, i) => {
        const chg = (Math.random()-0.468)*p*0.0045;
        const o = p, c = p+chg, h = Math.max(o,c)+Math.random()*Math.abs(chg)*0.4, l = Math.min(o,c)-Math.random()*Math.abs(chg)*0.4;
        const dd = new Date(Date.now()-400*60000+i*60000);
        p = c;
        return { t: dd.toLocaleTimeString('tr',{hour:'2-digit',minute:'2-digit'}), o, h, l, c, v: Math.random()*30+4 };
      });
      setRaw(demo);
    }
  }, [base, quote]);

  // WebSocket
  useEffect(() => {
    const wsManager = new MultiExchangeWS(base, quote,
      (cd) => {
        setRaw(prev => {
          if (!prev.length) return [cd];
          const last = prev[prev.length-1];
          if (last.t === cd.t) { const u = [...prev]; u[u.length-1] = cd; return u; }
          const next = [...prev, cd];
          if (next.length > 600) next.shift();
          return next;
        });
      },
      (tick) => { setAggPrice(prev => ({ ...(prev||{}), ...tick })); }
    );
    wsManager.connect('binance', tf);
    wsRef.current = wsManager;
    return () => wsManager.disconnect();
  }, [base, quote, tf]);

  useEffect(() => { loadData(tf); }, [tf, loadData]);

  // Aggregated price poll
  useEffect(() => {
    const poll = async () => {
      const agg = await fetchAggregatedPrice(base, quote).catch(() => null);
      if (agg) setAggPrice(agg);
    };
    poll();
    const iv = setInterval(poll, 15000);
    return () => clearInterval(iv);
  }, [base, quote]);

  // Funding
  useEffect(() => {
    const poll = async () => {
      const f = await fetchFundingRates(base, quote).catch(() => []);
      setFunding(f);
    };
    poll();
    const iv = setInterval(poll, 30000);
    return () => clearInterval(iv);
  }, [base, quote]);

  // DRAW
  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || !candles.length) return;
    const cx = canvas.getContext('2d');
    const { w: W, h: H } = dims;

    cx.fillStyle = T.bg; cx.fillRect(0, 0, W, H);

    const PL=12, PR=92, PT=28, VH=Math.floor(H*0.09), OH=72, OT=H-PT-OH-4, CH=OT-PT-VH-12, CW=W-PL-PR;
    const n = candles.length;
    const cw = Math.max(2, Math.min(32, CW/Math.max(30,n)*sX));
    const vis = Math.floor(CW/cw), maxO = Math.max(0, n-vis);
    const off = clamp(oX, 0, maxO);
    const fi = Math.max(0, n-vis-off), li = Math.min(n-1, fi+vis);
    const vI = Array.from({ length: li-fi+1 }, (_, i) => i+fi);
    if (vI.length < 2) return;

    // Store for overlay use
    stateRef.current = { pMn: 0, pMx: 0, fi, cw, PL, PT, CH, CW };

    // Price range
    const ap = vI.flatMap(i => [candles[i].h||candles[i].c, candles[i].l||candles[i].c]);
    if (act.bb && I.bb) vI.forEach(i => { if (I.bb.u[i]) ap.push(I.bb.u[i]); if (I.bb.l[i]) ap.push(I.bb.l[i]); });
    if (act.liq) { mags.up.forEach(m => ap.push(m.price)); mags.dn.forEach(m => ap.push(m.price)); }
    if (act.sr)  { srLvls.r.forEach(r => ap.push(r.p));  srLvls.s.forEach(s => ap.push(s.p)); }
    const rMn = Math.min(...ap.filter(Boolean)), rMx = Math.max(...ap.filter(Boolean));
    const mg2 = (rMx-rMn)*0.055, pMn = rMn-mg2, pMx = rMx+mg2;
    stateRef.current.pMn = pMn; stateRef.current.pMx = pMx;

    const toY = (p) => pY(p, pMn, pMx, PT, CH);
    const toX = (i) => iX(i, fi, cw, PL);

    // Grid
    cx.strokeStyle = T.b1; cx.lineWidth = 0.4;
    for (let i = 0; i <= 8; i++) {
      const y = PT+(CH/8)*i, p = pMx-((pMx-pMn)/8)*i;
      cx.beginPath(); cx.moveTo(PL, y); cx.lineTo(PL+CW, y); cx.stroke();
      cx.fillStyle = T.txt; cx.font = `${F.label} monospace`; cx.textAlign = 'left';
      cx.fillText(fmt(p), PL+CW+4, y+4);
    }
    for (let i = 0; i <= 7; i++) {
      const x = PL+(CW/7)*i;
      cx.beginPath(); cx.moveTo(x, PT); cx.lineTo(x, PT+CH); cx.stroke();
    }

    // Council bg tint
    if (act.con && council) {
      cx.fillStyle = council.fin >= 55 ? 'rgba(0,230,118,0.022)' : 'rgba(255,23,68,0.022)';
      cx.fillRect(PL, PT, CW, CH);
    }

    // BB
    if (act.bb && I.bb && chartType !== 'renko') {
      const { u, l } = I.bb;
      cx.beginPath(); let fs = false;
      for (let i = 0; i < vI.length; i++) { const v = u[vI[i]]; if (!v) continue; const x = toX(vI[i]), y = toY(v); if (!fs) { cx.moveTo(x,y); fs=true; } else cx.lineTo(x,y); }
      for (let i = vI.length-1; i >= 0; i--) { const v = l[vI[i]]; if (!v) continue; cx.lineTo(toX(vI[i]), toY(v)); }
      cx.closePath(); cx.fillStyle = 'rgba(55,55,130,0.05)'; cx.fill();
      drawLine(cx, u, vI, '#2a2a6a', 0.7, fi, cw, PL, pMn, pMx, PT, CH);
      drawLine(cx, l, vI, '#2a2a6a', 0.7, fi, cw, PL, pMn, pMx, PT, CH);
    }

    // S/R
    if (act.sr) {
      [...srLvls.r.slice(0,3).map(r => ({...r,bull:false})), ...srLvls.s.slice(0,3).map(s => ({...s,bull:true}))].forEach(z => {
        const y = toY(z.p); if (y<PT||y>PT+CH) return;
        const col = z.bull ? T.g : T.r;
        cx.fillStyle = `${col}04`; cx.fillRect(PL, y-2, CW, 4);
        cx.strokeStyle = `${col}55`; cx.lineWidth = 0.7; cx.setLineDash([4,7]);
        cx.beginPath(); cx.moveTo(PL,y); cx.lineTo(PL+CW,y); cx.stroke(); cx.setLineDash([]);
        cx.fillStyle = col; cx.font = `${F.label} monospace`; cx.textAlign = 'right';
        cx.fillText(`${z.bull?'S':'R'} ${z.t}×`, PL+CW-4, z.bull?y+10:y-2);
      });
    }

    // Liq map
    if (act.liq) {
      [...mags.up.map(m=>({...m,up:true})), ...mags.dn.map(m=>({...m,up:false}))].forEach(m => {
        const y = toY(m.price); if (y<PT-2||y>PT+CH+2) return;
        const col = m.up ? T.b : T.r;
        const alpha = 0.06+(m.strength/100)*0.48, barW = (m.strength/100)*CW*0.26;
        const gr = cx.createLinearGradient(PL, 0, PL+barW*1.5, 0);
        gr.addColorStop(0, `${col}${Math.floor(alpha*280).toString(16).padStart(2,'0')}`);
        gr.addColorStop(1, `${col}00`);
        cx.fillStyle = gr; cx.fillRect(PL, y-2, barW*1.5, 4);
        cx.strokeStyle = `${col}28`; cx.lineWidth = 0.5; cx.setLineDash([3,6]);
        cx.beginPath(); cx.moveTo(PL,y); cx.lineTo(PL+CW*0.82,y); cx.stroke(); cx.setLineDash([]);
        cx.fillStyle = col; cx.font = `${F.label} monospace`; cx.textAlign = 'left';
        cx.fillText(`${m.up?'▲':'▼'} $${fmt(m.price)}  ${m.strength}%${m.isRound?' ⊙':''}${m.isHVN?' ◉':''}`, PL+barW*1.5+4, y+4);
      });
    }

    // Magnet arrow
    if (act.mag && mags.up[0] && mags.dn[0]) {
      const topU = mags.up[0], topD = mags.dn[0], cur = candles[n-1].c;
      const isUp = topU.strength > topD.strength, sm = isUp ? topU : topD, col = isUp ? T.b : T.r;
      const tY = toY(sm.price), cY = toY(cur), ax = PL+CW*0.93;
      cx.save(); cx.shadowColor = col; cx.shadowBlur = 8;
      cx.strokeStyle = `${col}70`; cx.lineWidth = 1.5; cx.setLineDash([3,4]);
      cx.beginPath(); cx.moveTo(ax, cY); cx.lineTo(ax, tY); cx.stroke(); cx.setLineDash([]);
      cx.fillStyle = col; const dir = isUp ? -1 : 1;
      cx.beginPath(); cx.moveTo(ax, tY); cx.lineTo(ax-6, tY+dir*12); cx.lineTo(ax+6, tY+dir*12); cx.closePath(); cx.fill();
      cx.font = `${F.label} monospace`; cx.textAlign = 'center';
      cx.fillText('MAGNET', ax, tY+dir*24); cx.fillText(sm.strength+'%', ax, tY+dir*36);
      cx.restore();
    }

    // EMAs
    const emaLines = [
      ['e9',  I.e9,  `${T.b}d0`, 1.4], ['e21', I.e21, `${T.y}d0`, 1.4],
      ['e50', I.e50, `${T.o}c0`, 1.2], ['e200',I.e200,`${T.p}a0`, 1.0],
    ];
    for (const [k, arr, col, lw] of emaLines) {
      if (act[k] && arr) drawLine(cx, arr, vI, col, lw, fi, cw, PL, pMn, pMx, PT, CH);
    }
    if (act.vw && I.vw) drawLine(cx, I.vw, vI, `${T.t}c0`, 1.2, fi, cw, PL, pMn, pMx, PT, CH);

    // Chart body
    if (chartType === 'area') {
      cx.beginPath(); let aFs = false;
      for (const i of vI) {
        const x = toX(i), y = toY(candles[i].c);
        if (!aFs) { cx.moveTo(x, PT+CH); cx.lineTo(x, y); aFs=true; } else cx.lineTo(x, y);
      }
      if (aFs) { cx.lineTo(toX(vI[vI.length-1]), PT+CH); cx.closePath(); }
      const ag = cx.createLinearGradient(0, PT, 0, PT+CH);
      ag.addColorStop(0, 'rgba(0,176,255,0.22)'); ag.addColorStop(1, 'rgba(0,176,255,0.01)');
      cx.fillStyle = ag; cx.fill();
      drawLine(cx, candles.map(c=>c.c), vI, T.b, 1.8, fi, cw, PL, pMn, pMx, PT, CH);
    } else if (chartType === 'line') {
      drawLine(cx, candles.map(c=>c.c), vI, T.b, 1.8, fi, cw, PL, pMn, pMx, PT, CH);
    } else {
      for (const i of vI) {
        // Pine barColor aktifse Pine rengi, değilse standart
        const pineCol = (act.pineRF && pineData?.barColors?.[i]) ? pineData.barColors[i] : null;
        drawSingleCandle(cx, candles[i], toX(i), cw, pMn, pMx, PT, CH, chartType==='heikin'?'candle':chartType, pineCol);
      }
    }

    // ── PINE TP1 / TP2 / SL ÇİZGİLERİ ────────────────────────────────────
    if (act.pineRF && pineData?.tpsl) {
      const tpsl  = pineData.tpsl;
      const lastX = toX(n - 1);
      const lines = [
        { price: tpsl.tp1, col: '#00e676', label: `TP1 ${fmt(tpsl.tp1)}`, dash: [4,3] },
        { price: tpsl.tp2, col: '#69f0ae', label: `TP2 ${fmt(tpsl.tp2)}`, dash: [4,3] },
        { price: tpsl.sl,  col: '#ff1744', label: `SL  ${fmt(tpsl.sl)}`,  dash: [3,4] },
      ];
      for (const ln of lines) {
        const y = toY(ln.price);
        if (y < PT || y > PT + CH) continue;
        cx.save();
        cx.strokeStyle = ln.col + 'aa';
        cx.lineWidth   = 1;
        cx.setLineDash(ln.dash);
        cx.beginPath(); cx.moveTo(lastX, y); cx.lineTo(PL + CW, y); cx.stroke();
        cx.setLineDash([]);
        cx.fillStyle   = ln.col;
        cx.font        = `${F.tiny} monospace`;
        cx.textAlign   = 'right';
        cx.fillText(ln.label, PL + CW - 4, y - 2);
        cx.restore();
      }
    }

    // ── SUPERTREND (missingBundle) ─────────────────────────────────────────
    if (act.supertrend && missingBundle?.supertrend && candles.length >= 11) {
      const st    = missingBundle.supertrend;
      const isUp  = st.trend === 'UP';
      const stCol = isUp ? '#00e676' : '#ff1744';
      const lastY = toY(st.currentBand || candles[n-1].c);

      // Son bant değerini yatay çizgi olarak göster
      cx.save();
      cx.strokeStyle = stCol + 'cc';
      cx.lineWidth   = 1.5;
      cx.setLineDash([5, 3]);
      cx.beginPath();
      cx.moveTo(PL, lastY);
      cx.lineTo(PL + CW, lastY);
      cx.stroke();
      cx.setLineDash([]);
      // Etiket
      cx.fillStyle  = stCol;
      cx.font       = `bold ${F.badge} monospace`;
      cx.textAlign  = 'left';
      cx.fillText(`ST ${isUp?'▲':'▼'}`, PL + 4, lastY - 3);
      // Sinyal oku
      if (st.signal === 'BUY') {
        const x = toX(n-1), y2 = toY(candles[n-1].l||candles[n-1].c) + 14;
        cx.fillStyle = '#00e676';
        cx.beginPath(); cx.moveTo(x,y2-7); cx.lineTo(x-5,y2); cx.lineTo(x+5,y2); cx.closePath(); cx.fill();
        cx.font = `bold ${F.badge} monospace`; cx.textAlign = 'center';
        cx.fillText('ST BUY', x, y2+10);
      } else if (st.signal === 'SELL') {
        const x = toX(n-1), y2 = toY(candles[n-1].h||candles[n-1].c) - 14;
        cx.fillStyle = '#ff1744';
        cx.beginPath(); cx.moveTo(x,y2+7); cx.lineTo(x-5,y2); cx.lineTo(x+5,y2); cx.closePath(); cx.fill();
        cx.font = `bold ${F.badge} monospace`; cx.textAlign = 'center';
        cx.fillText('ST SELL', x, y2-4);
      }
      cx.restore();
    }

    // ── KELTNER CHANNEL (missingBundle) ───────────────────────────────────
    if (act.keltner && missingBundle?.keltner) {
      const kc = missingBundle.keltner;
      if (kc.upper && kc.lower && kc.basis) {
        // Basis (EMA)
        cx.save();
        cx.strokeStyle = '#00bcd480';
        cx.lineWidth   = 1;
        const basisY = toY(kc.basis);
        cx.beginPath(); cx.moveTo(PL, basisY); cx.lineTo(PL + CW, basisY); cx.stroke();
        // Upper band
        const upperY = toY(kc.upper);
        cx.strokeStyle = '#00bcd440';
        cx.setLineDash([4, 4]);
        cx.beginPath(); cx.moveTo(PL, upperY); cx.lineTo(PL + CW, upperY); cx.stroke();
        // Lower band
        const lowerY = toY(kc.lower);
        cx.beginPath(); cx.moveTo(PL, lowerY); cx.lineTo(PL + CW, lowerY); cx.stroke();
        cx.setLineDash([]);
        // Dolgu
        cx.globalAlpha = 0.05;
        cx.fillStyle   = '#00bcd4';
        cx.fillRect(PL, upperY, CW, lowerY - upperY);
        cx.globalAlpha = 1;
        // Etiket
        cx.fillStyle = '#00bcd4'; cx.font = `${F.tiny} monospace`; cx.textAlign = 'right';
        cx.fillText('KC', PL + CW - 4, basisY - 2);
        cx.restore();
      }
    }

    // ── TREND CLOUD (missingBundle) ───────────────────────────────────────
    if (act.trendCloud && missingBundle?.trendCloud) {
      const tc = missingBundle.trendCloud;
      if (tc.cloudTop && tc.cloudBottom) {
        const topY = toY(tc.cloudTop), botY = toY(tc.cloudBottom);
        cx.save();
        cx.globalAlpha = 0.08;
        cx.fillStyle   = tc.signal === 'YUKARI' ? '#00ff88' : tc.signal === 'ASAGI' ? '#ff1744' : '#888888';
        cx.fillRect(PL, topY, CW, botY - topY);
        cx.globalAlpha = 1;
        cx.fillStyle   = tc.signal === 'YUKARI' ? '#00ff88' : tc.signal === 'ASAGI' ? '#ff1744' : '#888888';
        cx.font = `${F.tiny} monospace`; cx.textAlign = 'left';
        cx.fillText(`☁ ${tc.signal||'NÖTR'}`, PL + 4, topY + 10);
        cx.restore();
      }
    }

    // ── PINE RANGE FILTER ──────────────────────────────────────────────────
    if (act.pineRF && pineData?.filtLine?.length) {
      const rfUp   = pineData.rf?.trendUp;
      const rfCol  = rfUp ? T.g : T.r;

      // filtLine — kalın renkli ana çizgi
      drawLine(cx, pineData.filtLine, vI, rfCol, 2.2, fi, cw, PL, pMn, pMx, PT, CH);

      // hband / lband — hafif bantlar
      if (pineData.hbandLine?.length) {
        drawLine(cx, pineData.hbandLine, vI, `${T.t}55`, 0.8, fi, cw, PL, pMn, pMx, PT, CH);
        drawLine(cx, pineData.lbandLine, vI, `${T.p}55`, 0.8, fi, cw, PL, pMn, pMx, PT, CH);
      }

      // filtLine legend
      cx.fillStyle = rfCol;
      cx.font = `${F.badge} monospace`;
      cx.textAlign = 'left';
      cx.fillText(`RF ${rfUp ? '▲' : '▼'}`, PL + CW - 48, PT + 26);
    }

    // ── PINE S/R ZONES ────────────────────────────────────────────────────
    if (act.pineSR && pineData?.srZones?.length) {
      const curPrice = candles[n-1].c;
      for (const zone of pineData.srZones) {
        if (!zone.hi || !zone.lo) continue;
        const topY = toY(zone.hi);
        const botY = toY(zone.lo);
        if (topY > PT + CH || botY < PT) continue; // görünür alanda değil

        const isRes  = zone.lo > curPrice;      // tamamen yukarı = direnç
        const isSup  = zone.hi < curPrice;      // tamamen aşağı = destek
        const col    = isRes ? T.r : isSup ? T.g : '#888888';

        // Dolgu
        cx.globalAlpha = 0.10;
        cx.fillStyle   = col;
        cx.fillRect(PL, topY, CW, Math.max(1, botY - topY));
        cx.globalAlpha = 1;

        // Çerçeve
        cx.strokeStyle = col + '70';
        cx.lineWidth   = 0.8;
        cx.setLineDash([3, 3]);
        cx.strokeRect(PL, topY, CW, Math.max(1, botY - topY));
        cx.setLineDash([]);

        // Dokunuş sayısı + etiket
        cx.fillStyle   = col;
        cx.font        = `${F.tiny} monospace`;
        cx.textAlign   = 'right';
        cx.fillText(
          `${zone.touches || ''}x ${isRes ? 'DİR' : isSup ? 'DES' : 'S/R'}`,
          PL + CW - 4,
          topY - 2
        );
      }
    }

    // ── PINE BUY / SELL SİNYALLERİ (Range Filter flip) ───────────────────
    if (pineData?.rf) {
      const rf = pineData.rf;

      // RF BUY — son 3 mum içinde buySignal var mı?
      if (act.pineRF && rf.buySignal) {
        const x   = toX(n - 1);
        const low = candles[n-1].l || candles[n-1].c;
        const y   = toY(low) + 18;
        // Ok
        cx.fillStyle = T.g;
        cx.beginPath();
        cx.moveTo(x, y - 8); cx.lineTo(x - 6, y); cx.lineTo(x + 6, y);
        cx.closePath(); cx.fill();
        // Etiket
        const lw2 = 38;
        cx.fillStyle = T.g;
        cx.fillRect(x - lw2 / 2, y + 2, lw2, 14);
        cx.fillStyle = T.bg;
        cx.font = `bold ${F.badge} monospace`;
        cx.textAlign = 'center';
        cx.fillText('RF BUY', x, y + 12);
      }

      // RF SELL — sellSignal
      if (act.pineRF && rf.sellSignal) {
        const x   = toX(n - 1);
        const hi  = candles[n-1].h || candles[n-1].c;
        const y   = toY(hi) - 18;
        // Ok
        cx.fillStyle = T.r;
        cx.beginPath();
        cx.moveTo(x, y + 8); cx.lineTo(x - 6, y); cx.lineTo(x + 6, y);
        cx.closePath(); cx.fill();
        // Etiket
        const lw2 = 42;
        cx.fillStyle = T.r;
        cx.fillRect(x - lw2 / 2, y - 16, lw2, 14);
        cx.fillStyle = '#fff';
        cx.font = `bold ${F.badge} monospace`;
        cx.textAlign = 'center';
        cx.fillText('RF SELL', x, y - 5);
      }
    }

    // ── PINE PB-AL / PB-SAT ───────────────────────────────────────────────
    if (act.pinePB && pineData?.pb) {
      const pb = pineData.pb;

      if (pb.pbBuy) {
        const x = toX(n - 1);
        const low = candles[n-1].l || candles[n-1].c;
        const y   = toY(low) + 36;
        const lw2 = 46;
        cx.fillStyle = T.g;
        cx.fillRect(x - lw2 / 2, y - 8, lw2, 15);
        cx.fillStyle = T.bg;
        cx.font = `bold ${F.badge} monospace`;
        cx.textAlign = 'center';
        cx.fillText('PB-AL', x, y + 4);
        // Bağlantı çizgisi
        cx.strokeStyle = `${T.g}60`;
        cx.lineWidth = 0.8;
        cx.beginPath();
        cx.moveTo(x, toY(low) + 2);
        cx.lineTo(x, y - 8);
        cx.stroke();
      }

      if (pb.pbSell) {
        const x = toX(n - 1);
        const hi  = candles[n-1].h || candles[n-1].c;
        const y   = toY(hi) - 36;
        const lw2 = 52;
        cx.fillStyle = T.o;
        cx.fillRect(x - lw2 / 2, y - 8, lw2, 15);
        cx.fillStyle = T.bg;
        cx.font = `bold ${F.badge} monospace`;
        cx.textAlign = 'center';
        cx.fillText('PB-SAT', x, y + 4);
        // Bağlantı çizgisi
        cx.strokeStyle = `${T.o}60`;
        cx.lineWidth = 0.8;
        cx.beginPath();
        cx.moveTo(x, toY(hi) - 2);
        cx.lineTo(x, y + 7);
        cx.stroke();
      }
    }

    // Signal labels
    if (act.sig && sigs.length) {
      const curY = toY(candles[n-1].c), lastX = toX(n-1);
      sigs.slice(0,4).forEach((sg, idx) => {
        const sy = sg.up ? curY+(22+idx*18) : curY-(22+idx*18);
        const lw2 = cx.measureText(sg.type).width+14;
        cx.fillStyle = sg.col; cx.fillRect(lastX-lw2/2-2, sy-9, lw2+4, 16);
        cx.fillStyle = T.bg; cx.font = `bold ${F.value} monospace`; cx.textAlign = 'center';
        cx.fillText(sg.type, lastX, sy+4);
        cx.strokeStyle = `${sg.col}70`; cx.lineWidth = 0.8;
        cx.beginPath(); cx.moveTo(lastX, sg.up?curY+2:curY-2); cx.lineTo(lastX, sg.up?sy-9:sy+16); cx.stroke();
      });
    }

    // Council overlay panel (okunaklı boyut)
    if (act.con && council) {
      const px = PL+4, py = PT+8, pw = 160, ph = 88;
      cx.fillStyle = 'rgba(2,2,12,0.88)'; cx.fillRect(px-4, py-4, pw+8, ph+8);
      cx.strokeStyle = T.b2; cx.lineWidth = 0.5; cx.strokeRect(px-4, py-4, pw+8, ph+8);
      [
        { k:'alpha', col:T.b,  lbl:'◈ ALPHA' },
        { k:'flow',  col:T.g,  lbl:'⟁ FLOW'  },
        { k:'risk',  col:T.r,  lbl:'⬡ RISK'  },
        { k:'macro', col:T.y,  lbl:'⎈ MACRO' },
      ].forEach((cv, i) => {
        const sc = council[cv.k] ?? 50, ry = py+i*21;
        cx.fillStyle = T.txt; cx.font = `${F.badge} monospace`; cx.textAlign = 'left';
        cx.fillText(cv.lbl, px, ry+10);
        cx.fillStyle = T.b1; cx.fillRect(px+56, ry+1, 90, 12);
        cx.fillStyle = cv.col; cx.fillRect(px+56, ry+1, Math.max(2, (sc/100)*90), 12);
        cx.fillStyle = cv.col; cx.textAlign = 'right'; cx.font = `bold ${F.value} monospace`;
        cx.fillText(sc, px+53, ry+11);
      });
    }

    // Volume
    if (act.vol) {
      const mxV = Math.max(...vI.map(i => candles[i].v||0)) || 1;
      for (const i of vI) {
        const c = candles[i], x = toX(i), bull = c.c >= c.o;
        const vh = ((c.v||0)/mxV)*VH, bw2 = Math.max(1, cw*0.65);
        cx.fillStyle = bull ? `${T.g}38` : `${T.r}38`;
        cx.fillRect(x-bw2/2, PT+CH+VH-vh, bw2, vh);
      }
    }

    // Price line
    const cp = candles[n-1].c, isUpC = candles[n-1].c >= (candles[n-1].o || candles[n-1].c);
    const cpy = toY(cp);
    cx.strokeStyle = `${isUpC?T.g:T.r}70`; cx.lineWidth = 0.9; cx.setLineDash([2,5]);
    cx.beginPath(); cx.moveTo(PL, cpy); cx.lineTo(PL+CW, cpy); cx.stroke(); cx.setLineDash([]);
    const pLbl = fmt(cp);
    const plw = cx.measureText(pLbl).width + 14;
    cx.fillStyle = isUpC ? T.g : T.r; cx.fillRect(PL+CW+2, cpy-8, plw, 16);
    cx.fillStyle = T.bg; cx.font = `bold ${F.value} monospace`; cx.textAlign = 'left';
    cx.fillText(pLbl, PL+CW+6, cpy+4);

    // Chart type label
    const typeLabels = { candle:'Mum', heikin:'Heikin Ashi', hollow:'Hollow', bar:'Bar', line:'Çizgi', area:'Alan', renko:'Renko' };
    cx.fillStyle = T.mid; cx.font = `${F.tiny} monospace`; cx.textAlign = 'left';
    cx.fillText(typeLabels[chartType], PL+2, PT+12);

    // EMA legend
    [['e9',T.b,'E9'],['e21',T.y,'E21'],['e50',T.o,'E50']].forEach(([k,col,lbl],i) => {
      if (!act[k]) return;
      cx.fillStyle = col; cx.font = `${F.badge} monospace`; cx.textAlign = 'left';
      cx.fillText(lbl, PL+CW-(70-i*24), PT+13);
    });
    if (act.vw) { cx.fillStyle = T.t; cx.fillText('VW', PL+CW-2, PT+13); }

    // Oscillator panel
    cx.fillStyle = T.s2; cx.fillRect(PL, OT, CW, OH);
    cx.strokeStyle = T.b1; cx.lineWidth = 0.5; cx.strokeRect(PL, OT, CW, OH);
    drawOscillator(cx, vI, fi, cw, PL, OT, OH, CW, I, osc);

    // Time labels
    cx.fillStyle = T.txt; cx.font = `${F.label} monospace`; cx.textAlign = 'center';
    const tSt = Math.max(1, Math.floor(vI.length/7));
    for (let i = 0; i < vI.length; i += tSt) {
      const ci = vI[i], x = toX(ci);
      cx.fillText((candles[ci].t||'').slice(0,5), x, PT+CH+VH+16);
    }
  }, [candles, I, mags, srLvls, sigs, pineData, council, missingBundle, dims, oX, sX, act, osc, chartType]);

  function drawOscillator(cx, vI, fi, cw, pl, ot, oh, cw2, I, oscType) {
    const dL = (vals, col, lw, mn, mx) => drawLine(cx, vals, vI, col, lw, fi, cw, pl, mn, mx, ot, oh);
    const cw3 = cw2/vI.length;
    const FONT = `${F.value} monospace`;

    if (oscType === 'RSI' && I.rsi) {
      const y70=ot+oh*(1-70/100), y30=ot+oh*(1-30/100);
      cx.fillStyle='rgba(255,23,68,0.05)';cx.fillRect(pl,ot,cw2,y70-ot);
      cx.fillStyle='rgba(0,230,118,0.05)';cx.fillRect(pl,y30,cw2,ot+oh-y30);
      [{y:y70,c:T.r},{y:y30,c:T.g}].forEach(l=>{cx.strokeStyle=`${l.c}30`;cx.setLineDash([3,5]);cx.beginPath();cx.moveTo(pl,l.y);cx.lineTo(pl+cw2,l.y);cx.stroke();cx.setLineDash([]);});
      dL(I.rsi, T.b, 1.5, 0, 100);
      const lr=I.rsi[vI[vI.length-1]];const rc=lr>70?T.r:lr<30?T.g:T.b;
      cx.fillStyle=rc; cx.font=FONT; cx.textAlign='left'; cx.fillText(`RSI ${lr!=null?lr.toFixed(1):'—'}`, pl+5, ot+14);
    } else if (oscType === 'MACD' && I.macd) {
      const{ml,sl,h:hist}=I.macd, vH=vI.map(i=>hist[i]).filter(v=>v!=null), mxA=Math.max(...vH.map(Math.abs),0.0001), mid=ot+oh/2;
      cx.strokeStyle=T.b1;cx.beginPath();cx.moveTo(pl,mid);cx.lineTo(pl+cw2,mid);cx.stroke();
      for(let i=0;i<vI.length;i++){const v=hist[vI[i]];if(v==null)continue;const x=pl+i*cw3+cw3/2,bw2=Math.max(1,cw3*0.65),bH=(Math.abs(v)/mxA)*(oh/2-2);cx.fillStyle=v>=0?`${T.g}50`:`${T.r}50`;cx.fillRect(x-bw2/2,v>=0?mid-bH:mid,bw2,bH);}
      dL(ml,T.b,1,-mxA,mxA); dL(sl,T.o,1,-mxA,mxA);
      const lh=hist[vI[vI.length-1]]; cx.fillStyle=lh>=0?T.g:T.r; cx.font=FONT; cx.textAlign='left';
      cx.fillText(`MACD ${lh!=null?(lh>=0?'+':'')+lh.toFixed(4):'—'}`, pl+5, ot+14);
    } else if (oscType === 'STOCH' && I.stoch) {
      const{k,d}=I.stoch;
      [{y:ot+oh*0.2,c:T.r},{y:ot+oh*0.8,c:T.g}].forEach(l=>{cx.strokeStyle=`${l.c}30`;cx.setLineDash([3,5]);cx.beginPath();cx.moveTo(pl,l.y);cx.lineTo(pl+cw2,l.y);cx.stroke();cx.setLineDash([]);});
      dL(k,T.p,1.5,0,100); dL(d,T.y,1,0,100);
      const lk=k[vI[vI.length-1]]; cx.fillStyle=T.p; cx.font=FONT; cx.textAlign='left';
      cx.fillText(`STOCH ${lk!=null?lk.toFixed(1):'—'}`, pl+5, ot+14);
    } else if (oscType === 'ADX' && I.adx) {
      dL(I.adx,T.o,1.5,0,100);
      const la=I.adx[vI[vI.length-1]]; cx.fillStyle=T.o; cx.font=FONT; cx.textAlign='left';
      cx.fillText(`ADX ${la!=null?la.toFixed(1):'—'}`, pl+5, ot+14);
    } else if (oscType === 'CCI' && I.cci) {
      const mxC=Math.max(...vI.map(i=>Math.abs(I.cci[i]||0)),100); dL(I.cci,T.t,1.5,-mxC,mxC);
      const lc=I.cci[vI[vI.length-1]]; cx.fillStyle=T.t; cx.font=FONT; cx.textAlign='left';
      cx.fillText(`CCI ${lc!=null?lc.toFixed(0):'—'}`, pl+5, ot+14);
    } else if (oscType === 'MFI' && I.mfi) {
      const y70=ot+oh*(1-70/100), y30=ot+oh*(1-30/100);
      cx.fillStyle='rgba(255,23,68,0.05)';cx.fillRect(pl,ot,cw2,y70-ot);
      cx.fillStyle='rgba(0,230,118,0.05)';cx.fillRect(pl,y30,cw2,ot+oh-y30);
      dL(I.mfi,T.t,1.5,0,100);
      const lm=I.mfi[vI[vI.length-1]]; cx.fillStyle=T.t; cx.font=FONT; cx.textAlign='left';
      cx.fillText(`MFI ${lm!=null?lm.toFixed(1):'—'}`, pl+5, ot+14);
    } else if (oscType === 'OBV' && I.obv) {
      const mxO=Math.max(...vI.map(i=>Math.abs(I.obv[i]||0)),1); dL(I.obv,T.g,1.5,-mxO,mxO);
      const lo=I.obv[vI[vI.length-1]]; cx.fillStyle=T.g; cx.font=FONT; cx.textAlign='left';
      cx.fillText(`OBV ${lo!=null?fmtV(Math.abs(lo)):'—'}`, pl+5, ot+14);
    }
  }

  useEffect(() => {
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    rafRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(rafRef.current);
  }, [draw]);

  // Mouse/touch handlers
  const handleMouseMove = useCallback((e) => {
    const rect = overlayRef.current?.getBoundingClientRect();
    if (!rect) return;
    const mxP = e.clientX-rect.left, myP = e.clientY-rect.top;
    if (isDrag.current) {
      const dx = e.clientX-dragStartX.current;
      const { cw } = stateRef.current;
      setOX(Math.max(0, dragOff.current - dx/(cw||6)));
      return;
    }
    // Crosshair
    const { pMn, pMx, fi, cw, PL, PT, CH, CW } = stateRef.current;
    if (!act.cross || mxP < PL || mxP > PL+CW || myP < PT || myP > PT+CH) {
      overlayRef.current?.getContext('2d')?.clearRect(0, 0, dims.w, dims.h);
      return;
    }
    const octx = overlayRef.current.getContext('2d');
    octx.clearRect(0, 0, dims.w, dims.h);
    octx.strokeStyle = 'rgba(80,80,200,0.28)'; octx.lineWidth = 0.8; octx.setLineDash([4,7]);
    octx.beginPath(); octx.moveTo(mxP, PT); octx.lineTo(mxP, PT+CH); octx.stroke();
    octx.beginPath(); octx.moveTo(PL, myP); octx.lineTo(PL+CW, myP); octx.stroke();
    octx.setLineDash([]);
    const price = pMx - ((myP-PT)/CH)*(pMx-pMn), lbl = fmt(price);
    const tw = octx.measureText(lbl).width+14;
    octx.fillStyle = T.s1; octx.fillRect(PL+CW+2, myP-8, tw, 16);
    octx.strokeStyle = T.b1; octx.lineWidth = 0.5; octx.strokeRect(PL+CW+2, myP-8, tw, 16);
    octx.fillStyle = T.w; octx.font = `${F.value} monospace`; octx.textAlign = 'left';
    octx.fillText(lbl, PL+CW+6, myP+4);
    const ci = Math.round((mxP-PL)/cw)+fi;
    const cd = candles[clamp(ci, 0, candles.length-1)];
    if (cd) {
      setHover({ ...cd, idx: ci });
    }
  }, [candles, act.cross, dims]);

  const handleMouseDown = useCallback((e) => {
    isDrag.current = true; dragStartX.current = e.clientX; dragOff.current = oX;
    overlayRef.current.style.cursor = 'grabbing';
  }, [oX]);
  const handleMouseUp = useCallback(() => { isDrag.current = false; overlayRef.current.style.cursor = 'crosshair'; }, []);
  const handleMouseLeave = useCallback(() => {
    isDrag.current = false; setHover(null);
    overlayRef.current?.getContext('2d')?.clearRect(0, 0, dims.w, dims.h);
  }, [dims]);
  const handleWheel = useCallback((e) => {
    e.preventDefault();
    setSX(s => clamp(s + (e.deltaY > 0 ? -0.12 : 0.12), 0.3, 10));
  }, []);
  const handleTouchStart = useCallback((e) => {
    isDrag.current = true; dragStartX.current = e.touches[0].clientX; dragOff.current = oX;
  }, [oX]);
  const handleTouchMove = useCallback((e) => {
    if (!isDrag.current) return;
    const dx = e.touches[0].clientX - dragStartX.current;
    const { cw } = stateRef.current;
    setOX(prev => Math.max(0, dragOff.current - dx/(cw||6)));
  }, []);
  const handleTouchEnd = useCallback(() => { isDrag.current = false; }, []);

  const n = candles.length;
  const currentCandle = candles[n-1];
  const prevCandle    = candles[n-2];
  const priceChange   = currentCandle && prevCandle ? ((currentCandle.c-prevCandle.c)/prevCandle.c*100) : 0;
  const isUp          = priceChange >= 0;
  const lastRSI       = I.rsi?.[n-1];
  const lastMACD      = I.macd?.h?.[n-1];
  const lastBBPos     = useMemo(() => { const u=I.bb?.u?.[n-1],l=I.bb?.l?.[n-1],c=currentCandle?.c; return u&&l&&c?(c-l)/(u-l)*100:50; }, [I.bb, currentCandle, n]);

  const toggleAct = (k) => setAct(prev => ({ ...prev, [k]: prev[k]?0:1 }));

  return (
    <div style={{ display:'flex', flexDirection:'column', height:'100%', background:T.bg, border:`1px solid ${T.b1}`, borderRadius:10, overflow:'hidden', fontFamily:"'Courier New',monospace" }}>

      {/* HEADER */}
      <div style={{ background:T.s1, borderBottom:`1px solid ${T.b1}`, padding:'7px 14px', display:'flex', alignItems:'center', gap:10, flexWrap:'wrap', flexShrink:0 }}>
        <div style={{ width:8, height:8, borderRadius:'50%', background:connected?T.g:T.r, boxShadow:`0 0 8px ${connected?T.g:T.r}`, flexShrink:0 }} />
        <span style={{ color:T.b, fontSize:13, fontWeight:700, letterSpacing:2 }}>{base}<span style={{ color:T.dim }}>/</span>{quote}</span>
        <span style={{ color:T.w, fontSize:F.price, fontWeight:700 }}>
          {currentCandle?.c > 100 ? currentCandle.c.toLocaleString('en',{minimumFractionDigits:2}) : currentCandle?.c?.toFixed(6) || '—'}
        </span>
        <span style={{ fontSize:11, fontWeight:700, padding:'2px 8px', borderRadius:4, color:isUp?T.g:T.r, background:isUp?'rgba(0,230,118,.1)':'rgba(255,23,68,.1)' }}>
          {isUp?'▲':'▼'} {Math.abs(priceChange).toFixed(3)}%
        </span>
        {aggPrice && (
          <span style={{ fontSize:10, color:T.mid }}>
            {aggPrice.exchanges?.length} borsa · Spread {aggPrice.spread?.toFixed(3)}%
          </span>
        )}
        {/* Pine RF + Council durum rozeti */}
        {pineData?.rf && (
          <span style={{
            fontSize:10, fontWeight:700, padding:'2px 8px', borderRadius:4,
            background: pineData.rf.trendUp ? 'rgba(0,230,118,.12)' : 'rgba(255,23,68,.12)',
            color:      pineData.rf.trendUp ? '#00e676' : '#ff1744',
            border:     `1px solid ${pineData.rf.trendUp ? '#00e67640' : '#ff174440'}`,
          }}>
            RF {pineData.rf.trendUp ? '▲ YUKARI' : '▼ AŞAĞI'}
            {pineData.rf.buySignal  && ' 🟢 BUY'}
            {pineData.rf.sellSignal && ' 🔴 SELL'}
          </span>
        )}
        {pineData?.council && (
          <span style={{
            fontSize:10, fontWeight:700, padding:'2px 8px', borderRadius:4,
            background:'rgba(0,176,255,.10)', color:'#00b0ff',
            border:'1px solid rgba(0,176,255,.30)',
          }}>
            {pineData.council.councilAction} {pineData.council.councilScore}
            <span style={{ opacity:.6, fontWeight:400 }}> %{pineData.council.councilConfidence}</span>
          </span>
        )}
        {pineData?.pb?.pbBuy  && (
          <span style={{ fontSize:10, fontWeight:700, padding:'2px 8px', borderRadius:4, background:'rgba(0,230,118,.12)', color:'#00e676', border:'1px solid #00e67640' }}>PB-AL</span>
        )}
        {pineData?.pb?.pbSell && (
          <span style={{ fontSize:10, fontWeight:700, padding:'2px 8px', borderRadius:4, background:'rgba(255,109,0,.12)', color:'#ff6d00', border:'1px solid #ff6d0040' }}>PB-SAT</span>
        )}
        <div style={{ display:'flex', gap:4, marginLeft:'auto', flexWrap:'wrap' }}>
          {[
            { label:'RSI', val:lastRSI?.toFixed(1), color:lastRSI>70?T.r:lastRSI<30?T.g:T.b },
            { label:'MACD', val:lastMACD!=null?(lastMACD>=0?'+':'')+lastMACD.toFixed(4):null, color:lastMACD>=0?T.g:T.r },
            { label:'BB', val:lastBBPos.toFixed(0)+'%', color:lastBBPos<20?T.g:lastBBPos>80?T.r:T.mid },
            { label:'VOL', val:fmtV(currentCandle?.v||0), color:T.mid },
          ].map(s => (
            <div key={s.label} style={{ background:T.s2, border:`1px solid ${T.b1}`, borderRadius:4, padding:'2px 8px', fontSize:11, color:T.dim }}>
              {s.label} <span style={{ fontWeight:700, color:s.color }}>{s.val||'—'}</span>
            </div>
          ))}
        </div>
        <div style={{ display:'flex', gap:2 }}>
          {TIMEFRAMES.map(t => (
            <button key={t} onClick={() => { setTf(t); setOX(0); setSX(1); }}
              style={{ background:tf===t?`rgba(0,176,255,.12)`:'transparent', border:`1px solid ${tf===t?'rgba(0,176,255,.4)':T.b1}`, color:tf===t?T.b:T.dim, fontSize:11, fontFamily:'inherit', padding:'3px 9px', borderRadius:3, cursor:'pointer' }}>
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* CHART TYPE + INDICATORS */}
      <div style={{ background:T.s1, borderBottom:`1px solid ${T.b1}`, padding:'4px 12px', display:'flex', gap:4, alignItems:'center', flexWrap:'wrap', flexShrink:0 }}>
        {/* Chart types */}
        <div style={{ display:'flex', gap:2, background:T.s2, border:`1px solid ${T.b1}`, borderRadius:5, padding:2 }}>
          {CHART_TYPES.map(ct => (
            <button key={ct.id} onClick={() => setChartType(ct.id)}
              style={{ background:chartType===ct.id?T.b2:'transparent', border:'none', color:chartType===ct.id?T.b:T.dim, fontSize:10, fontFamily:'inherit', padding:'3px 9px', borderRadius:3, cursor:'pointer' }}>
              {ct.label}
            </button>
          ))}
        </div>
        <div style={{ width:1, height:16, background:T.b1, margin:'0 4px' }} />
        {[
          { k:'e9',  label:'EMA 9',  col:T.b  }, { k:'e21', label:'EMA 21', col:T.b  },
          { k:'e50', label:'EMA 50', col:T.b  }, { k:'e200',label:'EMA 200',col:T.p  },
          { k:'vw',  label:'VWAP',   col:T.b  }, { k:'bb',  label:'BB',     col:T.b  },
          { k:'liq', label:'Liq Map',col:T.b  }, { k:'mag', label:'Magnet', col:T.o  },
          { k:'sr',  label:'S/R',    col:T.b  }, { k:'vol', label:'Hacim',  col:T.g  },
          { k:'sig', label:'Sinyal', col:T.g  }, { k:'con', label:'Konsey', col:T.p  },
          { k:'cross',label:'✛ Cross',col:T.y },
          // Pine İndikatör butonları
          { k:'pineRF', label:'Pine RF', col:'#00e676' },
          { k:'pineSR', label:'Pine S/R',col:'#00bcd4' },
          { k:'pinePB', label:'PB',       col:'#ff6d00' },
          { k:'supertrend', label:'Supertrend', col:'#00e5ff' },
          { k:'keltner',    label:'Keltner',    col:'#00bcd4' },
          { k:'trendCloud', label:'☁ Bulut',    col:'#9c27b0' },
        ].map(({ k, label, col }) => (
          <button key={k} onClick={() => toggleAct(k)}
            style={{
              background:act[k]?`${col}14`:'transparent', border:`1px solid ${act[k]?col+'38':T.b1}`,
              color:act[k]?col:T.dim, fontSize:10, fontFamily:'inherit', padding:'2px 8px', borderRadius:3, cursor:'pointer',
            }}>
            {label}
          </button>
        ))}
        <button onClick={() => { setOX(0); setSX(1); }}
          style={{ background:'transparent', border:`1px solid ${T.b1}`, color:T.dim, fontSize:10, fontFamily:'inherit', padding:'2px 8px', borderRadius:3, cursor:'pointer', marginLeft:'auto' }}>
          ⟲ Sıfırla
        </button>
      </div>

      {/* MAGNET STRIP */}
      <div style={{ background:T.s1, borderBottom:`1px solid ${T.b1}`, padding:'3px 12px', display:'flex', gap:6, alignItems:'center', minHeight:28, overflowX:'auto', flexShrink:0 }}>
        <span style={{ fontSize:10, color:T.dim, fontWeight:700, flexShrink:0 }}>MAGNET ›</span>
        {mags.up.slice(0,3).map((m,i) => (
          <div key={i} style={{ background:'rgba(0,176,255,.09)', border:'1px solid rgba(0,176,255,.32)', color:T.b, borderRadius:4, padding:'2px 9px', fontSize:10, fontWeight:700, whiteSpace:'nowrap' }}>
            ▲ ${fmt(m.price)} <span style={{ opacity:.6 }}>{m.strength}%{m.isRound?' ⊙':''}</span>
          </div>
        ))}
        {mags.dn.slice(0,3).map((m,i) => (
          <div key={i} style={{ background:'rgba(255,23,68,.09)', border:'1px solid rgba(255,23,68,.32)', color:T.r, borderRadius:4, padding:'2px 9px', fontSize:10, fontWeight:700, whiteSpace:'nowrap' }}>
            ▼ ${fmt(m.price)} <span style={{ opacity:.6 }}>{m.strength}%{m.isRound?' ⊙':''}</span>
          </div>
        ))}
        {/* Pine S/R bölgeleri özeti */}
        {pineData?.srZones?.length > 0 && (
          <>
            <div style={{ width:1, height:14, background:T.b1, margin:'0 2px', flexShrink:0 }} />
            <span style={{ fontSize:10, color:'#00bcd4', fontWeight:700, flexShrink:0 }}>S/R ›</span>
            {pineData.sr?.res?.slice(0,2).map((z,i) => (
              <div key={`r${i}`} style={{ background:'rgba(255,23,68,.07)', border:'1px solid rgba(255,23,68,.28)', color:T.r, borderRadius:4, padding:'2px 8px', fontSize:10, whiteSpace:'nowrap' }}>
                ▲ {fmt((z.lo+z.hi)/2)} <span style={{ opacity:.5 }}>{z.touches}x</span>
              </div>
            ))}
            {pineData.sr?.sup?.slice(0,2).map((z,i) => (
              <div key={`s${i}`} style={{ background:'rgba(0,230,118,.07)', border:'1px solid rgba(0,230,118,.28)', color:T.g, borderRadius:4, padding:'2px 8px', fontSize:10, whiteSpace:'nowrap' }}>
                ▼ {fmt((z.lo+z.hi)/2)} <span style={{ opacity:.5 }}>{z.touches}x</span>
              </div>
            ))}
          </>
        )}
      </div>

      {/* HOVER BAR */}
      <div style={{ background:T.s2, borderBottom:`1px solid ${T.b1}`, padding:'3px 12px', fontSize:11, color:T.dim, minHeight:22, display:'flex', gap:10, alignItems:'center', flexShrink:0 }}>
        {hover ? (
          <>
            <span>{hover.t}</span>
            <span>O <b style={{ color:T.txt }}>{fmt(hover.o||hover.c)}</b></span>
            <span>H <b style={{ color:T.g  }}>{fmt(hover.h||hover.c)}</b></span>
            <span>L <b style={{ color:T.r  }}>{fmt(hover.l||hover.c)}</b></span>
            <span>C <b style={{ color:T.txt }}>{fmt(hover.c)}</b></span>
            <span>V <b style={{ color:T.mid }}>{fmtV(hover.v||0)}</b></span>
          </>
        ) : (
          <span>Mumun üzerine gelin — sürükle: pan · scroll: zoom</span>
        )}
      </div>

      {/* CANVAS */}
      <div ref={containerRef} style={{ flex:1, position:'relative', minHeight:0 }}>
        <canvas ref={canvasRef} style={{ position:'absolute', top:0, left:0, width:'100%', height:'100%' }} />
        <canvas ref={overlayRef}
          style={{ position:'absolute', top:0, left:0, width:'100%', height:'100%', cursor:'crosshair' }}
          onMouseMove={handleMouseMove}
          onMouseDown={handleMouseDown}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseLeave}
          onWheel={handleWheel}
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
        />
        {!candles.length && (
          <div style={{ position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center' }}>
            <span style={{ color:T.dim, fontSize:14, fontFamily:'monospace' }}>Veri yükleniyor...</span>
          </div>
        )}
      </div>

      {/* OSC BAR */}
      <div style={{ background:T.s1, borderTop:`1px solid ${T.b1}`, padding:'4px 12px', display:'flex', gap:4, alignItems:'center', flexShrink:0 }}>
        <span style={{ fontSize:10, color:T.dim, marginRight:4 }}>OSC ›</span>
        {OSCS.map(o => (
          <button key={o} onClick={() => setOsc(o)}
            style={{ background:osc===o?'rgba(0,176,255,.12)':'transparent', border:`1px solid ${osc===o?'rgba(0,176,255,.4)':T.b1}`, color:osc===o?T.b:T.dim, fontSize:10, fontFamily:'inherit', padding:'2px 9px', borderRadius:3, cursor:'pointer' }}>
            {o}
          </button>
        ))}
      </div>

      {/* COUNCIL BAR */}
      <div style={{ background:T.s1, borderTop:`1px solid ${T.b1}`, padding:'5px 12px', display:'flex', gap:5, alignItems:'center', flexWrap:'wrap', flexShrink:0 }}>
        {[
          { k:'alpha', col:T.b, lbl:'◈ ALPHA' },
          { k:'flow',  col:T.g, lbl:'⟁ FLOW'  },
          { k:'risk',  col:T.r, lbl:'⬡ RISK'  },
          { k:'macro', col:T.y, lbl:'⎈ MACRO' },
        ].map(cv => {
          const sc = council?.[cv.k] ?? 50;
          const a  = sc >= 58 ? 'AL' : sc <= 45 ? 'SAT' : 'BEKLE';
          return (
            <div key={cv.k} style={{ background:`${cv.col}08`, border:`1px solid ${cv.col}20`, borderRadius:5, padding:'3px 10px', display:'flex', gap:6, alignItems:'center' }}>
              <span style={{ color:cv.col, fontSize:11, fontWeight:700, letterSpacing:.5 }}>{cv.lbl}</span>
              <span style={{ color:cv.col, fontSize:13, fontWeight:700 }}>{sc}</span>
              <span style={{ color:cv.col, fontSize:10, opacity:.7 }}>{a}</span>
            </div>
          );
        })}
        {council && (
          <div style={{ marginLeft:'auto', background:`${council.fc}12`, border:`1px solid ${council.fc}40`, borderRadius:6, padding:'4px 12px', display:'flex', gap:8, alignItems:'center' }}>
            <span style={{ fontSize:11, color:T.mid }}>KARAR</span>
            <span style={{ fontSize:15, fontWeight:700, color:council.fc }}>{council.act}</span>
            <span style={{ fontSize:13, fontWeight:700, color:council.fc }}>{council.fin}</span>
            <span style={{ fontSize:10, padding:'1px 6px', borderRadius:3, background:`${council.rl==='DÜŞÜK'?T.g:council.rl==='ORTA'?T.y:T.r}14`, color:council.rl==='DÜŞÜK'?T.g:council.rl==='ORTA'?T.y:T.r }}>{council.rl}</span>
            <span style={{ fontSize:10, color:council.fin>=58?T.g:council.fin<=45?T.r:T.y }}>{council.bias}</span>
          </div>
        )}
        {/* Funding rates */}
        {funding.map(f => (
          <div key={f.ex} style={{ fontSize:10, color:T.mid }}>
            {f.ex} <span style={{ color:f.rate>0.05?T.r:f.rate<-0.05?T.g:T.dim }}>{f.rate>0?'+':''}{f.rate.toFixed(4)}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}
