/**
 * GRID MASTER GLOBAL — COMMODITY ENGINE v1
 * ==========================================
 * SAFE HAVEN FLOW ENGINE
 * INFLATION HEDGE ENGINE
 * PRECIOUS METAL MOMENTUM ENGINE
 * COMMODITY LIQUIDITY ENGINE
 * MACRO PRESSURE ANALYZER
 * CENTRAL BANK GOLD FLOW
 * OIL SUPPLY SHOCK ENGINE
 * ENERGY DEMAND ANALYZER
 * OPEC POLICY ENGINE
 * ENERGY VOLATILITY ENGINE
 */

import { clamp } from './engineCore.js';

// ─── ÖNBELLEK ─────────────────────────────────────────────────────────────────
const _cache = new Map();
function cacheGet(k, ttl = 10 * 60 * 1000) { const e = _cache.get(k); return e && Date.now() - e.ts < ttl ? e.v : null; }
function cacheSet(k, v) { _cache.set(k, { v, ts: Date.now() }); }

// ─── STOOQ VERİ ÇEK ──────────────────────────────────────────────────────────
async function fetchStooq(sym, id) {
  const cached = cacheGet(id);
  if (cached) return cached;
  try {
    const res  = await fetch(`https://stooq.com/q/l/?s=${sym}&f=sd2t2ohlcv&h&e=csv`, { signal: AbortSignal.timeout(6000) });
    const csv  = await res.text();
    const rows = csv.split('\n');
    if (rows.length < 2) return null;
    const h = rows[0].split(','); const v = rows[1].split(',');
    const row = {}; h.forEach((k, i) => { row[k.trim()] = v[i]?.trim(); });
    const close = parseFloat(row['Close']); const open = parseFloat(row['Open']);
    if (isNaN(close)) return null;
    const result = { id, close, open, high: parseFloat(row['High']), low: parseFloat(row['Low']),
      change24h: open ? parseFloat(((close - open) / open * 100).toFixed(3)) : 0 };
    cacheSet(id, result);
    return result;
  } catch (e) { return null; }
}

// ════════════════════════════════════════════════════════════════════════════════
// 1. SAFE HAVEN FLOW ENGINE
// ════════════════════════════════════════════════════════════════════════════════
/**
 * Güvenli liman varlıklarına (Altın, JPY, CHF, Tahvil) para akışını ölçer.
 * Safe haven talebi yüksekse = risk-off = kripto düşer
 */
export function runSafeHavenFlowEngine({
  goldChange    = 0,   // Altın % değişim
  jpyChange     = 0,   // JPY güçlenme % (USDJPY düşüşü)
  chfChange     = 0,   // CHF güçlenme %
  bondYield10y  = 4.0, // 10y tahvil getirisi
  vixLevel      = 20,
} = {}) {

  let   safeHavenScore = 0;
  const signals = [];

  // Altın yükselişi = güvenli liman talebi
  if (goldChange >= 1.5)       { safeHavenScore += 25; signals.push(`Altın +${goldChange.toFixed(2)}% — Güvenli liman talebi`); }
  else if (goldChange >= 0.5)  { safeHavenScore += 12; }
  else if (goldChange <= -1.0) { safeHavenScore -= 15; signals.push('Altın düşüyor — Risk iştahı açılıyor'); }

  // JPY güçlenmesi
  if (jpyChange >= 1.0)        { safeHavenScore += 20; signals.push(`JPY +${jpyChange.toFixed(2)}% — Safe haven talebi`); }
  else if (jpyChange >= 0.3)   { safeHavenScore += 10; }

  // CHF güçlenmesi
  if (chfChange >= 0.8)        { safeHavenScore += 15; signals.push(`CHF güçleniyor — Risk-off`); }

  // VIX
  if (vixLevel >= 30)          { safeHavenScore += 20; signals.push(`VIX ${vixLevel} — Korku yüksek`); }
  else if (vixLevel <= 15)     { safeHavenScore -= 10; }

  safeHavenScore = clamp(safeHavenScore);

  // Safe haven yüksekse kripto için olumsuz
  const cryptoImpact = clamp(100 - safeHavenScore);

  return {
    score:         cryptoImpact, // Kripto için pozitif etki skoru
    safeHavenScore,
    riskOff:       safeHavenScore >= 60,
    riskOn:        safeHavenScore <= 30,
    signals,
    summary:       signals[0] || `Safe Haven: ${safeHavenScore >= 60 ? 'Risk-OFF' : safeHavenScore <= 30 ? 'Risk-ON' : 'Nötr'}`,
    timestamp:     new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// 2. INFLATION HEDGE ENGINE
// ════════════════════════════════════════════════════════════════════════════════
/**
 * Enflasyon koruması talebi: Altın + BTC + Petrol bir arada yükseliyorsa
 * enflasyon beklentisi güçlü demektir → Kripto için orta-uzun vadeli pozitif
 */
export function runInflationHedgeEngine({
  cpiYoY       = 3.0,  // CPI yıllık %
  goldChange7d = 0,
  btcChange7d  = 0,
  oilChange7d  = 0,
  breakeven10y = 2.5,  // 10y enflasyon break-even
} = {}) {

  let   score   = 50;
  const signals = [];

  // Yüksek enflasyon = hedge talebi = altın+kripto destekli
  if (cpiYoY >= 5)           { score += 15; signals.push(`CPI %${cpiYoY} — Yüksek enflasyon, hedge talebi`); }
  else if (cpiYoY >= 3)      { score += 8; }
  else if (cpiYoY <= 1.5)    { score -= 10; signals.push(`CPI %${cpiYoY} — Düşük enflasyon, hedge gerek yok`); }

  // Break-even
  if (breakeven10y >= 3.0)   { score += 12; signals.push(`10Y break-even %${breakeven10y} — Enflasyon beklentisi yüksek`); }
  else if (breakeven10y < 2) { score -= 8; }

  // Hedge varlıkları aynı yönde mi?
  const hedgeConsensus = (goldChange7d > 0 ? 1 : 0) + (btcChange7d > 0 ? 1 : 0) + (oilChange7d > 0 ? 1 : 0);
  if (hedgeConsensus >= 3)   { score += 10; signals.push('Tüm hedge varlıkları yükseliyor — Enflasyon beklentisi güçlü'); }
  else if (hedgeConsensus === 0) { score -= 8; }

  return {
    score:          clamp(score),
    cpiYoY,
    breakeven10y,
    hedgeConsensus,
    inflationHigh:  cpiYoY >= 4,
    signals,
    summary:        signals[0] || `Enflasyon Hedge: CPI=%${cpiYoY}, BE=${breakeven10y}%`,
    timestamp:      new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// 3. PRECIOUS METAL MOMENTUM ENGINE
// ════════════════════════════════════════════════════════════════════════════════
/**
 * Altın ve gümüş momentum analizi.
 * Altın/Gümüş oranı değişimi = piyasa risk algısı
 */
export function runPreciousMetalMomentumEngine({
  goldPrice    = 2000, goldChange1d = 0, goldChange7d = 0,
  silverPrice  = 25,   silverChange1d = 0,
  goldSilverRatio = null, // null ise hesapla
} = {}) {

  const gsRatio   = goldSilverRatio ?? (silverPrice ? goldPrice / silverPrice : 80);
  let   score     = 50;
  const signals   = [];

  // Altın momentumu
  if (goldChange1d >= 1.5)      { score += 18; signals.push(`Altın +${goldChange1d.toFixed(2)}% güçlü — Risk-off/Enflasyon`); }
  else if (goldChange1d >= 0.5) { score += 8; }
  else if (goldChange1d <= -1.5){ score -= 15; signals.push(`Altın ${goldChange1d.toFixed(2)}% — Risk-on, kripto için pozitif`); }

  // Haftalık trend
  if (goldChange7d >= 3)        { score += 12; signals.push(`Altın haftalık +${goldChange7d.toFixed(1)}% güçlü trend`); }
  else if (goldChange7d <= -3)  { score -= 10; }

  // Altın/Gümüş oranı
  // Düşük oran = gümüş güçlü = risk iştahı (spekülatif metal)
  if (gsRatio <= 70)            { score += 10; signals.push(`G/G oranı ${gsRatio.toFixed(0)} — Gümüş güçlü, risk iştahı var`); }
  else if (gsRatio >= 90)       { score -= 8; signals.push(`G/G oranı ${gsRatio.toFixed(0)} — Gümüş zayıf, risk-off`); }

  score = clamp(score);

  // Kripto korelasyonu: Altın yükselişi genelde kripto ile paralel (enflasyon hedge)
  const cryptoCorr = goldChange1d >= 0 ? 0.4 : -0.2;

  return {
    score,
    goldPrice, goldChange1d, goldChange7d,
    silverPrice, silverChange1d,
    goldSilverRatio: parseFloat(gsRatio.toFixed(2)),
    cryptoCorr,
    signals,
    summary: signals[0] || `Altın: $${goldPrice} (${goldChange1d >= 0 ? '+' : ''}${goldChange1d.toFixed(2)}%)`,
    timestamp: new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// 4. CENTRAL BANK GOLD FLOW
// ════════════════════════════════════════════════════════════════════════════════
/**
 * Merkez bankalarının altın rezerv değişimi.
 * Net alım = uzun vadeli güvenli liman talebi = altın bullish
 */
export function runCentralBankGoldFlow({
  netPurchasesTonnes = 0,  // Son çeyrek net alım (ton)
  largestBuyers     = [],  // ['Çin', 'Hindistan', 'Türkiye']
  reserveChangePct  = 0,   // Global rezerv % değişim
} = {}) {

  let   score   = 50;
  const signals = [];

  if (netPurchasesTonnes >= 200)      { score += 25; signals.push(`MB ${netPurchasesTonnes}t altın aldı — Güçlü talep`); }
  else if (netPurchasesTonnes >= 100) { score += 15; signals.push(`MB ${netPurchasesTonnes}t altın alımı`); }
  else if (netPurchasesTonnes <= -50) { score -= 15; signals.push('Merkez bankası altın satıyor'); }

  if (reserveChangePct >= 2)          { score += 10; }
  if (largestBuyers.includes('Çin'))  { score += 8; signals.push('Çin altın alımı — Dolar rezerv azaltma'); }

  return {
    score:      clamp(score),
    netPurchasesTonnes,
    largestBuyers,
    reserveChangePct,
    bullish:    netPurchasesTonnes >= 100,
    signals,
    summary:    signals[0] || `MB altın akışı: ${netPurchasesTonnes >= 0 ? '+' : ''}${netPurchasesTonnes}t`,
    timestamp:  new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// 5. OIL SUPPLY SHOCK ENGINE
// ════════════════════════════════════════════════════════════════════════════════
/**
 * Petrol arz şokları: Jeopolitik, OPEC kararı, üretim kesintisi
 * Petrol fiyatı yüksekse = enflasyon = kripto karma etki
 */
export function runOilSupplyShockEngine({
  wtiPrice         = 80,
  wtiChange1d      = 0,
  wtiChange7d      = 0,
  supplyDisruption = false, // Arz kesintisi var mı?
  opecCutAnnounced = false,
  strategicReserveRelease = false,
} = {}) {

  let   score   = 50;
  const signals = [];

  // Ani yükseliş = arz şoku
  if (wtiChange1d >= 3)        { score -= 15; signals.push(`Petrol +${wtiChange1d.toFixed(1)}% — Enerji enflasyonu riski`); }
  else if (wtiChange1d >= 1.5) { score -= 8; }
  else if (wtiChange1d <= -3)  { score += 12; signals.push(`Petrol ${wtiChange1d.toFixed(1)}% — Enflasyon baskısı azalıyor`); }
  else if (wtiChange1d <= -1.5){ score += 6; }

  // Arz olayları
  if (supplyDisruption) { score -= 20; signals.push('⚠️ Arz kesintisi — Petrol volatilite yüksek'); }
  if (opecCutAnnounced) { score -= 12; signals.push('OPEC üretim kesinti kararı — Fiyat baskısı'); }
  if (strategicReserveRelease) { score += 10; signals.push('Stratejik rezerv salındı — Arz arttı'); }

  // Yüksek petrol fiyatı (>100) = enflasyon = FED sıkışma = kripto baskı
  if (wtiPrice >= 100)         { score -= 10; signals.push(`WTI $${wtiPrice} — Kritik seviye, enflasyon baskısı`); }
  else if (wtiPrice <= 60)     { score += 8; signals.push(`WTI $${wtiPrice} — Düşük enerji maliyeti, pozitif`); }

  return {
    score:      clamp(score),
    wtiPrice, wtiChange1d, wtiChange7d,
    supplyShock: supplyDisruption || opecCutAnnounced,
    signals,
    summary:    signals[0] || `Petrol: $${wtiPrice} (${wtiChange1d >= 0 ? '+' : ''}${wtiChange1d.toFixed(1)}%)`,
    timestamp:  new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// 6. ENERGY DEMAND ANALYZER + OPEC POLICY + ENERGY VOLATILITY
// ════════════════════════════════════════════════════════════════════════════════
export function runEnergyDemandAnalyzer({
  globalGDPGrowth  = 2.5,  // %
  chinaManufPMI    = 50,
  usIndustrialProd = 0,    // % değişim
  natGasChange     = 0,
} = {}) {

  let score = 50;
  if (globalGDPGrowth >= 3.5)  { score += 15; }
  else if (globalGDPGrowth < 1){ score -= 15; }
  if (chinaManufPMI >= 52)     { score += 10; }
  else if (chinaManufPMI < 48) { score -= 10; }
  if (usIndustrialProd >= 2)   { score += 8; }

  return {
    score: clamp(score),
    globalGDPGrowth, chinaManufPMI,
    demandStrong: score >= 60,
    summary: `Enerji talebi: ${score >= 60 ? 'Güçlü' : score <= 40 ? 'Zayıf' : 'Normal'} (GDP:%${globalGDPGrowth})`,
    timestamp: new Date().toISOString(),
  };
}

export function runOPECPolicyEngine({
  opecProductionMbd  = 28,   // Günlük üretim (milyon varil)
  productionChangeMbd = 0,   // Değişim
  meetingScheduled   = false,
  expectedDecision   = 'HOLD', // 'CUT' | 'INCREASE' | 'HOLD'
} = {}) {

  let score = 50;
  const signals = [];

  if (expectedDecision === 'CUT')      { score -= 15; signals.push('OPEC üretim kesinti kararı bekleniyor — Fiyat yükselir'); }
  else if (expectedDecision === 'INCREASE') { score += 12; signals.push('OPEC üretim artışı — Fiyat baskısı azalır'); }
  if (meetingScheduled)                { signals.push('⚠️ OPEC toplantısı yakın — Volatilite bekleniyor'); }
  if (productionChangeMbd < -0.5)      { score -= 10; }
  else if (productionChangeMbd > 0.5)  { score += 8; }

  return {
    score: clamp(score),
    opecProductionMbd, expectedDecision, meetingScheduled,
    signals,
    summary: signals[0] || `OPEC: ${opecProductionMbd}M varil/gün, Karar: ${expectedDecision}`,
    timestamp: new Date().toISOString(),
  };
}

export function runEnergyVolatilityEngine({ oilVol30d = 20, natGasVol30d = 25, energyVIX = 20 } = {}) {
  const avgVol = (oilVol30d + natGasVol30d + energyVIX) / 3;
  let score    = 50;
  if (avgVol >= 35)      { score -= 20; }
  else if (avgVol >= 25) { score -= 10; }
  else if (avgVol <= 15) { score += 10; }

  return {
    score:        clamp(score),
    oilVol30d, natGasVol30d, energyVIX,
    avgVolatility: parseFloat(avgVol.toFixed(1)),
    highVol:       avgVol >= 30,
    summary:       `Enerji volatilitesi: ${avgVol.toFixed(1)} (${avgVol >= 30 ? 'Yüksek' : 'Normal'})`,
    timestamp:     new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// 7. COMMODITY LIQUIDITY ENGINE + MACRO PRESSURE ANALYZER
// ════════════════════════════════════════════════════════════════════════════════
export function runCommodityLiquidityEngine({
  goldVolume30dAvg = 100, goldVolumeToday = 100,
  oilOpenInterest  = 500000, oiChange = 0,
} = {}) {
  const goldVolSpike = goldVolumeToday > goldVolume30dAvg * 1.5;
  let   score        = 50;
  if (goldVolSpike)      { score += 15; }
  if (oiChange >= 5)     { score += 10; }
  else if (oiChange <= -5){ score -= 10; }
  return {
    score: clamp(score),
    goldVolSpike, oiChange,
    summary: `Emtia likidite: ${goldVolSpike ? 'Hacim patlaması' : 'Normal'}`,
    timestamp: new Date().toISOString(),
  };
}

export function runCommodityMacroPressureAnalyzer({
  realRates = 0,    // Reel faiz (nominal - enflasyon)
  dxyChange = 0,
  riskAppetite = 50,
} = {}) {
  let score = 50;
  const signals = [];
  // Negatif reel faiz = altın + kripto için pozitif
  if (realRates <= -1)       { score += 20; signals.push(`Reel faiz ${realRates}% — Negatif, altın/kripto destekli`); }
  else if (realRates >= 2)   { score -= 15; signals.push(`Reel faiz %${realRates} — Yüksek, emtia baskı altında`); }
  if (dxyChange >= 0.5)      { score -= 10; }
  else if (dxyChange <= -0.5){ score += 10; }
  score += (riskAppetite - 50) * 0.2;
  return {
    score: clamp(score),
    realRates, dxyChange,
    signals,
    summary: signals[0] || `Makro baskı: Reel faiz ${realRates}%`,
    timestamp: new Date().toISOString(),
  };
}

// ════════════════════════════════════════════════════════════════════════════════
// ANA COMMODITY ENGINE
// ════════════════════════════════════════════════════════════════════════════════
export async function runCommodityEngine(params = {}) {
  const {
    gold = {}, oil = {}, energy = {}, opec = {},
    safeHaven = {}, inflation = {}, cbGold = {}, macro = {},
  } = params;

  const safeHavenR = runSafeHavenFlowEngine(safeHaven);
  const inflationR = runInflationHedgeEngine(inflation);
  const metalR     = runPreciousMetalMomentumEngine(gold);
  const cbGoldR    = runCentralBankGoldFlow(cbGold);
  const oilR       = runOilSupplyShockEngine(oil);
  const energyDR   = runEnergyDemandAnalyzer(energy);
  const opecR      = runOPECPolicyEngine(opec);
  const energyVolR = runEnergyVolatilityEngine(energy);
  const liqR       = runCommodityLiquidityEngine(gold);
  const macroR     = runCommodityMacroPressureAnalyzer(macro);

  const score = clamp(
    safeHavenR.score * 0.15 +
    inflationR.score * 0.15 +
    metalR.score     * 0.15 +
    cbGoldR.score    * 0.10 +
    oilR.score       * 0.15 +
    macroR.score     * 0.15 +
    energyVolR.score * 0.05 +
    opecR.score      * 0.10
  );

  const topSignal = safeHavenR.signals[0] || metalR.signals[0] || oilR.signals[0] || inflationR.signals[0];

  return {
    score:      parseFloat(score.toFixed(1)),
    modules: {
      safeHaven: safeHavenR, inflation: inflationR, metal: metalR,
      cbGold: cbGoldR, oil: oilR, energyDemand: energyDR,
      opec: opecR, energyVol: energyVolR, liquidity: liqR, macro: macroR,
    },
    topSignal:  topSignal || 'Emtia: Normal',
    verdict:    score >= 60 ? 'EMTİA POZİTİF' : score <= 40 ? 'EMTİA NEGATİF' : 'NÖTR',
    summary:    `${score >= 60 ? 'EMTİA POZİTİF' : score <= 40 ? 'EMTİA NEGATİF' : 'NÖTR'} (${score.toFixed(0)}/100)`,
    timestamp:  new Date().toISOString(),
  };
}
