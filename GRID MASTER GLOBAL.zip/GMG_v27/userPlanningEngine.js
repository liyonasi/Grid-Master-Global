/**
 * userPlanningEngine.js — GMG v16
 * Kullanıcıya Özel Planlama:
 *   169-172. Scalp Engine (Long/Short/Trap)
 *   173-174. Accumulation Engine & Selector
 *   175-176. Entry/Exit Zone Engine
 *   177. TP/SL Engine (gelişmiş)
 *   178. Micro Risk Engine
 *   219. User Profile Engine
 *   220. Risk Mode Selector
 */

const clamp = (v, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, v));

// ─── USER PROFILE ENGINE ──────────────────────────────────────────────────────
const _defaultProfile = {
  riskMode:       'normal',       // conservative | normal | aggressive
  capital:        10000,          // başlangıç sermayesi
  maxPositionPct: 10,             // maksimum pozisyon yüzdesi
  maxDailyLoss:   5,              // günlük maksimum kayıp %
  preferredAssets: ['BTC', 'ETH'],
  notifications:  { telegram: false, webPush: false, email: false },
  language:       'tr',
  theme:          'dark',
};

let _userProfile = { ..._defaultProfile };

export const UserProfileEngine = {
  get: () => ({ ..._userProfile }),
  set: (updates) => { _userProfile = { ..._userProfile, ...updates }; return _userProfile; },
  reset: () => { _userProfile = { ..._defaultProfile }; },
  getRiskMultiplier() {
    return { conservative: 0.5, normal: 1.0, aggressive: 1.5 }[_userProfile.riskMode] || 1.0;
  },
  getMaxPositionSize(capital = null) {
    const cap = capital || _userProfile.capital;
    const pct = _userProfile.maxPositionPct * this.getRiskMultiplier();
    return parseFloat((cap * pct / 100).toFixed(2));
  },
  isAssetAllowed: (symbol) => _userProfile.preferredAssets.includes(symbol) || _userProfile.preferredAssets.includes('ALL'),
};

// ─── RISK MODE SELECTOR ───────────────────────────────────────────────────────
export const RiskModeSelector = {
  modes: {
    conservative: {
      label: 'Temkinli',
      maxRisk: 1,           // %1 risk per trade
      tpMultiplier: 1.5,
      slMultiplier: 1.0,
      minConfidence: 75,    // minimum güven skoru
      minScore: 65,         // minimum master skor
      description: 'Küçük yatırımcı koruması — sadece çok güçlü sinyaller',
    },
    normal: {
      label: 'Normal',
      maxRisk: 2,
      tpMultiplier: 2.0,
      slMultiplier: 1.0,
      minConfidence: 60,
      minScore: 55,
      description: 'Dengeli risk/kazanç',
    },
    aggressive: {
      label: 'Agresif',
      maxRisk: 5,
      tpMultiplier: 3.0,
      slMultiplier: 1.5,
      minConfidence: 45,
      minScore: 45,
      description: 'Yüksek kazanç potansiyeli, yüksek risk',
    },
  },
  get: (mode = 'normal') => RiskModeSelector.modes[mode] || RiskModeSelector.modes.normal,
  isSignalValid: (mode, masterScore, confidence) => {
    const m = RiskModeSelector.get(mode);
    return masterScore >= m.minScore && confidence >= m.minConfidence;
  },
};

// ─── SCALP ENGINE ─────────────────────────────────────────────────────────────
export function runScalpEngine({
  klines = [],
  rsi = 50,
  macdHistogram = 0,
  bbPosition = 50,
  adx = 25,
  volume = 0,
  avgVolume = 0,
  masterScore = 50,
  userMode = 'normal',
} = {}) {
  const modeParams = RiskModeSelector.get(userMode);

  // Scalp kriterleri (kısa vadeli, 5m-15m)
  const longConditions = {
    rsiOversold:    rsi < 42,
    macdBullish:    macdHistogram > 0,
    bbLow:          bbPosition < 35,
    volumeConfirm:  avgVolume > 0 && volume > avgVolume * 1.3,
    adxTrend:       adx > 20,
  };
  const shortConditions = {
    rsiOverbought: rsi > 62,
    macdBearish:   macdHistogram < 0,
    bbHigh:        bbPosition > 68,
    volumeConfirm: avgVolume > 0 && volume > avgVolume * 1.3,
    adxTrend:      adx > 20,
  };

  const longMet  = Object.values(longConditions).filter(Boolean).length;
  const shortMet = Object.values(shortConditions).filter(Boolean).length;

  const longScore  = clamp(longMet  / 5 * 80 + (masterScore - 50) * 0.4);
  const shortScore = clamp(shortMet / 5 * 80 + (50 - masterScore) * 0.4);

  return {
    longSignal:  longScore >= 55,
    shortSignal: shortScore >= 55,
    longScore:   parseFloat(longScore.toFixed(1)),
    shortScore:  parseFloat(shortScore.toFixed(1)),
    longConditions,
    shortConditions,
    recommendation: longScore > shortScore && longScore >= 55
      ? 'SCALP LONG'
      : shortScore > longScore && shortScore >= 55
      ? 'SCALP SHORT'
      : 'WAIT',
    timestamp: Date.now(),
  };
}

// ─── SCALP LONG ENGINE ────────────────────────────────────────────────────────
export function runScalpLongEngine(params = {}) {
  const base = runScalpEngine(params);
  if (!base.longSignal) return { signal: false, score: base.longScore, reason: 'Koşullar sağlanmadı' };

  return {
    signal:  true,
    score:   base.longScore,
    type:    'SCALP_LONG',
    reason:  'RSI düşük + MACD pozitif + BB alt bant',
    conditions: base.longConditions,
    timestamp: Date.now(),
  };
}

// ─── SCALP SHORT ENGINE ───────────────────────────────────────────────────────
export function runScalpShortEngine(params = {}) {
  const base = runScalpEngine(params);
  if (!base.shortSignal) return { signal: false, score: base.shortScore, reason: 'Koşullar sağlanmadı' };

  return {
    signal:  true,
    score:   base.shortScore,
    type:    'SCALP_SHORT',
    reason:  'RSI yüksek + MACD negatif + BB üst bant',
    conditions: base.shortConditions,
    timestamp: Date.now(),
  };
}

// ─── SCALP TRAP ENGINE ────────────────────────────────────────────────────────
export function runScalpTrapEngine({ stopHuntScore = 0, fakeBreakoutScore = 0, hftScore = 0, masterScore = 50 }) {
  const trapRisk = (stopHuntScore * 0.4 + fakeBreakoutScore * 0.35 + hftScore * 0.25);
  const isTrap   = trapRisk >= 50;

  return {
    isTrap,
    trapRisk:         parseFloat(trapRisk.toFixed(1)),
    stopHuntRisk:     stopHuntScore >= 50,
    fakeBreakout:     fakeBreakoutScore >= 55,
    hftActive:        hftScore >= 50,
    recommendation:   isTrap ? 'SCALP YAPMA — Tuzak riski var' : 'Scalp yapılabilir',
    timestamp: Date.now(),
  };
}

// ─── ACCUMULATION ENGINE ──────────────────────────────────────────────────────
export function runAccumulationEngine({
  klines = [],
  rsi = 50,
  bbPosition = 50,
  price = 0,
  supportLevels = [],
  dipConfirmScore = 0,
  timeHorizon = 'medium',  // short | medium | long
  capital = 10000,
  userMode = 'normal',
} = {}) {
  const modeParams = RiskModeSelector.get(userMode);

  // Birikim koşulları
  const isOversold     = rsi < 45;
  const isNearSupport  = supportLevels.some(s => Math.abs(price - s) / price < 0.02);
  const isBBLow        = bbPosition < 40;
  const dipConfirmed   = dipConfirmScore >= 50;

  const accumulationScore = clamp(
    (isOversold ? 25 : 0) +
    (isNearSupport ? 25 : 0) +
    (isBBLow ? 20 : 0) +
    (dipConfirmed ? 30 : 0)
  );

  // Plan: 3 farklı fiyat seviyesinde birikim
  const zones = price > 0 ? [
    { zone: 1, price: parseFloat((price * 0.98).toFixed(2)), pct: 30, label: 'İlk giriş' },
    { zone: 2, price: parseFloat((price * 0.95).toFixed(2)), pct: 40, label: 'Ana giriş' },
    { zone: 3, price: parseFloat((price * 0.90).toFixed(2)), pct: 30, label: 'Dip giriş' },
  ] : [];

  const positionSize = (capital * modeParams.maxRisk / 100);

  return {
    score: accumulationScore,
    recommended: accumulationScore >= 55,
    isOversold,
    isNearSupport,
    isBBLow,
    dipConfirmed,
    zones,
    totalPositionSize: parseFloat(positionSize.toFixed(2)),
    zoneAllocations: zones.map(z => ({ ...z, amount: parseFloat((positionSize * z.pct / 100).toFixed(2)) })),
    verdict: accumulationScore >= 70 ? 'BİRİKTİRME VAKTİ — Güçlü dip koşulları' : accumulationScore >= 55 ? 'Kademeli birikim yapılabilir' : 'Henüz erken',
    timestamp: Date.now(),
  };
}

// ─── ENTRY ZONE ENGINE ────────────────────────────────────────────────────────
export function runEntryZoneEngine({
  price = 0,
  atr = 0,
  supportLevels = [],
  bbLower = 0,
  rsi = 50,
  signalType = 'BUY',
} = {}) {
  if (!price || !atr) return { zones: [], recommended: null };

  const zones = [];

  // Agresif giriş (şu an)
  zones.push({
    type: 'AGGRESSIVE',
    price: parseFloat(price.toFixed(2)),
    quality: rsi < 45 ? 'İYİ' : rsi < 55 ? 'ORTA' : 'ZAYIF',
    description: 'Şu anki fiyattan giriş',
  });

  // BB alt bandı girişi
  if (bbLower && bbLower < price) {
    zones.push({
      type: 'BB_LOWER',
      price: parseFloat(bbLower.toFixed(2)),
      quality: 'İYİ',
      description: 'Bollinger alt bandı girişi',
    });
  }

  // ATR bazlı geri çekilme girişi
  zones.push({
    type: 'PULLBACK',
    price: parseFloat((price - atr * 0.5).toFixed(2)),
    quality: 'MÜKEMMEL',
    description: `ATR çekilmesi: ${(atr * 0.5).toFixed(0)} $ geri`,
  });

  // En yakın destek
  const nearestSupport = supportLevels.filter(s => s < price).sort((a, b) => b - a)[0];
  if (nearestSupport) {
    zones.push({
      type: 'SUPPORT',
      price: parseFloat(nearestSupport.toFixed(2)),
      quality: 'MÜKEMMEL',
      description: 'Destek seviyesinden giriş',
    });
  }

  const recommended = zones.find(z => z.quality === 'MÜKEMMEL') || zones[0];

  return {
    zones: zones.sort((a, b) => a.price - b.price),
    recommended,
    currentPrice: price,
    signalType,
    timestamp: Date.now(),
  };
}

// ─── EXIT ZONE ENGINE ─────────────────────────────────────────────────────────
export function runExitZoneEngine({
  entryPrice = 0,
  atr = 0,
  resistanceLevels = [],
  bbUpper = 0,
  rsiTarget = 65,
  direction = 'LONG',
} = {}) {
  if (!entryPrice || !atr) return { tp1: null, tp2: null, sl: null };

  const isLong = direction === 'LONG';

  const tp1 = isLong ? entryPrice + atr * 1.0 : entryPrice - atr * 1.0;
  const tp2 = isLong ? entryPrice + atr * 2.2 : entryPrice - atr * 2.2;
  const tp3 = isLong ? entryPrice + atr * 3.5 : entryPrice - atr * 3.5;
  const sl  = isLong ? entryPrice - atr * 1.0 : entryPrice + atr * 1.0;

  // BB üst bant ile karşılaştır
  const tp2Adjusted = bbUpper && isLong && bbUpper < tp2 ? bbUpper : tp2;

  // Direnç seviyeleri
  const nearResistance = resistanceLevels.filter(r => r > entryPrice).sort((a, b) => a - b)[0];
  const tp1Adjusted = nearResistance && isLong && nearResistance < tp1 * 1.005 ? nearResistance * 0.999 : tp1;

  const rr1 = Math.abs(tp1Adjusted - entryPrice) / Math.abs(sl - entryPrice);
  const rr2 = Math.abs(tp2Adjusted - entryPrice) / Math.abs(sl - entryPrice);

  return {
    tp1:  parseFloat(tp1Adjusted.toFixed(2)),
    tp2:  parseFloat(tp2Adjusted.toFixed(2)),
    tp3:  parseFloat(tp3.toFixed(2)),
    sl:   parseFloat(sl.toFixed(2)),
    rr1:  parseFloat(rr1.toFixed(2)),
    rr2:  parseFloat(rr2.toFixed(2)),
    rrOk: rr1 >= 1.5,
    direction,
    verdict: rr1 >= 2 ? `✅ Risk/Ödül mükemmel: 1:${rr1.toFixed(1)}` : rr1 >= 1.5 ? `✓ Risk/Ödül kabul edilir: 1:${rr1.toFixed(1)}` : `⚠ Risk/Ödül zayıf: 1:${rr1.toFixed(1)} — giriş yapma`,
    timestamp: Date.now(),
  };
}

// ─── MICRO RISK ENGINE ────────────────────────────────────────────────────────
export function runMicroRiskEngine({
  capital = 10000,
  riskPct = 2,       // sermayenin yüzdesi
  entryPrice = 0,
  stopLoss = 0,
  userMode = 'normal',
  leverage = 1,
} = {}) {
  const modeParams = RiskModeSelector.get(userMode);
  const adjustedRisk = Math.min(riskPct, modeParams.maxRisk);

  const riskAmount    = capital * adjustedRisk / 100;
  const stopDistance  = entryPrice > 0 && stopLoss > 0 ? Math.abs(entryPrice - stopLoss) : 0;
  const stopDistPct   = entryPrice > 0 && stopDistance > 0 ? stopDistance / entryPrice * 100 : 0;
  const positionSize  = stopDistPct > 0 ? (riskAmount / (stopDistPct / 100)) : 0;
  const leveragedSize = positionSize * leverage;
  const maxSafe       = capital * 0.3; // Maksimum pozisyon: sermayenin %30'u

  const isOversized   = leveragedSize > maxSafe;
  const recommendation = isOversized
    ? parseFloat((maxSafe / entryPrice).toFixed(6))
    : parseFloat((positionSize / entryPrice).toFixed(6));

  return {
    riskAmount:      parseFloat(riskAmount.toFixed(2)),
    positionSize:    parseFloat(positionSize.toFixed(2)),
    units:           recommendation,
    stopDistance:    parseFloat(stopDistance.toFixed(2)),
    stopDistPct:     parseFloat(stopDistPct.toFixed(3)),
    isOversized,
    maxSafePosition: parseFloat(maxSafe.toFixed(2)),
    leverage,
    verdict: isOversized
      ? `⚠ Pozisyon çok büyük — ${adjustedRisk}% risk ile maksimum $${maxSafe.toFixed(0)}`
      : `✅ Uygun boyut: $${positionSize.toFixed(0)} (${adjustedRisk}% risk = $${riskAmount.toFixed(0)})`,
    riskReward: stopDistPct > 0
      ? `SL: %${stopDistPct.toFixed(2)} · Risk: $${riskAmount.toFixed(0)}`
      : 'SL belirsiz',
    timestamp: Date.now(),
  };
}
