# GMG — DEVİR TESLİM v28
## Tarih: 2026-03-26 | 96 dosya | ~30.812 satır | 478 export
## URL: http://46.224.185.115:8014/

---

## YENİ OTURUMA BAŞLARKEN

1. ZIP yükle: GMG_FULL_BACKUP_v28.zip
2. Yaz: "DEVIR_TESLIM_v28.md oku, kaldığın yerden devam et"

---

## PROJE DURUMU — GENEL

GMG production-ready trading dashboard.
React + Canvas + WebSocket frontend.
96 JS/JSX modül, 478 export fonksiyon.

Deploy: ZIP içindeki dosyalar → src/components/grid-master/
Ana sayfa: Dashboard_v4.jsx

---

## TÜM DOSYALAR VE SATIR SAYILARI

### JSX PANELLERİ (14 dosya)

| Dosya | Satır | İçerik | Durum |
|---|---|---|---|
| GMGChart_v3.jsx | 1448 | Pine grafik, 7 borsa, 7 osilatör, Pine çizgileri | ✅ Tam |
| Dashboard_v4.jsx | 1241 | 4 sayfa mimarisi, tüm entegrasyonlar | ✅ Tam |
| BacktestPanel.jsx | 964 | Worker, Optimizer, MultiPeriodChart | ✅ Tam |
| MultiMarketDashboard.jsx | 853 | Forex/Emtia/Endeks/Tahvil/Makro 6 sekme | ✅ Tam |
| ScannerPage.jsx | 712 | 13 tarayıcı aynı anda, Glassnode/CQ rozet | ✅ Tam |
| MarketIntelPanel.jsx | 669 | Tab bazlı intel, ETF, OnChain sekmeleri | ✅ Tam |
| LiveAICouncilPanel.jsx | 543 | 5 konsey + CryptoPanic haberler | ✅ Tam |
| SystemMonitorPanel.jsx | 522 | API Keys, Email, WebPush, sistem sağlık | ✅ Tam |
| FundingPanel.jsx | 432 | Funding/OI/L-S | ✅ Tam |
| LiquidityRadar.jsx | 402 | Likidite radar | ✅ Tam |
| CouncilPanel.jsx | 328 | Konsey oylama | ✅ Tam |
| DipOnayPanel.jsx | 256 | Dip onay sonuçları | ✅ Tam |
| ForexAndMultiMarketPanels.jsx | 222 | Forex + MultiMarket | ✅ Tam |
| WallAndAccumulationPanels.jsx | 192 | Duvar + birikim | ✅ Tam |
| MultiTimeframePanel.jsx | 271 | 6 zaman dilimi özet | ✅ Tam |
| TrapScoreModal.jsx | ~150 | TrapScore detay modal | ✅ Tam |

### JS ENGINElar (54+ dosya)

| Dosya | Satır | İçerik |
|---|---|---|
| missingModules.js | 1048 | 18 modül: Keltner/Supertrend/Panic/OPEC/VIX/Contagion... |
| dipOnaylayici.js | 802 | 8 katman dip onay |
| masterCouncil.js | 718 | ANA GİRİŞ — runMasterCouncil(), glassnodeKey/cqKey |
| pineEngine.js | 596 | Pine Script v6 port + runPineOptimizer() |
| newsSentimentAlertExt.js | 546 | CryptoPanic + sentiment |
| aiCouncilEngine.js | 542 | AI skor + konsey |
| executionLayer.js | 539 | Veto + 8 filtre + trapScore |
| exchangeAPI_multi.js | 528 | 7 borsa fallback |
| intelligenceEngine.js | 520 | 16 tarayıcı, 19 export |
| forexEngine.js | 508 | DXY/Carry/Session/CentralBank |
| technicalExtEngine.js | 507 | Gelişmiş teknik |
| alertMonitorEngines.js | 481 | Telegram + EmailJS + WebPush |
| councilEngine.js | 464 | 5 konsey |
| chartModule.js | 458 | Pattern recognition |
| macroAPIEngine.js | 451 | DXY/VIX/Gold/Oil/Fear — gerçek API |
| councilAdvancedEngine.js | 443 | CouncilMemory + Specialist |
| liquiditySpecialEngines.js | 436 | Glassnode/CQ entegrasyon, glassnodeKey/cqApiKey |
| technicalAdvancedEngine.js | 421 | Trend/Candle/Gap/Fractal |
| bondMacroEngine.js | 424 | Yield curve/Fed/Bond |
| commodityEngine.js | 419 | Emtia motorları |
| macroNewsEngines.js | 404 | Makro haber |
| backtestingEngine.js | 385 | Detaylı backtest |
| multiAssetEngines.js | 384 | Forex/Bond/Squeeze/Wall |
| userPlanningEngine.js | 375 | Scalp/Accumulation/Entry/MicroRisk |
| realDerivativesEngine.js | 372 | OI/Funding/LiqMap canlı |
| trapDetectionEngine.js | 369 | StopHunt/Sweep/HFT/Bait |
| bondMacroAdvancedEngine.js | 361 | YieldCurve/GeoRisk/MacroCalendar |
| engineCore.js | 360 | 16 tarayıcı + 4 konsey |
| intelligenceAdvancedEngine.js | 358 | Whale/SmartMoney/Contagion |
| advancedOnchainEngine.js | 350 | OnChain gelişmiş |
| indexEngine.js | 348 | Endeks motoru |
| newsAdvancedEngine.js | 337 | Haber pipeline |
| alertMonitorEngines.js | 331 | Alert motorları |
| performanceCacheEngine.js | 330 | Cache/perf |
| backtestEngine.js | 183 | Backtest hesaplama |
| backtestWorker.js | 110 | Worker — OPTIMIZE/TEST mesaj tipleri |
| ... | ... | diğer 20+ modül |

---

## DASHBOARD MİMARİSİ (v27 — 4 sayfa)

```
01 — Grafik & Sinyal
     ├── GMGChart (Pine çizgileri, 7 osilatör)
     ├── LiveAICouncilPanel (5 konsey + CryptoPanic)
     ├── Sol: Sinyal/İstihbarat/Forex/Birikim/DipOnay/System sekmeler
     └── Sağ: Council/Backtest/MultiMarket sekmeler

02 — Tarayıcılar (ScannerPage)
     └── 13 tarayıcı aynı anda (BTC'ye Rağmen/Scalp/StopHunt/Pump vb.)

03 — Türev & Akış
     ├── LiquidityRadar
     ├── FundingPanel
     └── BacktestPanel (Worker + Optimizer + MultiPeriodChart)

04 — 🌍 Global Piyasalar (MultiMarketDashboard)
     ├── Genel Bakış (risk sinyal özeti)
     ├── Forex (DXY + 6 parite)
     ├── Emtia (8 varlık: Au/Ag/Pt/WTI/Brent/Gas/Cu/Wheat)
     ├── Endeksler (7: S&P/Nasdaq/Dow/DAX/FTSE/Nikkei/VIX)
     ├── Tahvil (US10Y/US2Y/Spread + SVG eğri)
     └── Makro (Fear/VIX/DXY/Gold gauge + riskMode)
```

---

## v27'DE TAMAMLANAN ÖZETİ

### 1. liquiditySpecialEngines.js
- glassnodeKey + cqApiKey parametresi eklendi
- Glassnode → gerçek netFlow verisi (API key varsa)
- CryptoQuant → gerçek OTC flow (API key varsa)
- Async hale getirildi

### 2. SystemMonitorPanel.jsx
- 🔑 API Keys sekmesi: Glassnode, CryptoQuant, CryptoPanic, Telegram, EmailJS (4 alan), Alıcı Email
- localStorage'a kayıt/yükle
- Göster/gizle, sil, durum rozeti
- onAPIKeysChange(keys) callback → Dashboard'a bağlı

### 3. Dashboard_v4.jsx
- WebPush "🔔 Bildirimleri Aç" butonu topbar'a eklendi
- apiKeys state localStorage'dan başlatılıyor
- glassnodeKey/cqKey → masterCouncil → liquiditySpecialEngines
- Email/WebPush sinyal gönderimi (Telegram ile aynı koşul)

### 4. BacktestPanel.jsx
- Optimizör Worker entegrasyonu (OPTIMIZE mesaj tipi)
- runOptimizer → optimizedPineParams state + runTest otomatik tetik
- MultiPeriodComparisonChart: 4 dönem SVG equity curve
- Sonuç kartında aktif params göstergesi

### 5. pineEngine.js
- runPineOptimizer(klines, {onProgress}) export edildi
- rfPer × rfMult × signalMode grid search, async
- compositeScore = winRate×0.6 + avgPnl×0.4
- Return: {bestParams, topN(5), testedCombos}

### 6. backtestWorker.js
- type:'OPTIMIZE' → runPineOptimizer worker'da çalışır
- OPT_RESULT / OPT_ERROR / PROGRESS mesajları

### 7. alertMonitorEngines.js
- EmailAlertEngine — EmailJS SDK dinamik yükleme
- WebPushEngine — izin yönetimi, requireInteraction (skor≥75)
- Singleton: emailAlerts, webPush

### 8. masterCouncil.js
- glassnodeKey/cqKey parametresi eklendi
- env fallback ikincil
- liquiditySpecialEngines'e aktarılıyor

---

## KRİTİK API REFERANSLARI

### masterCouncil.js — runMasterCouncil() parametreleri
```javascript
await runMasterCouncil({
  candles, I, scanResults, orderbook,
  heatmapData, fundingRates,
  btcChange, vixLevel,        // ← gerçek VIX (fetchAllMacro)
  dxyLevel, us10yYield,
  goldChange, oilChange,      // ← gerçek veriler
  symbol, externalTrapScore,
  glassnodeKey,               // ← API Keys sekmesinden
  cqKey,                      // ← API Keys sekmesinden
  pineParams: { rfPer:100, rfMult:3.0, signalMode:'KLASİK' },
})
// Döner: { action, score, confidence, councils, missingBundle,
//          pineData, advanced, multiAsset, health, probability }
```

### pineEngine.js — runPineOptimizer()
```javascript
const result = await runPineOptimizer(klines, {
  onProgress: (pct, msg) => console.log(pct, msg),
  rfPerRange:  [50, 75, 100, 150],
  rfMultRange: [2.0, 2.5, 3.0, 3.5],
  modes:       ['KLASİK', 'AGGRESSIVE'],
});
// Döner: { bestParams, topN: [...5 en iyi], testedCombos }
```

### alertMonitorEngines.js — Email + WebPush
```javascript
import { emailAlerts, webPush } from './alertMonitorEngines';

// Email gönder
await emailAlerts.send({
  serviceId: keys.emailServiceId,
  templateId: keys.emailTemplateId,
  publicKey:  keys.emailPublicKey,
  toEmail:    keys.emailTo,
  subject:    'GMG Sinyal',
  body:       'BTC: AL — Skor: 78',
});

// WebPush izni + bildirim
await webPush.requestPermission();
await webPush.send({ title: '🟢 GMG AL', body: 'BTC/USDT — 78/100' });
```

### liquiditySpecialEngines.js
```javascript
import { runLiquiditySpecialEngines } from './liquiditySpecialEngines';

const result = await runLiquiditySpecialEngines({
  candles, orderbook, scanResults,
  glassnodeKey: 'your_key',  // → gerçek netFlow
  cqApiKey:     'your_key',  // → gerçek OTC flow
});
```

---

## SONRAKI OTURUMDA YAPILABİLECEKLER

1. **Alert geçmişi UI** — kaç sinyal gönderildi, son Telegram/Email zamanları
2. **WebSocket yeniden bağlanma** — bağlantı kopunca retry sayacı
3. **PWA manifest** — ana ekrana ekle desteği  
4. **Dark/Light tema toggle**
5. **Kullanıcı profili** — favori semboller, risk toleransı localStorage
6. **Ekran eksikleri** — missingBundle sonuçlarını ScannerPage/Dashboard'da göster
   (Supertrend, Keltner, PanicDetector vb.)

---

## API KURULUM TABLOSU

| Servis | URL | Sekme | Not |
|---|---|---|---|
| Glassnode | studio.glassnode.com | 🔑 API Keys | Ücretsiz tier |
| CryptoQuant | cryptoquant.com | 🔑 API Keys | Ücretsiz tier |
| CryptoPanic | cryptopanic.com/api | 🔑 API Keys | Ücretsiz |
| EmailJS | emailjs.com | 🔑 API Keys | 200 email/ay |
| Telegram Bot | @BotFather | 🔑 API Keys | Bot token |
| WebPush | — | Topbar butonu | Tarayıcı izni |

Tüm anahtarlar: Dashboard → System Monitor sekmesi → 🔑 API Keys

---

## KOD YAZIM KURALLARI
1. Tüm fonksiyonlar export edilmeli
2. Türkçe yorum satırları
3. clamp(v, 0, 100) ile 0-100 arası skor
4. Her modül { score, summary, timestamp } döndürür
5. Null-safe (?.) operatör
6. Async/await ile API çağrıları
7. Her oturum sonunda ZIP + devir teslim

---
Son güncelleme: 2026-03-26 | v28
96 dosya | ~30.812 satır | 478 export
