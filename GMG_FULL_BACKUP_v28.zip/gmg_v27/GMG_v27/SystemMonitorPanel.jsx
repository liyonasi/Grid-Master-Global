/**
 * SystemMonitorPanel.jsx
 * =======================
 * LatencyMonitor UI + MacroEventCalendar UI + CrossFeedValidator UI
 * Dashboard ayarlar/sağlık paneli olarak kullanılır.
 *
 * Props:
 *   latencyData    — LatencyMonitor.getAll() çıktısı
 *   macroCalendar  — MacroEventCalendar objesi
 *   crossFeedData  — CrossFeedValidator çıktısı
 *   missingBundle  — masterResult.missingBundle
 *   onAddEvent     — callback(event) yeni makro olay ekle
 */
import React, { useState, useEffect } from 'react';
import { Activity, Clock, Calendar, Shield, Zap, AlertTriangle, CheckCircle } from 'lucide-react';
import { LatencyMonitor, MacroEventCalendar, CrossFeedValidator } from './missingModules';

// ─── LATENCY MONITOR PANEL ────────────────────────────────────────────────────
export function LatencyMonitorPanel({ autoRefresh = true }) {
  const [data, setData]   = useState([]);
  const [summary, setSummary] = useState(null);

  useEffect(() => {
    const refresh = () => {
      setData(LatencyMonitor.getAll());
      setSummary(LatencyMonitor.getSummary());
    };
    refresh();
    if (autoRefresh) {
      const id = setInterval(refresh, 2000);
      return () => clearInterval(id);
    }
  }, [autoRefresh]);

  const statusColor = (s) =>
    s === 'KRİTİK' ? '#ff0055' : s === 'YAVAŞ' ? '#ff8800' : '#00e676';

  return (
    <div style={{ fontFamily: 'monospace', fontSize: 10 }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
        <Activity style={{ width: 11, height: 11, color: '#00aaff' }} />
        <span style={{ fontSize: 11, fontWeight: 700, color: '#00aaff', letterSpacing: 2 }}>
          GECIKME MONİTÖRÜ
        </span>
        {summary && (
          <span style={{
            marginLeft: 'auto', fontSize: 9,
            color: summary.slowCount > 0 ? '#ff8800' : '#00e676',
          }}>
            {summary.slowCount > 0 ? `⚠ ${summary.slowCount} yavaş` : '✓ Normal'} | Ort: {summary.avgOverall}ms
          </span>
        )}
      </div>

      {data.length === 0 ? (
        <div style={{ fontSize: 9, color: '#404070', padding: '8px 0' }}>
          Henüz gecikme verisi yok — API çağrıları başladığında dolacak
        </div>
      ) : (
        <div>
          {data.map((entry, i) => {
            const col   = statusColor(entry.status);
            const barW  = Math.min(100, (entry.avg / 3000) * 100);
            return (
              <div key={i} style={{ marginBottom: 5 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 2 }}>
                  <span style={{ color: '#9090c0', fontSize: 9 }}>{entry.key}</span>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <span style={{ color: col, fontSize: 9 }}>{entry.last}ms</span>
                    <span style={{ color: '#404070', fontSize: 8 }}>ort:{entry.avg}ms</span>
                    <span style={{ color: '#404070', fontSize: 8 }}>max:{entry.max}ms</span>
                    <span style={{
                      fontSize: 8, padding: '0 4px', borderRadius: 2,
                      background: `${col}18`, color: col,
                    }}>{entry.status}</span>
                  </div>
                </div>
                <div style={{ height: 3, background: '#0a0a1c', borderRadius: 2 }}>
                  <div style={{ width: `${barW}%`, height: '100%', background: col + '88', borderRadius: 2, transition: 'width .3s' }} />
                </div>
              </div>
            );
          })}
          <div style={{ marginTop: 6, fontSize: 8, color: '#2a2a4a' }}>
            Eşik: Sarı &gt;1sn · Kırmızı &gt;3sn
          </div>
        </div>
      )}
    </div>
  );
}

// ─── MACRO EVENT CALENDAR PANEL ───────────────────────────────────────────────
export function MacroCalendarPanel({ onRiskScore }) {
  const [events, setEvents]       = useState([]);
  const [newEvent, setNewEvent]   = useState({ name: '', type: 'FED', impact: 0.8, hoursFromNow: 4 });
  const [adding, setAdding]       = useState(false);
  const [riskScore, setRiskScore] = useState(null);
  const [view, setView]           = useState('upcoming'); // 'upcoming' | 'all'

  // Sabit yüksek etkili olay listesi
  const HIGH_IMPACT = MacroEventCalendar.HIGH_IMPACT_EVENTS;

  // İlk yüklemede getAll() + getUpcoming() ile doldur
  useEffect(() => {
    try {
      const known = MacroEventCalendar.getAll?.() || [];
      if (known.length) {
        setEvents(known);
        const upcoming = MacroEventCalendar.getUpcoming?.(168) || known; // 7 gün
        const rs = MacroEventCalendar.getRiskScore(upcoming);
        setRiskScore(rs);
        onRiskScore?.(rs);
      }
    } catch(e) { /* missingModules import hatası — manuel mod */ }
  }, []);

  const updateRisk = (evts) => {
    const upcoming = evts.filter(e => e.time > Date.now() && e.time < Date.now() + 168*3600000);
    const rs = MacroEventCalendar.getRiskScore(upcoming);
    setRiskScore(rs);
    onRiskScore?.(rs);
  };

  // Görünüme göre filtrele
  const displayEvents = view === 'upcoming'
    ? events.filter(e => e.time > Date.now() - 3600000).slice(0, 12)
    : events.slice(0, 30);

  const addEvent = () => {
    const ev = {
      ...newEvent,
      time:       Date.now() + newEvent.hoursFromNow * 3600000,
      cryptoEffect: newEvent.impact >= 0.7 ? 'HIGH' : newEvent.impact >= 0.5 ? 'MEDIUM' : 'LOW',
    };
    const updated = [...events, ev].sort((a, b) => a.time - b.time);
    setEvents(updated);
    updateRisk(updated);
    setAdding(false);
    setNewEvent({ name: '', type: 'FED', impact: 0.8, hoursFromNow: 4 });
  };

  const removeEvent = (i) => {
    const updated = events.filter((_, idx) => idx !== i);
    setEvents(updated);
    updateRisk(updated);
  };

  const hoursUntil = (time) => Math.max(0, Math.round((time - Date.now()) / 3600000));

  const impactColor = (imp) =>
    imp >= 0.7 ? '#ff3366' : imp >= 0.5 ? '#ff8800' : '#ffcc00';

  return (
    <div style={{ fontFamily: 'monospace', fontSize: 10 }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
        <Calendar style={{ width: 11, height: 11, color: '#aa88ff' }} />
        <span style={{ fontSize: 11, fontWeight: 700, color: '#aa88ff', letterSpacing: 2 }}>
          MAKRO TAKVİM
        </span>
        {riskScore && riskScore.score > 0 && (
          <span style={{
            marginLeft: 'auto', fontSize: 9, fontWeight: 700,
            padding: '1px 7px', borderRadius: 3,
            background: riskScore.score >= 60 ? 'rgba(255,0,80,.18)' : 'rgba(255,136,0,.15)',
            color: riskScore.score >= 60 ? '#ff0055' : '#ff8800',
          }}>
            Risk: {riskScore.score}
          </span>
        )}
      </div>

      {/* Risk mesajı */}
      {riskScore?.message && (
        <div style={{ fontSize: 9, color: '#ff8800', marginBottom: 8, padding: '4px 8px', background: 'rgba(255,136,0,.08)', borderRadius: 4, border: '1px solid rgba(255,136,0,.2)' }}>
          {riskScore.message}
        </div>
      )}

      {/* Sabit olay referansı */}
      <div style={{ marginBottom: 8 }}>
        <div style={{ fontSize: 8, color: '#404070', marginBottom: 4, letterSpacing: 1 }}>YÜKSEK ETKİLİ OLAYLAR (REFERANS)</div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 3 }}>
          {HIGH_IMPACT.map((ev, i) => (
            <span key={i} style={{
              fontSize: 8, padding: '1px 5px', borderRadius: 3,
              background: `${impactColor(ev.impact)}15`,
              color: impactColor(ev.impact),
              border: `1px solid ${impactColor(ev.impact)}30`,
              cursor: 'pointer',
            }}
            onClick={() => {
              setNewEvent(prev => ({ ...prev, name: ev.name, type: ev.type, impact: ev.impact }));
              setAdding(true);
            }}>
              {ev.type}
            </span>
          ))}
        </div>
      </div>

      {/* View toggle */}
      <div style={{ display:'flex', gap:3, marginBottom:6 }}>
        {['upcoming','all'].map(v => (
          <button key={v} onClick={() => setView(v)}
            style={{ fontSize:7, padding:'1px 7px', borderRadius:3, cursor:'pointer', fontFamily:'monospace',
              background: view===v ? '#aa88ff20' : 'transparent',
              border: `1px solid ${view===v ? '#aa88ff60' : '#1a1a2e'}`,
              color: view===v ? '#aa88ff' : '#404070' }}>
            {v === 'upcoming' ? '📅 YAKLAŞAN' : '📋 TÜMÜ'}
          </button>
        ))}
        <span style={{ marginLeft:'auto', fontSize:7, color:'#2a2a4a', alignSelf:'center' }}>
          {displayEvents.length} olay
        </span>
      </div>

      {/* Olaylar listesi */}
      {displayEvents.length > 0 && (
        <div style={{ marginBottom: 8 }}>
          <div style={{ fontSize: 8, color: '#404070', marginBottom: 4, letterSpacing: 1 }}>
            {view === 'upcoming' ? 'YAKLAŞAN OLAYLAR (7 GÜN)' : 'TÜM OLAYLAR'}
          </div>
          {displayEvents.map((ev, i) => (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: 6,
              padding: '4px 8px', borderRadius: 4, marginBottom: 3,
              background: '#06060e', border: `1px solid ${impactColor(ev.impact)}25`,
            }}>
              <div style={{ width: 6, height: 6, borderRadius: '50%', background: impactColor(ev.impact), flexShrink: 0 }} />
              <span style={{ flex: 1, fontSize: 9, color: '#9090c0' }}>{ev.name}</span>
              <span style={{ fontSize: 8, color: '#6060a0' }}>{hoursUntil(ev.time)}s sonra</span>
              <span style={{ fontSize: 8, color: ev.cryptoEffect === 'HIGH' ? '#ff3366' : '#ff8800' }}>
                {ev.cryptoEffect}
              </span>
              <button onClick={() => removeEvent(i)} style={{ background: 'none', border: 'none', color: '#303050', cursor: 'pointer', fontSize: 10, padding: 0 }}>✕</button>
            </div>
          ))}
        </div>
      )}

      {/* Olay ekleme formu */}
      {adding ? (
        <div style={{ background: '#06060e', border: '1px solid #1a1a3e', borderRadius: 6, padding: '8px 10px' }}>
          <div style={{ fontSize: 9, color: '#404070', marginBottom: 6 }}>YENİ OLAY EKLE</div>
          <input
            value={newEvent.name}
            onChange={e => setNewEvent(p => ({ ...p, name: e.target.value }))}
            placeholder="Olay adı (ör: FOMC Toplantısı)"
            style={{
              width: '100%', marginBottom: 5, padding: '4px 8px',
              background: '#0a0a18', border: '1px solid #1a1a3e', borderRadius: 3,
              color: '#9090c0', fontSize: 9, fontFamily: 'monospace', boxSizing: 'border-box',
            }}
          />
          <div style={{ display: 'flex', gap: 5, marginBottom: 5 }}>
            <select value={newEvent.type} onChange={e => setNewEvent(p => ({ ...p, type: e.target.value }))}
              style={{ flex: 1, padding: '3px 5px', background: '#0a0a18', border: '1px solid #1a1a3e', borderRadius: 3, color: '#9090c0', fontSize: 9, fontFamily: 'monospace' }}>
              {['FED','CPI','NFP','GDP','PPI','PCE','ECB','BOJ','OTHER'].map(t => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
            <select value={newEvent.impact} onChange={e => setNewEvent(p => ({ ...p, impact: parseFloat(e.target.value) }))}
              style={{ flex: 1, padding: '3px 5px', background: '#0a0a18', border: '1px solid #1a1a3e', borderRadius: 3, color: '#9090c0', fontSize: 9, fontFamily: 'monospace' }}>
              <option value={0.9}>Kritik (0.9)</option>
              <option value={0.7}>Yüksek (0.7)</option>
              <option value={0.5}>Orta (0.5)</option>
              <option value={0.3}>Düşük (0.3)</option>
            </select>
          </div>
          <div style={{ display: 'flex', gap: 5, alignItems: 'center', marginBottom: 6 }}>
            <span style={{ fontSize: 9, color: '#6060a0' }}>{newEvent.hoursFromNow} saat sonra</span>
            <input type="range" min={1} max={48} value={newEvent.hoursFromNow}
              onChange={e => setNewEvent(p => ({ ...p, hoursFromNow: parseInt(e.target.value) }))}
              style={{ flex: 1 }} />
          </div>
          <div style={{ display: 'flex', gap: 5 }}>
            <button onClick={addEvent} style={{ flex: 1, padding: '4px 8px', background: 'rgba(0,170,255,.15)', border: '1px solid rgba(0,170,255,.3)', borderRadius: 3, color: '#00aaff', fontSize: 9, fontFamily: 'monospace', cursor: 'pointer' }}>
              ✓ Ekle
            </button>
            <button onClick={() => setAdding(false)} style={{ padding: '4px 10px', background: 'none', border: '1px solid #1a1a3e', borderRadius: 3, color: '#404070', fontSize: 9, fontFamily: 'monospace', cursor: 'pointer' }}>
              İptal
            </button>
          </div>
        </div>
      ) : (
        <button onClick={() => setAdding(true)} style={{
          width: '100%', padding: '5px', background: 'none',
          border: '1px dashed #1a1a3e', borderRadius: 4,
          color: '#2a2a50', fontSize: 9, fontFamily: 'monospace', cursor: 'pointer',
          transition: 'all .2s',
        }} onMouseEnter={e => e.target.style.color='#6060a0'}
           onMouseLeave={e => e.target.style.color='#2a2a50'}>
          + Olay Ekle
        </button>
      )}
    </div>
  );
}

// ─── CROSS FEED VALIDATOR PANEL ───────────────────────────────────────────────
export function CrossFeedPanel({ prices = {} }) {
  // prices: { binance: 45000, bybit: 45010, okx: 44990 }
  const [result, setResult] = useState(null);

  useEffect(() => {
    if (Object.keys(prices).length < 2) return;
    try {
      const validated = CrossFeedValidator.validateMultiple(prices);
      setResult(validated);
    } catch {}
  }, [prices]);

  if (!result) return (
    <div style={{ fontSize: 9, color: '#404070', fontFamily: 'monospace', padding: '8px 0' }}>
      Çapraz fiyat doğrulama — en az 2 borsa verisi gerekli
    </div>
  );

  return (
    <div style={{ fontFamily: 'monospace', fontSize: 10 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
        <Shield style={{ width: 11, height: 11, color: result.isValid ? '#00e676' : '#ff3366' }} />
        <span style={{ fontSize: 11, fontWeight: 700, color: result.isValid ? '#00e676' : '#ff3366', letterSpacing: 2 }}>
          ÇAPRAZ DOĞRULAMA
        </span>
        <span style={{ marginLeft: 'auto', fontSize: 9, color: result.isValid ? '#00e67688' : '#ff336688' }}>
          {result.isValid ? '✓ Tutarlı' : '✗ Tutarsız'}
        </span>
      </div>

      {Object.entries(prices).map(([exchange, price]) => (
        <div key={exchange} style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #0a0a1c' }}>
          <span style={{ color: '#6060a0', fontSize: 9 }}>{exchange.toUpperCase()}</span>
          <span style={{ color: '#9090c0', fontSize: 9 }}>${typeof price === 'number' ? price.toLocaleString('en', { minimumFractionDigits: 2 }) : price}</span>
        </div>
      ))}

      {result.maxDeviation != null && (
        <div style={{ marginTop: 6, fontSize: 9, color: result.maxDeviation > 0.5 ? '#ff8800' : '#6060a0' }}>
          Maks. sapma: %{(result.maxDeviation || 0).toFixed(3)}
          {result.maxDeviation > 0.5 && ' ⚠ Yüksek'}
        </div>
      )}

      {result.anomalies?.length > 0 && (
        <div style={{ marginTop: 4 }}>
          {result.anomalies.map((a, i) => (
            <div key={i} style={{ fontSize: 9, color: '#ff8800' }}>⚠ {a}</div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── API KEY AYAR PANELİ ──────────────────────────────────────────────────────
function APIKeyPanel({ onKeysChange }) {
  const LS_KEY = 'gmg_api_keys';
  const saved = (() => { try { return JSON.parse(localStorage.getItem(LS_KEY) || '{}'); } catch { return {}; } })();

  const [keys, setKeys] = useState({
    glassnode:       saved.glassnode       || '',
    cryptoquant:     saved.cryptoquant     || '',
    cryptopanic:     saved.cryptopanic     || '',
    telegram_bot:    saved.telegram_bot    || '',
    telegram_chat:   saved.telegram_chat   || '',
    emailjs_service: saved.emailjs_service || '',
    emailjs_template:saved.emailjs_template|| '',
    emailjs_key:     saved.emailjs_key     || '',
    email_to:        saved.email_to        || '',
  });
  const [saved2, setSaved2] = useState(false);
  const [show, setShow]     = useState({});

  const handleSave = () => {
    try { localStorage.setItem(LS_KEY, JSON.stringify(keys)); } catch {}
    setSaved2(true);
    setTimeout(() => setSaved2(false), 2000);
    if (onKeysChange) onKeysChange(keys);
  };

  const fields = [
    { key: 'glassnode',        label: 'Glassnode API Key',      hint: 'studio.glassnode.com — ücretsiz',     color: '#00e87a' },
    { key: 'cryptoquant',      label: 'CryptoQuant API Key',    hint: 'cryptoquant.com — ücretsiz tier',     color: '#00aaff' },
    { key: 'cryptopanic',      label: 'CryptoPanic Token',      hint: 'cryptopanic.com/api — ücretsiz',      color: '#ff8844' },
    { key: 'telegram_bot',     label: 'Telegram Bot Token',     hint: '@BotFather\'dan al',                  color: '#9966ff' },
    { key: 'telegram_chat',    label: 'Telegram Chat ID',       hint: '@userinfobot ile öğren',              color: '#9966ff' },
    { key: 'emailjs_service',  label: 'EmailJS Service ID',     hint: 'emailjs.com → Email Services',        color: '#ff6644' },
    { key: 'emailjs_template', label: 'EmailJS Template ID',    hint: 'emailjs.com → Email Templates',       color: '#ff6644' },
    { key: 'emailjs_key',      label: 'EmailJS Public Key',     hint: 'emailjs.com → Account → API Keys',   color: '#ff6644' },
    { key: 'email_to',         label: 'Alıcı Email',            hint: 'Sinyallerin gönderileceği adres',     color: '#ff6644' },
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      <div style={{ fontSize: 8, color: '#2a2a50', letterSpacing: 1, marginBottom: 4 }}>
        API anahtarları localStorage'a kaydedilir. Sunucuya gönderilmez.
      </div>
      {fields.map(f => (
        <div key={f.key} style={{ background: '#09091a', borderRadius: 6, padding: '8px 10px', border: '1px solid #0f0f22' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
            <span style={{ fontSize: 9, color: f.color, fontWeight: 700 }}>{f.label}</span>
            <span style={{ fontSize: 8, color: '#1e1e38' }}>{f.hint}</span>
          </div>
          <div style={{ display: 'flex', gap: 6 }}>
            <input
              type={show[f.key] ? 'text' : 'password'}
              value={keys[f.key]}
              onChange={e => setKeys(k => ({ ...k, [f.key]: e.target.value }))}
              placeholder={keys[f.key] ? '••••••••••••' : 'Buraya yapıştır…'}
              style={{
                flex: 1, background: '#06060e', border: '1px solid #16162a',
                borderRadius: 4, padding: '4px 8px', fontSize: 10,
                fontFamily: 'monospace', color: keys[f.key] ? f.color : '#252545',
                outline: 'none',
              }}
            />
            <button
              onClick={() => setShow(s => ({ ...s, [f.key]: !s[f.key] }))}
              style={{ background: '#0f0f22', border: '1px solid #16162a', borderRadius: 4, padding: '2px 7px', cursor: 'pointer', fontSize: 9, color: '#3a3a68' }}
            >
              {show[f.key] ? 'gizle' : 'göster'}
            </button>
            {keys[f.key] && (
              <button
                onClick={() => setKeys(k => ({ ...k, [f.key]: '' }))}
                style={{ background: 'rgba(255,51,92,.1)', border: '1px solid rgba(255,51,92,.2)', borderRadius: 4, padding: '2px 7px', cursor: 'pointer', fontSize: 9, color: '#ff335c' }}
              >
                sil
              </button>
            )}
          </div>
          <div style={{ marginTop: 4, display: 'flex', alignItems: 'center', gap: 4 }}>
            <div style={{ width: 4, height: 4, borderRadius: '50%', background: keys[f.key] ? f.color : '#1e1e38' }} />
            <span style={{ fontSize: 8, color: keys[f.key] ? f.color : '#1e1e38' }}>
              {keys[f.key] ? `${keys[f.key].length} karakter — aktif` : 'Girilmedi — simüle mod çalışıyor'}
            </span>
          </div>
        </div>
      ))}
      <button
        onClick={handleSave}
        style={{
          padding: '7px 0', borderRadius: 6, cursor: 'pointer',
          background: saved2 ? 'rgba(0,232,122,.15)' : 'rgba(0,170,255,.1)',
          border: `1px solid ${saved2 ? 'rgba(0,232,122,.35)' : 'rgba(0,170,255,.25)'}`,
          color: saved2 ? '#00e87a' : '#00aaff',
          fontSize: 10, fontFamily: 'monospace', fontWeight: 700, letterSpacing: 1,
          transition: 'all .2s',
        }}
      >
        {saved2 ? '✓ KAYDEDİLDİ' : 'KAYDET'}
      </button>
    </div>
  );
}

// ─── ANA SİSTEM MONİTÖR PANELİ ───────────────────────────────────────────────
export default function SystemMonitorPanel({ missingBundle, prices = {}, onMacroRisk, onAPIKeysChange }) {
  const [tab, setTab] = useState('latency');

  const tabs = [
    { id: 'latency',  label: '⚡ Gecikme',   icon: Clock    },
    { id: 'macro',    label: '📅 Makro',     icon: Calendar },
    { id: 'crossfeed',label: '🔍 Doğrulama', icon: Shield   },
    { id: 'missing',  label: '📦 18 Modül',  icon: Zap      },
    { id: 'apikeys',  label: '🔑 API Keys',  icon: Zap      },
  ];

  return (
    <div style={{ fontFamily: 'monospace', fontSize: 10 }}>
      {/* Tab switcher */}
      <div style={{ display: 'flex', gap: 3, marginBottom: 10, borderBottom: '1px solid #0d0d1e', paddingBottom: 6 }}>
        {tabs.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{
            background: tab === t.id ? 'rgba(0,170,255,.12)' : 'none',
            border: `1px solid ${tab === t.id ? 'rgba(0,170,255,.3)' : '#0d0d1e'}`,
            borderRadius: 4, color: tab === t.id ? '#00aaff' : '#404070',
            fontSize: 9, fontFamily: 'monospace', padding: '3px 8px', cursor: 'pointer',
          }}>
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'latency'   && <LatencyMonitorPanel autoRefresh />}
      {tab === 'macro'     && <MacroCalendarPanel onRiskScore={onMacroRisk} />}
      {tab === 'crossfeed' && <CrossFeedPanel prices={prices} />}
      {tab === 'missing'   && missingBundle && (
        <div>
          <div style={{ fontSize: 9, color: '#404070', marginBottom: 6, letterSpacing: 1 }}>18 MODÜL SONUÇLARI</div>
          {[
            { k:'supertrend', label:'Supertrend',    val: missingBundle.supertrend?.trend },
            { k:'keltner',    label:'Keltner',        val: missingBundle.keltner?.position },
            { k:'trendCloud', label:'Trend Bulutu',   val: missingBundle.trendCloud?.signal },
            { k:'sessionVol', label:'Seans Vol',      val: missingBundle.sessionVol?.session },
            { k:'precious',   label:'Değ. Metaller',  val: missingBundle.precious?.signal },
            { k:'energyVol',  label:'Enerji Vol',     val: missingBundle.energyVol?.level },
            { k:'indexStress',label:'Endeks Stres',   val: missingBundle.indexStress?.level },
            { k:'contagion',  label:'BTC Bulaşma',    val: missingBundle.contagion?.contagion ? 'AKTİF' : 'YOK' },
            { k:'panic',      label:'Panik',           val: missingBundle.panic?.isPanic ? missingBundle.panic.level : 'YOK' },
            { k:'rateExpect', label:'Fed Beklenti',   val: missingBundle.rateExpect?.expectation },
          ].map(({ k, label, val }) => val ? (
            <div key={k} style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderBottom: '1px solid #0a0a1c' }}>
              <span style={{ color: '#6060a0', fontSize: 9 }}>{label}</span>
              <span style={{ color: '#9090c0', fontSize: 9, fontWeight: 700 }}>{val}</span>
            </div>
          ) : null)}
          <div style={{ marginTop: 8, padding: '4px 8px', borderRadius: 4, background: 'rgba(0,170,255,.08)', border: '1px solid rgba(0,170,255,.15)' }}>
            <span style={{ fontSize: 9, color: '#00aaff' }}>
              Bonus Katkı: {missingBundle.bonusScore >= 0 ? '+' : ''}{missingBundle.bonusScore?.toFixed(2) || '0.00'}
            </span>
          </div>
        </div>
      )}
      {tab === 'apikeys' && <APIKeyPanel onKeysChange={onAPIKeysChange} />}
    </div>
  );
}
