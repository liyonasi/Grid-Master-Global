import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion } from 'framer-motion';
import DecisionEngine from '../components/grid-master/DecisionEngine';
import LiveChart from '../components/grid-master/LiveChart';
import LiquidityWall from '../components/grid-master/LiquidityWall';
import WhaleAlert from '../components/grid-master/WhaleAlert';
import StatsBar from '../components/grid-master/StatsBar';
import SymbolSelector from '../components/grid-master/SymbolSelector';
import ExchangeStatus from '../components/grid-master/ExchangeStatus';
import HeatmapGrid from '../components/grid-master/HeatmapGrid';
import LiquidationMap from '../components/grid-master/LiquidationMap';
import TradingViewChart from '../components/grid-master/TradingViewChart';
import SignalPanel from '../components/grid-master/SignalPanel';
import LiquidityRadar from '../components/grid-master/LiquidityRadar';
import MarketIntelPanel from '../components/grid-master/MarketIntelPanel';
import CouncilPanel from '../components/grid-master/CouncilPanel';
import LiveAICouncilPanel from '../components/grid-master/LiveAICouncilPanel';
import GMGChart from '../components/grid-master/GMGChart_v3';
import { LiquidityWallPanel, AccumulationPlanPanel } from '../components/grid-master/WallAndAccumulationPanels';
import { ForexPanel, MultiMarketPanel } from '../components/grid-master/ForexAndMultiMarketPanels';
import { askLiveAI, autoMarketSummary } from '../components/grid-master/liveAIEngine';
import { TelegramAlertEngine, EmailAlertEngine, WebPushEngine } from '../components/grid-master/alertMonitorEngines';
import { BacktestPanelInline } from '../components/grid-master/BacktestPanel';
import ScannerPage from '../components/grid-master/ScannerPage';
import {
  fetchBinanceTicker, fetchBinanceOrderbook, fetchBinanceKlines,
  fetchBybitTicker, fetchOKXTicker, fetchKrakenTicker,
  fetchCoinGeckoMarkets, computeVWAP, computeRSI,
} from '../components/grid-master/exchangeAPI';
import { computeConfidenceScore } from '../components/grid-master/mockData';
import { runAllScanners } from '../components/grid-master/intelligenceEngine';
import { runCouncils } from '../components/grid-master/councilEngine';
import { runMasterCouncil } from '../components/grid-master/masterCouncil';
import { fetchMacroData, fetchAllMacro } from '../components/grid-master/macroAPIEngine';
import { runBottomConfirmation } from '../components/grid-master/dipOnaylayici';
import DipOnayPanel from '../components/grid-master/DipOnayPanel';
import { RiskModeSelector, runScalpEngine, runAccumulationEngine } from '../components/grid-master/userPlanningEngine';
import { runTrapScoreEngine } from '../components/grid-master/trapDetectionEngine';
import TrapScoreModal from '../components/grid-master/TrapScoreModal';
import { initInfra } from '../components/grid-master/infraEngine';
import { JSONOutputEngine } from '../components/grid-master/jsonOutputEngine';
import { CouncilMemoryEngine } from '../components/grid-master/councilAdvancedEngine';
import FundingPanel from '../components/grid-master/FundingPanel';
import MultiMarketDashboard from '../components/grid-master/MultiMarketDashboard';
import SystemMonitorPanel from '../components/grid-master/SystemMonitorPanel';
import { LatencyMonitor, CrossFeedValidator } from '../components/grid-master/missingModules';

// ─── TABS ─────────────────────────────────────────────────────────────────────
const LEFT_TABS = [
  { id: 'signal',   label: 'Sinyal' },
  { id: 'intel',    label: 'İstihbarat' },
  { id: 'forex',    label: '🌐 Forex/Makro' },
  { id: 'accu',     label: '📦 Birikim' },
  { id: 'dip',      label: '🎯 Dip Onay' },
];

const RIGHT_TABS = [
  { id: 'master',      label: '⚡ Master AI' },
  { id: 'council',     label: 'Konseyler'   },
  { id: 'orderbook',   label: 'Orderbook'   },
  { id: 'radar',       label: 'Liq Radar'   },
  { id: 'multimarket', label: '📊 Piyasalar' },
  { id: 'backtest',    label: '🔬 Backtest'  },
  { id: 'sysmonitor',  label: '⚙ Sistem'    },
];

function TabSwitch({ tabs, active, onChange }) {
  return (
    <div style={{
      display: 'flex',
      background: '#08080f',
      border: '1px solid #16162a',
      borderRadius: 8,
      overflow: 'hidden',
      gap: 1,
    }}>
      {tabs.map(t => (
        <button
          key={t.id}
          onClick={() => onChange(t.id)}
          style={{
            flex: 1,
            padding: '6px 6px',
            fontSize: 9,
            fontFamily: 'monospace',
            fontWeight: 700,
            letterSpacing: '0.5px',
            textTransform: 'uppercase',
            cursor: 'pointer',
            border: 'none',
            borderBottom: active === t.id ? '2px solid #00aaff' : '2px solid transparent',
            background: active === t.id ? 'rgba(0,170,255,0.08)' : 'transparent',
            color: active === t.id ? '#00aaff' : '#3a3a60',
            transition: 'all 0.15s',
          }}
        >
          {t.label}
        </button>
      ))}
    </div>
  );
}

// ─── COUNCIL MEMORY PANEL ────────────────────────────────────────────────────
function CouncilMemoryPanel() {
  const [summary, setSummary] = React.useState([]);
  const [expanded, setExpanded] = React.useState(false);

  React.useEffect(() => {
    try {
      const s = CouncilMemoryEngine.getSummary();
      setSummary(s);
    } catch(e) {}
  }, []);

  const hasSummary = summary.some(s => s.totalDecisions > 0);

  return (
    <div style={{
      background:'#06060f', border:'1px solid #1a1a2e', borderRadius:6,
      padding:'8px 10px', marginTop:4,
    }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', cursor:'pointer' }}
        onClick={() => setExpanded(e => !e)}>
        <span style={{ fontSize:9, color:'#aa88ff', fontFamily:'monospace', fontWeight:'bold', letterSpacing:1 }}>
          📊 COUNCIL MEMORY {hasSummary ? '' : '(veri bekleniyor)'}
        </span>
        <span style={{ fontSize:8, color:'#404070' }}>{expanded ? '▲' : '▼'}</span>
      </div>
      {expanded && (
        <div style={{ marginTop:6 }}>
          {!hasSummary ? (
            <div style={{ fontSize:8, color:'#404070', fontFamily:'monospace', textAlign:'center', padding:'6px 0' }}>
              Henüz karar kaydedilmedi — ilk tarama sonrası güncellenir
            </div>
          ) : (
            <div style={{ display:'flex', flexDirection:'column', gap:3 }}>
              {summary.filter(s => s.totalDecisions > 0).map(s => {
                const acc = s.accuracy;
                const color = acc === null ? '#555' : acc >= 70 ? '#00ff88' : acc >= 50 ? '#ffcc00' : '#ff3366';
                return (
                  <div key={s.councilId} style={{
                    display:'flex', justifyContent:'space-between', alignItems:'center',
                    background:'#0a0a1a', borderRadius:4, padding:'3px 6px',
                  }}>
                    <span style={{ fontSize:8, color:'#8888aa', fontFamily:'monospace', width:120 }}>
                      {s.councilId.replace('_COUNCIL','').replace('_SPECIALIST','')}
                    </span>
                    <span style={{ fontSize:8, color:'#555', fontFamily:'monospace' }}>
                      {s.totalDecisions} karar
                    </span>
                    <span style={{ fontSize:9, color, fontFamily:'monospace', fontWeight:'bold', width:40, textAlign:'right' }}>
                      {acc !== null ? `%${acc}` : '--'}
                    </span>
                    <span style={{ fontSize:7, color: s.weightMultiplier >= 1.1 ? '#00ff88' : s.weightMultiplier <= 0.85 ? '#ff3366' : '#555',
                      fontFamily:'monospace', width:32, textAlign:'right' }}>
                      x{s.weightMultiplier}
                    </span>
                  </div>
                );
              })}
              <div style={{ display:'flex', justifyContent:'space-between', borderTop:'1px solid #1a1a2e', paddingTop:4, marginTop:2 }}>
                <span style={{ fontSize:8, color:'#404070', fontFamily:'monospace' }}>
                  Toplam: {summary.reduce((a,s) => a + s.totalDecisions, 0)} karar
                </span>
                <span style={{ fontSize:8, color:'#404070', fontFamily:'monospace' }}>
                  Ağırlık sistemi aktif
                </span>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default function Dashboard() {
  // ─── STATE ─────────────────────────────────────────────────────────────────
  const [selectedSymbol, setSelectedSymbol] = useState('BTC/USDT');
  const [tickerData, setTickerData]         = useState([]);
  const [vwap, setVwap]                     = useState(0);
  const [orderbook, setOrderbook]           = useState(null);
  const [priceHistory, setPriceHistory]     = useState([]);
  const [heatmapData, setHeatmapData]       = useState([]);
  const [alerts, setAlerts]                 = useState([]);
  const [confidenceData, setConfidenceData] = useState(null);
  const [lastUpdate, setLastUpdate]         = useState(null);
  const [connectedExchanges, setConnectedExchanges] = useState([]);
  const [loading, setLoading]               = useState(true);
  const [chartMode, setChartMode]           = useState('custom');
  const [leftTab, setLeftTab]               = useState('signal');
  const [rightTab, setRightTab]             = useState('council');
  const [activePage, setActivePage]         = useState('grafik'); // 'grafik' | 'tarayici' | 'turev' | 'piyasalar'

  // Intelligence & Council state
  const [scanResults, setScanResults]       = useState(null);
  const [councilResults, setCouncilResults] = useState(null);
  const [masterResult, setMasterResult]     = useState(null);
  const [masterLoading, setMasterLoading]   = useState(false);
  const [scanLoading, setScanLoading]       = useState(false);
  const [riskMode, setRiskMode]             = useState('NORMAL');   // AGRESIF | NORMAL | MUHAFAZAKAR
  const [scalpResult, setScalpResult]       = useState(null);
  const [accuResult, setAccuResult]         = useState(null);
  const [trapData, setTrapData]             = useState(null);
  const [trapModalOpen, setTrapModalOpen]   = useState(false);
  const [showTrapDetail, setShowTrapDetail]  = useState(false);
  const [jsonOutputs, setJsonOutputs]       = useState({});
  const jsonEngineRef = useRef(null);

  // Dip Onaylayici state
  const [dipData, setDipData] = useState(null);

  // Live AI soru-cevap state
  const [aiAnswer, setAiAnswer]     = useState(null);
  const [aiQuery, setAiQuery]       = useState('');
  const [aiLoading, setAiLoading]   = useState(false);
  const [autoSummary, setAutoSummary] = useState(null);

  // Telegram — BOT_TOKEN ve CHAT_ID env'den veya boş bırak (mock mod)
  const telegramRef = useRef(
    new TelegramAlertEngine(
      process.env.REACT_APP_TG_BOT_TOKEN || '',
      process.env.REACT_APP_TG_CHAT_ID   || ''
    )
  );
  const lastTelegramSignal = useRef(null); // son gönderilen sinyal hash

  // Email + WebPush — API Keys UI'dan gelir (localStorage'dan başlat)
  const emailRef   = useRef(new EmailAlertEngine());
  const webPushRef = useRef(new WebPushEngine());
  const [apiKeys, setApiKeys] = useState(() => {
    try { return JSON.parse(localStorage.getItem('gmg_api_keys') || '{}'); } catch { return {}; }
  });

  // API Keys değişince engine'leri güncelle
  useEffect(() => {
    if (apiKeys.telegram_bot && apiKeys.telegram_chat) {
      telegramRef.current = new TelegramAlertEngine(apiKeys.telegram_bot, apiKeys.telegram_chat);
    }
    if (apiKeys.emailjs_service && apiKeys.emailjs_template && apiKeys.emailjs_key && apiKeys.email_to) {
      emailRef.current = new EmailAlertEngine({
        serviceId:  apiKeys.emailjs_service,
        templateId: apiKeys.emailjs_template,
        publicKey:  apiKeys.emailjs_key,
        toEmail:    apiKeys.email_to,
      });
    }
  }, [apiKeys]);

  const lastSignalBarsAgo = useRef(999);
  const prevFinalScore    = useRef(50);
  const signalBarCount    = useRef(0);
  // Per-coin klines cache: { symbol: klines[] }
  const klineCache = useRef({});

  const wsRef        = useRef(null);
  const prevPriceRef = useRef(null);

  // ─── FETCH HELPERS ─────────────────────────────────────────────────────────

  const fetchAllTickers = useCallback(async () => {
    const results = await Promise.allSettled([
      fetchBinanceTicker(selectedSymbol), fetchBybitTicker(selectedSymbol),
      fetchOKXTicker(selectedSymbol),     fetchKrakenTicker(selectedSymbol),
    ]);
    const valid = results.filter(r => r.status === 'fulfilled' && r.value).map(r => r.value);
    setConnectedExchanges(valid.map(t => t.exchange));
    if (valid.length > 0) {
      setTickerData(valid);
      setVwap(computeVWAP(valid));
      const bin = valid.find(t => t.exchange === 'binance') || valid[0];
      if (prevPriceRef.current && bin) {
        const diff = Math.abs((bin.price - prevPriceRef.current) / prevPriceRef.current * 100);
        if (diff > 0.5) {
          setAlerts(prev => [{
            symbol: selectedSymbol, alert_type: 'price_spike',
            severity: diff > 2 ? 'critical' : diff > 1 ? 'high' : 'medium',
            message: `${selectedSymbol} — ${diff.toFixed(2)}% ani fiyat hareketi`,
            exchange: bin.exchange, value: bin.price, timestamp: Date.now(),
          }, ...prev].slice(0, 20));
        }
      }
      if (bin) prevPriceRef.current = bin.price;
    }
    return valid;
  }, [selectedSymbol]);

  const fetchOrderbook = useCallback(async () => {
    LatencyMonitor.start('orderbook');
    const ob = await fetchBinanceOrderbook(selectedSymbol, 20);
    LatencyMonitor.end('orderbook');
    setOrderbook(ob);
    return ob;
  }, [selectedSymbol]);

  const fetchKlines = useCallback(async () => {
    LatencyMonitor.start('klines');
    const klines = await fetchBinanceKlines(selectedSymbol, '1m', 120);
    LatencyMonitor.end('klines');
    setPriceHistory(klines);
    return klines;
  }, [selectedSymbol]);

  // ─── INTELLIGENCE SCAN ─────────────────────────────────────────────────────
  /**
   * Heatmap coinleri için kline çek (ilk 30 coin - API limitini aşmamak için)
   * Sonra tüm tarayıcıları çalıştır ve konseyleri oylatır
   */
  const runIntelligenceScan = useCallback(async (coins) => {
    if (!coins || coins.length === 0) return;
    setScanLoading(true);
    try {
      // En aktif 30 coin için kline çek (batch, rate limit dostu)
      const top30 = coins.slice(0, 30);
      const klineResults = await Promise.allSettled(
        top30.map(c =>
          fetchBinanceKlines(c.symbol, '1m', 30)
            .then(k => ({ symbol: c.symbol, klines: k }))
            .catch(() => null)
        )
      );
      const klineMap = {};
      klineResults.forEach(r => {
        if (r.status === 'fulfilled' && r.value) {
          klineCache.current[r.value.symbol] = r.value.klines;
          klineMap[r.value.symbol] = r.value.klines;
        }
      });
      // Merge with existing cache
      Object.assign(klineMap, klineCache.current);

      // BTC değişimini bul
      const btcCoin = coins.find(c => c.symbol === 'BTC/USDT');
      const btcChange = btcCoin?.change_24h || 0;

      // Orderbooklari sadece seçili coin için var
      const orderbookMap = selectedSymbol && orderbook
        ? { [selectedSymbol]: orderbook }
        : {};

      // Tüm tarayıcıları çalıştır
      const results = runAllScanners({
        coins,
        btcChange,
        orderbookMap,
        klineMap,
        mexcCoins: [],
      });

      setScanResults(results);

      // Konseyleri çalıştır (eski sistem)
      const councils = runCouncils(results);
      setCouncilResults(councils);

      // ── MASTER COUNCIL — tam karar motoru ──────────────────────────────
      setMasterLoading(true);
      try {
        const klines = priceHistory.length > 0 ? priceHistory : [];
        // Basit indikatör paketi (GMGChart'tan bağımsız)
        const closes = klines.map(k => k.c || k.price).filter(Boolean);
        const I = closes.length > 14 ? {
          rsi:  [computeRSI(closes)],
          macd: null, bb: null, ema: null, adx: null, mfi: null, obv: null, atr: null,
        } : {};

        // ─── Gerçek makro veri (DXY, US10Y, VIX, Gold, Oil) — fetchAllMacro ──
        let macroAll = null;
        try {
          macroAll = await fetchAllMacro();
        } catch {
          macroAll = null;
        }
        const dxyLevel    = macroAll?.dxy?.value    ?? 104.0;
        const us10yYield  = macroAll?.us10y?.value  ?? 4.3;
        const vixLevel    = macroAll?.vix?.value    ?? 20;
        const goldChange  = macroAll?.gold?.change  ?? 0;
        const oilChange   = macroAll?.oil?.change   ?? 0;
        const fearGreedVal= macroAll?.fearGreed?.value ?? 50;
        const riskModeVal = macroAll?.riskMode      ?? 'NEUTRAL';

        setMacroData({
          dxyLevel, us10yYield, vixLevel,
          goldChange, oilChange, fearGreedVal, riskModeVal,
          // Detaylı veriler (MultiMarketDashboard için)
          dxy:   macroAll?.dxy,
          us10y: macroAll?.us10y,
          us2y:  macroAll?.us2y,
          vix:   macroAll?.vix,
          gold:  macroAll?.gold,
          oil:   macroAll?.oil,
          silver:  macroAll?.silver,
          sp500:   macroAll?.sp500,
          nasdaq:  macroAll?.nasdaq,
          breadth: macroAll?.breadth,
          fearGreed:    macroAll?.fearGreed,
          yieldSpread:  macroAll?.yieldSpread,
          isInvertedCurve: macroAll?.isInvertedCurve,
          riskScore:       macroAll?.riskScore,
        });

        const master = await runMasterCouncil({
          candles:     klines,
          I,
          scanResults: results,
          orderbook,
          heatmapData: coins,
          fundingRates: [],
          btcChange,
          vixLevel,
          dxyLevel,
          us10yYield,
          goldChange,
          oilChange,
          symbol:      selectedSymbol,
          externalTrapScore: trapData?.score ?? 0,
          lastSignalBarsAgo: lastSignalBarsAgo.current,
          prevFinalScore:    prevFinalScore.current,
          signalBarCount:    signalBarCount.current,
          pineParams: { rfPer: 100, rfMult: 3.0, signalMode: 'KLASİK' },
          // CrossFeedValidator için borsa fiyatları
          aggregatedPrices: tickerData?.length >= 2
            ? tickerData.reduce((acc, t) => { if (t.exchange && t.price) acc[t.exchange] = t.price; return acc; }, {})
            : null,
          // missingModules için gerçek makro değerleri
          sp500Change:   macroAll?.sp500?.change  ?? 0,
          nasdaqChange:  macroAll?.nasdaq?.change ?? 0,
          silverChange:  macroAll?.silver?.change ?? 0,
          marketBreadth: macroAll?.breadth        ?? 0.6,
          fearGreed:     fearGreedVal,
          // API anahtarları — UI'dan localStorage üzerinden gelir
          glassnodeKey:  apiKeys?.glassnode    || process.env.REACT_APP_GLASSNODE_KEY    || '',
          cqKey:         apiKeys?.cryptoquant  || process.env.REACT_APP_CRYPTOQUANT_KEY  || '',
        });

        setMasterResult(master);

        // ─── JSON Output Engine — master result sonrası tüm çıktıları üret ──
        try {
          if (!jsonEngineRef.current) jsonEngineRef.current = new JSONOutputEngine();
          jsonEngineRef.current.generateAll(master, results, {
            scalpResult:  scalpResult,
            accuResult:   accuResult,
            trapData:     trapData,
            alerts:       alerts,
          });
          setJsonOutputs({ ...jsonEngineRef.current.outputs });
        } catch (e) { console.warn("[JSONOutput] hata:", e.message); }

        // Referansları güncelle
        prevFinalScore.current    = master.score ?? 50;
        lastSignalBarsAgo.current = master.action !== 'WAIT' ? 0 : (lastSignalBarsAgo.current + 1);
        if (master.action !== 'WAIT') signalBarCount.current++;

        // ─── Scalp + Accumulation Engine (Risk Mode ile) ─────────────────
        try {
          const modeParams = RiskModeSelector.getParams(riskMode);
          const curPrice   = priceHistory[priceHistory.length-1]?.c || 0;
          const atr        = master.pineData?.atrV || curPrice * 0.02;

          if (curPrice > 0) {
            const scalp = runScalpEngine({
              masterScore:   master.score,
              riskLevel:     master.riskLevel,
              pineSignal:    master.pineData,
              stopHuntScore: results?.stopHunts?.length > 0 ? 70 : 20,
              riskMode,
              currentPrice:  curPrice,
              atr,
            });
            setScalpResult(scalp);

            const accu = runAccumulationEngine({
              masterScore:   master.score,
              riskLevel:     master.riskLevel,
              currentPrice:  curPrice,
              atr,
              riskMode,
              srLevels:      master.pineData?.sr?.sup || [],
              pbNearSupport: master.pineData?.pb?.nearSupport || false,
            });
            setAccuResult(accu);
          }
        } catch {}

        // ─── Trap Score (trapDetectionEngine) ────────────────────────────
        try {
          if (priceHistory.length >= 20) {
            const trap = runTrapScoreEngine({
              stopHuntScore:  results?.stopHunts?.length > 0 ? 65 : 10,
              fakeBreakoutScore: master.advanced?.derivTrap?.isTrap ? 75 : 15,
              hftScore:       20,
              masterScore:    master.score,
              pineData:       master.pineData,
            });
            setTrapData(trap);
          }
        } catch {}



        // ─── Telegram Alert ──────────────────────────────────────────────
        // Sadece BUY/SELL sinyalinde ve aynı sinyali tekrar göndermemek için hash kontrolü
        if (master.action !== 'WAIT') {
          const signalHash = `${master.action}-${master.score}-${Math.floor(Date.now() / 60000)}`; // 1dk unique
          if (signalHash !== lastTelegramSignal.current) {
            lastTelegramSignal.current = signalHash;
            const pine = master.pineData;
            const msg  = telegramRef.current.formatSignalMessage({
              symbol:     selectedSymbol,
              action:     master.label,
              score:      master.score,
              confidence: master.confidence,
              tp1:        pine?.tp1 ? pine.tp1.toFixed(2) : null,
              sl:         pine?.sl  ? pine.sl.toFixed(2)  : null,
              reason:     master.summary?.[0] || '',
              phase:      master.execution?.phase || null,
            });
            telegramRef.current.send(msg).catch(() => {});

            // ── Email Alert ─────────────────────────────────────────────
            const sigPayload = {
              symbol:     selectedSymbol,
              action:     master.label,
              score:      master.score,
              confidence: master.confidence,
              tp1:        pine?.tp1 ? pine.tp1.toFixed(2) : null,
              sl:         pine?.sl  ? pine.sl.toFixed(2)  : null,
              reason:     master.summary?.[0] || '',
              phase:      master.execution?.phase || null,
            };
            emailRef.current.sendSignal(sigPayload).catch(() => {});

            // ── Web Push Bildirimi ───────────────────────────────────────
            webPushRef.current.sendSignal({
              symbol:     selectedSymbol,
              action:     master.label,
              score:      master.score,
              confidence: master.confidence,
              tp1:        pine?.tp1,
              sl:         pine?.sl,
            }).catch(() => {});
          }
        }

        // ─── Auto AI Market Summary (sadece BUY/SELL sinyalinde) ─────────
        if (master.action !== 'WAIT') {
          autoMarketSummary({ masterResult: master, scanResults: scans, symbol: selectedSymbol })
            .then(s => setAutoSummary(s))
            .catch(() => {});
        }

      } catch (err) {
        console.error('Master council error:', err);
      } finally {
        setMasterLoading(false);
      }

      // ─── DİP ONAYLAYICI — scan sonrası arka planda çalışır ───────────────
      try {
        // Gerçek BTC RSI hesapla
        const _btcCloses = priceHistory.map(k => k.c || k.price).filter(Boolean);
        const _btcRsi = _btcCloses.length > 15 ? computeRSI(_btcCloses) : 50;

        const dipResult = runBottomConfirmation(results, {
          klineMap:   klineCache.current || {},
          mags:       masterResult?.pineData?.sr?.all || null,
          btcRsi:     _btcRsi,
          obImbalance: orderbook
            ? (() => {
                const b = orderbook.bids?.slice(0,10).reduce((s,x) => s+(x.amount||0)*(x.price||0), 0) || 0;
                const a = orderbook.asks?.slice(0,10).reduce((s,x) => s+(x.amount||0)*(x.price||0), 0) || 0;
                return b + a > 0 ? Math.round((b / (b + a)) * 100) : 50;
              })()
            : 50,
        });
        setDipData(dipResult);
      } catch (dipErr) {
        console.warn('[DipOnaylayici] Hata:', dipErr.message);
      }

    } catch (err) {
      console.error('Intelligence scan error:', err);
    } finally {
      setScanLoading(false);
    }
  }, [selectedSymbol, orderbook]);

  // ─── WEBSOCKET ─────────────────────────────────────────────────────────────

  const connectBinanceWS = useCallback(() => {
    if (wsRef.current) wsRef.current.close();
    const stream = selectedSymbol.replace('/', '').toLowerCase();
    const ws = new WebSocket(
      `wss://stream.binance.com:9443/stream?streams=${stream}@depth20@100ms/${stream}@trade`
    );
    ws.onmessage = (event) => {
      const msg = JSON.parse(event.data);
      if (!msg.stream) return;
      if (msg.stream.includes('@depth')) {
        let bt = 0, at = 0;
        const bids = (msg.data.bids || []).map(([p, a]) => {
          bt += parseFloat(a);
          return { price: parseFloat(p), amount: parseFloat(a), total: parseFloat(bt.toFixed(4)) };
        });
        const asks = (msg.data.asks || []).map(([p, a]) => {
          at += parseFloat(a);
          return { price: parseFloat(p), amount: parseFloat(a), total: parseFloat(at.toFixed(4)) };
        });
        setOrderbook({ bids, asks });
        const bigBid = bids.find(b => b.amount * b.price > 500000);
        const bigAsk = asks.find(a => a.amount * a.price > 500000);
        if (bigBid || bigAsk) {
          const side = bigBid ? 'alış' : 'satış';
          const val  = bigBid ? bigBid.amount * bigBid.price : bigAsk.amount * bigAsk.price;
          if (val > 1000000) {
            setAlerts(prev => [{
              symbol: selectedSymbol, alert_type: 'whale_movement',
              severity: val > 5000000 ? 'critical' : 'high',
              message: `${selectedSymbol} — $${(val / 1e6).toFixed(2)}M büyük ${side} emri`,
              exchange: 'binance', value: val, timestamp: Date.now(),
            }, ...prev].slice(0, 20));
          }
        }
      }
      if (msg.stream.includes('@trade')) {
        const price = parseFloat(msg.data.p), vol = parseFloat(msg.data.q);
        setPriceHistory(prev => {
          const timeStr = new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
          const last = prev[prev.length - 1];
          if (last && last.time.slice(0, 5) === timeStr.slice(0, 5)) {
            const u = [...prev];
            u[u.length - 1] = { ...last, price, high: Math.max(last.high || price, price), low: Math.min(last.low || price, price), volume: (last.volume || 0) + vol };
            return u;
          }
          return [...prev, { time: timeStr, timestamp: Date.now(), price, volume: vol }].slice(-200);
        });
      }
    };
    wsRef.current = ws;
  }, [selectedSymbol]);

  const loadHeatmap = useCallback(async () => {
    const data = await fetchCoinGeckoMarkets(200);
    setHeatmapData(data);
    return data;
  }, []);

  // ─── MAIN REFRESH ──────────────────────────────────────────────────────────

  const refreshAll = useCallback(async () => {
    const [tickers, ob, klines] = await Promise.allSettled([
      fetchAllTickers(), fetchOrderbook(), fetchKlines(),
    ]);
    const vt = tickers.status === 'fulfilled' ? tickers.value : [];
    const vo = ob.status === 'fulfilled' ? ob.value : null;
    const vk = klines.status === 'fulfilled' ? klines.value : [];
    if (vt.length > 0 && vo) {
      const rsiVal = computeRSI(vk);
      const rawConf = computeConfidenceScore(vt.map(t => ({ ...t, rsi: rsiVal })), vo);
      if (rawConf) {
        rawConf.score = Math.min(100, Math.max(0, Math.round(rawConf.score)));
        rawConf.confidence = Math.min(100, Math.max(0, Math.round(rawConf.confidence ?? rawConf.score)));
      }
      setConfidenceData(rawConf);
    }
    setLastUpdate(new Date());
    setLoading(false);
  }, [fetchAllTickers, fetchOrderbook, fetchKlines]);

  // ─── EFFECTS ───────────────────────────────────────────────────────────────

  useEffect(() => {
    setLoading(true);
    setOrderbook(null);
    setTickerData([]);
    setConfidenceData(null);
    prevPriceRef.current = null;
    refreshAll();
    connectBinanceWS();
  }, [selectedSymbol]);

  useEffect(() => {
    // Ticker + orderbook fast refresh (5s)
    const ti = setInterval(async () => {
      const tickers = await fetchAllTickers();
      const ob = await fetchOrderbook();
      if (tickers.length > 0 && ob) {
        const rsiVal = computeRSI(priceHistory);
        const rawConf = computeConfidenceScore(tickers.map(t => ({ ...t, rsi: rsiVal })), ob);
        if (rawConf) {
          rawConf.score = Math.min(100, Math.max(0, Math.round(rawConf.score)));
          rawConf.confidence = Math.min(100, Math.max(0, Math.round(rawConf.confidence ?? rawConf.score)));
        }
        setConfidenceData(rawConf);
      }
      setLastUpdate(new Date());
    }, 5000);

    // Klines medium refresh (30s)
    const ki = setInterval(() => fetchKlines(), 30000);

    // Heatmap + full intelligence scan (60s)
    const hi = setInterval(async () => {
      const data = await loadHeatmap();
      if (data?.length) runIntelligenceScan(data);
    }, 60000);

    return () => { clearInterval(ti); clearInterval(ki); clearInterval(hi); };
  }, [fetchAllTickers, fetchOrderbook, fetchKlines, loadHeatmap, runIntelligenceScan, priceHistory]);

  useEffect(() => {
    // Initial heatmap + scan
    loadHeatmap().then(data => {
      if (data?.length) runIntelligenceScan(data);
    });
    return () => { if (wsRef.current) wsRef.current.close(); };
  }, []);

  // ─── LIVE AI SORU HANDLER ──────────────────────────────────────────────────

  const handleAskAI = useCallback(async () => {
    if (!aiQuery.trim()) return;
    setAiLoading(true);
    try {
      const ans = await askLiveAI({
        question:     aiQuery,
        symbol:       selectedSymbol,
        masterResult,
        scanResults,
        language:     'tr',
      });
      setAiAnswer(ans);
    } catch (e) {
      setAiAnswer({ answer: `Hata: ${e.message}`, error: true, timestamp: Date.now() });
    } finally {
      setAiLoading(false);
    }
  }, [aiQuery, selectedSymbol, masterResult, scanResults]);

  // ─── RENDER ────────────────────────────────────────────────────────────────

  return (
    <div style={{ minHeight: '100vh', background: '#06060d', fontFamily: 'monospace' }}>

      {/* ─── TOP BAR ──────────────────────────────────────────────────────── */}
      <div style={{
        position: 'sticky', top: 0, zIndex: 30,
        background: 'rgba(6,6,13,0.96)',
        borderBottom: '1px solid #13132a',
        backdropFilter: 'blur(16px)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 20px', height: 48 }}>

          {/* Logo + symbol */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{
                width: 7, height: 7, borderRadius: '50%', background: '#00e87a',
                boxShadow: '0 0 10px #00e87a88',
                animation: 'gmgPulse 2s ease-in-out infinite',
              }} />
              <span style={{ fontSize: 12, fontWeight: 800, letterSpacing: 4, color: '#00e87a' }}>GMG</span>
              <span style={{ fontSize: 10, color: '#252545', letterSpacing: 1 }}>MASTER</span>
            </div>
            <SymbolSelector
              selectedSymbol={selectedSymbol}
              onSelect={setSelectedSymbol}
              symbols={heatmapData.map(c => c.symbol)}
            />
          </div>

          {/* Center — price + signal */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
            <ExchangeStatus activeExchanges={connectedExchanges} />
            {lastUpdate && (
              <span style={{ fontSize: 9, color: '#2a2a50', fontFamily: 'monospace' }}>
                {lastUpdate.toLocaleTimeString('tr-TR')}
              </span>
            )}
            {/* Risk Mode */}
            <div style={{ display: 'flex', gap: 2 }}>
              {['MUHAFAZAKAR','NORMAL','AGRESIF'].map(mode => (
                <button key={mode} onClick={() => setRiskMode(mode)} style={{
                  fontSize: 8, fontFamily: 'monospace', fontWeight: 700,
                  padding: '3px 7px', borderRadius: 4, cursor: 'pointer',
                  background: riskMode === mode
                    ? mode === 'AGRESIF' ? 'rgba(255,51,92,0.14)'
                    : mode === 'MUHAFAZAKAR' ? 'rgba(0,232,122,0.12)'
                    : 'rgba(0,170,255,0.12)' : 'transparent',
                  border: `1px solid ${riskMode === mode
                    ? mode === 'AGRESIF' ? '#ff335c' : mode === 'MUHAFAZAKAR' ? '#00e87a' : '#00aaff'
                    : '#16162a'}`,
                  color: riskMode === mode
                    ? mode === 'AGRESIF' ? '#ff335c' : mode === 'MUHAFAZAKAR' ? '#00e87a' : '#00aaff'
                    : '#2a2a50',
                  transition: 'all 0.15s',
                }}>
                  {mode === 'MUHAFAZAKAR' ? '◈' : mode === 'AGRESIF' ? '◆' : '◇'} {mode.slice(0,4)}
                </button>
              ))}
            </div>
            {/* Master signal badge */}
            {masterResult && (
              <div style={{
                display: 'flex', alignItems: 'center', gap: 6,
                padding: '4px 10px', borderRadius: 6,
                background: `${masterResult.color}12`,
                border: `1px solid ${masterResult.color}30`,
              }}>
                <div style={{ width: 5, height: 5, borderRadius: '50%', background: masterResult.color }} />
                <span style={{ fontSize: 10, fontWeight: 800, letterSpacing: 1.5, color: masterResult.color }}>
                  {masterResult.label}
                </span>
                <span style={{ fontSize: 9, color: '#3a3a68' }}>
                  {masterResult.score} · %{masterResult.confidence}
                </span>
                {masterResult.execution?.filters?.veto?.wasVetoed && (
                  <span style={{ fontSize: 8, color: '#ff0044', fontWeight: 700 }}>VETO</span>
                )}
              </div>
            )}
            {/* TrapScore */}
            {trapData && (
              <div onClick={() => setTrapModalOpen(true)} style={{
                display: 'flex', alignItems: 'center', gap: 4, cursor: 'pointer',
                padding: '3px 8px', borderRadius: 5,
                background: trapData.score >= 71 ? 'rgba(255,34,51,0.1)' : trapData.score >= 41 ? 'rgba(255,200,0,0.08)' : 'rgba(0,232,122,0.08)',
                border: `1px solid ${trapData.score >= 71 ? '#ff2233' : trapData.score >= 41 ? '#ffc800' : '#00e87a'}40`,
              }}>
                <span style={{ fontSize: 9, fontWeight: 700, color: trapData.score >= 71 ? '#ff2233' : trapData.score >= 41 ? '#ffc800' : '#00e87a' }}>
                  ⬡ {trapData.score}
                </span>
                <span style={{ fontSize: 8, color: '#3a3a68' }}>
                  {trapData.score >= 71 ? 'TUZAK' : trapData.score >= 41 ? 'DİKKAT' : 'TEMİZ'}
                </span>
              </div>
            )}
            {trapModalOpen && trapData && <TrapScoreModal trapData={trapData} onClose={() => setTrapModalOpen(false)} />}

            {/* missingBundle kritik uyarılar */}
            {masterResult?.missingBundle?.alerts?.map((alert, i) => (
              <span key={i} style={{
                fontSize: 9, fontFamily: 'monospace', fontWeight: 700,
                padding: '2px 7px', borderRadius: 4,
                background: 'rgba(255,60,0,.15)', color: '#ff6b35',
                border: '1px solid rgba(255,60,0,.3)',
              }}>{alert}</span>
            ))}

            {/* missingBundle: Panic veya Contagion varsa büyük uyarı */}
            {masterResult?.missingBundle?.panic?.isPanic && (
              <span style={{
                fontSize: 9, fontFamily: 'monospace', fontWeight: 700,
                padding: '2px 8px', borderRadius: 4,
                background: 'rgba(255,0,80,.18)', color: '#ff0055',
                border: '1px solid rgba(255,0,80,.4)',
                animation: 'gmgPulse 1s ease-in-out infinite',
              }}>⛔ PANİK: {masterResult.missingBundle.panic.level}</span>
            )}
            {masterResult?.missingBundle?.contagion?.contagion && (
              <span style={{
                fontSize: 9, fontFamily: 'monospace', fontWeight: 700,
                padding: '2px 8px', borderRadius: 4,
                background: 'rgba(255,100,0,.15)', color: '#ff6400',
                border: '1px solid rgba(255,100,0,.3)',
              }}>⚡ BTC BULAŞMA</span>
            )}

            {/* CrossFeed fiyat tutarsızlığı uyarısı */}
            {masterResult?.health?.crossFeed && !masterResult.health.crossFeed.isValid && (
              <span style={{
                fontSize: 9, fontFamily: 'monospace', fontWeight: 700,
                padding: '2px 7px', borderRadius: 4,
                background: 'rgba(255,136,0,.15)', color: '#ff8800',
                border: '1px solid rgba(255,136,0,.3)',
              }}>
                ⚠ Fiyat sapması %{(masterResult.health.crossFeed.maxDeviation || 0).toFixed(2)}
              </span>
            )}
            {masterLoading && <span style={{ fontSize: 9, color: '#9966ff', animation: 'gmgPulse 1.4s ease-in-out infinite' }}>◈ ANALİZ</span>}
            {loading && <span style={{ fontSize: 9, color: '#ffcc00', animation: 'gmgPulse 1.4s ease-in-out infinite' }}>◈ YÜKLENİYOR</span>}
            {/* WebPush bildirim izin butonu */}
            {(() => {
              const status = webPushRef.current.getStatus();
              if (!status.supported) return null;
              if (status.active) return (
                <span style={{ fontSize: 8, fontFamily: 'monospace', color: '#00e87a', padding: '2px 6px', borderRadius: 3, background: 'rgba(0,232,122,.08)', border: '1px solid rgba(0,232,122,.2)' }}>
                  🔔 Bildirim Açık
                </span>
              );
              return (
                <button
                  onClick={() => webPushRef.current.requestPermission().then(() => { /* re-render tetiklemez, kullanıcı yeniden açar */ })}
                  style={{
                    fontSize: 8, fontFamily: 'monospace', fontWeight: 700,
                    padding: '3px 8px', borderRadius: 4, cursor: 'pointer',
                    background: 'rgba(153,102,255,.12)', border: '1px solid rgba(153,102,255,.3)',
                    color: '#9966ff',
                  }}
                >
                  🔔 Bildirimleri Aç
                </button>
              );
            })()}
          </div>
        </div>

        {/* Stats bar */}
        <div style={{ borderTop: '1px solid #0d0d1e' }}>
          <StatsBar tickerData={tickerData} vwap={vwap} confidenceData={confidenceData} />
        </div>

        {/* Page nav */}
        <div style={{
          display: 'flex', borderTop: '1px solid #0d0d1e',
          background: '#08080f',
        }}>
          {[
            { id: 'grafik',    label: '01 — Grafik & Sinyal' },
            { id: 'tarayici', label: '02 — Tarayıcılar & Scanner' },
            { id: 'turev',    label: '03 — Türev & Akış' },
            { id: 'piyasalar', label: '04 — 🌍 Global Piyasalar' },
          ].map(p => (
            <button key={p.id} onClick={() => setActivePage(p.id)} style={{
              padding: '8px 20px', fontSize: 10, fontFamily: 'monospace', fontWeight: 700,
              letterSpacing: 1, cursor: 'pointer', border: 'none',
              borderBottom: activePage === p.id ? '2px solid #00aaff' : '2px solid transparent',
              background: activePage === p.id ? 'rgba(0,170,255,0.07)' : 'transparent',
              color: activePage === p.id ? '#00aaff' : '#252545',
              transition: 'all 0.15s',
            }}>
              {p.label}
            </button>
          ))}
        </div>
      </div>

      <style>{`
        @keyframes gmgPulse { 0%,100%{opacity:1} 50%{opacity:.45} }
        .gmg-panel { background:#0b0b18; border:1px solid #13132a; border-radius:10px; }
        .gmg-panel-inner { padding:12px 14px; }
        .gmg-section-title {
          font-size:8px; font-family:monospace; font-weight:700;
          letter-spacing:2px; text-transform:uppercase; color:#2a2a50;
          display:flex; align-items:center; gap:8px; margin-bottom:10px;
        }
        .gmg-section-title::after { content:''; flex:1; height:1px; background:#0f0f22; }
        .gmg-accent-green::before { content:''; display:inline-block; width:2px; height:9px; border-radius:1px; background:#00e87a; margin-right:5px; }
        .gmg-accent-blue::before { content:''; display:inline-block; width:2px; height:9px; border-radius:1px; background:#00aaff; margin-right:5px; }
        .gmg-accent-purple::before { content:''; display:inline-block; width:2px; height:9px; border-radius:1px; background:#9966ff; margin-right:5px; }
        .gmg-accent-red::before { content:''; display:inline-block; width:2px; height:9px; border-radius:1px; background:#ff335c; margin-right:5px; }
        .gmg-accent-gold::before { content:''; display:inline-block; width:2px; height:9px; border-radius:1px; background:#ffc800; margin-right:5px; }
      `}</style>

      {/* ─── MAIN CONTENT ─────────────────────────────────────────────────── */}

      {/* PAGE 2: TARAYICILAR */}
      {activePage === 'tarayici' && (
        <ScannerPage
          scanResults={scanResults}
          masterResult={masterResult}
          scalpResult={scalpResult}
          missingBundle={masterResult?.missingBundle || null}
          loading={scanLoading}
          onRefresh={() => heatmapData.length && runIntelligenceScan(heatmapData)}
        />
      )}

      {/* PAGE 3: TÜREV & AKIŞ */}
      {activePage === 'turev' && (
        <div style={{ padding: '12px 14px', display: 'grid', gridTemplateColumns: 'repeat(3, minmax(0,1fr))', gap: 12 }}>
          <div className="gmg-panel gmg-panel-inner">
            <div className="gmg-section-title gmg-accent-blue">Likidasyon Haritası</div>
            <LiquidationMap symbol={selectedSymbol} />
          </div>
          <div className="gmg-panel gmg-panel-inner">
            <div className="gmg-section-title gmg-accent-purple">Likidite Radar</div>
            <LiquidityRadar orderbook={orderbook} priceHistory={priceHistory} symbol={selectedSymbol} />
          </div>
          <div className="gmg-panel gmg-panel-inner">
            <div className="gmg-section-title gmg-accent-gold">Funding Rates</div>
            <FundingPanel symbol={selectedSymbol} priceHistory={priceHistory} />
          </div>
          <div className="gmg-panel gmg-panel-inner" style={{ gridColumn: '1/3' }}>
            <div className="gmg-section-title gmg-accent-blue">Orderbook</div>
            <LiquidityWall orderbook={orderbook} symbol={selectedSymbol} />
          </div>
          <div className="gmg-panel gmg-panel-inner">
            <div className="gmg-section-title gmg-accent-green">Backtest</div>
            <BacktestPanelInline symbol={selectedSymbol} masterResult={masterResult} />
          </div>
          <div className="gmg-panel gmg-panel-inner" style={{ gridColumn: '1/-1' }}>
            <div className="gmg-section-title gmg-accent-purple">Multi-Market & Piyasalar</div>
            <MultiMarketPanel
              masterResult={masterResult}
              scanResults={scanResults}
              heatmapData={heatmapData}
              dxyLevel={macroData?.dxyLevel}
              us10yYield={macroData?.us10yYield}
            />
          </div>
        </div>
      )}
      {activePage === 'piyasalar' && (
        <div style={{ flex: 1, overflow: 'auto', background: '#03030e' }}>
          <MultiMarketDashboard masterResult={masterResult} />
        </div>
      )}

      {/* PAGE 1: GRAFİK & SİNYAL */}
      {activePage === 'grafik' && (
        <div style={{
          display: 'grid',
          gridTemplateColumns: '264px 1fr 272px',
          gap: 10,
          padding: '12px 14px',
          minHeight: 'calc(100vh - 140px)',
          alignItems: 'start',
        }}>

        {/* ── LEFT COLUMN ─────────────────────────────────────────────────── */}
        <motion.div
          initial={{ opacity: 0, x: -16 }} animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.4 }}
          style={{ display: 'flex', flexDirection: 'column', gap: 10 }}
        >
          <DecisionEngine symbol={selectedSymbol} confidenceData={confidenceData} tickerData={tickerData} />
          <TabSwitch tabs={LEFT_TABS} active={leftTab} onChange={setLeftTab} />

          {leftTab === 'signal' && (
            <>
              <SignalPanel confidenceData={confidenceData} tickerData={tickerData} priceHistory={priceHistory} />
              <WhaleAlert alerts={alerts} />
              <LiquidationMap symbol={selectedSymbol} />
            </>
          )}
          {leftTab === 'intel' && (
            <MarketIntelPanel
              scanResults={scanResults}
              masterResult={masterResult}
              loading={scanLoading}
              onRefresh={() => heatmapData.length && runIntelligenceScan(heatmapData)}
            />
          )}
          {leftTab === 'forex' && (
            <ForexPanel
              masterResult={masterResult}
              scanResults={scanResults}
              symbol={selectedSymbol}
              dxyLevel={macroData.dxyLevel}
              us10yYield={macroData.us10yYield}
            />
          )}
          {leftTab === 'accu' && (
            <AccumulationPlanPanel
              symbol={selectedSymbol}
              currentPrice={tickerData?.[0]?.price || 0}
              masterResult={masterResult}
            />
          )}
          {leftTab === 'dip' && (
            <DipOnayPanel dipData={dipData} loading={scanLoading} />
          )}
        </motion.div>

        {/* ── CENTER COLUMN ───────────────────────────────────────────────── */}
        <motion.div
          initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.08 }}
          style={{ display: 'flex', flexDirection: 'column', gap: 10 }}
        >
          {/* Chart area */}
          <div className="gmg-panel" style={{ position: 'relative', height: 440 }}>
            {/* Chart mode toggle */}
            <div style={{
              position: 'absolute', top: 10, right: 10, zIndex: 20,
              display: 'flex', gap: 1,
              background: '#08080f', border: '1px solid #13132a', borderRadius: 6, overflow: 'hidden',
            }}>
              {['custom', 'tradingview'].map(mode => (
                <button key={mode} onClick={() => setChartMode(mode)} style={{
                  padding: '4px 10px', fontSize: 9, fontFamily: 'monospace', fontWeight: 700,
                  letterSpacing: 1, textTransform: 'uppercase', cursor: 'pointer', border: 'none',
                  background: chartMode === mode ? 'rgba(0,170,255,0.12)' : 'transparent',
                  color: chartMode === mode ? '#00aaff' : '#2a2a50',
                  transition: 'all 0.15s',
                }}>
                  {mode === 'custom' ? 'CUSTOM' : 'TRADINGVIEW'}
                </button>
              ))}
            </div>
            {chartMode === 'custom'
              ? <GMGChart
                  symbol={selectedSymbol}
                  onCouncilUpdate={() => {}}
                  chartOverlay={masterResult?.chartOverlay || null}
                  councilResult={masterResult || null}
                  missingBundle={masterResult?.missingBundle || null}
                />
              : <TradingViewChart symbol={selectedSymbol} />
            }
          </div>

          {/* Heatmap */}
          <div className="gmg-panel gmg-panel-inner">
            <div className="gmg-section-title gmg-accent-green">Coin Heatmap</div>
            <HeatmapGrid data={heatmapData} onSelectSymbol={setSelectedSymbol} />
          </div>
        </motion.div>

        {/* ── RIGHT COLUMN ────────────────────────────────────────────────── */}
        <motion.div
          initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.4, delay: 0.16 }}
          style={{ display: 'flex', flexDirection: 'column', gap: 10 }}
        >
          <TabSwitch tabs={RIGHT_TABS} active={rightTab} onChange={setRightTab} />

          {rightTab === 'master' && (
            <>
              <LiveAICouncilPanel
                masterResult={masterResult}
                jsonOutputs={jsonOutputs}
                loading={masterLoading}
                symbol={selectedSymbol}
                onRefresh={() => heatmapData.length && runIntelligenceScan(heatmapData)}
              />
              <CouncilMemoryPanel />
            </>
          )}
          {rightTab === 'council' && <CouncilPanel councilResults={councilResults} />}
          {rightTab === 'orderbook' && (
            <div style={{ height: 680 }}>
              <LiquidityWall orderbook={orderbook} symbol={selectedSymbol} />
            </div>
          )}
          {rightTab === 'radar' && (
            <LiquidityRadar orderbook={orderbook} priceHistory={priceHistory} symbol={selectedSymbol} />
          )}
          {rightTab === 'multimarket' && (
            <MultiMarketPanel
              masterResult={masterResult}
              scanResults={scanResults}
              heatmapData={heatmapData}
              dxyLevel={macroData.dxyLevel}
              us10yYield={macroData.us10yYield}
            />
          )}
          {rightTab === 'backtest' && (
            <BacktestPanelInline symbol={selectedSymbol} masterResult={masterResult} />
          )}

          {rightTab === 'sysmonitor' && (
            <div className="gmg-panel gmg-panel-inner">
              <SystemMonitorPanel
                missingBundle={masterResult?.missingBundle || null}
                prices={(() => {
                  const ob = {};
                  if (tickerData?.length) tickerData.forEach(t => { if (t.exchange && t.price) ob[t.exchange] = t.price; });
                  return ob;
                })()}
                onMacroRisk={(rs) => { /* makro risk skoru alındı — ileride masterCouncil'e geçirilebilir */ }}
                onAPIKeysChange={(keys) => {
                  setApiKeys(keys);
                  try { localStorage.setItem('gmg_api_keys', JSON.stringify(keys)); } catch {}
                }}
              />
            </div>
          )}

          {/* ─── LIVE AI SORU KUTUSU ──────────────────────────────────────── */}
          <div className="gmg-panel gmg-panel-inner" style={{ marginTop: 2 }}>
            <div className="gmg-section-title gmg-accent-purple">Live AI</div>
            {autoSummary?.summary && (
              <div style={{
                fontSize: 9, color: '#3a3a68', fontFamily: 'monospace',
                lineHeight: 1.6, marginBottom: 8,
                padding: '6px 8px', background: '#09091a', borderRadius: 5,
                border: '1px solid #0f0f28',
              }}>
                {autoSummary.summary}
              </div>
            )}
            <div style={{ display: 'flex', gap: 6 }}>
              <input
                type="text"
                value={aiQuery}
                onChange={e => setAiQuery(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleAskAI()}
                placeholder={`${selectedSymbol} hakkında sor…`}
                style={{
                  flex: 1, background: '#08080f', border: '1px solid #16162a',
                  borderRadius: 6, padding: '6px 10px',
                  fontSize: 10, fontFamily: 'monospace', color: '#9090c0',
                  outline: 'none',
                }}
              />
              <button
                onClick={handleAskAI}
                disabled={aiLoading || !aiQuery.trim()}
                style={{
                  padding: '6px 12px', borderRadius: 6, cursor: 'pointer',
                  fontSize: 9, fontFamily: 'monospace', fontWeight: 700,
                  background: 'rgba(153,102,255,0.14)',
                  border: '1px solid rgba(153,102,255,0.35)',
                  color: '#9966ff',
                  opacity: (aiLoading || !aiQuery.trim()) ? 0.4 : 1,
                  transition: 'all 0.15s',
                }}
              >
                {aiLoading ? '…' : 'SOR'}
              </button>
            </div>
            {aiAnswer && (
              <div style={{
                marginTop: 7, padding: '8px 10px',
                background: '#0a0a1c', borderRadius: 6,
                border: '1px solid rgba(153,102,255,0.15)',
              }}>
                <p style={{ fontSize: 9, fontFamily: 'monospace', color: '#7070a0', lineHeight: 1.7, margin: 0 }}>
                  {aiAnswer.answer}
                </p>
                <span style={{ fontSize: 8, color: '#252545', fontFamily: 'monospace', display: 'block', marginTop: 4 }}>
                  {new Date(aiAnswer.timestamp).toLocaleTimeString('tr-TR')}
                </span>
              </div>
            )}
          </div>

        </motion.div>
      </div>
      {/* /PAGE 1 */}
      )}

    </div>
  </div>
  </div>
  );
}
