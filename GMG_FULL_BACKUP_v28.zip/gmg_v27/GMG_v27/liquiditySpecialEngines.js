/**
 * GMG — LİKİDİTE ÖZEL MOTORLAR
 * ==============================
 * darkPoolEngine.js + flashCrashDetector.js + otcFlowEngine.js
 * 235 modül kataloğunun eksik likidite modülleri
 */

const clamp = (v, lo = 0, hi = 100) => Math.max(lo, Math.min(hi, v || 50));

// ═══════════════════════════════════════════════════════════════════════════════
// 1. DARK POOL ENGINE — Karanlık Havuz Tespiti
// ═══════════════════════════════════════════════════════════════════════════════
/**
 * Dark pool işlemleri: büyük hacim + düşük fiyat etkisi = gizli birikim/dağıtım
 * Gerçek dark pool verisi kurumsal API gerektirir.
 * Burada proxy yaklaşım: orderbook derinliği + hacim anomalisi + fiyat direnç analizi
 */
export function runDarkPoolEngine({
  candles = [],
  orderbook = null,
  volumeSpike = 1.0,
  priceImpact = 0,    // büyük hacimde fiyat değişim %
  currentPrice = 0,
}) {
  if (!candles.length) return { score: 50, detected: false, type: null, summary: 'Veri yetersiz' };

  const n       = candles.length - 1;
  const closes  = candles.map(c => c.c);
  const volumes = candles.map(c => c.v || 0);

  // Son 20 mumun ortalama hacmi
  const recentVols = volumes.slice(-20);
  const avgVol     = recentVols.reduce((a, b) => a + b, 0) / recentVols.length || 1;
  const lastVol    = volumes[n] || 0;
  const volRatio   = lastVol / avgVol;

  // Fiyat etkisi — yüksek hacim düşük fiyat hareketi = dark pool
  const priceChange = candles.length >= 2
    ? Math.abs((closes[n] - closes[n-1]) / closes[n-1] * 100)
    : 0;
  const darkPoolSignal = volRatio > 2.0 && priceChange < 0.3; // Yüksek hacim + düşük fiyat etkisi

  // Orderbook duvarı analizi — büyük gizli emirler
  let hiddenWall = false;
  if (orderbook?.bids?.length) {
    const topBid   = orderbook.bids[0];
    const totalBid = orderbook.bids.slice(0, 5).reduce((s, b) => s + b.amount * b.price, 0);
    if (totalBid > avgVol * currentPrice * 3) hiddenWall = true;
  }

  // Accumulation/Distribution tahmini
  const recentCloses = closes.slice(-10);
  const trend = recentCloses[recentCloses.length - 1] > recentCloses[0] ? 'UP' : 'DOWN';
  const type  = darkPoolSignal
    ? (trend === 'UP' ? 'GIZLI_BIRIKIM' : 'GIZLI_DAGITIM')
    : null;

  let score = 50;
  if (darkPoolSignal && type === 'GIZLI_BIRIKIM') score += 18;
  if (darkPoolSignal && type === 'GIZLI_DAGITIM') score -= 15;
  if (hiddenWall) score += 8;

  return {
    score:         Math.round(clamp(score)),
    detected:      darkPoolSignal,
    type,
    volRatio:      parseFloat(volRatio.toFixed(2)),
    priceImpact:   parseFloat(priceChange.toFixed(3)),
    hiddenWall,
    confidence:    darkPoolSignal ? Math.min(85, Math.round(volRatio * 20)) : 0,
    signal:        type === 'GIZLI_BIRIKIM'
      ? `🕵 Gizli birikim: ${volRatio.toFixed(1)}x hacim, %${priceChange.toFixed(2)} fiyat etkisi`
      : type === 'GIZLI_DAGITIM'
      ? `⚠ Gizli dağıtım tespit: yüksek hacim satış`
      : null,
    summary:       darkPoolSignal
      ? `Dark Pool ${type}: Hacim ${volRatio.toFixed(1)}x, Fiyat etkisi %${priceChange.toFixed(2)}`
      : 'Normal piyasa akışı',
    timestamp: Date.now(),
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// 2. FLASH CRASH DETECTOR — Ani Çöküş Tespiti
// ═══════════════════════════════════════════════════════════════════════════════
/**
 * Flash crash: çok kısa sürede %2+ ani düşüş + hızlı toparlanma
 * veya ani sert düşüş + yüksek likidite tüketimi
 */
export function runFlashCrashDetector({
  candles   = [],
  trades    = [],       // son işlemler [{price, amount, time}]
  threshold = 2.0,      // % ani düşüş eşiği
  timeWindow = 5,       // mum sayısı
}) {
  if (candles.length < timeWindow + 2) {
    return { detected: false, score: 50, severity: 'NONE', summary: 'Yetersiz veri' };
  }

  const n      = candles.length - 1;
  const recent = candles.slice(-timeWindow);
  const prices = recent.map(c => c.c);
  const high   = Math.max(...recent.map(c => c.h || c.c));
  const low    = Math.min(...recent.map(c => c.l || c.c));
  const cur    = prices[prices.length - 1];

  // Son N mum içinde maksimum düşüş
  const maxDrop   = high > 0 ? ((high - low) / high * 100) : 0;
  const dropFast  = maxDrop >= threshold;

  // Toparlanma kontrolü — flash crash sonrası hızlı dönüş
  const recovered = dropFast && cur > (high + low) / 2;

  // Wick analizi — alt wick uzunsa flash crash
  const lastCandle = candles[n];
  const wickLen    = lastCandle
    ? ((lastCandle.c - (lastCandle.l || lastCandle.c)) / (lastCandle.c || 1) * 100)
    : 0;
  const longLowerWick = wickLen > 1.5;

  // Likidite tüketimi — trade verisi varsa
  let liquidityConsumed = false;
  if (trades.length > 5) {
    const sellVol = trades.filter(t => t.side === 'sell').reduce((s, t) => s + t.amount, 0);
    const buyVol  = trades.filter(t => t.side === 'buy').reduce((s, t)  => s + t.amount, 0);
    liquidityConsumed = sellVol > buyVol * 3;
  }

  const severity =
    maxDrop >= 5  ? 'KRİTİK' :
    maxDrop >= 3  ? 'YÜKSEK' :
    maxDrop >= threshold ? 'ORTA' : 'NONE';

  const detected = dropFast || (longLowerWick && maxDrop >= 1);

  let score = 50;
  if (detected)          score -= maxDrop * 5;
  if (recovered)         score += 10; // Toparlanma = fırsat
  if (liquidityConsumed) score -= 10;

  return {
    detected,
    severity,
    score:    Math.round(clamp(score)),
    maxDrop:  parseFloat(maxDrop.toFixed(2)),
    recovered,
    longLowerWick,
    liquidityConsumed,
    signal:   detected
      ? `⚡ FLASH CRASH: %${maxDrop.toFixed(2)} düşüş${recovered ? ' (toparlanıyor)' : ''}`
      : null,
    warning:  severity === 'KRİTİK' ? '🚨 KRİTİK ÇÖKÜŞ — İşlem yapma' :
              severity === 'YÜKSEK' ? '⚠ Yüksek volatilite — dikkat' : null,
    summary:  detected
      ? `Flash Crash ${severity}: %${maxDrop.toFixed(2)}, ${recovered ? 'toparlandı' : 'toparlanmıyor'}`
      : 'Normal piyasa hareketi',
    timestamp: Date.now(),
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// 3. OTC FLOW ENGINE — Tezgah Üstü İşlem Akışı
// ═══════════════════════════════════════════════════════════════════════════════
/**
 * OTC (Over-the-Counter) işlemler: büyük kurumsal blok satışları/alışları
 * Gerçek OTC verisi Chainalysis/Glassnode gerektirir.
 * Burada proxy: büyük transfer + borsa dışı fiyat farklılığı
 */
export function runOTCFlowEngine({
  exchangeInflow24h  = 0,  // borsaya giren BTC miktarı
  exchangeOutflow24h = 0,  // borsadan çıkan BTC miktarı
  largeTransfers     = [], // büyük transferler [{amount, type:'in'|'out'}]
  premiumDiscount    = 0,  // spot fiyat vs OTC fiyat farkı %
  currentPrice       = 0,
}) {
  // Net borsa akışı
  const netExchangeFlow  = exchangeOutflow24h - exchangeInflow24h;
  const isAccumulating   = netExchangeFlow > 0; // Net çıkış = birikim
  const isDistributing   = netExchangeFlow < 0 && Math.abs(netExchangeFlow) > exchangeInflow24h * 0.3;

  // Büyük OTC transferleri
  const bigOTCIn  = largeTransfers.filter(t => t.type === 'in'  && t.amount > 1000).length;
  const bigOTCOut = largeTransfers.filter(t => t.type === 'out' && t.amount > 1000).length;

  // OTC premium/discount
  const otcPremium    = premiumDiscount > 0.5;  // OTC fiyat > spot = güçlü talep
  const otcDiscount   = premiumDiscount < -0.5; // OTC fiyat < spot = güçlü arz

  let score = 50;
  if (isAccumulating)       score += 15;
  if (isDistributing)       score -= 12;
  if (bigOTCIn > bigOTCOut) score += 8;
  if (bigOTCOut > bigOTCIn) score -= 8;
  if (otcPremium)           score += 10;
  if (otcDiscount)          score -= 10;

  return {
    score:           Math.round(clamp(score)),
    netExchangeFlow,
    isAccumulating,
    isDistributing,
    bigOTCIn,
    bigOTCOut,
    otcPremium,
    otcDiscount,
    premiumDiscount,
    signal: isAccumulating && bigOTCIn > 0
      ? `🏛 OTC Birikim: ${bigOTCIn} büyük giriş, net ${(netExchangeFlow/1000).toFixed(1)}K BTC çıkış`
      : isDistributing
      ? `⚠ OTC Dağıtım: Net ${Math.abs(netExchangeFlow/1000).toFixed(1)}K BTC borsa girişi`
      : 'Normal OTC akışı',
    summary: `OTC: ${isAccumulating ? 'Birikim' : isDistributing ? 'Dağıtım' : 'Nötr'} | Premium: ${premiumDiscount >= 0 ? '+' : ''}${premiumDiscount.toFixed(2)}%`,
    timestamp: Date.now(),
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// 4. TOPLU ÇALIŞTIRICI
// ═══════════════════════════════════════════════════════════════════════════════
export async function runLiquiditySpecialEngines({
  candles      = [],
  orderbook    = null,
  trades       = [],
  currentPrice = 0,
  exchangeFlows = {},
  largeTransfers = [],
  glassnodeKey = '',
  cqApiKey     = '',
}) {
  // API anahtarı varsa gerçek Glassnode/CryptoQuant verisiyle zenginleştir
  let darkPool, otcFlow;

  if (glassnodeKey) {
    try {
      darkPool = await runDarkPoolEngineWithGlassnode(
        { candles, orderbook, currentPrice }, glassnodeKey
      );
    } catch { darkPool = runDarkPoolEngine({ candles, orderbook, currentPrice }); }
  } else {
    darkPool = runDarkPoolEngine({ candles, orderbook, currentPrice });
  }

  if (cqApiKey) {
    try {
      otcFlow = await runOTCFlowEngineWithAPI(
        { exchangeInflow24h: exchangeFlows.inflow || 0, exchangeOutflow24h: exchangeFlows.outflow || 0, largeTransfers, currentPrice },
        cqApiKey
      );
    } catch {
      otcFlow = runOTCFlowEngine({ exchangeInflow24h: exchangeFlows.inflow || 0, exchangeOutflow24h: exchangeFlows.outflow || 0, largeTransfers, currentPrice });
    }
  } else {
    otcFlow = runOTCFlowEngine({
      exchangeInflow24h:  exchangeFlows.inflow  || 0,
      exchangeOutflow24h: exchangeFlows.outflow || 0,
      largeTransfers,
      currentPrice,
    });
  }

  const flashCrash = runFlashCrashDetector({ candles, trades });

  const score = Math.round(
    darkPool.score  * 0.35 +
    (100 - flashCrash.score) * 0.35 + // flash crash → reverse (düşük flash = iyi)
    otcFlow.score   * 0.30
  );

  const alerts = [
    darkPool.signal,
    flashCrash.signal,
    otcFlow.signal,
  ].filter(Boolean);

  return {
    score:     Math.round(clamp(score)),
    darkPool,
    flashCrash,
    otcFlow,
    alerts,
    critical:  flashCrash.severity === 'KRİTİK' || flashCrash.severity === 'YÜKSEK',
    summary:   `DarkPool:${darkPool.detected?'✓':'—'} FlashCrash:${flashCrash.severity} OTC:${otcFlow.isAccumulating?'BİRİKİM':otcFlow.isDistributing?'DAĞITIM':'NÖTR'}`,
    timestamp: Date.now(),
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// GLASSNODE API ENTEGRASYONU — ücretsiz tier
// ═══════════════════════════════════════════════════════════════════════════════
const _glassCache = new Map();
const GLASS_TTL   = 10 * 60 * 1000; // 10dk cache

/**
 * Glassnode ücretsiz tier metrikleri çeker.
 * API key: https://studio.glassnode.com/settings/api (ücretsiz kayıt)
 * Ücretsiz metrikler: exchange_net_position_change, active_addresses, transaction_count
 */
export async function fetchGlassnodeMetric(metric, asset = 'BTC', apiKey = '') {
  const key    = `${metric}_${asset}`;
  const cached = _glassCache.get(key);
  if (cached && Date.now() - cached.ts < GLASS_TTL) return cached.data;

  if (!apiKey) {
    // API key yoksa simüle et
    return _simulateGlassnode(metric);
  }

  try {
    const url  = `https://api.glassnode.com/v1/metrics/${metric}?a=${asset}&api_key=${apiKey}&i=24h&f=JSON`;
    const res  = await fetch(url, { signal: AbortSignal.timeout(8000) });
    if (!res.ok) throw new Error(`Glassnode HTTP ${res.status}`);
    const data = await res.json();
    // Son değeri al
    const last = Array.isArray(data) ? data[data.length - 1]?.v : data?.v;
    const result = { value: last, metric, asset, ts: Date.now(), live: true };
    _glassCache.set(key, { data: result, ts: Date.now() });
    return result;
  } catch(e) {
    console.warn(`[Glassnode] ${metric} hata:`, e.message);
    return _simulateGlassnode(metric);
  }
}

function _simulateGlassnode(metric) {
  const simulations = {
    'transactions/transfers_volume_to_exchanges_sum': { value: Math.random() * 500 + 100, live: false },
    'transactions/transfers_volume_from_exchanges_sum': { value: Math.random() * 400 + 80, live: false },
    'addresses/active_count': { value: Math.floor(Math.random() * 100000 + 800000), live: false },
    'market/price_usd_close': { value: 0, live: false },
  };
  return simulations[metric] || { value: 0, live: false };
}

/**
 * runDarkPoolEngineWithGlassnode — Glassnode verisi ile güçlendirilmiş DarkPool analizi
 */
export async function runDarkPoolEngineWithGlassnode(params = {}, glassnodeApiKey = '') {
  // Temel dark pool skoru (mevcut engine)
  const base = runDarkPoolEngine(params);

  // Glassnode exchange inflow/outflow — gerçek veri
  const [inflow, outflow, activeAddr] = await Promise.all([
    fetchGlassnodeMetric('transactions/transfers_volume_to_exchanges_sum',   'BTC', glassnodeApiKey),
    fetchGlassnodeMetric('transactions/transfers_volume_from_exchanges_sum',  'BTC', glassnodeApiKey),
    fetchGlassnodeMetric('addresses/active_count', 'BTC', glassnodeApiKey),
  ]);

  // Net flow: pozitif = borsaya giriş (satış baskısı), negatif = çıkış (birikim)
  const netFlow       = (inflow?.value || 0) - (outflow?.value || 0);
  const isAccumulating = netFlow < -50; // $50M+ çıkış = birikim
  const isDistributing = netFlow > 100;  // $100M+ giriş = dağıtım

  let adjustedScore = base.score;
  if (isAccumulating) adjustedScore += 12;
  if (isDistributing) adjustedScore -= 12;

  const clamp = (v, lo=0, hi=100) => Math.max(lo, Math.min(hi, v));

  return {
    ...base,
    score:        Math.round(clamp(adjustedScore)),
    glassnode: {
      exchangeInflow:    parseFloat((inflow?.value  || 0).toFixed(2)),
      exchangeOutflow:   parseFloat((outflow?.value || 0).toFixed(2)),
      netFlow:           parseFloat(netFlow.toFixed(2)),
      activeAddresses:   Math.round(activeAddr?.value || 0),
      isAccumulating,
      isDistributing,
      liveData:          inflow?.live || false,
    },
    enhanced:   true,
    summary:    `${base.summary} | Glassnode Net:${netFlow > 0 ? '+' : ''}${netFlow.toFixed(0)}M${isAccumulating ? ' 🟢BİRİKİM' : isDistributing ? ' 🔴DAĞITIM' : ''}`,
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// CRYPTOQUANT — OTC Flow gerçek veri
// ═══════════════════════════════════════════════════════════════════════════════
const _cqCache = new Map();
const CQ_TTL   = 10 * 60 * 1000;

export async function fetchCryptoQuantFlow(metric = 'inflow', exchange = 'all', apiKey = '') {
  const key    = `cq_${metric}_${exchange}`;
  const cached = _cqCache.get(key);
  if (cached && Date.now() - cached.ts < CQ_TTL) return cached.data;

  if (!apiKey) {
    return { value: Math.random() * 1000 + 100, live: false, metric };
  }

  try {
    const url  = `https://api.cryptoquant.com/v1/btc/exchange-flows/${metric}?exchange=${exchange}&window=day`;
    const res  = await fetch(url, {
      headers: { 'Authorization': `Bearer ${apiKey}` },
      signal:  AbortSignal.timeout(8000),
    });
    if (!res.ok) throw new Error(`CryptoQuant HTTP ${res.status}`);
    const data = await res.json();
    const last = data?.result?.data?.slice(-1)[0]?.value || 0;
    const result = { value: last, live: true, metric };
    _cqCache.set(key, { data: result, ts: Date.now() });
    return result;
  } catch(e) {
    console.warn(`[CryptoQuant] ${metric} hata:`, e.message);
    return { value: Math.random() * 800 + 50, live: false, metric };
  }
}

export async function runOTCFlowEngineWithAPI(params = {}, cqApiKey = '') {
  const base = runOTCFlowEngine(params);

  // CryptoQuant'tan gerçek inflow/outflow
  const [inflowData, outflowData] = await Promise.all([
    fetchCryptoQuantFlow('inflow',  'all', cqApiKey),
    fetchCryptoQuantFlow('outflow', 'all', cqApiKey),
  ]);

  const netFlow = (outflowData?.value || 0) - (inflowData?.value || 0);
  const clamp   = (v, lo=0, hi=100) => Math.max(lo, Math.min(hi, v));

  let adjustedScore = base.score;
  if (netFlow > 200) adjustedScore += 15;  // Büyük çıkış = birikim
  if (netFlow < -200) adjustedScore -= 12; // Büyük giriş = satış baskısı

  return {
    ...base,
    score:      Math.round(clamp(adjustedScore)),
    cryptoquant: {
      inflow:    parseFloat((inflowData?.value  || 0).toFixed(2)),
      outflow:   parseFloat((outflowData?.value || 0).toFixed(2)),
      netFlow:   parseFloat(netFlow.toFixed(2)),
      liveData:  inflowData?.live || false,
    },
    enhanced:  true,
  };
}
